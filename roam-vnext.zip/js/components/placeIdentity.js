/**
 * ROAM Place Identity Component (V2)
 * Concise Cultural DNA + Real Photography Accent + Concept Explanations
 */

import { LOCATION_THEMES } from '../data/themes/locationThemes.js';
import { renderTooltip } from '../utils/formatters.js';

export class PlaceIdentityController {
  constructor(mountId) {
    this.mount = document.getElementById(mountId);
  }

  render(locationData) {
    if (!this.mount || !locationData) return;

    const theme = LOCATION_THEMES[locationData.id] || LOCATION_THEMES.default;
    const isPartial = locationData.intelligenceTier === 'PARTIAL';

    const dna = locationData.culturalDNA || {
      knownFor: ['Regional Cultural Heritage', 'Grassroots Craftsmanship', 'Ancient Community Centers'],
      taste: ['Traditional Regional Delicacies', 'Locally Harvested Spices'],
      landscape: ['Historic Geography', 'Subtropical / Semi-arid terrain'],
      festivals: ['Annual Cultural Fairs', 'Regional Community Celebrations']
    };

    this.mount.innerHTML = `
      <div class="place-identity-panel">
        <div class="place-identity-header">
          <div class="place-title-wrap">
            <span class="place-region-badge">
              ${locationData.state || 'India'} • ${locationData.culturalRegion || locationData.region || 'Heritage Corridor'}
            </span>
            <div class="place-name">
              <span>${locationData.name}</span>
              ${isPartial 
                ? '<span class="badge badge-elevated">PARTIAL LOCATION INTELLIGENCE' + renderTooltip('capacity') + '</span>'
                : '<span class="badge badge-optimal">FULL INTELLIGENCE ACTIVE' + renderTooltip('demand') + '</span>'
              }
            </div>
            <div class="place-atmosphere-tag">${locationData.tagline || theme.atmosphere}</div>
          </div>

          <!-- Real Destination Photography Accent Card -->
          <div class="place-photo-chip">
            <img src="${theme.photoUrl}" alt="${theme.name}" class="place-photo-thumb" loading="lazy" />
            <div class="place-photo-meta">
              <span class="place-photo-caption">${theme.photoCaption || locationData.name}</span>
              <span class="place-photo-credit">${theme.photoCredit || 'Verified Destination Photo'}</span>
            </div>
          </div>
        </div>

        <!-- Cultural DNA Grid -->
        <div class="cultural-dna-grid">
          <!-- 1. Known For -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🏛️</span> KNOWN FOR
            </div>
            <ul class="dna-list">
              ${(dna.knownFor || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>

          <!-- 2. Taste -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🍲</span> TASTE
            </div>
            <ul class="dna-list">
              ${(dna.taste || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>

          <!-- 3. Landscape -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🌄</span> LANDSCAPE
            </div>
            <ul class="dna-list">
              ${(dna.landscape || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>

          <!-- 4. Festivals -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🪔</span> FESTIVALS
            </div>
            <ul class="dna-list">
              ${(dna.festivals || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>
        </div>
      </div>
    `;
  }
}
