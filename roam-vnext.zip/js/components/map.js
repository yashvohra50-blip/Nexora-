/**
 * ROAM Destination Load Map Component (V3)
 * Spatial intelligence visualization with node interactivity:
 * - Floating intelligence card on node hover (seamless, flicker-free)
 * - Interactive intelligence drawer on node click
 * - Working Google Maps links and Add to Plan
 * - Integrated with travelState
 */

import { travelState } from '../state/travelState.js';
import { formatCrowdLevel, formatVisitorCount, formatWaitTime } from '../utils/formatters.js';

export class DestinationLoadMap {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.onNodeClick = options.onNodeClick || (() => {});
    this.locationData = null;
    this.attractions = [];
    this.selectedNodeId = null;
    this.filter = 'all';

    // Subscribe to travelState changes
    travelState.subscribe((event) => {
      if (event === 'focus:changed') {
        const focused = travelState.getFocusedItem();
        if (focused && this.selectedNodeId !== focused.id) {
          const match = this.attractions.find(a => a.id === focused.id || a.name.toLowerCase() === focused.name.toLowerCase());
          if (match) {
            this.selectedNodeId = match.id;
            this.render();
          }
        }
      }
    });
  }

  setDestination(locationData) {
    this.locationData = locationData;
    this.attractions = (locationData && locationData.attractions) ? locationData.attractions : [];
    this.selectedNodeId = this.attractions[0] ? this.attractions[0].id : null;
    this.filter = 'all';
    this.render();
  }

  setFilter(filterType) {
    this.filter = filterType;
    this.render();
  }

  selectNode(id) {
    this.selectedNodeId = id;
    this.render();
  }

  render() {
    if (!this.container) return;

    if (!this.locationData || this.locationData.intelligenceTier === 'PARTIAL') {
      this.renderPartialMap();
      return;
    }

    let filtered = this.attractions;
    if (this.filter === 'critical') {
      filtered = this.attractions.filter(a => a.status === 'critical');
    } else if (this.filter === 'optimal') {
      filtered = this.attractions.filter(a => a.status === 'optimal');
    }

    const selectedAttraction = this.attractions.find(a => a.id === this.selectedNodeId) || this.attractions[0];

    const svgHtml = `
      <svg class="map-svg" viewBox="0 0 800 650" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Live Destination Load Map">
        <defs>
          <radialGradient id="mapGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="var(--roam-accent)" stop-opacity="0.16" />
            <stop offset="100%" stop-color="var(--roam-accent)" stop-opacity="0" />
          </radialGradient>
          <pattern id="gridPattern" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.03)" stroke-width="1" />
          </pattern>
        </defs>

        <!-- Ambient Background Glow & Radar Grid -->
        <rect width="800" height="650" fill="url(#gridPattern)" />
        <circle cx="400" cy="325" r="320" fill="url(#mapGlow)" />

        <!-- Visitor Flow Reroute Lines -->
        <g class="map-routes">
          <line x1="550" y1="110" x2="480" y2="550" class="flow-route-line route-reroute active" stroke-dasharray="6,6" />
          <line x1="510" y1="390" x2="440" y2="310" class="flow-route-line route-reroute active" stroke-dasharray="6,6" />
        </g>

        <!-- Nodes -->
        <g class="map-nodes-layer">
          ${filtered.map(att => {
            const isSelected = att.id === this.selectedNodeId;
            const isCritical = att.status === 'critical';
            const isOptimal = att.status === 'optimal';
            const color = isCritical ? 'var(--load-critical)' : (isOptimal ? 'var(--load-optimal)' : 'var(--load-elevated)');
            const radius = isCritical ? 24 : (isOptimal ? 16 : 20);
            const nodeVisitors = att.currentVisitors >= 1000 ? `${(att.currentVisitors / 1000).toFixed(1).replace(/\.0$/, '')}k` : `${Math.round(att.currentVisitors || 0)}`;

            return `
              <g class="map-node ${isSelected ? 'selected' : ''}" data-id="${att.id}" tabindex="0" role="button" aria-label="${att.name}: ${formatVisitorCount(att.currentVisitors)} visitors, ${formatCrowdLevel(att.loadPercentage).status}" transform="translate(${att.coords.x}, ${att.coords.y})">
                <!-- Outer Pulse Rings -->
                <circle cx="0" cy="0" r="${radius + 10}" fill="${color}" opacity="0.18" class="${isCritical ? 'pulse-ring' : ''}" />
                <circle cx="0" cy="0" r="${radius + 4}" fill="${color}" opacity="0.3" />

                <!-- Core Node -->
                <circle cx="0" cy="0" r="${radius}" fill="rgba(12, 18, 30, 0.95)" stroke="${color}" stroke-width="${isSelected ? '3.5' : '2'}" />

                <!-- Load Label Inside Node -->
                <text y="4" text-anchor="middle" fill="#fff" font-size="11" font-weight="800" font-family="var(--font-mono)">
                  ${nodeVisitors}
                </text>

                <!-- Label Badge -->
                <g transform="translate(0, ${radius + 16})">
                  <rect x="-68" y="-12" width="136" height="24" rx="4" fill="rgba(12, 18, 30, 0.92)" stroke="${color}" stroke-width="${isSelected ? '2' : '1'}" />
                  <text y="3" text-anchor="middle" fill="#f8fafc" font-size="10.5" font-weight="700" font-family="var(--font-sans)">
                    ${att.name.length > 17 ? att.name.substring(0, 16) + '…' : att.name}
                  </text>
                </g>
              </g>
            `;
          }).join('')}
        </g>
      </svg>
      <!-- Floating Intelligence Card for Node Hover -->
      <div class="map-hover-floating-card" id="map-hover-card" style="display:none;"></div>
    `;

    this.container.innerHTML = svgHtml;
    this.renderInteractiveDrawer(selectedAttraction);
    this.attachNodeEvents();
  }

  renderInteractiveDrawer(attraction) {
    if (!attraction) return;
    let drawerMount = document.getElementById('map-intel-drawer-mount');
    if (!drawerMount) return;

    const crowd = formatCrowdLevel(attraction.loadPercentage);
    const visitors = formatVisitorCount(attraction.currentVisitors);
    const wait = formatWaitTime(attraction.currentWaitMinutes || 0);
    const city = this.locationData?.name || 'Jaipur';
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(attraction.name + ', ' + city)}`;

    const optimalAlt = this.attractions.find(a => a.status === 'optimal') || this.attractions[1];

    drawerMount.innerHTML = `
      <div class="map-intel-drawer" id="map-intelligence-drawer">
        <div class="drawer-header">
          <div>
            <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted); font-weight:700;">
              SELECTED DESTINATION
            </div>
            <div class="drawer-site-name" id="map-intel-name">${attraction.name}</div>
          </div>
          <span class="badge ${crowd.badgeClass}" id="map-intel-crowd">${crowd.status}</span>
        </div>

        <div style="display:flex; gap:18px; font-size:0.85rem; margin:8px 0; flex-wrap:wrap; color:var(--text-secondary);">
          <div><strong>Visitors now:</strong> <span style="color:#fff;">${visitors}</span></div>
          <div><strong>Expected Wait:</strong> <span style="color:${attraction.status === 'critical' ? '#ef4444' : 'var(--load-optimal)'};">${wait}</span></div>
          <div><strong>Entry:</strong> <span style="color:var(--brand-cyan);">${attraction.entryFeeINR === 0 ? 'Free' : '₹' + attraction.entryFeeINR}</span></div>
        </div>

        <!-- Working Google Maps & Add to Plan Links (Requirement 15, 17) -->
        <div style="display:flex; align-items:center; justify-content:space-between; margin-top:8px; padding-top:8px; border-top:1px solid var(--border-subtle); flex-wrap:wrap; gap:8px;">
          <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="drawer-maps-link">
            OPEN IN MAPS ↗
          </a>

          <div style="display:flex; gap:8px;">
            <button class="btn btn-sm btn-secondary" id="drawer-view-crowd-btn" data-id="${attraction.id}">
              VIEW CROWD FORECAST 📊
            </button>
            <button class="btn btn-sm btn-primary drawer-add-btn" id="drawer-add-plan-btn" data-id="${attraction.id}">
              + ADD TO PLAN
            </button>
          </div>
        </div>

        ${attraction.status === 'critical' && optimalAlt ? `
          <!-- Immediate ROAM Suggestion -->
          <div class="drawer-suggests-box" style="margin-top:10px;">
            <div class="drawer-suggests-label">⚡ ROAM RECOMMENDS INSTEAD</div>
            <div class="drawer-suggests-title" id="map-intel-alt-name">${optimalAlt.name}</div>
            <div class="drawer-suggests-reason">
              Save ${Math.max(0, (attraction.currentWaitMinutes || 50) - (optimalAlt.currentWaitMinutes || 0))} minutes of waiting • Only ${formatVisitorCount(optimalAlt.currentVisitors)} • ${optimalAlt.description || 'Comfortable, quiet heritage experience'}
            </div>
            <button class="drawer-action-btn" id="drawer-select-alt-btn" data-id="${optimalAlt.id}">
              <span>SHOW ALTERNATIVE ROUTE ➔</span>
            </button>
          </div>
        ` : ''}
      </div>
    `;

    const altBtn = document.getElementById('drawer-select-alt-btn');
    if (altBtn) {
      altBtn.onclick = (e) => {
        const id = e.currentTarget.dataset.id;
        this.selectNode(id);
        const recStack = document.getElementById('recommendations-stack');
        if (recStack) recStack.scrollIntoView({ behavior: 'smooth', block: 'center' });
      };
    }

    const viewCrowdBtn = document.getElementById('drawer-view-crowd-btn');
    if (viewCrowdBtn) {
      viewCrowdBtn.onclick = () => {
        this.focusMatchingItineraryItem(attraction);
        if (window.ROAM) {
          window.ROAM.switchMode('plan');
        }
      };
    }

    const addBtn = document.getElementById('drawer-add-plan-btn');
    if (addBtn) {
      addBtn.onclick = () => {
        const res = travelState.addPlaceIntelligently({
          name: attraction.name,
          category: attraction.category || 'heritage',
          durationMinutes: attraction.averageVisitMinutes || 90,
          status: attraction.status,
          visitors: attraction.currentVisitors,
          coords: attraction.coords
        });
        if (window.ROAM?.modalController) {
          window.ROAM.modalController.showToast(`Added ${attraction.name} at ${res.time} (${res.reason})`);
        }
        if (window.ROAM) {
          window.ROAM.switchMode('plan');
        }
      };
    }
  }

  renderPartialMap() {
    const loc = this.locationData;
    this.container.innerHTML = `
      <div style="height:100%; min-height:480px; display:flex; flex-direction:column; align-items:center; justify-content:center; padding:var(--space-xl); text-align:center; background:radial-gradient(circle at center, rgba(245, 158, 11, 0.06) 0%, transparent 70%);">
        <span style="font-size:2.8rem; margin-bottom:12px;">🧭</span>
        <span class="partial-badge">REGIONAL CLUSTER MAPPING ACTIVE</span>
        <h3 style="font-size:1.6rem; font-weight:800; color:#fff; margin-bottom:6px;">${loc.name} Demand Telemetry</h3>
        <p style="color:var(--text-secondary); max-width:560px; font-size:0.9rem; line-height:1.5; margin-bottom:16px;">
          Sensor array and grassroots merchant onboarding are underway in the ${loc.district || loc.state} corridor. Live crowd redistribution will link directly to nearby regional hub: <strong style="color:var(--roam-accent)">${loc.nearbyHub || 'Jaipur'}</strong>.
        </p>
      </div>
    `;
    const drawerMount = document.getElementById('map-intel-drawer-mount');
    if (drawerMount) drawerMount.innerHTML = '';
  }

  // --- Node Events: temporary hover preview + persistent click ---
  attachNodeEvents() {
    const nodes = this.container.querySelectorAll('.map-node');
    const hoverCard = this.container.querySelector('#map-hover-card');

    nodes.forEach(node => {
      const id = node.dataset.id;
      const attraction = this.attractions.find(a => a.id === id);
      if (!attraction) return;

      const show = () => {
        if (!hoverCard) return;
        this.updateHoverCard(hoverCard, attraction, node);
        node.classList.add('hovered');
      };
      const hide = () => {
        if (hoverCard) hoverCard.style.display = 'none';
        node.classList.remove('hovered');
      };

      node.addEventListener('pointerenter', show);
      node.addEventListener('pointerleave', hide);
      node.addEventListener('focus', show);
      node.addEventListener('blur', hide);
      node.addEventListener('click', () => {
        hide();
        this.selectedNodeId = id;
        this.render();
        this.focusMatchingItineraryItem(attraction);
        if (this.onNodeClick) this.onNodeClick(attraction);
      });
      node.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          node.click();
        }
      });
    });

    const svg = this.container.querySelector('.map-svg');
    if (svg && hoverCard) {
      svg.addEventListener('pointerleave', () => {
        hoverCard.style.display = 'none';
      });
    }
  }

  focusMatchingItineraryItem(attraction) {
    const match = travelState.itinerary.find(item =>
      item.id === attraction.id || item.name.toLowerCase() === attraction.name.toLowerCase()
    );
    if (match) travelState.setFocusedItem(match.id);
  }

  updateHoverCard(card, attraction, node) {
    const crowd = formatCrowdLevel(attraction.loadPercentage);
    const visitors = formatVisitorCount(attraction.currentVisitors);
    const wait = formatWaitTime(attraction.currentWaitMinutes || 0);
    const entry = attraction.entryFeeINR === 0 ? 'Free Entry' : '₹' + attraction.entryFeeINR;

    card.innerHTML = `
      <div class="hover-card-top">
        <div>
          <div class="hover-card-title">${attraction.name}</div>
          <div class="hover-card-category">${attraction.category || 'PLACE'} · ${this.locationData?.name || 'India'}</div>
        </div>
        <span class="badge ${crowd.badgeClass}">${crowd.status}</span>
      </div>
      <div class="hover-card-metrics">
        <div class="hover-card-row"><span>People expected</span><span class="hover-card-val">${visitors}</span></div>
        <div class="hover-card-row"><span>Typical wait</span><span class="hover-card-val" style="color:${attraction.status === 'critical' ? '#ef4444' : 'var(--load-optimal)'};">${wait}</span></div>
        <div class="hover-card-row"><span>Best window</span><span class="hover-card-val">${attraction.bestTime || 'Off-peak hours'}</span></div>
        <div class="hover-card-row"><span>Entry</span><span class="hover-card-val">${entry}</span></div>
      </div>
    `;

    this.positionHoverCard(card, node);
    card.style.display = 'block';
  }

  positionHoverCard(card, node) {
    const containerRect = this.container.getBoundingClientRect();
    const nodeRect = node.getBoundingClientRect();
    
    // Position above the node
    let left = (nodeRect.left + nodeRect.width / 2) - containerRect.left;
    let top = nodeRect.top - containerRect.top - 8;

    // Safety bounds within container
    const cardWidth = card.offsetWidth || 190;
    if (left - cardWidth / 2 < 8) left = cardWidth / 2 + 8;
    if (left + cardWidth / 2 > containerRect.width - 8) left = containerRect.width - cardWidth / 2 - 8;
    if (top < 70) top = nodeRect.bottom - containerRect.top + 75;

    card.style.left = `${left}px`;
    card.style.top = `${top}px`;
  }
}
