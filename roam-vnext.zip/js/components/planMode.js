/**
 * ROAM Plan Mode Component (V3)
 * Central Travel Command Center connecting:
 * PLAN + CROWD FORECAST + MARKET + MAP
 *
 * Features:
 * - 3-Column Command Center (Timeline | Spatial Route Map | Connected Intelligence)
 * - User Interest Chips (Food, Shopping, History, Architecture, Culture, Nature, Local Life, Relaxed)
 * - Single Simple Day Health Status Chip (Balanced, Too Crowded, Too Much Travel, Good Flow)
 * - Interactive Time Editor Popover with hourly crowd predictions & human labels
 * - Connected Crowd Forecast Curve dynamically highlighting the scheduled time
 * - "Better Time" Proactive Intelligence Layer with 1-click move button
 * - "Balance My Day" Optimizer with Before/After modal
 * - Dynamic "What Should I Do Next?" card
 * - "Open Slot" Detection card with category shortcuts
 * - Working Google Maps links (Open in Maps ↗, Get Directions ↗)
 */

import { travelState } from '../state/travelState.js';
import { formatIndianNumber } from '../utils/formatters.js';

export class PlanModeController {
  constructor(app) {
    this.app = app;
    this.mount = document.getElementById('plan-view-mount');
    this.activeTimeEditorItemId = null;
    this.showDayHealthExplanation = false;
    this.selectedSlotCategory = null;

    // Subscribe to centralized travelState changes
    travelState.subscribe((event, data) => {
      // Re-render when relevant state changes
      if (['itinerary:updated', 'focus:changed', 'interests:changed', 'date:changed'].includes(event)) {
        if (this.app?.activeMode === 'plan') {
          this.render();
        }
      }
    });
  }

  setDestination(locationData) {
    travelState.setLocation(locationData);
    this.render();
  }

  // --- Actions ---
  toggleInterest(interestId) {
    travelState.toggleInterest(interestId);
  }

  setDate(dateKey) {
    travelState.setDate(dateKey);
  }

  focusItem(id) {
    travelState.setFocusedItem(id);
    this.render();
  }

  openTimeEditor(itemId, event) {
    if (event) event.stopPropagation();
    this.activeTimeEditorItemId = (this.activeTimeEditorItemId === itemId) ? null : itemId;
    this.render();
  }

  setTime(itemId, newTime) {
    travelState.updateItemTime(itemId, newTime);
    this.activeTimeEditorItemId = null;
    if (this.app?.modalController) {
      const item = travelState.itinerary.find(i => i.id === itemId);
      this.app.modalController.showToast(`Updated ${item?.name || 'Stop'} to ${newTime}`);
    }
  }

  setDuration(itemId, durationMinutes) {
    travelState.updateItemDuration(itemId, durationMinutes);
  }

  removeItem(itemId) {
    const item = travelState.itinerary.find(i => i.id === itemId);
    travelState.removeItem(itemId);
    if (this.app?.modalController) {
      this.app.modalController.showToast(`Removed ${item?.name || 'Stop'}`);
    }
  }

  moveItem(itemId, direction) {
    travelState.moveItem(itemId, direction);
  }

  runBalanceMyDay() {
    const comparison = travelState.balanceDay();
    if (!comparison) return;

    if (this.app && this.app.modalController) {
      this.app.modalController.openBalanceModal(
        comparison.currentPlan,
        comparison.balancedPlan,
        () => {
          travelState.applyBalancedSchedule(comparison.balancedPlan);
        }
      );
    }
  }

  addPlace(place) {
    const res = travelState.addPlaceIntelligently(place);
    if (this.app?.modalController) {
      this.app.modalController.showToast(`Added ${res.item.name} at ${res.time} (${res.reason})`);
    }
    this.render();
  }

  // --- Rendering ---
  render() {
    if (!this.mount) {
      this.mount = document.getElementById('plan-view-mount');
      if (!this.mount) return;
    }

    const city = travelState.location?.name || 'Jaipur';
    const itinerary = travelState.itinerary;
    const focusedItem = travelState.getFocusedItem();
    const dayHealth = travelState.dayHealth;
    const betterTime = travelState.getBetterTimeInsight(focusedItem);
    const whatNext = travelState.getWhatShouldIDoNext();
    const openSlots = travelState.openSlots;

    const interestChips = [
      { id: 'food', label: '🍛 Food' },
      { id: 'shopping', label: '🛍️ Shopping' },
      { id: 'history', label: '🏛️ History' },
      { id: 'architecture', label: '🏰 Architecture' },
      { id: 'culture', label: '🎨 Culture' },
      { id: 'nature', label: '🌿 Nature' },
      { id: 'local_life', label: '🧭 Local Life' },
      { id: 'relaxed', label: '☕ Relaxed' }
    ];

    this.mount.innerHTML = `
      <!-- Top Command Center Bar -->
      <div class="plan-header-card">
        <div class="plan-header-top">
          <div>
            <div class="plan-eyebrow">
              PERSONAL TRAVEL COMMAND CENTER
            </div>
            <h2 class="plan-city-title">MY ${city.toUpperCase()} DAY</h2>
            <p class="plan-subtitle">
              Intelligent connected loop: every stop updates crowds, transit times, market fits, and day balance in real-time.
            </p>
          </div>

          <div class="plan-header-actions">
            <button id="plan-balance-cta" class="btn btn-primary balance-glow-btn" title="Reorder stops to avoid peak queues and midday heat">
              ⚡ BALANCE MY DAY
            </button>
            <button id="plan-add-place-cta" class="btn btn-secondary">
              + ADD PLACE
            </button>
          </div>
        </div>

        <!-- Lightweight User Interest Chips Bar (Requirement 21) -->
        <div class="plan-interests-bar">
          <span class="interests-label">YOUR INTERESTS:</span>
          <div class="interests-chips-wrap">
            ${interestChips.map(c => `
              <button class="interest-chip ${travelState.hasInterest(c.id) ? 'active' : ''}" data-interest="${c.id}">
                ${c.label}
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Date Pills & Simple Day Health Pill (Requirement 22) -->
        <div class="plan-status-bar">
          <div class="plan-date-wrap">
            <span style="font-size:0.82rem; font-weight:700; color:#fff;">Date:</span>
            <div class="plan-date-pills">
              <button class="plan-date-pill ${travelState.selectedDate === 'today' ? 'active' : ''}" data-date="today">Today</button>
              <button class="plan-date-pill ${travelState.selectedDate === 'tomorrow' ? 'active' : ''}" data-date="tomorrow">Tomorrow</button>
              <button class="plan-date-pill ${travelState.selectedDate === 'your_day' ? 'active' : ''}" data-date="your_day">Your Day 📅</button>
            </div>
          </div>

          <!-- Single Simple DAY HEALTH Indicator (Requirement 22) -->
          <div class="day-health-wrapper">
            <button id="day-health-chip" class="day-health-chip ${dayHealth.status.toLowerCase()}" style="border-color:${dayHealth.color}; color:${dayHealth.color};">
              <span class="health-pulse-dot" style="background:${dayHealth.color};"></span>
              <span>YOUR DAY: ${dayHealth.status}</span>
              <span class="health-expand-arrow">▾</span>
            </button>
          </div>
        </div>

        <!-- Day Health Explanation Dropdown / Card (Requirement 22) -->
        ${this.showDayHealthExplanation ? `
          <div class="day-health-popover">
            <div class="popover-header">
              <span style="color:${dayHealth.color}; font-weight:800; font-size:0.9rem;">${dayHealth.headline}</span>
              <button class="popover-close-btn" id="health-popover-close">&times;</button>
            </div>
            <p class="popover-desc">${dayHealth.description}</p>
            ${dayHealth.fixAction ? `
              <div class="popover-actions">
                <button class="btn btn-sm btn-primary" id="health-quick-fix-btn" data-type="${dayHealth.fixAction.type}">
                  ⚡ ${dayHealth.fixAction.label}
                </button>
              </div>
            ` : ''}
          </div>
        ` : ''}
      </div>

      <!-- 3-Column Responsive Command Center Grid (Requirement 27) -->
      <div class="plan-command-grid">
        
        <!-- ============================================================
             COLUMN 1: ITINERARY TIMELINE (Requirements 2, 3, 4)
             ============================================================ -->
        <div class="plan-col-timeline">
          <div class="col-header-strip">
            <span class="col-header-title">ITINERARY SCHEDULE</span>
            <span class="col-header-meta">${itinerary.length} STOPS • ~${Math.round(itinerary.reduce((a, b) => a + (b.durationMinutes || 90), 0) / 60)}H TOTAL</span>
          </div>

          <div class="plan-timeline-container">
            ${itinerary.map((item, idx) => {
              const nextItem = itinerary[idx + 1];
              const isSelected = focusedItem && focusedItem.id === item.id;
              const isQuiet = item.crowdStatus === 'optimal';
              const isBusy = item.crowdStatus === 'critical';
              const isEditingTime = this.activeTimeEditorItemId === item.id;

              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(item.name + ', ' + city)}`;
              const directionsUrl = nextItem 
                ? `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(item.name + ', ' + city)}&destination=${encodeURIComponent(nextItem.name + ', ' + city)}`
                : mapsUrl;

              return `
                <div class="plan-timeline-step ${isSelected ? 'selected' : ''}" data-id="${item.id}">
                  
                  <!-- Left: Interactive Time & Duration -->
                  <div class="step-time-col">
                    <button class="step-time-btn ${isBusy ? 'time-busy' : (isQuiet ? 'time-quiet' : 'time-elevated')}" data-id="${item.id}" title="Click to open Time Editor">
                      ${item.time} ▾
                    </button>

                    <!-- Compact Time Editor Popover (Requirement 4) -->
                    ${isEditingTime ? this.renderTimeEditorPopover(item) : ''}

                    <div class="step-duration-label">
                      <select class="step-duration-select" data-id="${item.id}" aria-label="Visit Duration">
                        <option value="45" ${item.durationMinutes === 45 ? 'selected' : ''}>45m</option>
                        <option value="60" ${item.durationMinutes === 60 ? 'selected' : ''}>1h 00m</option>
                        <option value="75" ${item.durationMinutes === 75 ? 'selected' : ''}>1h 15m</option>
                        <option value="90" ${item.durationMinutes === 90 ? 'selected' : ''}>1h 30m</option>
                        <option value="120" ${item.durationMinutes === 120 ? 'selected' : ''}>2h 00m</option>
                        <option value="150" ${item.durationMinutes === 150 ? 'selected' : ''}>2h 30m</option>
                      </select>
                    </div>
                  </div>

                  <!-- Center: Node Dot & Smart Route Line -->
                  <div class="step-node-col">
                    <div class="step-dot ${isQuiet ? 'dot-optimal' : (isBusy ? 'dot-critical' : 'dot-elevated')}" data-id="${item.id}">
                      ${idx + 1}
                    </div>
                    ${idx < itinerary.length - 1 ? '<div class="step-connector-line"></div>' : ''}
                  </div>

                  <!-- Right: Activity Card -->
                  <div class="step-card-col">
                    <div class="plan-activity-card ${isSelected ? 'card-focused' : ''}" data-id="${item.id}">
                      
                      <!-- Top Row: Name, Category, Crowd Status -->
                      <div class="activity-top-row">
                        <div>
                          <div class="activity-name">${item.name}</div>
                          <div class="activity-category">${item.category.toUpperCase()} • ${item.durationMinutes} min visit</div>
                        </div>

                        <div class="activity-crowd-tag ${isQuiet ? 'tag-optimal' : (isBusy ? 'tag-critical' : 'tag-elevated')}">
                          <span class="crowd-dot"></span>
                          <span>${item.crowdLabel} (~${formatIndianNumber(item.expectedVisitors)})</span>
                        </div>
                      </div>

                      <!-- Peak Bottleneck Warning inline tag -->
                      ${item.isOvercrowded ? `
                        <div class="peak-warning-pill">
                          ⚠️ Peak queue window (~50+ min line). Click time or Balance My Day to optimize.
                        </div>
                      ` : ''}

                      <!-- Item Actions: Order, Remove, Open in Maps -->
                      <div class="activity-actions-row">
                        <div class="activity-order-buttons">
                          <button class="order-btn" data-action="up" data-id="${item.id}" title="Move Up" ${idx === 0 ? 'disabled' : ''}>▲</button>
                          <button class="order-btn" data-action="down" data-id="${item.id}" title="Move Down" ${idx === itinerary.length - 1 ? 'disabled' : ''}>▼</button>
                          <button class="order-btn delete-btn" data-action="remove" data-id="${item.id}" title="Remove Activity">✕</button>
                        </div>

                        <div style="display:flex; align-items:center; gap:12px;">
                          <button class="plan-focus-btn" data-id="${item.id}">
                            ${isSelected ? '● FOCUSING' : 'VIEW CURVE ➔'}
                          </button>
                          <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="plan-maps-link" onclick="event.stopPropagation();">
                            OPEN IN MAPS ↗
                          </a>
                        </div>
                      </div>
                    </div>

                    <!-- Transit Card to Next Stop (Requirement 14 & 17) -->
                    ${nextItem ? `
                      <div class="plan-transit-card">
                        <span class="transit-icon">🚶 / 🚗</span>
                        <span class="transit-info">~${item.transitMinutesToNext || 20} min travel to ${nextItem.name}</span>
                        <a href="${directionsUrl}" target="_blank" rel="noopener noreferrer" class="transit-directions-link">
                          GET DIRECTIONS ↗
                        </a>
                      </div>
                    ` : ''}
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          <!-- Add Stop Bottom CTA -->
          <div style="text-align:center; margin:24px 0;">
            <button id="plan-add-inline-btn" class="btn btn-secondary" style="width:100%;">
              + Add Another Attraction or Bazaar
            </button>
          </div>
        </div>

        <!-- ============================================================
             COLUMN 2: SPATIAL ROUTE MAP (Requirements 14, 15)
             ============================================================ -->
        <div class="plan-col-map">
          <div class="col-header-strip">
            <span class="col-header-title">SMART ROUTE MAP</span>
            <span class="col-header-meta">INTERACTIVE FLOW</span>
          </div>

          <div class="plan-embedded-map-wrap">
            ${this.renderEmbeddedRouteMap(itinerary, focusedItem)}
          </div>

          <!-- Route Sequence Summary Strip -->
          <div class="smart-route-summary-box">
            <div class="smart-route-title">ROUTE PROGRESSION</div>
            <div class="smart-route-chain">
              ${itinerary.map((it, i) => `
                <span class="route-stop-chip ${focusedItem?.id === it.id ? 'active' : ''}" data-id="${it.id}">
                  ${i + 1}. ${it.name}
                </span>
                ${i < itinerary.length - 1 ? '<span class="route-arrow">↓ ~20m ↓</span>' : ''}
              `).join('')}
            </div>
          </div>
        </div>

        <!-- ============================================================
             COLUMN 3: CONNECTED INTELLIGENCE & FORECAST
             (Requirements 5, 6, 12, 13)
             ============================================================ -->
        <div class="plan-col-intel">
          <div class="col-header-strip">
            <span class="col-header-title">ROAM INTELLIGENCE</span>
            <span class="col-header-meta">CONNECTED DEMAND</span>
          </div>

          <!-- 1. Connected Crowd Forecast Component (Requirement 5) -->
          <div class="connected-forecast-card">
            ${this.renderConnectedCrowdCurve(focusedItem)}
          </div>

          <!-- 2. "Better Time" Proactive Intelligence Layer (Requirement 6) -->
          ${betterTime ? `
            <div class="better-time-card">
              <div class="better-time-badge">⚡ BETTER TIME RECOMMENDED</div>
              <div class="better-time-title">${focusedItem.name} at ${betterTime.currentHour} is very busy</div>
              <p class="better-time-insight">
                ${betterTime.insight} Expected crowd is ~${formatIndianNumber(betterTime.currentVisitors)} visitors with 50+ min queues.
              </p>
              
              <div class="better-time-highlight-box">
                <div class="better-time-opt-label">BETTER OPTION</div>
                <div class="better-time-opt-val">${betterTime.betterTime} (~${formatIndianNumber(betterTime.betterVisitors)} visitors • ${betterTime.betterLabel})</div>
                <div class="better-time-saving">Save ~${formatIndianNumber(betterTime.savedVisitors)} visitors of crowd exposure</div>
              </div>

              <button class="btn btn-primary better-time-apply-btn" id="better-time-move-cta" data-id="${focusedItem.id}" data-target="${betterTime.betterTime}">
                [ ${betterTime.actionText} ]
              </button>
            </div>
          ` : ''}

          <!-- 3. Dynamic "What Should I Do Next?" Card (Requirement 12) -->
          ${whatNext ? `
            <div class="what-next-card">
              <div class="what-next-badge">WHAT SHOULD I DO NEXT?</div>
              <div class="what-next-headline">${whatNext.headline}</div>
              
              <div class="what-next-pick">
                <div class="what-next-title">${whatNext.title}</div>
                <div class="what-next-specialty">${whatNext.specialty}</div>
                <div class="what-next-meta">
                  <span>~${formatIndianNumber(whatNext.visitors)} visitors</span> • 
                  <span>~${whatNext.transitMinutes} min away</span>
                </div>
              </div>

              <div class="what-next-why">
                <strong>WHY?</strong> ${whatNext.why}
              </div>

              <div class="what-next-actions">
                <button class="btn btn-sm btn-primary what-next-add-btn" data-id="${whatNext.pick.id}">
                  + ADD TO PLAN
                </button>
                <button class="btn btn-sm btn-secondary what-next-explore-btn" data-id="${whatNext.pick.id}">
                  EXPLORE ↗
                </button>
              </div>
            </div>
          ` : ''}

          <!-- 4. "Open Slot" Detection Card (Requirement 13) -->
          ${openSlots.length > 0 ? `
            <div class="open-slot-card">
              <div class="open-slot-badge">⏰ OPEN SLOT DETECTED</div>
              <div class="open-slot-title">
                ${Math.round(openSlots[0].durationMinutes / 60)}h ${openSlots[0].durationMinutes % 60 ? (openSlots[0].durationMinutes % 60 + 'm ') : ''}OPEN (${openSlots[0].startTime} — ${openSlots[0].endTime})
              </div>
              <p class="open-slot-desc">
                ROAM can fill this free window near your route without adding transit fatigue.
              </p>

              <div class="open-slot-pills">
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'shopping' ? 'active' : ''}" data-cat="shopping">🛍️ SHOP</button>
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'culture' ? 'active' : ''}" data-cat="culture">🎨 CULTURE</button>
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'food' ? 'active' : ''}" data-cat="food">🍛 FOOD</button>
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'crafts' ? 'active' : ''}" data-cat="crafts">🏺 CRAFTS</button>
              </div>

              <div id="slot-recommendations-list">
                ${this.renderSlotRecommendations(openSlots[0])}
              </div>
            </div>
          ` : ''}

        </div>

      </div>
    `;

    this.attachEventListeners();
  }

  // --- Compact Time Editor Popover (Requirement 4) ---
  renderTimeEditorPopover(item) {
    const options = travelState.getTimeEditorOptions(item);

    return `
      <div class="time-editor-popover" data-id="${item.id}" onclick="event.stopPropagation();">
        <div class="time-editor-header">
          <div class="time-editor-title">${item.name}</div>
          <div class="time-editor-current">CURRENT: <strong>${item.time}</strong></div>
        </div>

        <div class="time-editor-label">CHOOSE A TIME</div>
        <div class="time-editor-custom-row">
          <input class="plan-time-input" type="time" value="${item.time}" data-id="${item.id}" aria-label="Choose visit time for ${item.name}">
          <button class="btn btn-sm btn-primary plan-time-apply" data-id="${item.id}">Apply</button>
        </div>
        <div class="time-editor-label time-editor-or">OR PICK A FORECAST WINDOW</div>
        <div class="time-editor-options-list">
          ${options.map(opt => `
            <button class="time-opt-btn ${opt.isCurrent ? 'current' : ''}" data-time="${opt.time}" data-id="${item.id}">
              <span class="time-opt-time">${opt.time}</span>
              <span class="time-opt-visitors">~${formatIndianNumber(opt.visitors)} visitors</span>
              <span class="time-opt-badge ${opt.status === 'optimal' ? 'badge-optimal' : (opt.status === 'critical' ? 'badge-critical' : 'badge-elevated')}">
                ${opt.label}
              </span>
            </button>
          `).join('')}
        </div>
      </div>
    `;
  }

  // --- Connected Crowd Curve SVG (Requirement 5) ---
  renderConnectedCrowdCurve(focusedItem) {
    if (!focusedItem) return '';

    const curve = travelState.getCrowdCurveForItem(focusedItem);
    const scheduledHour = focusedItem.time;
    const hourNum = parseInt(scheduledHour.split(':')[0], 10);

    const svgWidth = 440;
    const svgHeight = 110;
    const padX = 35;
    const padY = 20;
    const stepX = (svgWidth - padX * 2) / (curve.length - 1);

    const coords = curve.map((p, i) => {
      const x = padX + i * stepX;
      const y = svgHeight - padY - (p.pct / 100) * (svgHeight - padY * 2);
      const isSelected = Math.abs(parseInt(p.hour.split(':')[0], 10) - hourNum) <= 1;
      return { x, y, isSelected, ...p };
    });

    let d = `M ${coords[0].x} ${coords[0].y}`;
    for (let i = 0; i < coords.length - 1; i++) {
      const p0 = coords[i];
      const p1 = coords[i + 1];
      const cpX1 = p0.x + (p1.x - p0.x) / 2;
      const cpX2 = cpX1;
      d += ` C ${cpX1} ${p0.y}, ${cpX2} ${p1.y}, ${p1.x} ${p1.y}`;
    }
    const areaD = `${d} L ${coords[coords.length - 1].x} ${svgHeight - padY} L ${coords[0].x} ${svgHeight - padY} Z`;

    const activePoint = coords.find(c => c.isSelected) || coords[0];

    return `
      <div class="crowd-curve-inner">
        <div class="curve-header-row">
          <div>
            <div class="curve-title-eyebrow">CROWD FORECAST • TODAY / YOUR DAY</div>
            <div class="curve-title-name">${focusedItem.name}</div>
          </div>

          <div class="curve-honesty-tag">
            ROAM FORECAST • Modelled estimate
          </div>
        </div>

        <div class="curve-scheduled-indicator">
          <span>Scheduled: <strong style="color:#fff;">${focusedItem.time}</strong> (~${formatIndianNumber(focusedItem.expectedVisitors)} visitors • ${focusedItem.crowdLabel})</span>
        </div>

        <div class="curve-svg-container">
          <svg viewBox="0 0 ${svgWidth} ${svgHeight}" class="connected-curve-svg" preserveAspectRatio="none">
            <defs>
              <linearGradient id="planCurveGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="var(--roam-accent)" stop-opacity="0.35"/>
                <stop offset="100%" stop-color="var(--roam-accent)" stop-opacity="0.0"/>
              </linearGradient>
            </defs>

            <!-- Gradient Area -->
            <path d="${areaD}" fill="url(#planCurveGrad)" />

            <!-- Curve Stroke -->
            <path d="${d}" fill="none" stroke="var(--roam-accent)" stroke-width="2.5" stroke-linecap="round" />

            <!-- Vertical Indicator for Scheduled Time -->
            <line x1="${activePoint.x}" y1="10" x2="${activePoint.x}" y2="${svgHeight - padY}" stroke="#fff" stroke-width="1.5" stroke-dasharray="3,3" opacity="0.8" />

            <!-- Interactive Clickable Points -->
            ${coords.map(c => `
              <g class="curve-node-group" data-hour="${c.hour}" data-id="${focusedItem.id}">
                <circle cx="${c.x}" cy="${c.y}" r="${c.isSelected ? '7' : '4'}" fill="${c.pct > 75 ? '#ef4444' : (c.pct > 40 ? '#f59e0b' : '#10b981')}" stroke="#fff" stroke-width="${c.isSelected ? '3' : '1.5'}" class="${c.isSelected ? 'pulse-point' : ''}" />
              </g>
            `).join('')}
          </svg>

          <!-- Labels Row -->
          <div class="curve-labels-strip">
            ${curve.map(p => `
              <button class="curve-time-chip ${p.hour === activePoint.hour ? 'active' : ''}" data-hour="${p.hour}" data-id="${focusedItem.id}">
                <span class="chip-h">${p.hour}</span>
                <span class="chip-v">~${formatIndianNumber(p.visitors)}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <div class="curve-hint">
          💡 Click any time chip or curve node above to reschedule ${focusedItem.name} immediately.
        </div>
      </div>
    `;
  }

  // --- Embedded Route Map SVG (Requirements 14, 15) ---
  renderEmbeddedRouteMap(itinerary, focusedItem) {
    const allAttractions = travelState.location?.attractions || [];
    const businesses = travelState.location?.localBusinesses || [];

    return `
      <svg class="embedded-route-svg" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Smart Route Map">
        <defs>
          <radialGradient id="planMapGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="var(--roam-accent)" stop-opacity="0.18" />
            <stop offset="100%" stop-color="transparent" />
          </radialGradient>
        </defs>

        <rect width="800" height="600" fill="rgba(8, 12, 20, 0.95)" />
        <circle cx="400" cy="300" r="300" fill="url(#planMapGlow)" />

        <!-- Polyline connecting sequential itinerary stops -->
        ${itinerary.length > 1 ? `
          <polyline points="${itinerary.map(i => `${i.coords.x},${i.coords.y}`).join(' ')}" fill="none" stroke="var(--roam-accent)" stroke-width="2.5" stroke-dasharray="6,6" opacity="0.75" />
        ` : ''}

        <!-- Other city sites as subtle reference dots -->
        <g opacity="0.35">
          ${allAttractions.map(a => `
            <circle cx="${a.coords.x}" cy="${a.coords.y}" r="6" fill="#64748b" />
          `).join('')}
        </g>

        <!-- Itinerary Stops with Numbers & Status Glow -->
        <g class="itinerary-map-nodes">
          ${itinerary.map((item, idx) => {
            const isSelected = focusedItem && focusedItem.id === item.id;
            const isQuiet = item.crowdStatus === 'optimal';
            const isBusy = item.crowdStatus === 'critical';
            const color = isBusy ? '#ef4444' : (isQuiet ? 'var(--load-optimal)' : '#f59e0b');

            return `
              <g class="route-map-node ${isSelected ? 'selected' : ''}" data-id="${item.id}" transform="translate(${item.coords.x}, ${item.coords.y})">
                <circle cx="0" cy="0" r="${isSelected ? 26 : 20}" fill="${color}" opacity="0.22" class="${isSelected ? 'pulse-ring' : ''}" />
                <circle cx="0" cy="0" r="${isSelected ? 18 : 14}" fill="rgba(12, 18, 30, 0.95)" stroke="${color}" stroke-width="${isSelected ? '3' : '2'}" />
                
                <text y="4" text-anchor="middle" fill="#fff" font-size="11" font-weight="900" font-family="var(--font-mono)">
                  ${idx + 1}
                </text>

                <g transform="translate(0, 26)">
                  <rect x="-60" y="-10" width="120" height="20" rx="4" fill="rgba(10, 15, 26, 0.92)" stroke="${color}" stroke-width="1" />
                  <text y="4" text-anchor="middle" fill="#fff" font-size="10" font-weight="700">
                    ${item.name.length > 15 ? item.name.substring(0, 14) + '…' : item.name}
                  </text>
                </g>
              </g>
            `;
          }).join('')}
        </g>
      </svg>
    `;
  }

  // --- Open Slot Recommendations (Requirement 13) ---
  renderSlotRecommendations(slot) {
    const businesses = travelState.location?.localBusinesses || [];
    const cat = this.selectedSlotCategory || 'shopping';

    const matches = businesses.filter(b => b.category === cat || (cat === 'shopping' && (b.category === 'markets' || b.category === 'shopping'))).slice(0, 2);

    if (matches.length === 0) {
      return `<div style="font-size:0.8rem; color:var(--text-muted); padding:8px 0;">No matching places found for this category.</div>`;
    }

    return matches.map(m => `
      <div class="slot-match-item">
        <div>
          <div class="slot-match-name">${m.name}</div>
          <div class="slot-match-sub">~${formatIndianNumber(m.estimatedActivity)} visitors • ${m.zone}</div>
        </div>
        <button class="btn btn-sm btn-secondary slot-match-add-btn" data-id="${m.id}">
          + Add
        </button>
      </div>
    `).join('');
  }

  // --- Event Listener Attachments ---
  attachEventListeners() {
    if (!this.mount) return;

    // 1. Balance My Day CTA
    const balanceBtn = this.mount.querySelector('#plan-balance-cta');
    if (balanceBtn) balanceBtn.onclick = () => this.runBalanceMyDay();

    // 2. Add Place CTAs
    const addTop = this.mount.querySelector('#plan-add-place-cta');
    const addInline = this.mount.querySelector('#plan-add-inline-btn');
    const openAddModal = () => {
      if (this.app?.modalController && travelState.location) {
        this.app.modalController.openAddPlace(travelState.location);
      }
    };
    if (addTop) addTop.onclick = openAddModal;
    if (addInline) addInline.onclick = openAddModal;

    // 3. User Interest Chips
    this.mount.querySelectorAll('.interest-chip').forEach(btn => {
      btn.onclick = () => {
        this.toggleInterest(btn.dataset.interest);
      };
    });

    // 4. Date Pills
    this.mount.querySelectorAll('.plan-date-pill').forEach(btn => {
      btn.onclick = () => {
        this.setDate(btn.dataset.date);
      };
    });

    // 5. Day Health Chip & Explanation Popover
    const healthChip = this.mount.querySelector('#day-health-chip');
    if (healthChip) {
      healthChip.onclick = () => {
        this.showDayHealthExplanation = !this.showDayHealthExplanation;
        this.render();
      };
    }
    const healthClose = this.mount.querySelector('#health-popover-close');
    if (healthClose) {
      healthClose.onclick = () => {
        this.showDayHealthExplanation = false;
        this.render();
      };
    }
    const healthFix = this.mount.querySelector('#health-quick-fix-btn');
    if (healthFix) {
      healthFix.onclick = () => {
        const type = healthFix.dataset.type;
        if (type === 'move_early') {
          const action = travelState.dayHealth.fixAction;
          if (action?.itemId && action?.targetTime) {
            travelState.updateItemTime(action.itemId, action.targetTime);
            this.showDayHealthExplanation = false;
            if (this.app?.modalController) {
              this.app.modalController.showToast('Amber Fort moved to 08:30 — Day is now BALANCED!');
            }
          }
        } else {
          this.runBalanceMyDay();
          this.showDayHealthExplanation = false;
        }
      };
    }

    // 6. Time Editor Buttons & Popover
    this.mount.querySelectorAll('.step-time-btn').forEach(btn => {
      btn.onclick = (e) => {
        const id = btn.dataset.id;
        this.openTimeEditor(id, e);
      };
    });

    this.mount.querySelectorAll('.plan-time-apply').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const input = this.mount.querySelector(`.plan-time-input[data-id="${id}"]`);
        if (input?.value) this.setTime(id, input.value);
      };
    });

    this.mount.querySelectorAll('.time-opt-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const time = btn.dataset.time;
        this.setTime(id, time);
      };
    });

    // 7. Duration select
    this.mount.querySelectorAll('.step-duration-select').forEach(sel => {
      sel.onchange = (e) => {
        const id = sel.dataset.id;
        this.setDuration(id, e.target.value);
      };
    });

    // 8. Order / Remove buttons
    this.mount.querySelectorAll('.order-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const act = btn.dataset.action;
        if (act === 'up') this.moveItem(id, -1);
        else if (act === 'down') this.moveItem(id, 1);
        else if (act === 'remove') this.removeItem(id);
      };
    });

    // 9. Focus item cards & buttons
    this.mount.querySelectorAll('.plan-activity-card').forEach(card => {
      card.onclick = () => this.focusItem(card.dataset.id);
    });
    this.mount.querySelectorAll('.plan-focus-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        this.focusItem(btn.dataset.id);
      };
    });
    this.mount.querySelectorAll('.route-stop-chip').forEach(chip => {
      chip.onclick = () => this.focusItem(chip.dataset.id);
    });
    this.mount.querySelectorAll('.route-map-node').forEach(node => {
      node.onclick = () => this.focusItem(node.dataset.id);
    });

    // 10. Connected Curve interactive point click
    this.mount.querySelectorAll('.curve-node-group, .curve-time-chip').forEach(el => {
      el.onclick = () => {
        const hour = el.dataset.hour;
        const id = el.dataset.id;
        if (hour && id) {
          this.setTime(id, hour);
        }
      };
    });

    // 11. Better Time 1-Click Move Button (Requirement 6)
    const betterTimeMove = this.mount.querySelector('#better-time-move-cta');
    if (betterTimeMove) {
      betterTimeMove.onclick = () => {
        const id = betterTimeMove.dataset.id;
        const target = betterTimeMove.dataset.target;
        this.setTime(id, target);
        if (this.app?.modalController) {
          this.app.modalController.showToast(`Moved visit to ${target} — Queue eliminated!`);
        }
      };
    }

    // 12. What Next buttons (Requirement 12)
    const whatNextAdd = this.mount.querySelector('.what-next-add-btn');
    if (whatNextAdd) {
      whatNextAdd.onclick = () => {
        const pick = travelState.getWhatShouldIDoNext()?.pick;
        if (pick) {
          this.addPlace(pick);
        }
      };
    }
    const whatNextExplore = this.mount.querySelector('.what-next-explore-btn');
    if (whatNextExplore) {
      whatNextExplore.onclick = () => {
        const pick = travelState.getWhatShouldIDoNext()?.pick;
        if (pick && this.app?.modalController) {
          this.app.modalController.openShopDetail(pick, travelState.location?.name);
        }
      };
    }

    // 13. Slot category pills
    this.mount.querySelectorAll('.slot-cat-pill').forEach(pill => {
      pill.onclick = () => {
        this.selectedSlotCategory = pill.dataset.cat;
        this.render();
      };
    });

    this.mount.querySelectorAll('.slot-match-add-btn').forEach(btn => {
      btn.onclick = () => {
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop) this.addPlace(shop);
      };
    });
  }
}
