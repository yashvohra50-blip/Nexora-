/**
 * ROAM Tourist Mode (Discover View) Component (V3)
 * Human-First Travel Product:
 * Cultural Intent Filters, "Live Like a Local" tips,
 * "What Will It Be Like Then?" Interactive Time Slider,
 * Crowd Forecast Curves (Today/Tomorrow/Your Day), Best Time to Visit,
 * and Working Google Maps Links.
 */

import { 
  formatCrowdLevel, 
  formatVisitorCount, 
  formatWaitTime, 
  formatIndianNumber, 
  renderTooltip 
} from '../utils/formatters.js';
import { travelState } from '../state/travelState.js';

export class TouristModeController {
  constructor(mapInstance, appInstance) {
    this.map = mapInstance;
    this.app = appInstance;
    this.locationData = null;
    this.isRerouted = false;
    this.activeIntentFilter = 'all'; // all, architecture, food, shopping, spiritual, quiet
    this.forecastDay = 'today'; // today, tomorrow, your_day
    this.selectedHour = 12; // 08 to 20
  }

  setDestination(locationData) {
    this.locationData = locationData;
    this.isRerouted = false;
    this.activeIntentFilter = 'all';

    if (this.map) {
      this.map.setDestination(locationData);
    }

    this.render();
  }

  render() {
    if (!this.locationData) return;

    this.renderHeroCounts();
    this.renderHealthBar();
    this.renderLiveLikeALocal();
    this.renderCulturalIntentFilters();
    this.renderRecommendations();
    this.renderCrowdForecastCurve();
    this.renderRerouteBanner();
  }

  renderHeroCounts() {
    const attractions = this.locationData.attractions || [];
    const overcrowded = attractions.filter(a => a.status === 'critical').length;
    const withRoom = attractions.filter(a => a.status === 'optimal').length;

    const bannerMount = document.getElementById('hero-live-crowd-strip');
    if (bannerMount) {
      bannerMount.innerHTML = `
        <div style="display:inline-flex; align-items:center; gap:16px; background:rgba(255,255,255,0.04); border:1px solid var(--border-medium); border-radius:var(--radius-full); padding:6px 18px; font-size:0.85rem; font-weight:700;">
          <span style="color:#ef4444; display:flex; align-items:center; gap:6px;">
            <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#ef4444;"></span>
            ${overcrowded} places are overcrowded
          </span>
          <span style="color:var(--text-muted);">•</span>
          <span style="color:#10b981; display:flex; align-items:center; gap:6px;">
            <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:#10b981;"></span>
            ${withRoom} places have room
          </span>
        </div>
      `;
    }
  }

  renderHealthBar() {
    const metrics = this.locationData.metrics;
    const bar = document.getElementById('tourist-health-bar');
    if (!bar) return;

    const concentration = this.isRerouted ? 48 : metrics.visitorConcentration;
    const attractions = this.locationData.attractions || [];
    const roomCount = attractions.filter(a => a.status === 'optimal').length;

    bar.innerHTML = `
      <!-- Metric 1: Where Everyone Is Going -->
      <div class="health-stat">
        <div class="health-label-row">
          <span class="health-label">
            Where Everyone Is Going ${renderTooltip('visitorPressure')}
          </span>
          <span style="font-size:0.7rem; color:var(--text-muted); font-family:var(--font-mono);">
            ${concentration}% concentration
          </span>
        </div>
        <div class="health-human-headline" style="color: ${this.isRerouted ? 'var(--load-optimal)' : 'var(--load-critical)'}">
          ${this.isRerouted ? 'Balanced Across City' : 'Crowded in Top 3 Sites'}
        </div>
        <div class="health-sub-metric">
          ${this.isRerouted ? 'Visitors moving freely' : 'Surge traffic at main gates'}
        </div>
        <div class="health-meter-track">
          <div class="health-meter-fill" style="width:${concentration}%; background:${this.isRerouted ? 'var(--load-optimal)' : 'var(--load-critical)'};"></div>
        </div>
      </div>

      <!-- Metric 2: Places With Room -->
      <div class="health-stat">
        <div class="health-label-row">
          <span class="health-label">
            Places With Room ${renderTooltip('capacity')}
          </span>
          <span style="font-size:0.7rem; color:var(--text-muted); font-family:var(--font-mono);">
            ${roomCount} discovered
          </span>
        </div>
        <div class="health-human-headline" style="color:var(--load-optimal);">
          ${roomCount} Sites Ready To Visit
        </div>
        <div class="health-sub-metric">
          Zero queue wait right now
        </div>
        <div class="health-meter-track">
          <div class="health-meter-fill" style="width:100%; background:var(--load-optimal);"></div>
        </div>
      </div>

      <!-- Metric 3: Typical Wait Time -->
      <div class="health-stat">
        <div class="health-label-row">
          <span class="health-label">
            Average Wait Time ${renderTooltip('utilization')}
          </span>
          <span style="font-size:0.7rem; color:var(--text-muted); font-family:var(--font-mono);">
            ${this.isRerouted ? 'Saved 35 min' : 'Peak hours'}
          </span>
        </div>
        <div class="health-human-headline" style="color: ${this.isRerouted ? 'var(--load-optimal)' : 'var(--load-elevated)'}">
          ${this.isRerouted ? '< 10 min average' : formatWaitTime(metrics.avgWaitTimeMinutes)}
        </div>
        <div class="health-sub-metric">
          ${this.isRerouted ? 'Smooth entry everywhere' : 'Longest: Amber Fort (65 min)'}
        </div>
        <div class="health-meter-track">
          <div class="health-meter-fill" style="width:${this.isRerouted ? 18 : 68}%; background:${this.isRerouted ? 'var(--load-optimal)' : 'var(--load-elevated)'};"></div>
        </div>
      </div>

      <!-- Metric 4: Local Spending Impact -->
      <div class="health-stat">
        <div class="health-label-row">
          <span class="health-label">
            Local Spending Shared ${renderTooltip('opportunity')}
          </span>
          <span style="font-size:0.7rem; color:var(--text-muted); font-family:var(--font-mono);">
            ${this.isRerouted ? '+24% uplift' : 'Baseline'}
          </span>
        </div>
        <div class="health-human-headline" style="color:var(--brand-cyan);">
          ${this.isRerouted ? '₹38 Lakh / day' : '₹14 Lakh / day'}
        </div>
        <div class="health-sub-metric">
          Distributed to artisan guilds
        </div>
        <div class="health-meter-track">
          <div class="health-meter-fill" style="width:${this.isRerouted ? 75 : 30}%; background:var(--brand-cyan);"></div>
        </div>
      </div>
    `;
  }

  renderLiveLikeALocal() {
    const mount = document.getElementById('live-like-local-mount');
    if (!mount) return;

    const tips = this.locationData.liveLikeALocal || [];
    if (tips.length === 0) {
      mount.innerHTML = '';
      return;
    }

    mount.innerHTML = `
      <div class="local-tips-container">
        <div class="local-tips-header">
          <div>
            <div style="font-size:0.75rem; text-transform:uppercase; color:var(--roam-accent); font-weight:800; letter-spacing:0.12em; margin-bottom:2px;">
              Authentic Destination Rhythm
            </div>
            <h3 style="font-size:1.35rem; font-weight:900; color:#fff; margin:0;">
              LIVE LIKE A LOCAL IN ${this.locationData.name.toUpperCase()}
            </h3>
          </div>
          <span style="font-size:0.78rem; color:var(--text-muted); font-family:var(--font-mono);">
            ROAM CURATED INSIDER ADVICE
          </span>
        </div>

        <div class="local-tips-grid">
          ${tips.map(tip => `
            <div class="local-tip-card">
              <div class="local-tip-icon">${tip.icon}</div>
              <div class="local-tip-body">
                <div class="local-tip-title">${tip.title}</div>
                <div class="local-tip-desc">${tip.description}</div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
  }

  renderCulturalIntentFilters() {
    const mount = document.getElementById('intent-filter-mount');
    if (!mount) return;

    const filters = [
      { id: 'all', label: 'All Places' },
      { id: 'heritage', label: '🏛️ Architecture & Forts' },
      { id: 'food', label: '🍛 Authentic Taste' },
      { id: 'shopping', label: '🛍️ Bazaars & Crafts' },
      { id: 'spiritual', label: '🪔 Spiritual & Sacred' },
      { id: 'optimal', label: '🟢 Quiet Gems' }
    ];

    mount.innerHTML = `
      <div class="intent-filter-row">
        <span class="intent-filter-label">WHAT ARE YOU LOOKING FOR?</span>
        <div class="intent-filter-pills">
          ${filters.map(f => `
            <button class="intent-pill ${this.activeIntentFilter === f.id ? 'active' : ''}" data-filter="${f.id}">
              ${f.label}
            </button>
          `).join('')}
        </div>
      </div>
    `;

    mount.querySelectorAll('.intent-pill').forEach(btn => {
      btn.onclick = () => {
        this.activeIntentFilter = btn.dataset.filter;
        mount.querySelectorAll('.intent-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.renderRecommendations();
      };
    });
  }

  renderCrowdForecastCurve() {
    const mount = document.getElementById('crowd-forecast-mount');
    if (!mount) return;

    const primaryHotspot = (this.locationData.attractions || [])[0];
    if (!primaryHotspot) return;

    const selectedDate = travelState.selectedDate || this.forecastDay;
    this.forecastDay = selectedDate;
    const factor = selectedDate === 'tomorrow' ? 0.94 : (selectedDate === 'your_day' ? 1.04 : 1);
    const basePoints = [
      { time: '08:00', visitors: 420 },
      { time: '10:00', visitors: 1100 },
      { time: '12:00', visitors: 1950 },
      { time: '14:00', visitors: 1650 },
      { time: '17:00', visitors: 850 },
      { time: '19:00', visitors: 350 }
    ];
    const points = basePoints.map(p => {
      const visitors = Math.round(p.visitors * factor);
      const pct = Math.min(100, Math.round((visitors / 2050) * 100));
      return { ...p, visitors, pct, label: pct >= 80 ? 'Very Busy' : (pct >= 55 ? 'Moderate' : 'Quiet') };
    });

    // Build SVG curve path
    // Width 600, height 140
    const svgWidth = 600;
    const svgHeight = 120;
    const padX = 40;
    const padY = 20;
    const stepX = (svgWidth - padX * 2) / (points.length - 1);

    const coords = points.map((p, i) => {
      const x = padX + i * stepX;
      const y = svgHeight - padY - (p.pct / 100) * (svgHeight - padY * 2);
      return { x, y, ...p };
    });

    // Create smooth bezier path
    let d = `M ${coords[0].x} ${coords[0].y}`;
    for (let i = 0; i < coords.length - 1; i++) {
      const p0 = coords[i];
      const p1 = coords[i + 1];
      const cpX1 = p0.x + (p1.x - p0.x) / 2;
      const cpX2 = cpX1;
      d += ` C ${cpX1} ${p0.y}, ${cpX2} ${p1.y}, ${p1.x} ${p1.y}`;
    }

    // Area fill path
    const areaD = `${d} L ${coords[coords.length - 1].x} ${svgHeight - padY} L ${coords[0].x} ${svgHeight - padY} Z`;

    mount.innerHTML = `
      <div class="forecast-card">
        <div class="forecast-top-bar">
          <div>
            <div style="font-size:0.75rem; text-transform:uppercase; color:var(--roam-accent); font-weight:800; letter-spacing:0.12em;">
              CROWD FORECAST • ${primaryHotspot.name.toUpperCase()}
            </div>
            <div style="font-size:0.8rem; color:var(--text-muted); font-family:var(--font-mono); margin-top:2px;">
              ROAM FORECAST • Simulation based on historical & demand models
            </div>
          </div>

          <div class="forecast-day-pills">
            <button class="forecast-day-btn ${this.forecastDay === 'today' ? 'active' : ''}" data-day="today">TODAY</button>
            <button class="forecast-day-btn ${this.forecastDay === 'tomorrow' ? 'active' : ''}" data-day="tomorrow">TOMORROW</button>
            <button class="forecast-day-btn ${this.forecastDay === 'your_day' ? 'active' : ''}" data-day="your_day">YOUR DAY 📅</button>
          </div>
        </div>

        <!-- Smooth SVG Demand Curve -->
        <div class="forecast-svg-wrap">
          <svg viewBox="0 0 ${svgWidth} ${svgHeight}" class="forecast-svg" preserveAspectRatio="none">
            <defs>
              <linearGradient id="curveGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="#ef4444" stop-opacity="0.45"/>
                <stop offset="60%" stop-color="#f59e0b" stop-opacity="0.25"/>
                <stop offset="100%" stop-color="#10b981" stop-opacity="0.05"/>
              </linearGradient>
            </defs>

            <!-- Gradient Area Fill -->
            <path d="${areaD}" fill="url(#curveGradient)" />

            <!-- Curve Stroke Line -->
            <path d="${d}" fill="none" stroke="var(--roam-accent)" stroke-width="3" stroke-linecap="round" />

            <!-- Highlight Nodes -->
            ${coords.map(c => `
              <circle cx="${c.x}" cy="${c.y}" r="5" fill="${c.pct > 75 ? '#ef4444' : (c.pct > 40 ? '#f59e0b' : '#10b981')}" stroke="#fff" stroke-width="2" />
            `).join('')}
          </svg>

          <!-- Label markers below curve -->
          <div class="forecast-labels-row">
            ${points.map(p => `
              <div class="forecast-point-label">
                <div class="point-time">${p.time}</div>
                <div class="point-status" style="color:${p.pct > 75 ? '#ef4444' : (p.pct > 40 ? '#f59e0b' : '#10b981')}">${p.label}</div>
                <div class="point-vis">~${formatIndianNumber(p.visitors)}</div>
              </div>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    mount.querySelectorAll('.forecast-day-btn').forEach(btn => {
      btn.onclick = () => {
        this.forecastDay = btn.dataset.day;
        travelState.setDate(btn.dataset.day);
        this.renderCrowdForecastCurve();
      };
    });
  }

  renderRecommendations() {
    const stack = document.getElementById('recommendations-stack');
    if (!stack) return;

    let attractions = this.locationData.attractions || [];
    const city = this.locationData.name;

    // Apply cultural intent filter
    if (this.activeIntentFilter === 'optimal') {
      attractions = attractions.filter(a => a.status === 'optimal');
    } else if (this.activeIntentFilter !== 'all') {
      attractions = attractions.filter(a => a.category === this.activeIntentFilter);
    }

    if (attractions.length === 0) {
      stack.innerHTML = `
        <div style="text-align:center; padding:48px 24px; color:var(--text-muted); background:var(--roam-surface); border:1px solid var(--border-subtle); border-radius:var(--radius-lg);">
          No destinations matching this filter. Try selecting <strong>All Places</strong> above.
        </div>
      `;
      return;
    }

    stack.innerHTML = attractions.map(a => {
      const isCritical = a.status === 'critical';
      const isOptimal = a.status === 'optimal';
      const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(a.name + ', ' + city)}`;
      const best = a.bestTime || { bestHours: '08:30 — 10:00', avoidHours: '12:00 — 14:00', why: 'Pleasant lighting and shorter queues.' };

      return `
        <div class="story-rec-card ${isCritical ? 'card-critical-congested' : 'card-optimal-surrogate'}" data-id="${a.id}">
          
          <!-- Top Header Strip -->
          <div class="story-header-row">
            <div>
              <span class="badge ${isCritical ? 'badge-critical' : 'badge-optimal'}">
                ${isCritical ? 'VERY CROWDED' : 'ROOM AVAILABLE'}
              </span>
              <span style="font-size:0.75rem; color:var(--text-muted); margin-left:8px; font-family:var(--font-mono);">
                ${a.category.toUpperCase()} • ${a.openHours || 'Open Today'}
              </span>
            </div>

            <!-- Best Time Pill -->
            <div class="best-time-chip">
              <span class="best-time-icon">⏰</span>
              <span>Best: <strong>${best.bestHours}</strong></span>
            </div>
          </div>

          <!-- Destination Name & Description -->
          <div style="margin-top:10px;">
            <h3 style="font-size:1.25rem; font-weight:900; color:#fff; margin-bottom:4px;">${a.name}</h3>
            <p style="font-size:0.86rem; color:var(--text-secondary); line-height:1.45; margin-bottom:12px;">
              ${a.description || ''}
            </p>
          </div>

          <!-- "What Will It Be Like Then?" Interactive Time Slider -->
          <div class="time-slider-container">
            <div class="time-slider-header">
              <span class="time-slider-title">WHAT WILL IT BE LIKE THEN?</span>
              <span class="time-slider-dynamic-readout" id="readout-${a.id}">
                At <strong>12:00</strong>: ~${formatIndianNumber(a.currentVisitors)} visitors (Very Busy)
              </span>
            </div>

            <div class="time-slider-track-wrap">
              <input type="range" min="8" max="20" value="12" step="1" class="roam-time-slider" data-id="${a.id}" id="slider-${a.id}">
              <div class="slider-hour-marks">
                <span>08:00</span>
                <span>10:00</span>
                <span>12:00</span>
                <span>14:00</span>
                <span>17:00</span>
                <span>20:00</span>
              </div>
            </div>
          </div>

          <!-- Human Metrics Grid -->
          <div class="human-metrics-grid" style="margin-top:14px;">
            <div class="metric-pill">
              <span class="metric-pill-label">Estimated Crowd</span>
              <span class="metric-pill-value" style="color:${isCritical ? '#ef4444' : 'var(--load-optimal)'};" id="metric-crowd-${a.id}">
                ~${formatIndianNumber(a.currentVisitors)} people
              </span>
            </div>

            <div class="metric-pill">
              <span class="metric-pill-label">Expected Wait</span>
              <span class="metric-pill-value" id="metric-wait-${a.id}">
                ${formatWaitTime(a.currentWaitMinutes || 0)}
              </span>
            </div>

            <div class="metric-pill">
              <span class="metric-pill-label">Entry Fee</span>
              <span class="metric-pill-value" style="color:var(--brand-cyan);">
                ${a.entryFeeINR === 0 ? 'Free Entry' : '₹' + a.entryFeeINR}
              </span>
            </div>
          </div>

          <!-- Best Time Advice Box -->
          <div class="visiting-advice-box">
            <div style="font-size:0.75rem; font-weight:800; color:var(--text-muted); text-transform:uppercase; margin-bottom:4px;">
              VISITOR INTELLIGENCE
            </div>
            <div style="font-size:0.83rem; color:var(--text-secondary); line-height:1.4;">
              <span style="color:var(--load-optimal); font-weight:700;">Why go then:</span> ${best.why}
              ${isCritical ? `<div style="color:#ef4444; font-weight:700; margin-top:3px;">Avoid: ${best.avoidHours} (Peak bus congestion)</div>` : ''}
            </div>
          </div>

          <!-- Card Actions (Add to Plan + Google Maps Link) -->
          <div class="story-actions-row">
            <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="story-maps-link">
              OPEN IN MAPS ↗
            </a>

            <button class="btn btn-primary btn-sm add-to-plan-btn" data-id="${a.id}">
              + ADD TO MY PLAN
            </button>
          </div>
        </div>
      `;
    }).join('');

    this.attachCardEventListeners();
  }

  attachCardEventListeners() {
    const stack = document.getElementById('recommendations-stack');
    if (!stack) return;

    // Time Sliders
    stack.querySelectorAll('.roam-time-slider').forEach(slider => {
      slider.oninput = (e) => {
        const hour = parseInt(e.target.value, 10);
        const id = e.target.dataset.id;
        const timeStr = `${hour < 10 ? '0' : ''}${hour}:00`;

        const att = (this.locationData.attractions || []).find(a => a.id === id);
        if (!att) return;

        let vis = att.currentVisitors;
        let label = 'Moderate';
        let color = '#f59e0b';
        let wait = '15 min wait';

        if (hour >= 11 && hour <= 14) {
          vis = Math.round(att.capacityMax * 0.92);
          label = 'Very Busy';
          color = '#ef4444';
          wait = '50+ min wait';
        } else if (hour <= 9 || hour >= 18) {
          vis = Math.round(att.capacityMax * 0.22);
          label = 'Quiet';
          color = 'var(--load-optimal)';
          wait = '< 10 min wait';
        } else {
          vis = Math.round(att.capacityMax * 0.58);
          label = 'Moderate';
          color = '#f59e0b';
          wait = '25 min wait';
        }

        const readout = document.getElementById(`readout-${id}`);
        if (readout) {
          readout.innerHTML = `At <strong>${timeStr}</strong>: <span style="color:${color}; font-weight:800;">~${formatIndianNumber(vis)} visitors (${label})</span>`;
        }

        const crowdMetric = document.getElementById(`metric-crowd-${id}`);
        if (crowdMetric) {
          crowdMetric.style.color = color;
          crowdMetric.textContent = `~${formatIndianNumber(vis)} people`;
        }

        const waitMetric = document.getElementById(`metric-wait-${id}`);
        if (waitMetric) {
          waitMetric.textContent = wait;
        }
      };
    });

    // Add To Plan buttons
    stack.querySelectorAll('.add-to-plan-btn').forEach(btn => {
      btn.onclick = () => {
        const att = (this.locationData.attractions || []).find(a => a.id === btn.dataset.id);
        if (att && this.app && this.app.planController) {
          this.app.planController.addPlace({
            name: att.name,
            category: att.category || 'heritage',
            durationMinutes: att.averageVisitMinutes || 90,
            status: att.status,
            visitors: att.currentVisitors,
            coords: att.coords
          });
          if (this.app.modalController) {
            this.app.modalController.showToast(`Added ${att.name} to your Plan!`);
          }
          this.app.switchMode('plan');
        }
      };
    });
  }

  renderRerouteBanner() {
    const banner = document.getElementById('hero-balance-cta');
    if (banner) {
      banner.onclick = () => {
        this.isRerouted = !this.isRerouted;
        banner.innerHTML = this.isRerouted 
          ? '<span>✓ JOURNEY BALANCED</span>' 
          : '<span>⚡ BALANCE MY JOURNEY</span>';
        this.renderHealthBar();
        if (this.map) this.map.render();
      };
    }
  }
}
