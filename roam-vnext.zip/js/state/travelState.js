/**
 * ROAM Centralized Travel Planning Reactive State (V3)
 * Single Source of Truth connecting PLAN + CROWD FORECAST + MARKET + MAP
 *
 * Manages:
 * - currentLocation (Jaipur, Varanasi, Mumbai, Kochi, Leh, Delhi)
 * - selectedDate ('today', 'tomorrow', 'your_day')
 * - userInterests (Set: 'food', 'shopping', 'history', 'architecture', 'culture', 'nature', 'local_life', 'relaxed')
 * - itinerary (array of sequential stops with dynamic start times, transit, crowds, status)
 * - focusedItemId (ID of item whose crowd curve & map node are highlighted)
 * - dayHealth (BALANCED | TOO CROWDED | TOO MUCH TRAVEL | GOOD FLOW with actionable reasoning)
 * - openSlots (free gaps >= 60m between stops)
 * - dynamic recommendations & "What Should I Do Next?"
 */

import { formatIndianNumber } from '../utils/formatters.js';

class TravelStateManager {
  constructor() {
    this.location = null;
    this.selectedDate = 'today';
    this.userInterests = new Set(['history', 'culture', 'shopping', 'food']);
    this.itinerary = [];
    this.focusedItemId = null;
    this.dayHealth = {
      status: 'BALANCED',
      label: '● BALANCED',
      headline: 'Schedule is Well-Paced',
      description: 'Stops are planned during optimal hours with smooth transit and low queue fatigue.',
      color: '#10b981',
      fixAction: null
    };
    this.openSlots = [];
    this.subscribers = [];
  }

  // --- Subscription Management ---
  subscribe(fn) {
    this.subscribers.push(fn);
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== fn);
    };
  }

  notify(event, data = {}) {
    this.subscribers.forEach(fn => {
      try {
        fn(event, { state: this, ...data });
      } catch (err) {
        console.error('[TravelState] Subscriber error:', err);
      }
    });
  }

  // --- Location & Schedule Initialization ---
  setLocation(locationData) {
    this.location = locationData;
    this.buildDefaultSchedule();
    this.recalculate();
    this.notify('location:changed', { location: locationData });
  }

  buildDefaultSchedule() {
    if (!this.location) return;
    const city = this.location.id;

    if (city === 'jaipur') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '09:00',
          durationMinutes: 120,
          name: 'Amber Fort',
          category: 'heritage',
          icon: '🏛️',
          expectedVisitors: 420,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet',
          coords: { x: 550, y: 110, lat: 26.9855, lng: 75.8513 }
        },
        {
          id: 'step-2',
          time: '11:45',
          durationMinutes: 60,
          name: 'Rawat Mishthan Bhandar',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 680,
          crowdStatus: 'optimal',
          crowdLabel: 'Fresh & Uncrowded',
          coords: { x: 420, y: 460, lat: 26.9196, lng: 75.7994 }
        },
        {
          id: 'step-3',
          time: '13:15',
          durationMinutes: 90,
          name: 'Albert Hall Museum',
          category: 'culture',
          icon: '🎨',
          expectedVisitors: 310,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet & Cool',
          coords: { x: 480, y: 550, lat: 26.9116, lng: 75.8195 }
        },
        {
          id: 'step-4',
          time: '16:00',
          durationMinutes: 75,
          name: 'Bapu Bazaar Traditional Shopping',
          category: 'shopping',
          icon: '🛍️',
          expectedVisitors: 700,
          crowdStatus: 'optimal',
          crowdLabel: 'Moderate',
          coords: { x: 490, y: 440, lat: 26.9182, lng: 75.8224 }
        },
        {
          id: 'step-5',
          time: '18:00',
          durationMinutes: 90,
          name: 'Sunset at Nahargarh Ramparts',
          category: 'nature',
          icon: '🌅',
          expectedVisitors: 650,
          crowdStatus: 'optimal',
          crowdLabel: 'Golden Hour View',
          coords: { x: 450, y: 280, lat: 26.9388, lng: 75.8183 }
        }
      ];
    } else if (city === 'varanasi') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '06:00',
          durationMinutes: 90,
          name: 'Assi Ghat Sunrise & Rowing Boat',
          category: 'spiritual',
          icon: '🚣',
          expectedVisitors: 320,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Dawn',
          coords: { x: 540, y: 550, lat: 25.2895, lng: 83.0068 }
        },
        {
          id: 'step-2',
          time: '08:00',
          durationMinutes: 60,
          name: 'Morning Hing Kachori in Thatheri Gali',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 450,
          crowdStatus: 'optimal',
          crowdLabel: 'Fresh & Quiet',
          coords: { x: 490, y: 310, lat: 25.3122, lng: 83.0118 }
        },
        {
          id: 'step-3',
          time: '13:30',
          durationMinutes: 90,
          name: 'Kashi Vishwanath Temple Corridor',
          category: 'spiritual',
          icon: '🏛️',
          expectedVisitors: 850,
          crowdStatus: 'optimal',
          crowdLabel: 'Off-Peak Midday',
          coords: { x: 505, y: 320, lat: 25.3109, lng: 83.0107 }
        },
        {
          id: 'step-4',
          time: '15:30',
          durationMinutes: 90,
          name: 'Madanpura Handloom Silk Guild',
          category: 'crafts',
          icon: '🧵',
          expectedVisitors: 280,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Workshop',
          coords: { x: 470, y: 360, lat: 25.3025, lng: 83.0035 }
        },
        {
          id: 'step-5',
          time: '18:00',
          durationMinutes: 90,
          name: 'Ganga Maha Aarti from Riverboat',
          category: 'spiritual',
          icon: '🪔',
          expectedVisitors: 2100,
          crowdStatus: 'critical',
          crowdLabel: 'Very Busy',
          coords: { x: 520, y: 340, lat: 25.3075, lng: 83.0105 }
        }
      ];
    } else {
      const atts = (this.location.attractions || []).slice(0, 4);
      let hour = 9;
      this.itinerary = atts.map((a, idx) => {
        const timeStr = `${hour < 10 ? '0' : ''}${hour}:00`;
        hour += 2;
        return {
          id: `step-${idx + 1}`,
          time: timeStr,
          durationMinutes: a.averageVisitMinutes || 90,
          name: a.name,
          category: a.category || 'heritage',
          icon: a.category === 'nature' ? '🌿' : (a.category === 'food' ? '🍛' : '🏛️'),
          expectedVisitors: a.currentVisitors || 500,
          crowdStatus: a.status || 'optimal',
          crowdLabel: a.status === 'optimal' ? 'Quiet' : (a.status === 'critical' ? 'Very Busy' : 'Moderate'),
          coords: a.coords || { x: 400 + idx * 30, y: 300 + idx * 40, lat: 26.9, lng: 75.8 }
        };
      });
    }

    this.focusedItemId = this.itinerary[0] ? this.itinerary[0].id : null;
  }

  // --- Time Helpers ---
  timeToMins(tStr) {
    if (!tStr) return 9 * 60;
    const parts = tStr.split(':').map(Number);
    return (parts[0] || 0) * 60 + (parts[1] || 0);
  }

  minsToTime(mins) {
    mins = (mins + 24 * 60) % (24 * 60);
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h < 10 ? '0' : ''}${h}:${m < 10 ? '0' : ''}${m}`;
  }

  // --- Preferences & Date ---
  setDate(dateKey) {
    this.selectedDate = dateKey;
    this.recalculate();
    this.notify('date:changed', { date: dateKey });
  }

  toggleInterest(interestId) {
    if (this.userInterests.has(interestId)) {
      if (this.userInterests.size > 1) {
        this.userInterests.delete(interestId);
      }
    } else {
      this.userInterests.add(interestId);
    }
    this.recalculate();
    this.notify('interests:changed', { interests: Array.from(this.userInterests) });
  }

  hasInterest(interestId) {
    return this.userInterests.has(interestId);
  }

  // --- Focused Item for Connected Curve & Map ---
  setFocusedItem(id) {
    this.focusedItemId = id;
    this.notify('focus:changed', { id });
  }

  getFocusedItem() {
    return this.itinerary.find(item => item.id === this.focusedItemId) || this.itinerary[0] || null;
  }

  // --- Recalculation Engine ---
  recalculate() {
    if (!this.itinerary || this.itinerary.length === 0) {
      this.dayHealth = {
        status: 'BALANCED',
        label: '● BALANCED',
        headline: 'No Activities Scheduled',
        description: 'Add places to your day to begin intelligent crowd and transit analysis.',
        color: '#10b981',
        fixAction: null
      };
      this.openSlots = [];
      return;
    }

    let currentMins = this.timeToMins(this.itinerary[0].time || '09:00');
    let totalTransitMins = 0;
    const conflicts = [];
    this.openSlots = [];

    this.itinerary.forEach((item, idx) => {
      if (idx > 0) {
        const prevItem = this.itinerary[idx - 1];
        const prevEndMins = this.timeToMins(prevItem.time) + (prevItem.durationMinutes || 90);
        
        const explicitMins = this.timeToMins(item.time);
        const autoMins = prevEndMins + (prevItem.transitMinutesToNext || 20);

        if (explicitMins > autoMins) {
          const gapDuration = explicitMins - prevEndMins;
          if (gapDuration >= 60) {
            this.openSlots.push({
              startMins: prevEndMins,
              endMins: explicitMins,
              startTime: this.minsToTime(prevEndMins),
              endTime: this.minsToTime(explicitMins),
              durationMinutes: gapDuration,
              afterItem: prevItem,
              beforeItem: item
            });
          }
          currentMins = explicitMins;
        } else {
          currentMins = autoMins;
          item.time = this.minsToTime(currentMins);
        }
      } else {
        currentMins = this.timeToMins(item.time);
      }

      const hourNum = Math.floor(currentMins / 60);

      const transitToNext = (idx < this.itinerary.length - 1) ? 20 : 0;
      item.transitMinutesToNext = transitToNext;
      totalTransitMins += transitToNext;

      const curve = this.getCrowdCurveForItem(item);
      const scheduledPoint = curve.find(p => {
        const pHour = parseInt(p.hour.split(':')[0], 10);
        return pHour === hourNum || pHour === hourNum - 1 || pHour === hourNum + 1;
      }) || curve[Math.min(curve.length - 1, Math.max(0, Math.floor((hourNum - 8) / 2)))];

      if (scheduledPoint) {
        item.expectedVisitors = scheduledPoint.visitors;
        item.crowdStatus = scheduledPoint.status;
        item.crowdLabel = scheduledPoint.label;
      }

      const isHeritagePeak = (item.category === 'heritage' || item.name.toLowerCase().includes('fort') || item.name.toLowerCase().includes('temple')) &&
                             (hourNum >= 11 && hourNum <= 14) &&
                             (item.expectedVisitors >= 1400 || item.crowdStatus === 'critical');

      if (isHeritagePeak) {
        item.isOvercrowded = true;
        conflicts.push({
          item,
          reason: `Peak queue bottleneck at ${item.time} (~${formatIndianNumber(item.expectedVisitors)} visitors, 50+ min queue)`
        });
      } else {
        item.isOvercrowded = false;
      }
    });

    const lastItem = this.itinerary[this.itinerary.length - 1];
    if (lastItem) {
      const lastEndMins = this.timeToMins(lastItem.time) + (lastItem.durationMinutes || 90);
      if (lastEndMins <= 16 * 60) {
        this.openSlots.push({
          startMins: lastEndMins,
          endMins: 19 * 60,
          startTime: this.minsToTime(lastEndMins),
          endTime: '19:00',
          durationMinutes: (19 * 60) - lastEndMins,
          afterItem: lastItem,
          beforeItem: null
        });
      }
    }

    if (conflicts.length > 0) {
      const conflictItem = conflicts[0].item;
      this.dayHealth = {
        status: 'TOO CROWDED',
        label: '● TOO CROWDED',
        color: '#ef4444',
        headline: `${conflictItem.name} Scheduled at Peak Congestion`,
        description: `Visiting ${conflictItem.name} at ${conflictItem.time} exposes you to ~${formatIndianNumber(conflictItem.expectedVisitors)} visitors and 50+ min wait times. ROAM recommends moving this visit to 08:30.`,
        fixAction: {
          type: 'move_early',
          itemId: conflictItem.id,
          targetTime: '08:30',
          label: 'Move to 08:30 (Quiet)'
        }
      };
    } else if (totalTransitMins > 90) {
      this.dayHealth = {
        status: 'TOO MUCH TRAVEL',
        label: '● TOO MUCH TRAVEL',
        color: '#f59e0b',
        headline: 'High Cross-City Transit Time (~' + totalTransitMins + ' min)',
        description: 'Your route crisscrosses different parts of the city. Re-ordering stops by geographical proximity will save over 35 minutes of transit.',
        fixAction: {
          type: 'balance',
          label: 'Cluster Stops by Zone'
        }
      };
    } else {
      this.dayHealth = {
        status: 'BALANCED',
        label: '● BALANCED',
        color: '#10b981',
        headline: 'Schedule is Well-Paced',
        description: 'Stops are planned during optimal hours with minimal queues, comfortable transit, and room for local exploration.',
        fixAction: null
      };
    }
  }

  // --- Dynamic Crowd Curves for Attractions AND Markets (Requirement 19) ---
  getCrowdCurveForItem(itemOrId) {
    const item = typeof itemOrId === 'string' 
      ? this.itinerary.find(i => i.id === itemOrId)
      : itemOrId;

    const itemName = item?.name || '';

    const att = (this.location?.attractions || []).find(a => 
      a.id === item?.id || a.name.toLowerCase() === itemName.toLowerCase()
    );
    const dateFactor = this.selectedDate === 'tomorrow' ? 0.94 : (this.selectedDate === 'your_day' ? 1.04 : 1);

    if (att && att.crowdCurve && att.crowdCurve.length > 0) {
      return att.crowdCurve.map(p => {
        const visitors = Math.max(0, Math.round(p.visitors * dateFactor));
        const pct = Math.min(100, Math.round((visitors / (att.capacityMax || 2500)) * 100));
        const status = pct >= 80 ? 'critical' : (pct >= 60 ? 'elevated' : 'optimal');
        const label = pct >= 80 ? 'Very Busy' : (pct >= 60 ? 'Moderate' : 'Quieter');
        return { hour: p.hour, visitors, status, label, pct };
      });
    }

    const shop = (this.location?.localBusinesses || []).find(b => 
      b.id === item?.id || b.name.toLowerCase() === itemName.toLowerCase()
    );

    const baseActivity = Math.round((shop?.estimatedActivity || item?.expectedVisitors || 600) * dateFactor);
    const cat = item?.category || shop?.category || 'shopping';

    if (cat === 'markets' || cat === 'shopping' || cat === 'crafts') {
      return [
        { hour: '08:00', visitors: Math.round(baseActivity * 0.35), status: 'optimal', label: 'Quiet', pct: 25 },
        { hour: '10:00', visitors: Math.round(baseActivity * 0.65), status: 'optimal', label: 'Quiet', pct: 45 },
        { hour: '13:00', visitors: Math.round(baseActivity * 0.95), status: 'elevated', label: 'Moderate', pct: 65 },
        { hour: '16:00', visitors: Math.round(baseActivity * 0.85), status: 'optimal', label: 'Quieter', pct: 55 },
        { hour: '18:00', visitors: Math.round(baseActivity * 1.35), status: 'critical', label: 'Busy', pct: 88 },
        { hour: '20:00', visitors: Math.round(baseActivity * 0.70), status: 'optimal', label: 'Quiet', pct: 40 }
      ];
    } else if (cat === 'food') {
      return [
        { hour: '08:00', visitors: Math.round(baseActivity * 0.85), status: 'elevated', label: 'Moderate', pct: 60 },
        { hour: '10:30', visitors: Math.round(baseActivity * 0.40), status: 'optimal', label: 'Quiet', pct: 30 },
        { hour: '13:00', visitors: Math.round(baseActivity * 1.40), status: 'critical', label: 'Very Busy', pct: 90 },
        { hour: '16:00', visitors: Math.round(baseActivity * 0.35), status: 'optimal', label: 'Quiet', pct: 25 },
        { hour: '19:30', visitors: Math.round(baseActivity * 1.30), status: 'critical', label: 'Busy', pct: 85 },
        { hour: '21:30', visitors: Math.round(baseActivity * 0.60), status: 'optimal', label: 'Quiet', pct: 40 }
      ];
    }

    return [
      { hour: '08:30', visitors: Math.round(baseActivity * 0.28), status: 'optimal', label: 'Quiet', pct: 22 },
      { hour: '10:00', visitors: Math.round(baseActivity * 0.75), status: 'elevated', label: 'Moderate', pct: 58 },
      { hour: '12:00', visitors: Math.round(baseActivity * 1.30), status: 'critical', label: 'Very Busy', pct: 94 },
      { hour: '14:00', visitors: Math.round(baseActivity * 1.10), status: 'critical', label: 'Busy', pct: 78 },
      { hour: '16:00', visitors: Math.round(baseActivity * 0.60), status: 'elevated', label: 'Moderate', pct: 46 },
      { hour: '18:00', visitors: Math.round(baseActivity * 0.30), status: 'optimal', label: 'Quiet', pct: 24 }
    ];
  }

  getTimeEditorOptions(item) {
    const curve = this.getCrowdCurveForItem(item);
    return curve.map(p => ({
      time: p.hour,
      visitors: p.visitors,
      status: p.status,
      label: p.label,
      isCurrent: p.hour === item.time || (parseInt(p.hour.split(':')[0], 10) === parseInt(item.time.split(':')[0], 10))
    }));
  }

  getBetterTimeInsight(item) {
    if (!item) return null;
    const curve = this.getCrowdCurveForItem(item);
    const hourNum = parseInt(item.time.split(':')[0], 10);

    if (item.crowdStatus === 'critical' || (hourNum >= 11 && hourNum <= 14)) {
      const quietOption = curve.find(p => p.status === 'optimal') || curve[0];
      const savedVisitors = Math.max(0, item.expectedVisitors - quietOption.visitors);

      return {
        hasBetterTime: true,
        currentHour: item.time,
        currentVisitors: item.expectedVisitors,
        insight: "You're visiting during the busiest part of the day.",
        betterTime: quietOption.hour,
        betterVisitors: quietOption.visitors,
        betterLabel: quietOption.label,
        savedVisitors: savedVisitors,
        actionText: `MOVE TO ${quietOption.hour}`
      };
    }

    return null;
  }

  getWhatShouldIDoNext() {
    if (!this.location) return null;

    const businesses = this.location.localBusinesses || [];
    const existingNames = new Set(this.itinerary.map(i => i.name.toLowerCase()));
    const unvisited = businesses.filter(b => !existingNames.has(b.name.toLowerCase()));

    const matches = unvisited.map(b => {
      let score = 10;
      if (this.userInterests.has(b.category)) score += 20;
      if (b.activityStatus === 'QUIET') score += 15;
      if (b.distanceKm <= 1.5) score += 10;
      return { ...b, matchScore: score };
    }).sort((a, b) => b.matchScore - a.matchScore);

    const topPick = matches[0] || businesses[0];
    if (!topPick) return null;

    const activeSlot = this.openSlots[0];
    const availableMinutes = activeSlot ? activeSlot.durationMinutes : 90;

    return {
      availableMinutes,
      pick: topPick,
      headline: `YOU HAVE ${availableMinutes} MINUTES BEFORE YOUR NEXT STOP.`,
      title: topPick.name,
      visitors: topPick.estimatedActivity || 700,
      distanceKm: topPick.distanceKm || 1.2,
      transitMinutes: topPick.transitMinutes || 12,
      specialty: topPick.specialty || 'Traditional Artisanal Experience',
      why: `It fits your available ${availableMinutes} min free window and is expected to be quieter than main corridors.`
    };
  }

  addPlaceIntelligently(place) {
    const category = place.category || 'shopping';
    const duration = place.durationMinutes || (category === 'food' ? 60 : 75);
    const placeName = place.name;

    let targetSlot = this.openSlots.find(s => s.durationMinutes >= duration);

    let insertedTime = '16:00';
    let slotReason = 'Placed in your afternoon open window.';

    if (targetSlot) {
      insertedTime = targetSlot.startTime;
      slotReason = `Fits between ${targetSlot.afterItem?.name || 'morning visits'} and ${targetSlot.beforeItem?.name || 'evening dinner'}.`;
    } else {
      if (category === 'food') {
        insertedTime = '12:30';
        slotReason = 'Scheduled for midday lunch.';
      } else if (category === 'shopping' || category === 'markets' || category === 'crafts') {
        insertedTime = '16:00';
        slotReason = 'Scheduled for late afternoon bazaar walk.';
      } else {
        const lastItem = this.itinerary[this.itinerary.length - 1];
        if (lastItem) {
          const nextMins = this.timeToMins(lastItem.time) + (lastItem.durationMinutes || 90) + 20;
          insertedTime = this.minsToTime(nextMins);
          slotReason = `Added after ${lastItem.name}.`;
        } else {
          insertedTime = '10:00';
          slotReason = 'Starting your day schedule.';
        }
      }
    }

    const newItem = {
      id: 'step-' + Date.now(),
      time: insertedTime,
      durationMinutes: duration,
      name: placeName,
      category: category,
      icon: category === 'food' ? '🍛' : (category === 'markets' || category === 'shopping' ? '🛍️' : (category === 'nature' ? '🌿' : '🏛️')),
      expectedVisitors: place.estimatedActivity || place.visitors || 650,
      crowdStatus: place.status || 'optimal',
      crowdLabel: 'Quiet',
      coords: place.coords || { x: 490, y: 440, lat: 26.9182, lng: 75.8224 }
    };

    this.itinerary.push(newItem);
    this.itinerary.sort((a, b) => this.timeToMins(a.time) - this.timeToMins(b.time));

    this.focusedItemId = newItem.id;
    this.recalculate();
    this.notify('itinerary:updated', { addedItem: newItem, slotReason });

    return {
      item: newItem,
      time: insertedTime,
      reason: slotReason
    };
  }

  updateItemTime(id, newTimeStr) {
    const item = this.itinerary.find(i => i.id === id);
    if (item) {
      item.time = newTimeStr;
      this.recalculate();
      this.notify('itinerary:updated', { updatedId: id });
    }
  }

  updateItemDuration(id, newDurationMinutes) {
    const item = this.itinerary.find(i => i.id === id);
    if (item) {
      item.durationMinutes = parseInt(newDurationMinutes, 10);
      this.recalculate();
      this.notify('itinerary:updated', { updatedId: id });
    }
  }

  removeItem(id) {
    this.itinerary = this.itinerary.filter(i => i.id !== id);
    if (this.focusedItemId === id) {
      this.focusedItemId = this.itinerary[0]?.id || null;
    }
    this.recalculate();
    this.notify('itinerary:updated', { removedId: id });
  }

  moveItem(id, direction) {
    const idx = this.itinerary.findIndex(i => i.id === id);
    if (idx === -1) return;
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= this.itinerary.length) return;

    const temp = this.itinerary[idx];
    this.itinerary[idx] = this.itinerary[targetIdx];
    this.itinerary[targetIdx] = temp;

    this.recalculate();
    this.notify('itinerary:updated', { movedId: id });
  }

  balanceDay() {
    if (!this.itinerary || this.itinerary.length === 0) return null;

    const currentPlan = JSON.parse(JSON.stringify(this.itinerary));
    const balancedPlan = JSON.parse(JSON.stringify(this.itinerary));

    const categoryPriority = {
      spiritual: 1,
      heritage: 1,
      food: 2,
      culture: 3,
      shopping: 4,
      markets: 4,
      crafts: 4,
      nature: 5
    };

    balancedPlan.sort((a, b) => {
      const pA = categoryPriority[a.category] || 3;
      const pB = categoryPriority[b.category] || 3;
      return pA - pB;
    });

    let currentMins = 8 * 60 + 30; // 08:30 AM
    balancedPlan.forEach((item, idx) => {
      item.time = this.minsToTime(currentMins);
      item.crowdStatus = 'optimal';
      item.crowdLabel = 'Quiet & Cool';
      item.isOvercrowded = false;
      currentMins += (item.durationMinutes || 90) + 25;
    });

    const whyPoints = [
      'Less crowd: Major monument moved to 08:30 skips tour bus convoys and 65-minute ticketing queues.',
      'Less waiting: Scheduled visits coincide with off-peak lulls.',
      'Better travel flow: Stops flow geographically from north fortress to central old city to southern ramparts.',
      'More time for local experiences: An open late-afternoon window enables unhurried artisan guild exploration.'
    ];

    return {
      currentPlan,
      balancedPlan,
      whyPoints
    };
  }

  applyBalancedSchedule(newSchedule) {
    this.itinerary = newSchedule;
    this.recalculate();
    this.notify('itinerary:updated', { balanced: true });
  }
}

export const travelState = new TravelStateManager();
