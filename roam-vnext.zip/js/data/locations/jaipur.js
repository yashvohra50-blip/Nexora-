/**
 * ROAM — Jaipur Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const JAIPUR_DATA = {
  "id": "jaipur",
  "name": "Jaipur",
  "type": "CITY",
  "state": "Rajasthan",
  "district": "Jaipur",
  "region": "NORTH",
  "culturalRegion": "Dhundhar & Shekhawati Gateway",
  "tagline": "The Pink City",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE PINK CITY HAS A FLOW.",
    "subheadline": "ROAM detected 3 severely congested monuments and 7 tranquil, high-quality surrogates across the Dhundhar corridor.",
    "overloadedCount": 3,
    "underutilizedCount": 7
  },
  "metrics": {
    "totalDailyTourists": 48500,
    "averageAttractionLoad": 64,
    "visitorConcentration": 82,
    "tourismDistributionStatus": "Critical Concentration",
    "localBusinessOpportunity": "High Opportunity",
    "monumentsAtRisk": 3,
    "avgWaitTimeMinutes": 42,
    "localEconomyCapturePct": 14
  },
  "culturalDNA": {
    "knownFor": [
      "Royal Rajput Architecture & Symmetrical Havelis",
      "Hand-Block Printing & Natural Vegetable Dyes",
      "Kundan, Meenakari & Polki Gem Jewellery",
      "UNESCO World Heritage Walled City Plan"
    ],
    "taste": [
      "Pyaaz Ki Kachori (Crisp flaky pastry stuffed with spiced caramelized onions)",
      "Dal Baati Churma (Baked whole wheat dumplings with 5-lentil curry & ghee)",
      "Laal Maas (Slow-cooked mutton with fiery Mathania chilies & cloves)",
      "Ghewar & Mawa Kachori (Honeycomb disc soaked in saffron syrup)"
    ],
    "architecture": [
      "Hawa Mahal (953 latticed honeycomb jharokhas)",
      "Amber Fort (High ramparts & mirror mosaic Sheesh Mahal)",
      "City Palace (Chandra Mahal & peacock courtyard)",
      "Panna Meena Ka Kund (Geometric 16th-century stepwell)",
      "Albert Hall Museum (Indo-Saracenic royal museum)"
    ],
    "markets": [
      "Johari Bazaar (World-famous jewellery & tie-dye bandhani)",
      "Bapu Bazaar (Everyday traditional textiles & mojari juttis)",
      "Kishanpole Bazaar (Wooden carvings, block prints & lac work)",
      "Tripolia Bazaar (Lac bangles, brass utensils & iron crafts)"
    ],
    "festivals": [
      "Gangaur Festival (Royal procession of Goddess Gauri through Tripolia gate)",
      "Teej Festival (Monsoon swings, leheriya dupattas, and folk processions)",
      "Jaipur Literature Festival (Diggi Palace annual literary gathering)"
    ],
    "localRhythm": "Start with the old walled city early morning for kachori and quiet streets, explore a local craft bazaar in the afternoon, and watch the sun set over the Aravallis from Nahargarh ramparts."
  },
  "liveLikeALocal": [
    {
      "icon": "☼",
      "title": "Morning Kachori at 07:30",
      "description": "Head to Rawat Mishthan Bhandar on Station Road before the tourist buses arrive for piping hot Pyaaz Kachori straight from the iron kadai."
    },
    {
      "icon": "🛍️",
      "title": "Bapu Bazaar Without Tour Guides",
      "description": "Explore the pink arcade lanes of Bapu Bazaar for authentic block-print cotton kurtas and leather mojaris at genuine local retail prices."
    },
    {
      "icon": "☕",
      "title": "Chai on MI Road",
      "description": "Stop at Gulab Ji Chai for ginger-infused masala chai served in earthen clay kulhads accompanied by bun-muska."
    },
    {
      "icon": "🌇",
      "title": "Sunset at Nahargarh Ramparts",
      "description": "Skip the overcrowded palace rooftops; climb Nahargarh Fort’s stone bastions to watch the entire Pink City glow amber in the evening."
    },
    {
      "icon": "🍽️",
      "title": "Pure Rajasthani Thali off the Corridor",
      "description": "Dine at an authentic bhojanalaya in Kishanpole Bazaar for limitless baati, churma, gatte ki sabzi, and fresh buttermilk."
    }
  ],
  "attractions": [
    {
      "id": "amber-fort",
      "name": "Amber Fort",
      "category": "heritage",
      "coords": {
        "x": 550,
        "y": 110,
        "lat": 26.9855,
        "lng": 75.8513
      },
      "capacityMax": 5000,
      "currentVisitors": 4700,
      "loadPercentage": 94,
      "status": "critical",
      "averageVisitMinutes": 150,
      "entryFeeINR": 500,
      "currentWaitMinutes": 65,
      "openHours": "08:00 — 17:30",
      "description": "Opulent hillside fort-palace renowned for mirror-mosaic Sheesh Mahal and Rajput-Mughal ramparts.",
      "whyCongested": "Tour bus convoys converge at Suraj Pol between 09:30 and 11:30 AM; single-file ticketing ramps create a 65-minute queue.",
      "roamResponse": "Redirect demand toward Albert Hall Museum (34% load, 0m wait) and Panna Meena Ka Kund stepwell (18% load, 5 min north).",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "albert-hall",
      "secondaryAlternativeId": "panna-meena",
      "nearbyBusinessIds": [
        "anokhi-handblock",
        "bapu-bazaar"
      ],
      "bestTime": {
        "bestHours": "08:00 — 09:30",
        "avoidHours": "11:00 — 14:00",
        "why": "Early morning avoids tour bus convoys, severe midday sun on the stone ramparts, and has minimal ticket queues."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 971,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 1216,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 1460,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 1705,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 1950,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 1705,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "14:00",
          "visitors": 1460,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 1216,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 971,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 726,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 695,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 695,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 695,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "hawa-mahal",
      "name": "Hawa Mahal",
      "category": "heritage",
      "coords": {
        "x": 510,
        "y": 390,
        "lat": 26.9239,
        "lng": 75.8267
      },
      "capacityMax": 2500,
      "currentVisitors": 2275,
      "loadPercentage": 91,
      "status": "critical",
      "averageVisitMinutes": 50,
      "entryFeeINR": 200,
      "currentWaitMinutes": 45,
      "openHours": "09:00 — 17:00",
      "description": "Iconic 5-story pink honeycomb palace with 953 jharokhas built for royal women to view city processions.",
      "whyCongested": "Sireh Deori street curbside parking bottlenecks tour vans; narrow interior spiral stairs limit throughput to 12 persons/min.",
      "roamResponse": "Reroute visitors to Royal Gaitor Cenotaphs (26% load, pristine carved marble chhatris in peaceful canyon).",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "royal-gaitor",
      "secondaryAlternativeId": "sisodia-rani",
      "nearbyBusinessIds": [
        "johari-bazaar",
        "laxmi-misthan"
      ],
      "bestTime": {
        "bestHours": "08:30 — 10:00",
        "avoidHours": "12:00 — 15:30",
        "why": "Morning golden sunlight hits the pink honeycomb facade directly from the east, perfect for photos without roadside crowds."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 544,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 731,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 918,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 1106,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 1293,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 1480,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "14:00",
          "visitors": 1293,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "15:00",
          "visitors": 1106,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 918,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 731,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "18:00",
          "visitors": 544,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 521,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 521,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "city-palace",
      "name": "City Palace",
      "category": "heritage",
      "coords": {
        "x": 480,
        "y": 360,
        "lat": 26.9258,
        "lng": 75.8237
      },
      "capacityMax": 3500,
      "currentVisitors": 3045,
      "loadPercentage": 87,
      "status": "critical",
      "averageVisitMinutes": 120,
      "entryFeeINR": 700,
      "currentWaitMinutes": 40,
      "openHours": "09:30 — 17:00",
      "description": "Royal residence combining Rajput, Mughal, and European architecture with courtyards, museums, and the Peacock Gate.",
      "whyCongested": "Pritam Niwas Chowk peacock doorways create a selfie bottleneck; shared courtyard access with Jantar Mantar crowds.",
      "roamResponse": "Divert toward Vidyadhar Garden (21% load) and Anokhi Museum of Hand Printing.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "vidyadhar-garden",
      "secondaryAlternativeId": "albert-hall",
      "nearbyBusinessIds": [
        "tripolia-bazaar",
        "kishanpole-bazaar"
      ],
      "bestTime": {
        "bestHours": "09:30 — 10:45",
        "avoidHours": "13:00 — 15:30",
        "why": "Museum courtyards are peaceful before noon, allowing unhurried viewing of royal textile and arms collections."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 603,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 628,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 826,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 1025,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 1223,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "13:00",
          "visitors": 1422,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "14:00",
          "visitors": 1620,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "15:00",
          "visitors": 1422,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "16:00",
          "visitors": 1223,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 1025,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "18:00",
          "visitors": 826,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "19:00",
          "visitors": 628,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 603,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "jantar-mantar",
      "name": "Jantar Mantar",
      "category": "heritage",
      "coords": {
        "x": 500,
        "y": 375,
        "lat": 26.9248,
        "lng": 75.8246
      },
      "capacityMax": 2000,
      "currentVisitors": 1560,
      "loadPercentage": 78,
      "status": "elevated",
      "averageVisitMinutes": 75,
      "entryFeeINR": 200,
      "currentWaitMinutes": 25,
      "openHours": "09:00 — 17:00",
      "description": "UNESCO World Heritage 18th-century astronomical observatory featuring the world’s largest stone sundial, the Vrihat Samrat Yantra.",
      "whyCongested": "Adjacent to City Palace; tour groups spill over directly after palace visits.",
      "roamResponse": "Suggest visiting during late afternoon or pairing with Albert Hall.",
      "crowdTrend": "steady",
      "pairedAlternativeId": "albert-hall",
      "secondaryAlternativeId": "royal-gaitor",
      "nearbyBusinessIds": [
        "johari-bazaar",
        "tripolia-bazaar"
      ],
      "bestTime": {
        "bestHours": "10:00 — 11:30",
        "avoidHours": "12:30 — 14:30",
        "why": "Midday shadows can be read on the stone instruments, but afternoon stone heat can be intense; late morning is optimal."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 550,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 687,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 825,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 962,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 1100,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 962,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "14:00",
          "visitors": 825,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 687,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 550,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 412,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 395,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 395,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 395,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "albert-hall",
      "name": "Albert Hall Museum",
      "category": "culture",
      "coords": {
        "x": 480,
        "y": 550,
        "lat": 26.9116,
        "lng": 75.8195
      },
      "capacityMax": 3000,
      "currentVisitors": 1020,
      "loadPercentage": 34,
      "status": "optimal",
      "averageVisitMinutes": 90,
      "entryFeeINR": 300,
      "currentWaitMinutes": 0,
      "openHours": "09:00 — 17:00 • Night: 19:00 — 22:00",
      "description": "Rajasthan’s oldest museum set in Ram Niwas Garden, showcasing Persian carpets, miniature paintings, ivory carvings, and an Egyptian mummy.",
      "whyCongested": "Located outside the walled city core; often skipped by hurried package tours despite world-class collections.",
      "roamResponse": "PRIMARY SURROGATE: Air-cooled interior galleries, zero queue, magnificent Indo-Saracenic towers, and peaceful gardens.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "amber-fort",
      "nearbyBusinessIds": [
        "jaipur-blue-pottery",
        "bapu-bazaar"
      ],
      "bestTime": {
        "bestHours": "13:30 — 16:00",
        "avoidHours": "None (Room all day)",
        "why": "Spacious high-ceiling galleries offer a cool, tranquil cultural oasis when outdoor monuments are at peak heat and congestion."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 259,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 259,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 268,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 338,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 409,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "13:00",
          "visitors": 479,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 550,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "15:00",
          "visitors": 620,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "16:00",
          "visitors": 550,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "17:00",
          "visitors": 479,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "18:00",
          "visitors": 409,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "19:00",
          "visitors": 338,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "20:00",
          "visitors": 268,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "panna-meena",
      "name": "Panna Meena Ka Kund",
      "category": "nature",
      "coords": {
        "x": 570,
        "y": 95,
        "lat": 26.9886,
        "lng": 75.8576
      },
      "capacityMax": 800,
      "currentVisitors": 144,
      "loadPercentage": 18,
      "status": "optimal",
      "averageVisitMinutes": 45,
      "entryFeeINR": 0,
      "currentWaitMinutes": 0,
      "openHours": "07:00 — 18:00",
      "description": "Hypnotic 16th-century criss-cross symmetrical stepwell tucked beside Amber Fort, historically used for community gathering and monsoon cooling.",
      "whyCongested": "Most visitors remain trapped in the upper fort parking lot, completely missing this quiet architectural marvel 5 minutes away.",
      "roamResponse": "PRIMARY SURROGATE: Quiet, free admission, striking optical architecture, and adjacent to authentic artisan workshops.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "amber-fort",
      "nearbyBusinessIds": [
        "anokhi-handblock"
      ],
      "bestTime": {
        "bestHours": "08:00 — 11:00 or 16:00 — 17:30",
        "avoidHours": "None (Very quiet)",
        "why": "Gentle angled light brings out the deep relief in the geometric stone staircases without crowds."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 133,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 159,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 184,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "11:00",
          "visitors": 210,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 184,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 159,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 133,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 108,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 82,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 79,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 79,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 79,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 79,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "royal-gaitor",
      "name": "Royal Gaitor Tumbas",
      "category": "heritage",
      "coords": {
        "x": 440,
        "y": 310,
        "lat": 26.9388,
        "lng": 75.8183
      },
      "capacityMax": 1200,
      "currentVisitors": 312,
      "loadPercentage": 26,
      "status": "optimal",
      "averageVisitMinutes": 60,
      "entryFeeINR": 100,
      "currentWaitMinutes": 0,
      "openHours": "09:00 — 17:00",
      "description": "Intricately carved white marble cenotaphs (chhatris) of Kachwaha rulers nestled in a quiet canyon beneath Nahargarh Fort.",
      "whyCongested": "Peaceful dead-end canyon filters out drive-by tourists; deeply atmospheric and serene.",
      "roamResponse": "PRIMARY SURROGATE for Hawa Mahal crowds: superior hand-carved stone artistry in total tranquility.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "hawa-mahal",
      "nearbyBusinessIds": [
        "kishanpole-bazaar"
      ],
      "bestTime": {
        "bestHours": "10:00 — 13:00",
        "avoidHours": "None (Peaceful)",
        "why": "Quiet canyon setting with dramatic shadowed marble columns."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 174,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 215,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 257,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 298,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 340,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 298,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "14:00",
          "visitors": 257,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 215,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 174,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 132,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 127,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 127,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 127,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "anokhi-handblock",
      "name": "Anokhi Community Block Print Guild",
      "category": "crafts",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Kheri Gate, Amer Old Town",
      "coords": {
        "x": 590,
        "y": 140,
        "lat": 26.9875,
        "lng": 75.8552
      },
      "distanceKm": 0.8,
      "transitMinutes": 10,
      "estimatedActivity": 420,
      "activityStatus": "QUIET",
      "bestTime": "10:00 — 13:00",
      "quietestTime": "14:30 — 17:00",
      "specialty": "Botanical Indigo Hand Printing & Wood Carving",
      "priceRange": "₹350 — ₹2,400",
      "rating": 4.9,
      "reviewsCount": 612,
      "whyRecommended": [
        "10 min walk from Amber Fort lower gate",
        "Direct artisan cooperative supporting 120+ village printers",
        "Watch live master carvers block-print natural dyes",
        "Completely avoids tourist souvenir broker commissions"
      ],
      "roamSays": "An extraordinary haveli workshop where you can observe real botanical block-carving and print your own handkerchief instead of standing in fort queues.",
      "googleMapsQuery": "Anokhi Museum of Hand Printing, Amber, Jaipur"
    },
    {
      "id": "johari-bazaar",
      "name": "Johari Bazaar Jewellery & Bandhani",
      "category": "markets",
      "badge": "POPULAR MARKET",
      "badgeClass": "badge-elevated",
      "zone": "Walled City Central Corridor",
      "coords": {
        "x": 520,
        "y": 410,
        "lat": 26.9215,
        "lng": 75.8285
      },
      "distanceKm": 0.4,
      "transitMinutes": 5,
      "estimatedActivity": 2450,
      "activityStatus": "BUSY",
      "bestTime": "11:00 — 13:30",
      "quietestTime": "10:00 — 11:30",
      "specialty": "Kundan Meenakari, Silver & Bandhani Sarees",
      "priceRange": "₹500 — ₹25,000",
      "rating": 4.8,
      "reviewsCount": 1420,
      "whyRecommended": [
        "Centuries-old royal jewellery street",
        "Unrivaled selection of Kundan and Meenakari enamelwork",
        "Gopalji Ka Rasta alleyway for wholesale silver",
        "Traditional pink colonnaded streetscape"
      ],
      "roamSays": "The undisputed historic epicenter of Rajasthani jewellery. Visit early before noon to browse family goldsmiths without the peak afternoon bustle.",
      "googleMapsQuery": "Johari Bazaar, Pink City, Jaipur"
    },
    {
      "id": "bapu-bazaar",
      "name": "Bapu Bazaar Traditional Shopping",
      "category": "shopping",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Between Sanganeri & New Gate",
      "coords": {
        "x": 490,
        "y": 440,
        "lat": 26.9182,
        "lng": 75.8224
      },
      "distanceKm": 1.2,
      "transitMinutes": 12,
      "estimatedActivity": 1850,
      "activityStatus": "BUSY",
      "bestTime": "10:30 — 12:30",
      "quietestTime": "15:00 — 17:00",
      "specialty": "Mojari Leather Juttis, Cotton Bedsheets & Leheriya",
      "priceRange": "₹200 — ₹1,800",
      "rating": 4.7,
      "reviewsCount": 2180,
      "whyRecommended": [
        "12 min from Hawa Mahal & City Palace",
        "Traditional Jaipur everyday shopping street",
        "Less crowded and more affordable than Johari Bazaar",
        "Famous for camel leather footwear and Jaipuri quilts"
      ],
      "roamSays": "Great if you are looking for authentic block-print textiles, breezy cotton apparel, and handcrafted camel leather footwear at honest local prices.",
      "googleMapsQuery": "Bapu Bazaar, Pink City, Jaipur"
    },
    {
      "id": "kishanpole-bazaar",
      "name": "Kishanpole Bazaar Woodcraft & Textiles",
      "category": "crafts",
      "badge": "HIGH LOCAL INTEREST",
      "badgeClass": "badge-optimal",
      "zone": "Kishanpole Heritage Axis",
      "coords": {
        "x": 460,
        "y": 390,
        "lat": 26.9242,
        "lng": 75.8198
      },
      "distanceKm": 0.6,
      "transitMinutes": 8,
      "estimatedActivity": 720,
      "activityStatus": "QUIET",
      "bestTime": "11:00 — 15:00",
      "quietestTime": "12:00 — 16:00",
      "specialty": "Hand-carved Teak Furniture, Wooden Blocks & Bandhej",
      "priceRange": "₹150 — ₹4,500",
      "rating": 4.8,
      "reviewsCount": 540,
      "whyRecommended": [
        "Substantially calmer than tourist markets",
        "Generational master woodworkers carving on-site",
        "Direct purchase of wooden textile print blocks",
        "Close to traditional vegetarian bhojanalayas"
      ],
      "roamSays": "When the main city palace corridor gets hectic, Kishanpole offers a peaceful glimpse into authentic craft guild trade with open workshops.",
      "googleMapsQuery": "Kishanpole Bazaar, Jaipur"
    },
    {
      "id": "tripolia-bazaar",
      "name": "Tripolia Bazaar Lac Bangles & Metals",
      "category": "markets",
      "badge": "CULTURAL SHOPPING",
      "badgeClass": "badge-optimal",
      "zone": "Tripolia Gate Axis",
      "coords": {
        "x": 480,
        "y": 380,
        "lat": 26.9245,
        "lng": 75.8222
      },
      "distanceKm": 0.5,
      "transitMinutes": 6,
      "estimatedActivity": 1100,
      "activityStatus": "MODERATE",
      "bestTime": "11:30 — 14:00",
      "quietestTime": "16:00 — 18:00",
      "specialty": "Manihaaron Ka Rasta Handcrafted Lac Bangles & Brass",
      "priceRange": "₹80 — ₹1,200",
      "rating": 4.9,
      "reviewsCount": 920,
      "whyRecommended": [
        "Famous Maniharon Ka Rasta lane where lac is melted by hand",
        "Rich centuries-old bangle-making legacy",
        "Direct interaction with generational artisan families",
        "High cultural value and memorable sensory experience"
      ],
      "roamSays": "Watch craftspeople shape hot natural resin into shimmering lac bangles studded with glass beads right before your eyes.",
      "googleMapsQuery": "Tripolia Bazaar, Jaipur"
    },
    {
      "id": "rawat-mishthan",
      "name": "Rawat Mishthan Bhandar",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Station Road Heritage Dining",
      "coords": {
        "x": 420,
        "y": 460,
        "lat": 26.9196,
        "lng": 75.7994
      },
      "distanceKm": 2.8,
      "transitMinutes": 15,
      "estimatedActivity": 1650,
      "activityStatus": "BUSY",
      "bestTime": "07:30 — 10:00",
      "quietestTime": "15:30 — 17:30",
      "specialty": "Original Pyaaz Kachori & Mawa Kachori",
      "priceRange": "₹50 — ₹300",
      "rating": 4.9,
      "reviewsCount": 3850,
      "whyRecommended": [
        "Legendary home of Jaipur’s definitive Pyaaz Kachori",
        "Crispy multi-layered pastry with spiced onion filling",
        "Always fresh out of the kadai with huge daily turnover",
        "Beloved by Jaipur locals for over 50 years"
      ],
      "roamSays": "The gold standard for Rajasthani breakfast. Pair a warm Pyaaz Kachori with their sweet Mawa Kachori for an unbeatable morning start.",
      "googleMapsQuery": "Rawat Mishthan Bhandar, Station Road, Jaipur"
    },
    {
      "id": "jaipur-blue-pottery",
      "name": "Kripal Kumbh & Blue Pottery Guild",
      "category": "crafts",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Bani Park Artisan Enclave",
      "coords": {
        "x": 410,
        "y": 420,
        "lat": 26.9272,
        "lng": 75.7951
      },
      "distanceKm": 3.1,
      "transitMinutes": 16,
      "estimatedActivity": 280,
      "activityStatus": "QUIET",
      "bestTime": "10:30 — 16:30",
      "quietestTime": "11:00 — 15:00",
      "specialty": "Turquoise Quartz Ceramic Vases, Plates & Tiles",
      "priceRange": "₹200 — ₹4,800",
      "rating": 5,
      "reviewsCount": 430,
      "whyRecommended": [
        "Founded by Padma Shri Kripal Singh Shekhawat",
        "Authentic Egyptian-paste quartz pottery (no clay used)",
        "Delicate floral Arabesque motifs in Persian blue",
        "Tranquil showroom away from roadside touts"
      ],
      "roamSays": "The premier center of authentic Jaipur blue pottery. Unlike cheap roadside imitations, their pieces are glazed with original mineral oxides and quartz.",
      "googleMapsQuery": "Kripal Kumbh Blue Pottery, Bani Park, Jaipur"
    }
  ]
};
