/**
 * ROAM — Delhi Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const DELHI_DATA = {
  "id": "delhi",
  "name": "Delhi",
  "type": "CITY",
  "state": "Delhi (NCT)",
  "district": "Central, South & Old Delhi",
  "region": "NORTH",
  "culturalRegion": "Mughal & Lutyens National Capital",
  "tagline": "The Seven Cities of Empire",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE HISTORIC CAPITAL DESERVES BALANCE.",
    "subheadline": "ROAM detected 3 severe transit bottlenecks in Old Delhi and 5 tranquil heritage parks across South Delhi.",
    "overloadedCount": 3,
    "underutilizedCount": 5
  },
  "metrics": {
    "totalDailyTourists": 92000,
    "averageAttractionLoad": 78,
    "visitorConcentration": 87,
    "tourismDistributionStatus": "Critical Old Delhi & India Gate Congestion",
    "localBusinessOpportunity": "High Zari & Culinary Potential",
    "monumentsAtRisk": 3,
    "avgWaitTimeMinutes": 55,
    "localEconomyCapturePct": 15
  },
  "culturalDNA": {
    "knownFor": [
      "Monumental Mughal Forts & UNESCO Tombs",
      "Ancient Qutub Minar Complex with 4th-Century Iron Pillar",
      "300-Year-Old Chandni Chowk Historic Bazaars",
      "Lutyens Grand Axial Rajpath & Rashtrapati Bhavan"
    ],
    "taste": [
      "Old Delhi Nihari & Seekh Kebabs with Roomali Roti",
      "Chandni Chowk Stuffed Paranthas with Pumpkin Pickle",
      "Daulat Ki Chaat (Cloud-like winter saffron froth)",
      "Natraj Dahi Bhalla & Rabri Falooda"
    ],
    "architecture": [
      "Red Fort (Lal Qila, red sandstone seat of Mughal emperors)",
      "Humayun’s Tomb (Magnificent red sandstone & marble garden tomb)",
      "Qutub Minar (73-meter fluted minaret with Arabic calligraphy)",
      "Jama Masjid (Vast Mughal courtyard holding 25,000 worshippers)",
      "Sunder Nursery (Lush 90-acre UNESCO heritage park with 16th-century tombs)"
    ],
    "markets": [
      "Chandni Chowk (Historic Shahjahanabad market street)",
      "Dariba Kalan (Centuries-old silver jewellery & ittar lane)",
      "Kinari Bazaar (Brocades, borders, tassels & wedding crafts)",
      "Dilli Haat INA (Open-air national artisan & food village)"
    ],
    "festivals": [
      "Phoolwalon Ki Sair (Historic communal festival of flower sellers)",
      "Qutub Music Festival under illuminated medieval minarets",
      "International Mango Festival"
    ],
    "localRhythm": "Early morning heritage walk through Sunder Nursery at sunrise, afternoon craft browsing at Dilli Haat, and late evening kebabs and rabri falooda in Old Delhi."
  },
  "liveLikeALocal": [
    {
      "icon": "🍃",
      "title": "Morning Walk in Sunder Nursery",
      "description": "Skip congested parks; walk through the tranquil 16th-century Mughal gardens and restored marble pavilions of Sunder Nursery at 07:00 AM."
    },
    {
      "icon": "🍲",
      "title": "Bedmi Puri in Old Delhi",
      "description": "Have crisp, lentil-stuffed Bedmi puris with spicy hing aloo and methi chutney for breakfast in the historic lanes of Chandni Chowk."
    },
    {
      "icon": "🧵",
      "title": "Dariba Kalan Silver & Ittar",
      "description": "Browse narrow heritage shops that have blended pure rose and khus ittar (perfume) and crafted silver jewellery since Shah Jahan’s reign."
    },
    {
      "icon": "☕",
      "title": "Afternoon Browsing in Khan Market",
      "description": "Spend an unhurried afternoon browsing independent bookshops and quiet courtyard cafes in Khan Market."
    },
    {
      "icon": "🍧",
      "title": "Kuremal Stuffed Fruit Kulfi",
      "description": "Head to Chawri Bazaar at night for pure, natural kulfi frozen inside real scooped mangoes, oranges, and pomegranates."
    }
  ],
  "attractions": [
    {
      "id": "india-gate",
      "name": "India Gate & Kartavya Path",
      "category": "heritage",
      "coords": {
        "x": 510,
        "y": 440,
        "lat": 28.6129,
        "lng": 77.2295
      },
      "capacityMax": 8000,
      "currentVisitors": 7400,
      "loadPercentage": 92,
      "status": "critical",
      "averageVisitMinutes": 60,
      "entryFeeINR": 0,
      "currentWaitMinutes": 40,
      "openHours": "Open 24 Hours",
      "description": "42-meter memorial arch dedicated to soldiers, anchoring the grand ceremonial Kartavya Path boulevard.",
      "whyCongested": "Tour buses and family picnics jam the lawns between 17:00 and 20:00.",
      "roamResponse": "Redirect to Humayun’s Tomb and adjacent Sunder Nursery.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "humayuns-tomb",
      "secondaryAlternativeId": "sunder-nursery",
      "nearbyBusinessIds": [
        "dilli-haat-ina"
      ],
      "bestTime": {
        "bestHours": "06:00 — 08:30",
        "avoidHours": "17:00 — 20:30",
        "why": "Dawn hours have zero traffic, pleasant morning breezes, and peaceful memorial lawns."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 883,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 883,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 883,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 883,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 883,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 920,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 1216,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 1512,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 1808,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 2104,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 2400,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 2104,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "20:00",
          "visitors": 1808,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    },
    {
      "id": "red-fort",
      "name": "Red Fort (Lal Qila)",
      "category": "heritage",
      "coords": {
        "x": 530,
        "y": 280,
        "lat": 28.6562,
        "lng": 77.241
      },
      "capacityMax": 6000,
      "currentVisitors": 5400,
      "loadPercentage": 90,
      "status": "critical",
      "averageVisitMinutes": 120,
      "entryFeeINR": 500,
      "currentWaitMinutes": 55,
      "openHours": "09:30 — 16:30 (Closed Mon)",
      "description": "Massive 17th-century Mughal red sandstone imperial palace fortress with historic Lahori Gate and Diwan-i-Khas.",
      "whyCongested": "Severe ticketing bottlenecks at Lahori Gate; heavy road congestion on Netaji Subhash Marg.",
      "roamResponse": "Reroute to Humayun’s Tomb (30% load, serene Persian charbagh gardens).",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "humayuns-tomb",
      "secondaryAlternativeId": "sunder-nursery",
      "nearbyBusinessIds": [
        "chandni-chowk",
        "dariba-kalan"
      ],
      "bestTime": {
        "bestHours": "09:30 — 11:00",
        "avoidHours": "13:00 — 15:30",
        "why": "Morning allows entry before midday heat on the expansive open red stone courtyards."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 686,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 899,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 1112,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 1324,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 1537,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 1750,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "14:00",
          "visitors": 1537,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "15:00",
          "visitors": 1324,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 1112,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 899,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "18:00",
          "visitors": 686,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 659,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 659,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "humayuns-tomb",
      "name": "Humayun’s Tomb",
      "category": "culture",
      "coords": {
        "x": 540,
        "y": 490,
        "lat": 28.5933,
        "lng": 77.2507
      },
      "capacityMax": 4000,
      "currentVisitors": 1200,
      "loadPercentage": 30,
      "status": "optimal",
      "averageVisitMinutes": 90,
      "entryFeeINR": 500,
      "currentWaitMinutes": 0,
      "openHours": "06:00 — 18:00",
      "description": "UNESCO World Heritage precursor to the Taj Mahal; breathtaking red sandstone and white marble dome in geometric paradise gardens.",
      "whyCongested": "Spacious 27-hectare quadrilateral garden complex absorbs crowds comfortably.",
      "roamResponse": "PRIMARY SURROGATE: Architectural perfection, quiet water channels, and zero queues.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "red-fort",
      "nearbyBusinessIds": [
        "dilli-haat-ina"
      ],
      "bestTime": {
        "bestHours": "06:30 — 09:00 or 15:30 — 17:30",
        "avoidHours": "None (Very comfortable)",
        "why": "Angled golden sunlight illuminates the intricate marble inlays and garden water channels."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 278,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 278,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 278,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 288,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 366,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "13:00",
          "visitors": 445,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 523,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 602,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "16:00",
          "visitors": 680,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "17:00",
          "visitors": 602,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 523,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "19:00",
          "visitors": 445,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "20:00",
          "visitors": 366,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "chandni-chowk",
      "name": "Chandni Chowk Historic Bazaars",
      "category": "markets",
      "badge": "POPULAR MARKET",
      "badgeClass": "badge-elevated",
      "zone": "Old Delhi Heritage Spine",
      "coords": {
        "x": 510,
        "y": 285,
        "lat": 28.6506,
        "lng": 77.2303
      },
      "distanceKm": 0.8,
      "transitMinutes": 10,
      "estimatedActivity": 3200,
      "activityStatus": "VERY BUSY",
      "bestTime": "10:30 — 12:30",
      "quietestTime": "14:30 — 16:30",
      "specialty": "Historic Spice Market (Khari Baoli), Silver & Street Food",
      "priceRange": "₹100 — ₹12,000",
      "rating": 4.8,
      "reviewsCount": 5120,
      "whyRecommended": [
        "300-year-old historic Mughal boulevard designed by Princess Jahanara",
        "Includes Khari Baoli, Asia’s largest wholesale spice market",
        "World-renowned street food legacy stretching back generations",
        "Now pedestrianized with rickshaws and walking lanes"
      ],
      "roamSays": "Immerse yourself in centuries of living trade. From aromatic spice hills to ancestral silver shops, Chandni Chowk is an unforgettable sensory adventure.",
      "googleMapsQuery": "Chandni Chowk, Old Delhi"
    },
    {
      "id": "dariba-kalan",
      "name": "Dariba Kalan Silver & Ittar Lane",
      "category": "crafts",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Old Delhi Goldsmith Alley",
      "coords": {
        "x": 515,
        "y": 290,
        "lat": 28.6528,
        "lng": 77.2341
      },
      "distanceKm": 0.9,
      "transitMinutes": 11,
      "estimatedActivity": 920,
      "activityStatus": "QUIET",
      "bestTime": "11:00 — 14:00",
      "quietestTime": "15:00 — 17:30",
      "specialty": "Handmade Silver Jewellery, Tribal Artifacts & Natural Ittar",
      "priceRange": "₹250 — ₹8,000",
      "rating": 4.9,
      "reviewsCount": 840,
      "whyRecommended": [
        "Delhi’s oldest silver quarter dating to the 17th century",
        "Direct family jewellers selling silver by weight at fair market rates",
        "Historic perfumeries (Gulabsingh Johrimal) distilling pure botanical ittar since 1816",
        "Calmer and more atmospheric than the main boulevard"
      ],
      "roamSays": "Step into Gulabsingh Johrimal (est. 1816) for a dab of pure Ruh Gulab (natural damask rose) or Mitti ittar (the scent of rain on baked earth) crafted using ancient deg-bhapka stills.",
      "googleMapsQuery": "Dariba Kalan, Chandni Chowk, Delhi"
    },
    {
      "id": "dilli-haat-ina",
      "name": "Dilli Haat Crafts & Food Village",
      "category": "shopping",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "INA / South Delhi",
      "coords": {
        "x": 490,
        "y": 530,
        "lat": 28.5731,
        "lng": 77.2081
      },
      "distanceKm": 4.2,
      "transitMinutes": 20,
      "estimatedActivity": 1600,
      "activityStatus": "MODERATE",
      "bestTime": "11:00 — 15:00",
      "quietestTime": "12:00 — 16:00",
      "specialty": "Pan-Indian Traditional Crafts, Handlooms & State Food Stalls",
      "priceRange": "₹150 — ₹6,000",
      "rating": 4.8,
      "reviewsCount": 3890,
      "whyRecommended": [
        "Open-air village bazaar showcasing rotating rural artisans from all 28 states",
        "Direct GI-tagged crafts: Madhubani paintings, Pashmina, Chanderi, Blue Pottery",
        "Authentic regional food stalls serving Momos, Litti Chokha, and Wazwan",
        "Fixed entry with calm, shady brick plazas and no aggressive touts"
      ],
      "roamSays": "The finest one-stop showcase of India’s living crafts. You can buy directly from national award-winning rural weavers and sample cuisine from across India in one afternoon.",
      "googleMapsQuery": "Dilli Haat INA, New Delhi"
    }
  ]
};
