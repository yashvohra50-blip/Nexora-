/**
 * ROAM — Kochi Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const KOCHI_DATA = {
  "id": "kochi",
  "name": "Kochi",
  "type": "CITY",
  "state": "Kerala",
  "district": "Ernakulam",
  "region": "SOUTH",
  "culturalRegion": "Malabar Coast & Vembanad Estuary",
  "tagline": "Queen of the Arabian Sea",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE SPICE COAST HAS NATURAL BALANCE.",
    "subheadline": "ROAM detected heavy visitor concentration at Fort Kochi beachfront and open capacity in the heritage spice warehouses of Mattancherry.",
    "overloadedCount": 1,
    "underutilizedCount": 4
  },
  "metrics": {
    "totalDailyTourists": 38000,
    "averageAttractionLoad": 52,
    "visitorConcentration": 72,
    "tourismDistributionStatus": "Beachfront Fishing Nets Bottleneck",
    "localBusinessOpportunity": "High Spice & Antique Craft Value",
    "monumentsAtRisk": 1,
    "avgWaitTimeMinutes": 30,
    "localEconomyCapturePct": 22
  },
  "culturalDNA": {
    "knownFor": [
      "Cantilevered Chinese Fishing Nets (Cheena Vala)",
      "Historic Mattancherry Spice Bazaars & Pepper Warehouses",
      "Jewish Synagogue & Jew Town Antique Warehouses",
      "Classical Kathakali & Kalaripayattu Martial Arts"
    ],
    "taste": [
      "Appam with Vegetable / Chicken Stew in coconut milk",
      "Kerala Sadya served on fresh banana leaf with 24 curries",
      "Karimeen Pollichathu (Pearl spot fish baked in banana leaf with shallots)",
      "Puttu with Kadala Curry & steamed banana"
    ],
    "architecture": [
      "Chinese Fishing Nets (Teak wood counterbalanced sea rigs)",
      "Paradesi Synagogue (1568 glass chandeliers & Chinese porcelain tiles)",
      "Mattancherry Palace / Dutch Palace (Murals depicting Ramayana)",
      "Santa Cruz Basilica (Heritage Gothic cathedral)",
      "Dutch and Portuguese colonial bungalows with terracotta tile roofs"
    ],
    "markets": [
      "Jew Town (Centuries-old antique shops, brass urulis & teak furniture)",
      "Broadway Ernakulam (Bustling local trade in spices, fabrics & copper)",
      "Bazaar Road Mattancherry (Aromatic ginger, pepper & clove warehouses)",
      "Fort Kochi Beach Artisan Shacks (Shell crafts & handloom cotton)"
    ],
    "festivals": [
      "Kochi-Muziris Biennale (International contemporary art festival)",
      "Cochin Carnival (New Year vibrant street pageantry & giant Pappanji)",
      "Uthralikkavu Pooram (Temple elephant & Panchavadyam percussion)"
    ],
    "localRhythm": "Morning walk past the Chinese fishing nets at sunrise, slow bicycle exploration of Mattancherry spice lanes, afternoon courtyard cafe lunch, and evening Kathakali makeup viewing."
  },
  "liveLikeALocal": [
    {
      "icon": "🐟",
      "title": "Fresh Catch from the Nets",
      "description": "Buy fish directly from the Cheena Vala fishermen as the nets rise at 08:00 AM, and take it to the family cook-shacks 50 meters away to have it grilled with fresh Malabar masala."
    },
    {
      "icon": "🌿",
      "title": "Smell Pure Black Pepper on Bazaar Road",
      "description": "Cycle down Bazaar Road in Mattancherry where gunny sacks of green cardamom, cloves, and Malabar black pepper are weighed on vintage scales."
    },
    {
      "icon": "☕",
      "title": "Iced Spiced Coffee at Kashi",
      "description": "Cool down in the shaded sculpture courtyard of Kashi Art Cafe with iced cinnamon filter coffee and their signature dense chocolate cake."
    },
    {
      "icon": "🛶",
      "title": "Ro-Ro Ferry to Vypin",
      "description": "Skip costly tourist cruises; take the public Ro-Ro ferry across the harbor channel to Vypin island for ₹6 for a stunning view of container ships and fishing boats."
    },
    {
      "icon": "🎭",
      "title": "Watch Kathakali Makeup at 17:00",
      "description": "Arrive at the Kerala Kathakali Centre an hour before the show to watch the actors grind natural mineral pigments and paint their own faces in silent meditation."
    }
  ],
  "attractions": [
    {
      "id": "chinese-fishing-nets",
      "name": "Chinese Fishing Nets (Cheena Vala)",
      "category": "nature",
      "coords": {
        "x": 460,
        "y": 320,
        "lat": 9.9675,
        "lng": 76.2415
      },
      "capacityMax": 3500,
      "currentVisitors": 3100,
      "loadPercentage": 88,
      "status": "critical",
      "averageVisitMinutes": 60,
      "entryFeeINR": 0,
      "currentWaitMinutes": 20,
      "openHours": "Open 24 Hours",
      "description": "Iconic 14th-century cantilevered sea nets operating with counterweighted stones and bamboo poles along Fort Kochi beachfront.",
      "whyCongested": "Tourists gather tightly along the promenade at sunset; touts push fish-pulling photo fees.",
      "roamResponse": "Redirect to Dutch Palace Mattancherry and Jew Town heritage district.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "mattancherry-palace",
      "secondaryAlternativeId": "jew-town",
      "nearbyBusinessIds": [
        "jew-town-antiques",
        "kashi-art-cafe"
      ],
      "bestTime": {
        "bestHours": "06:30 — 08:30",
        "avoidHours": "17:00 — 19:00",
        "why": "Fishermen are actively landing early morning catches; soft dawn mist without the sunset tourist crowd."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 464,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 611,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 758,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 906,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 1053,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 1200,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 1053,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "20:00",
          "visitors": 906,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    },
    {
      "id": "mattancherry-palace",
      "name": "Mattancherry Palace (Dutch Palace)",
      "category": "heritage",
      "coords": {
        "x": 550,
        "y": 390,
        "lat": 9.9583,
        "lng": 76.2592
      },
      "capacityMax": 2000,
      "currentVisitors": 620,
      "loadPercentage": 31,
      "status": "optimal",
      "averageVisitMinutes": 75,
      "entryFeeINR": 10,
      "currentWaitMinutes": 0,
      "openHours": "09:45 — 13:00, 14:00 — 16:45 (Closed Fri)",
      "description": "Portuguese-built, Dutch-renovated royal palace with magnificent 16th-century tempera murals depicting the Ramayana.",
      "whyCongested": "Shaded courtyard design and museum security manage flow comfortably with no outdoor line.",
      "roamResponse": "PRIMARY SURROGATE: World-class murals, serene wooden architecture, and ₹10 entry.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "chinese-fishing-nets",
      "nearbyBusinessIds": [
        "jew-town-antiques"
      ],
      "bestTime": {
        "bestHours": "10:00 — 12:30",
        "avoidHours": "None (Very comfortable)",
        "why": "Quiet galleries with rich natural ventilation."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 266,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 314,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 362,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "11:00",
          "visitors": 410,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 362,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 314,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 266,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 218,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 170,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "jew-town-antiques",
      "name": "Jew Town Heritage Antiques & Spices",
      "category": "markets",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Synagogue Lane, Mattancherry",
      "coords": {
        "x": 560,
        "y": 410,
        "lat": 9.9575,
        "lng": 76.2598
      },
      "distanceKm": 1.4,
      "transitMinutes": 12,
      "estimatedActivity": 820,
      "activityStatus": "QUIET",
      "bestTime": "10:30 — 13:00",
      "quietestTime": "14:30 — 17:00",
      "specialty": "Carved Teak Doors, Brass Urulis, Spices & Vintage Maps",
      "priceRange": "₹200 — ₹18,000",
      "rating": 4.9,
      "reviewsCount": 1450,
      "whyRecommended": [
        "Historic 500-year-old Jewish merchant street",
        "Incredible collection of Kerala temple woodwork and colonial artifacts",
        "Direct spice merchants selling export-grade Tellicherry peppercorns",
        "Leisurely, peaceful atmosphere away from vehicular traffic"
      ],
      "roamSays": "A treasure trove of maritime and colonial history. Walk among giant brass cooking vessels (urulis), carved snake-boat prows, and the unmistakable scent of dried ginger.",
      "googleMapsQuery": "Jew Town, Mattancherry, Kochi"
    },
    {
      "id": "kashi-art-cafe",
      "name": "Kashi Art Cafe & Gallery",
      "category": "food",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Burgher Street, Fort Kochi",
      "coords": {
        "x": 470,
        "y": 340,
        "lat": 9.9652,
        "lng": 76.2432
      },
      "distanceKm": 0.4,
      "transitMinutes": 5,
      "estimatedActivity": 450,
      "activityStatus": "QUIET",
      "bestTime": "11:00 — 14:30",
      "quietestTime": "15:00 — 17:00",
      "specialty": "Organic Kerala Roast Coffee & Farm Fresh Lunches",
      "priceRange": "₹180 — ₹550",
      "rating": 4.8,
      "reviewsCount": 2190,
      "whyRecommended": [
        "The heart of Fort Kochi’s contemporary art movement",
        "Relaxed open-air courtyard with rotating sculpture installations",
        "Freshly baked artisan breads and locally sourced organic ingredients",
        "Ideal cool sanctuary during midday tropical humidity"
      ],
      "roamSays": "Step off the sun-drenched street into this leafy, tranquil courtyard cafe for great locally roasted Malabar coffee and inspiring contemporary art.",
      "googleMapsQuery": "Kashi Art Cafe, Fort Kochi"
    }
  ]
};
