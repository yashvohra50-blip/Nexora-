/**
 * ROAM — Leh Ladakh Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const LEH_DATA = {
  "id": "leh",
  "name": "Leh Ladakh",
  "type": "CITY",
  "state": "Ladakh",
  "district": "Leh",
  "region": "NORTH",
  "culturalRegion": "High Himalaya & Indus Valley",
  "tagline": "The Land of High Passes",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE HIGH HIMALAYAS NEED MINDFUL TRAVEL.",
    "subheadline": "ROAM detected severe traffic on Khardung La access and tranquil capacity across ancient Indus Valley monasteries.",
    "overloadedCount": 1,
    "underutilizedCount": 4
  },
  "metrics": {
    "totalDailyTourists": 14000,
    "averageAttractionLoad": 48,
    "visitorConcentration": 75,
    "tourismDistributionStatus": "High Altitude Pass Bottlenecks",
    "localBusinessOpportunity": "High Eco-Artisan Potential",
    "monumentsAtRisk": 1,
    "avgWaitTimeMinutes": 25,
    "localEconomyCapturePct": 24
  },
  "culturalDNA": {
    "knownFor": [
      "Century-Old Tibetan Buddhist Cliffside Monasteries",
      "High Himalayan Glacial Valleys & Pangong Lake",
      "Hand-Spun Pashmina & Yak Wool Weaving",
      "Ancient Silk Route Caravanserai Heritage"
    ],
    "taste": [
      "Steamed Tingmo with Spicy Ema Datshi / Vegetable Stew",
      "Thukpa (Handmade hand-pulled noodle soup with mountain herbs)",
      "Gur Gur Chai (Traditional churned butter tea with roasted barley Tsampa)",
      "Wild Seabuckthorn Juice & Apricot Jam"
    ],
    "architecture": [
      "Leh Palace (9-story 17th-century mud-brick & timber royal citadel)",
      "Thiksey Monastery (12-story whitewashed complex resembling Potala Palace)",
      "Hemis Monastery (Hidden mountain gorge monastery with grand courtyard)",
      "Shanti Stupa (White domed Buddhist monument built by Japanese monks)",
      "Ancient mud stupas (chortens) along mountain ridges"
    ],
    "markets": [
      "Leh Main Bazaar (Pedestrian stone street with women’s organic market)",
      "Tibetan Refugee Handicraft Market (Prayer wheels, turquoise & singing bowls)",
      "Changspa Lane (Backpacker cafes, bakeries & trekking gear)",
      "Old Town Heritage Cluster (Earthen alleys with generational wool spinners)"
    ],
    "festivals": [
      "Hemis Festival (Sacred Cham masked dances commemorating Guru Padmasambhava)",
      "Ladakh Festival (Color-rich archery, polo & regional folk dances)",
      "Losar (Ladakhi New Year celebrated with oil lamps on rooftops)"
    ],
    "localRhythm": "Early morning monastery prayer ceremonies, slow walks through old town chortens to acclimatize, afternoon tea with Khambir bread, and crystal-clear stargazing under light-pollution free skies."
  },
  "liveLikeALocal": [
    {
      "icon": "🥣",
      "title": "Morning Butter Tea & Khambir",
      "description": "Start your morning in a traditional Ladakhi family kitchen with piping hot salted butter tea and dense freshly baked sourdough Khambir bread."
    },
    {
      "icon": "📿",
      "title": "Spin the Giant Prayer Wheels",
      "description": "Take the earthen trail up to Leh Palace at 08:30 AM before tourist jeeps arrive, spinning the giant brass mani wheels in mindful silence."
    },
    {
      "icon": "🌿",
      "title": "Drink Wild Seabuckthorn Juice",
      "description": "Visit Dzomsa in the main market to refill your water canteen and sip nutrient-rich organic seabuckthorn juice harvested by women’s cooperatives."
    },
    {
      "icon": "🧘",
      "title": "Thiksey Morning Chanting at 06:00",
      "description": "Sit respectfully on the carpeted floor of Thiksey Monastery’s main prayer hall during dawn puja as young monks chant deep bass sutras."
    },
    {
      "icon": "🛍️",
      "title": "Authentic Pashmina in Old Town",
      "description": "Avoid commercial shops; visit the women weavers’ cooperative in Leh Old Town to buy genuine hand-spun Changthangi pashmina shawls."
    }
  ],
  "attractions": [
    {
      "id": "leh-palace",
      "name": "Leh Palace",
      "category": "heritage",
      "coords": {
        "x": 500,
        "y": 310,
        "lat": 34.1663,
        "lng": 77.5855
      },
      "capacityMax": 1500,
      "currentVisitors": 1250,
      "loadPercentage": 83,
      "status": "critical",
      "averageVisitMinutes": 75,
      "entryFeeINR": 100,
      "currentWaitMinutes": 25,
      "openHours": "07:00 — 18:00",
      "description": "Imposing 9-story mud-brick fortress palace built in 1600 by King Sengge Namgyal overlooking Leh town.",
      "whyCongested": "Narrow uphill access lane bottlenecks tourist taxis around late morning.",
      "roamResponse": "Redirect to Thiksey Monastery and Shey Palace along the Indus valley.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "thiksey-monastery",
      "secondaryAlternativeId": "shey-palace",
      "nearbyBusinessIds": [
        "leh-main-bazaar",
        "dzomsa-eco"
      ],
      "bestTime": {
        "bestHours": "07:30 — 09:30",
        "avoidHours": "11:00 — 14:00",
        "why": "Crisp high-altitude morning air with clear mountain views across the Zanskar range."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 302,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 362,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 421,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "11:00",
          "visitors": 480,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 421,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 362,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 302,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 243,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 184,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 177,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 177,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 177,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 177,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "thiksey-monastery",
      "name": "Thiksey Monastery",
      "category": "culture",
      "coords": {
        "x": 560,
        "y": 440,
        "lat": 34.0569,
        "lng": 77.6667
      },
      "capacityMax": 2000,
      "currentVisitors": 560,
      "loadPercentage": 28,
      "status": "optimal",
      "averageVisitMinutes": 90,
      "entryFeeINR": 50,
      "currentWaitMinutes": 0,
      "openHours": "06:00 — 18:00",
      "description": "Spectacular 12-story Gelugpa monastery complex housing a 15-meter tall gilded statue of Maitreya Buddha.",
      "whyCongested": "Spacious terraced layout on hill slope easily absorbs visitors with serene prayer halls.",
      "roamResponse": "PRIMARY SURROGATE: Unforgettable mountain panoramas, morning chanting ceremonies, and peaceful courtyards.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "leh-palace",
      "nearbyBusinessIds": [
        "leh-main-bazaar"
      ],
      "bestTime": {
        "bestHours": "06:00 — 08:30",
        "avoidHours": "None (Peaceful)",
        "why": "Early morning dawn prayer session with conch shells and monk chanting."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 282,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "09:00",
          "visitors": 243,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 205,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 166,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 128,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "15:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "16:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 123,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "leh-main-bazaar",
      "name": "Leh Main Bazaar & Women’s Market",
      "category": "markets",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Leh Pedestrian Core",
      "coords": {
        "x": 490,
        "y": 340,
        "lat": 34.1645,
        "lng": 77.5842
      },
      "distanceKm": 0.5,
      "transitMinutes": 6,
      "estimatedActivity": 950,
      "activityStatus": "MODERATE",
      "bestTime": "10:00 — 13:00",
      "quietestTime": "14:00 — 16:30",
      "specialty": "Ladakhi Organic Dried Apricots, Yak Wool & Silver",
      "priceRange": "₹100 — ₹4,500",
      "rating": 4.8,
      "reviewsCount": 1680,
      "whyRecommended": [
        "Vehicle-free pedestrian promenade with Tibetan prayer flags",
        "Direct local women farmers selling organic Ladakh apricots and walnuts",
        "Handmade wool socks, mittens, and caps knitted by village cooperatives",
        "Surrounded by historic Buddhist stupas and mountain vistas"
      ],
      "roamSays": "Stroll down this clean cobblestone street to buy freshly harvested dried apricots directly from local village women sitting with woven willow baskets.",
      "googleMapsQuery": "Main Bazaar, Leh, Ladakh"
    },
    {
      "id": "dzomsa-eco",
      "name": "Dzomsa Eco-Friendly Collective",
      "category": "shopping",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Fort Road, Leh",
      "coords": {
        "x": 480,
        "y": 350,
        "lat": 34.1632,
        "lng": 77.5828
      },
      "distanceKm": 0.7,
      "transitMinutes": 8,
      "estimatedActivity": 210,
      "activityStatus": "QUIET",
      "bestTime": "09:30 — 17:00",
      "quietestTime": "11:00 — 15:00",
      "specialty": "Refill Drinking Water, Seabuckthorn Juice & Natural Soaps",
      "priceRange": "₹20 — ₹600",
      "rating": 5,
      "reviewsCount": 780,
      "whyRecommended": [
        "Pioneering Ladakh eco-initiative reducing plastic bottle waste",
        "Filtered Himalayan spring water refill for just ₹10",
        "Delicious pasteurized wild seabuckthorn juice harvested by local self-help groups",
        "Zero-waste laundry and organic apricot kernel oils"
      ],
      "roamSays": "Help preserve fragile Ladakh ecology by refilling your reusable canteen here while enjoying fresh wild seabuckthorn juice packed with Vitamin C.",
      "googleMapsQuery": "Dzomsa, Fort Road, Leh"
    }
  ]
};
