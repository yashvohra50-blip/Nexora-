/**
 * ROAM Business / Market Mode Component (V3)
 * Plan-Aware Local Discovery Experience:
 * "Where do locals actually go?"
 *
 * Connected Intelligence:
 * - Understands user itinerary, open slots, current location & preferences from travelState
 * - Categories: FITS YOUR PLAN, QUIETER NOW, LOCAL FAVOURITES, NEARBY, MARKETS, FOOD, CRAFTS, SHOPPING
 * - Dynamic "WHY ROAM RECOMMENDS THIS" explanation checklist
 * - Intelligent Slot Placement on "+ Add to Plan" (inserts into optimal gap)
 * - Working Google Maps links (Open in Maps ↗, Get Directions ↗)
 * - Detail popup modal integration
 */

import { travelState } from '../state/travelState.js';
import { formatIndianNumber } from '../utils/formatters.js';

export class BusinessModeController {
  constructor(appInstance) {
    this.app = appInstance;
    this.activeCategory = 'fits_plan'; // default to intelligent plan-aware filter
    this.mount = document.getElementById('market-view-mount');

    // Subscribe to travelState changes
    travelState.subscribe((event) => {
      if (['itinerary:updated', 'interests:changed', 'location:changed'].includes(event)) {
        if (this.app?.activeMode === 'market') {
          this.render();
        }
      }
    });
  }

  setDestination(locationData) {
    this.activeCategory = 'fits_plan';
    this.render();
  }

  render() {
    if (!this.mount) {
      this.mount = document.getElementById('market-view-mount');
      if (!this.mount) return;
    }

    const location = travelState.location;
    const city = location?.name || 'Jaipur';
    const businesses = location?.localBusinesses || [];
    const itinerary = travelState.itinerary;
    const openSlots = travelState.openSlots;
    const activeSlot = openSlots[0];
    const culturalMarkets = location?.culturalDNA?.markets || [];
    const culturalFoods = location?.culturalDNA?.taste || [];

    // Evaluate dynamic recommendation score and bullets for each business
    const enriched = businesses.map(shop => {
      let score = 20;
      const whyList = [];

      // 1. Distance from itinerary stops
      const distMin = shop.transitMinutes || 12;
      whyList.push(`${distMin} min from your itinerary corridor`);
      score += Math.max(0, 30 - distMin);

      // 2. Open slot fit
      if (activeSlot) {
        whyList.push(`Fits your ${activeSlot.startTime} open free window`);
        score += 25;
      } else {
        whyList.push(`Comfortable visit duration (~${shop.durationMinutes || 75}m)`);
      }

      // 3. Cultural match
      whyList.push(`Authentic ${city} ${shop.specialty || 'cultural heritage'}`);

      // 4. Crowd comparison
      if (shop.activityStatus === 'QUIET') {
        whyList.push(`Expected activity is ~${formatIndianNumber(shop.estimatedActivity)} — modelled from the destination dataset`);
        score += 20;
      } else {
        whyList.push(`Best visited during ${shop.bestTime || 'off-peak hours'}`);
      }

      // 5. User interest match
      if (travelState.hasInterest(shop.category) || travelState.hasInterest('shopping')) {
        whyList.push(`Matches your active interest in ${shop.category}`);
        score += 15;
      }

      return {
        ...shop,
        roamScore: score,
        dynamicWhy: whyList
      };
    });

    // Filter businesses based on activeCategory
    let filtered = enriched;
    if (this.activeCategory === 'fits_plan') {
      filtered = enriched.sort((a, b) => b.roamScore - a.roamScore);
    } else if (this.activeCategory === 'quieter_now') {
      filtered = enriched.filter(b => b.activityStatus === 'QUIET');
    } else if (this.activeCategory === 'local_favourites') {
      filtered = enriched.filter(b => b.badge === 'LOCAL FAVOURITE' || b.badge === 'ROAM CURATED');
    } else if (this.activeCategory === 'nearby') {
      filtered = enriched.filter(b => (b.distanceKm || 1.5) <= 2.0);
    } else if (this.activeCategory === 'markets') {
      filtered = enriched.filter(b => b.category === 'markets' || b.category === 'shopping');
    } else if (this.activeCategory === 'food') {
      filtered = enriched.filter(b => b.category === 'food');
    } else if (this.activeCategory === 'crafts') {
      filtered = enriched.filter(b => b.category === 'crafts');
    } else if (this.activeCategory === 'experiences') {
      filtered = enriched.filter(b => b.category === 'crafts' || b.category === 'markets');
    } else if (this.activeCategory === 'textiles') {
      filtered = enriched.filter(b => /textile|print|bandhani|leheriya|bedsheet|cotton/i.test(`${b.specialty} ${b.name}`));
    } else if (this.activeCategory === 'jewellery') {
      filtered = enriched.filter(b => /jewell|kundan|meenakari|silver|gem|bandhani/i.test(`${b.specialty} ${b.name}`));
    } else if (this.activeCategory === 'shopping') {
      filtered = enriched.filter(b => b.category === 'shopping' || b.category === 'markets' || b.category === 'crafts');
    }

    const categories = [
      { id: 'fits_plan', label: '🎯 Fits Your Plan' },
      { id: 'quieter_now', label: '🟢 Quieter Now' },
      { id: 'all', label: 'All Curated' },
      { id: 'local_favourites', label: '⭐ Local Favourites' },
      { id: 'nearby', label: '📍 Nearby (< 2 km)' },
      { id: 'markets', label: '🛍️ Traditional Bazaars' },
      { id: 'food', label: '🍛 Authentic Eateries' },
      { id: 'crafts', label: '🏺 Artisan Studios' },
      { id: 'experiences', label: '✨ Things to Experience' },
      { id: 'textiles', label: '🧵 Textiles & Prints' },
      { id: 'jewellery', label: '💎 Jewellery & Gems' },
      { id: 'shopping', label: '🎁 Gifts & Keepsakes' }
    ];

    this.mount.innerHTML = `
      <!-- Market Hero Section -->
      <div class="market-hero-card">
        <div class="market-hero-top">
          <div>
            <div class="plan-eyebrow">
              PLAN-CONNECTED LOCAL DISCOVERY
            </div>
            <h2 class="market-hero-title">WHERE SHOULD YOU GO IN ${city.toUpperCase()}?</h2>
            <p class="market-hero-subtitle">
              Local-favourite signals, cultural fit, distance and modelled activity — ranked around the day you are actually planning.
            </p>
          </div>

          <div class="market-honesty-pill">
            <span class="honesty-dot"></span>
            <span>ROAM FORECAST · MODELLED ACTIVITY</span>
          </div>
        </div>

        <!-- Plan-Aware Context Banner (Requirement 8) -->
        ${activeSlot ? `
          <div class="plan-aware-banner">
            <div class="banner-sparkle">💡</div>
            <div class="banner-content">
              <div class="banner-title">YOU HAVE ${Math.round(activeSlot.durationMinutes / 60)} HOURS OPEN NEAR CENTRAL ${city.toUpperCase()} (${activeSlot.startTime} — ${activeSlot.endTime}).</div>
              <div class="banner-desc">
                Between ${activeSlot.afterItem?.name || 'morning visits'} and ${activeSlot.beforeItem?.name || 'evening activities'}, ROAM recommends exploring these authentic local bazaars and craft guilds with minimal queues.
              </div>
            </div>
          </div>
        ` : `
          <div class="plan-aware-banner">
            <div class="banner-sparkle">🧭</div>
            <div class="banner-content">
              <div class="banner-title">INTELLIGENT LOCAL RECOMMENDATIONS FOR YOUR ITINERARY</div>
              <div class="banner-desc">
                Adding any market or eatery below will automatically slot it into your schedule without conflicting with monument visits.
              </div>
            </div>
          </div>
        `}

        <!-- Category Filter Pills (Requirement 9) -->
        <div class="market-filter-bar">
          ${categories.map(c => `
            <button class="market-filter-btn ${this.activeCategory === c.id ? 'active' : ''}" data-category="${c.id}">
              ${c.label}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Cultural Market Pulse -->
      <div class="market-culture-pulse">
        <div class="market-culture-heading">
          <span class="plan-eyebrow">THE MARKET HAS A STORY</span>
          <strong>${city}'s living culture</strong>
          <small>Don't just shop — notice what the street is made of.</small>
        </div>
        <div class="market-story-track">
          ${culturalMarkets.slice(0, 4).map((m, i) => `
            <div class="market-story-card">
              <span class="market-story-no">0${i+1}</span>
              <span class="market-story-icon">${['🪡','💎','🪵','✨'][i]}</span>
              <div><strong>${m}</strong><small>${['Craft, colour and conversation in the old city.','Look for family-run workshops and hand-finished pieces.','Watch the craft happen instead of buying from a counter.','Follow the lane, not the souvenir signs.'][i]}</small></div>
            </div>`).join('')}
        </div>
        <div class="market-food-ticker">
          <span>TRY THIS LIKE A LOCAL</span>
          ${culturalFoods.slice(0,3).map(x => `<b>${x.split('(')[0].trim()}</b>`).join('')}
        </div>
      </div>

      <!-- Market Recommendations Grid -->
      <div class="market-cards-grid">
        ${filtered.map(shop => {
          const isQuiet = shop.activityStatus === 'QUIET';
          const mapsQuery = shop.googleMapsQuery || shop.name + ', ' + city;
          const mapsUrl = shop.coords?.lat && shop.coords?.lng
            ? `https://www.google.com/maps/dir/?api=1&destination=${shop.coords.lat},${shop.coords.lng}`
            : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(mapsQuery)}`;

          return `
            <div class="market-card" data-id="${shop.id}">
              
              <!-- Card Top Strip -->
              <div class="market-card-top">
                <div>
                  <span class="badge ${shop.badgeClass || 'badge-optimal'}">${shop.badge || 'ROAM CURATED'}</span>
                  <span class="market-zone-label">${shop.zone}</span>
                </div>

                <div class="market-distance-pill">
                  📍 ~${shop.distanceKm || 1.2} km (~${shop.transitMinutes || 12} min)
                </div>
              </div>

              <!-- Shop Title & Specialty -->
              <div style="margin: 10px 0 12px;">
                <h3 class="market-card-title">${shop.name}</h3>
                <div class="market-card-specialty">${shop.specialty}</div>
              </div>

              <!-- Estimated Area Activity Strip (Requirement 19 - Market Crowd Model) -->
              <div class="activity-strip">
                <div class="activity-strip-left">
                  <div class="activity-strip-label">EXPECTED ACTIVITY · ROAM MODEL</div>
                  <div class="activity-strip-value" style="color:${isQuiet ? 'var(--load-optimal)' : '#f59e0b'};">
                    ~${formatIndianNumber(shop.estimatedActivity)} people • ${shop.activityStatus}
                  </div>
                </div>

                <div class="activity-strip-right">
                  <div class="activity-strip-label">BEST VISITING HOURS</div>
                  <div class="activity-strip-hours">${shop.bestTime || '11:00 — 14:00'}</div>
                </div>
              </div>

              <!-- Why ROAM Recommends This (Requirement 10) -->
              <div class="why-recommends-box">
                <div class="why-recommends-label">WHY ROAM RECOMMENDS THIS</div>
                <ul class="why-recommends-list">
                  ${shop.dynamicWhy.slice(0, 4).map(w => `<li><span class="why-check">✓</span> ${w}</li>`).join('')}
                </ul>
              </div>

              <!-- Bottom Actions (Requirement 17 & 18) -->
              <div class="market-card-actions">
                <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="market-maps-link" onclick="event.stopPropagation();">
                  OPEN IN MAPS ↗
                </a>

                <div style="display:flex; gap:8px;">
                  <button class="btn btn-sm btn-secondary market-view-btn" data-id="${shop.id}">
                    Details
                  </button>
                  <button class="btn btn-sm btn-primary market-add-plan-btn" data-id="${shop.id}">
                    + Add to Plan
                  </button>
                </div>
              </div>

            </div>
          `;
        }).join('')}
      </div>
    `;

    this.attachEventListeners();
  }

  attachEventListeners() {
    if (!this.mount) return;
    const city = travelState.location?.name || 'Jaipur';

    // Category Filter Buttons
    this.mount.querySelectorAll('.market-filter-btn').forEach(btn => {
      btn.onclick = () => {
        this.activeCategory = btn.dataset.category;
        this.render();
      };
    });

    // Card Details Click
    this.mount.querySelectorAll('.market-card').forEach(card => {
      card.onclick = () => {
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === card.dataset.id);
        if (shop && this.app?.modalController) {
          this.app.modalController.openShopDetail(shop, city);
        }
      };
    });

    // Details Button Click
    this.mount.querySelectorAll('.market-view-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop && this.app?.modalController) {
          this.app.modalController.openShopDetail(shop, city);
        }
      };
    });

    // Add to Plan Button Click (Intelligent Placement)
    this.mount.querySelectorAll('.market-add-plan-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop) {
          const res = travelState.addPlaceIntelligently({
            name: shop.name,
            category: shop.category || 'shopping',
            durationMinutes: 75,
            zone: shop.zone,
            coords: shop.coords,
            distanceKm: shop.distanceKm || 1.2,
            estimatedActivity: shop.estimatedActivity
          });

          if (this.app?.modalController) {
            this.app.modalController.showToast(`Added ${shop.name} at ${res.time} (${res.reason})`);
          }
          this.app.switchMode('plan');
        }
      };
    });
  }
}
