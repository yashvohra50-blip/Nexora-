/**
 * ROAM Cultural Canvas Component (V2)
 * Manages dynamic CSS variables, real destination photo backdrop with dark vignette,
 * and ambient SVG silhouettes at 5%-15% opacity with graceful fallbacks.
 */

import { LOCATION_THEMES } from '../data/themes/locationThemes.js';

export class CulturalCanvasController {
  constructor() {
    this.photoBackdrop = document.getElementById('cultural-photo-backdrop');
    this.bgLayer = document.getElementById('cultural-bg-layer');
    this.currentThemeId = 'jaipur';
  }

  applyTheme(themeId) {
    const theme = LOCATION_THEMES[themeId] || LOCATION_THEMES.default;
    this.currentThemeId = themeId;

    // 1. Update CSS Variables on Document Root
    const root = document.documentElement;
    root.style.setProperty('--roam-bg', theme.colors.bg);
    root.style.setProperty('--roam-surface', theme.colors.bgSurface);
    root.style.setProperty('--roam-card', theme.colors.bgCard);
    root.style.setProperty('--roam-elevated', theme.colors.bgElevated);
    root.style.setProperty('--roam-accent', theme.colors.accent);
    root.style.setProperty('--roam-accent-soft', theme.colors.accentSoft);
    root.style.setProperty('--roam-accent-border', theme.colors.accentBorder);
    root.style.setProperty('--roam-accent-glow', theme.colors.activeGlow);
    root.style.setProperty('--roam-text-primary', theme.colors.textPrimary);
    root.style.setProperty('--roam-text-secondary', theme.colors.textSecondary);

    // 2. Preload and Crossfade Real Destination Photograph
    if (this.photoBackdrop) {
      if (theme.photoUrl) {
        const img = new Image();
        img.onload = () => {
          this.photoBackdrop.style.opacity = '0';
          setTimeout(() => {
            this.photoBackdrop.style.backgroundImage = `url('${theme.photoUrl}')`;
            this.photoBackdrop.style.opacity = '0.28';
          }, 150);
        };
        img.onerror = () => {
          // Graceful fallback: clear photo backdrop and rely on SVG silhouettes
          this.photoBackdrop.style.backgroundImage = 'none';
          this.photoBackdrop.style.opacity = '0';
        };
        img.src = theme.photoUrl;
      } else {
        this.photoBackdrop.style.backgroundImage = 'none';
        this.photoBackdrop.style.opacity = '0';
      }
    }

    // 3. Crossfade Ambient Architectural Silhouette (5%-15% opacity)
    if (this.bgLayer) {
      this.bgLayer.style.opacity = '0';
      setTimeout(() => {
        this.bgLayer.innerHTML = `
          <svg viewBox="0 0 1000 700" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
            ${theme.silhouetteSvg}
          </svg>
        `;
        this.bgLayer.style.opacity = '1';
      }, 250);
    }
  }
}
