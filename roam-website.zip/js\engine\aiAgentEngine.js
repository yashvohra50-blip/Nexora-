/**
 * ROAM AI Agent Engine (V4)
 * "India's Living Destination Intelligence Layer"
 *
 * Architecture:
 * ┌────────────────────────────────────────────────────────┐
 * │                       ROAM AI AGENT                     │
 * │                                                        │
 * │  ├── ContextEngine            ├── CultureEngine        │
 * │  ├── IntentEngine             ├── MarketEngine         │
 * │  ├── KnowledgeEngine          ├── RuralDiscoveryEngine │
 * │  ├── RecommendationEngine     ├── RouteMapsEngine      │
 * │  ├── ItineraryEngine          └── ResponseComposer     │
 * │                                                        │
 * │  └── HybridAIProvider (LLMProvider + LocalROAMProvider)│
 * └────────────────────────────────────────────────────────┘
 */

import { travelState } from '../state/travelState.js';
import { ALL_INDIAN_LOCATIONS, resolveLocation } from '../data/locations/index.js';
import { formatIndianNumber } from '../utils/formatters.js';

// ============================================================
// 1. CONTEXT ENGINE
// ============================================================
export class ContextEngine {
  constructor() {
    this.conversationalHistory = [];
    this.lastDiscussedEntity = null;
  }

  recordTurn(userQuery, assistantReply) {
    this.conversationalHistory.push({ role: 'user', content: userQuery, timestamp: Date.now() });
    this.conversationalHistory.push({ role: 'assistant', content: assistantReply, timestamp: Date.now() });
    if (this.conversationalHistory.length > 20) {
      this.conversationalHistory = this.conversationalHistory.slice(-20);
    }
  }

  getSnapshot() {
    const loc = travelState.location || ALL_INDIAN_LOCATIONS[0];
    const itinerary = travelState.itinerary || [];
    const openSlots = travelState.openSlots || [];
    const mood = travelState.journeyMood || {
      chaosCalm: 65,
      touristLocal: 85,
      fastSlow: 45,
      luxuryRaw: 30,
      spontaneousPlanned: 60,
      cultureAdventure: 75,
      foodHistory: 50
    };
    const activeRoute = travelState.activeRoute || 'all';

    return {
      location: loc,
      city: loc.name,
      state: loc.state,
      region: loc.region,
      tier: loc.intelligenceTier || loc.tier,
      itineraryLength: itinerary.length,
      itineraryStops: itinerary.map(i => ({ id: i.id, name: i.name, time: i.time, category: i.category, crowdStatus: i.crowdStatus })),
      openSlots: openSlots,
      dayHealth: travelState.dayHealth?.status || 'BALANCED',
      journeyMood: mood,
      activeRoute: activeRoute,
      lastDiscussedEntity: this.lastDiscussedEntity,
      recentHistory: this.conversationalHistory.slice(-4)
    };
  }

  resolvePronouns(query) {
    const q = (query || '').toLowerCase().trim();
    // Resolve "it", "that", "this place", "the fort" to the last discussed item or focused itinerary item
    if (q.includes(' it ') || q.endsWith(' it') || q.includes(' that') || q.includes(' this place')) {
      const focused = travelState.getFocusedItem();
      if (this.lastDiscussedEntity) {
        return `${query} [Context: referring to ${this.lastDiscussedEntity.name}]`;
      } else if (focused) {
        return `${query} [Context: referring to ${focused.name}]`;
      }
    }
    return query;
  }
}

// ============================================================
// 2. INTENT ENGINE
// ============================================================
export class IntentEngine {
  classify(rawQuery) {
    const q = (rawQuery || '').toLowerCase().trim();

    // 1. Action intents (Direct agent actions on ROAM)
    if (q.includes('optimize') || q.includes('balance') || q.includes('make today less rushed') || q.includes('make tomorrow slower') || q.includes('avoid queues')) {
      return { type: 'OPTIMIZE_DAY', query: q };
    }
    if (q.includes('add this') || q.includes('add to itinerary') || q.includes('add to plan') || q.includes('add to my day')) {
      return { type: 'ADD_ITINERARY_ITEM', query: q };
    }
    if (q.includes('remove') || q.includes('delete') || q.includes('remove the crowded')) {
      return { type: 'REMOVE_ITINERARY_ITEM', query: q };
    }
    if (q.includes('replace') || q.includes('replace that') || q.includes('different version')) {
      return { type: 'REPLACE_ITINERARY_ITEM', query: q };
    }
    if (q.includes('take me there') || q.includes('get directions') || q.includes('open map') || q.includes('directions to')) {
      return { type: 'OPEN_MAP', query: q };
    }
    if (q.includes('show market') || q.includes('bazaars') || q.includes('bazaar') || q.includes('shopping')) {
      return { type: 'OPEN_MARKET', query: q };
    }
    if (q.includes('show culture') || q.includes('cultural') || q.includes('why this exists')) {
      return { type: 'OPEN_CULTURE', query: q };
    }

    // 2. Domain & Discovery queries
    if (q.includes('rural') || q.includes('village') || q.includes('beyond the city') || q.includes('hamlet') || q.includes('farm') || q.includes('potter')) {
      return { type: 'SHOW_RURAL', query: q };
    }
    if (q.includes('food') || q.includes('eat') || q.includes('lunch') || q.includes('breakfast') || q.includes('chai') || q.includes('dinner') || q.includes('sweet')) {
      return { type: 'SHOW_FOOD', query: q };
    }
    if (q.includes('craft') || q.includes('textile') || q.includes('handloom') || q.includes('block print') || q.includes('weaver') || q.includes('artisan')) {
      return { type: 'SHOW_CRAFT', query: q };
    }
    if (q.includes('hidden') || q.includes('secret') || q.includes('not touristy') || q.includes('tourists miss') || q.includes('offbeat') || q.includes('quiet')) {
      return { type: 'SHOW_HIDDEN', query: q };
    }
    if (q.includes('1000') || q.includes('1,000') || q.includes('5000') || q.includes('5,000') || q.includes('budget') || q.includes('bargain') || q.includes('price')) {
      return { type: 'BARGAINING_BUDGET', query: q };
    }
    if (q.includes('right now') || q.includes('current') || q.includes('vibe') || q.includes('weather') || q.includes('happening around me')) {
      return { type: 'RIGHT_NOW', query: q };
    }
    if (q.includes('3 hours') || q.includes('free time') || q.includes('window') || q.includes('gap') || q.includes('slot') || q.includes('next')) {
      return { type: 'FILL_WINDOW', query: q };
    }
    if (q.includes('like a local') || q.includes('local route') || q.includes('authentic')) {
      return { type: 'LOCAL_EXPERIENCE', query: q };
    }

    return { type: 'GENERAL_INTELLIGENCE', query: q };
  }
}

// ============================================================
// 3. DESTINATION KNOWLEDGE ENGINE
// ============================================================
export class DestinationKnowledgeEngine {
  getLocation(queryOrId) {
    return resolveLocation(queryOrId);
  }

  getAttractions(loc) {
    return loc?.attractions || [];
  }

  getBusinesses(loc) {
    return loc?.localBusinesses || [];
  }

  getRuralNeighbors(loc) {
    return ALL_INDIAN_LOCATIONS.filter(l => 
      (l.tier === 'RURAL' || l.type === 'RURAL_VILLAGE' || l.type === 'CRAFT_VILLAGE') &&
      (l.state === loc?.state || l.region === loc?.region)
    );
  }
}

// ============================================================
// 4. RECOMMENDATION & SCORING ENGINE
// ============================================================
export class RecommendationEngine {
  scoreItem(item, context) {
    const mood = context.journeyMood;
    let score = 50;

    // Local vs Tourist
    if (mood.touristLocal > 60 && (item.category === 'crafts' || item.badge === 'LOCAL FAVOURITE' || item.isRural)) {
      score += 25;
    }
    // Calm vs Chaos
    if (mood.chaosCalm > 60 && (item.crowdStatus === 'optimal' || item.activityStatus === 'QUIET')) {
      score += 20;
    }
    // Culture vs Adventure
    if (mood.cultureAdventure > 60 && (item.category === 'culture' || item.category === 'heritage')) {
      score += 15;
    }

    return Math.min(99, Math.max(65, score));
  }

  buildStructuredRecommendation(item, context, reason) {
    const city = context.city;
    const isQuiet = item.crowdStatus === 'optimal' || item.activityStatus === 'QUIET';
    const score = this.scoreItem(item, context);

    return {
      destination: item.name,
      id: item.id || ('rec-' + Date.now()),
      category: (item.category || 'culture').toUpperCase(),
      reason: reason || `${score}% Match with your ${context.journeyMood.touristLocal > 60 ? 'Authentic Local' : 'Heritage'} preference`,
      estimatedDuration: `${item.durationMinutes || 75} mins`,
      estimatedCost: item.estimatedCost || '₹100 — ₹400',
      distance: `~${item.distanceKm || 1.4} km (~${item.transitMinutes || 15}m)`,
      bestTime: item.bestTime || (isQuiet ? '08:00 — 10:30' : '11:00 — 14:00'),
      crowdStatus: isQuiet ? 'Tranquil & Quiet' : 'Moderate Flow',
      culturalSignificance: item.culturalSignificance || item.specialty || `Generational ${city} cultural heritage`,
      localRelevance: item.specialty || 'Verified authentic local hub with direct artisan benefits',
      mapsQuery: `${item.name}, ${city}`,
      action: {
        type: 'ADD_ITINERARY_ITEM',
        label: '+ Add to Itinerary',
        payload: item
      }
    };
  }
}

// ============================================================
// 5. ITINERARY ENGINE
// ============================================================
export class ItineraryEngine {
  optimizeDay() {
    return travelState.balanceDay();
  }

  applyOptimization(balancedPlan) {
    travelState.applyBalancedSchedule(balancedPlan);
  }

  makeDaySlower() {
    const itinerary = [...travelState.itinerary];
    if (itinerary.length > 3) {
      // Keep first, middle, and last, extend their duration by 30m, insert chai break
      const filtered = [itinerary[0], itinerary[Math.floor(itinerary.length / 2)], itinerary[itinerary.length - 1]];
      filtered.forEach(it => {
        it.durationMinutes = (it.durationMinutes || 90) + 30;
      });
      travelState.itinerary = filtered;
      travelState.insertBreak('chai');
      travelState.recalculate();
      return true;
    }
    return false;
  }
}

// ============================================================
// 6. CULTURE ENGINE
// ============================================================
export class CultureEngine {
  getCulturalStories(loc) {
    const dna = loc?.culturalDNA || {};
    return {
      whyThisExists: dna.knownFor?.[0] || 'Centuries of architectural and cultural engineering adapted to climate and trade.',
      whyLocalsDoThis: 'Community gathering at sacred dawn and dusk hours before the heat and tour groups arrive.',
      whatTouristsMiss: 'The geometric stepwells, secluded inner courtyards, and natural mineral handloom guilds.',
      craftStory: 'Generational master craftspeople using natural indigo, terracotta, and vegetable dyes.'
    };
  }
}

// ============================================================
// 7. MARKET ENGINE
// ============================================================
export class MarketEngine {
  getMarketDNA(city) {
    return {
      jaipur: {
        whatToBuy: 'Hand-block printed cotton stoles, blue pottery, lac bangles, raw spices in Khari Baoli.',
        whatNotToBuy: 'Machine-printed polyester stoles sold at fort parking lots, fake synthetic gems.',
        bargainingRisk: 'Moderate at Johari & Bapu Bazaar (counter at 50%, settle around 65-70%). Zero at direct weaver cooperatives.',
        what1000GetsYou: '1 authentic block-printed stole (₹450) + 1 heritage thali (₹320) + 4 kulhad chai pauses (₹120) + terracotta diya (₹80).'
      },
      varanasi: {
        whatToBuy: 'GI-tagged Handloom Banarasi Silk Sarees from Madanpura weaver guild, wooden toys from Ramnagar, brass bells.',
        whatNotToBuy: 'Powerloom polyester dupattas sold as pure silk on main Dashashwamedh approach.',
        bargainingRisk: 'Low at fixed weaver cooperatives, High at main ghat tourist stalls.',
        what1000GetsYou: '1 pure raw silk scarf (₹550) + morning Kachori Jalebi breakfast (₹100) + sunrise boat row (₹250) + Banarasi Paan & Chai (₹100).'
      }
    };
  }
}

// ============================================================
// 8. RURAL DISCOVERY ENGINE ("BEYOND THE CITY")
// ============================================================
export class RuralDiscoveryEngine {
  getFeaturedRuralVillages(activeLoc) {
    const list = [
      {
        id: 'raghurajpur',
        name: 'Raghurajpur',
        state: 'Odisha',
        specialty: 'Heritage Pattachitra & Palm Leaf Inscription Guild',
        story: 'Every single household in this village is a master craft studio preserving ancient temple art.',
        mapsQuery: 'Raghurajpur Heritage Crafts Village, Puri, Odisha'
      },
      {
        id: 'pochampally',
        name: 'Pochampally',
        state: 'Telangana',
        specialty: 'UNESCO Bhoodan Ikat Silk Handloom Village',
        story: 'Home to generational geometric tie-dye weavers where you watch silk threads spun on wooden looms.',
        mapsQuery: 'Pochampally Handloom Park, Telangana'
      },
      {
        id: 'khejarli',
        name: 'Khejarli',
        state: 'Rajasthan',
        specialty: 'Sacred Bishnoi Eco-Sanctuary & Blackbuck Habitat',
        story: 'Birthplace of India’s first environmental defense movement where 363 Bishnois sacrificed their lives for sacred trees.',
        mapsQuery: 'Khejarli Martyrs Memorial, Jodhpur, Rajasthan'
      },
      {
        id: 'hodka',
        name: 'Hodka & Nirona',
        state: 'Gujarat',
        specialty: 'Rann of Kutch Mud-Mirror Art & Rogan Castor Oil Painting',
        story: 'The sole remaining family practicing 400-year-old Rogan art with castor oil pigments.',
        mapsQuery: 'Nirona Rogan Art Village, Kutch, Gujarat'
      }
    ];

    // Prioritize villages in same state if available
    return list.sort((a, b) => (a.state === activeLoc?.state ? -1 : 1));
  }
}

// ============================================================
// 9. ROUTE & MAPS ENGINE
// ============================================================
export class RouteMapsEngine {
  getMapsUrl(destination, city) {
    return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(destination + ', ' + city + ', India')}`;
  }

  getDirectionsUrl(origin, destination, city) {
    return `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(origin + ', ' + city)}&destination=${encodeURIComponent(destination + ', ' + city)}`;
  }
}

// ============================================================
// 10. RESPONSE COMPOSER & HYBRID PROVIDER
// ============================================================
export class LocalROAMProvider {
  constructor(agent) {
    this.agent = agent;
  }

  async generateResponse(intent, context, rawQuery) {
    const city = context.city;
    const loc = context.location;
    const attractions = this.agent.knowledgeEngine.getAttractions(loc);
    const businesses = this.agent.knowledgeEngine.getBusinesses(loc);

    let text = '';
    let cards = [];
    let actions = [];

    switch (intent.type) {
      case 'OPTIMIZE_DAY': {
        const comp = this.agent.itineraryEngine.optimizeDay();
        text = `### ⚡ DAY HEALTH & QUEUE OPTIMIZATION FOR ${city.toUpperCase()}\n\n` +
          `I analyzed your full schedule against live crowd curves and transit corridors. \n\n` +
          `• **Bottleneck Removed**: High-density monument visits moved to morning (08:30) to skip 50+ min ticketing queues.\n` +
          `• **Smooth Flow**: Stops clustered geographically to eliminate cross-city transit fatigue.\n` +
          `• **Open Pacing**: Reserved an open late-afternoon window for unhurried local bazaar exploration.`;

        actions = [
          { type: 'APPLY_OPTIMIZED_DAY', label: '⚡ Apply Optimized Day', payload: comp?.balancedPlan },
          { type: 'SWITCH_MODE_PLAN', label: '📅 View Day Timetable' }
        ];
        break;
      }

      case 'SHOW_RURAL': {
        const ruralList = this.agent.ruralEngine.getFeaturedRuralVillages(loc);
        text = `### 🌾 BEYOND THE CITY: RURAL CRAFT & LIVING ARTISAN HUBS\n\n` +
          `*"Some of India's best stories don't have a pin on the tourist map."*\n\n` +
          `Here are verified community-led artisan hamlets near and around ${loc.state} where spending directly sustains master craftspeople:`;

        ruralList.slice(0, 3).forEach(rv => {
          cards.push({
            destination: `${rv.name}, ${rv.state}`,
            category: 'RURAL CRAFT VILLAGE',
            reason: rv.story,
            estimatedDuration: 'Half / Full Day',
            estimatedCost: '₹300 — ₹800',
            distance: `Regional ${rv.state}`,
            bestTime: '08:30 — 16:30',
            crowdStatus: 'Tranquil & Uncrowded',
            culturalSignificance: rv.specialty,
            localRelevance: 'Direct guild community tourism',
            mapsQuery: rv.mapsQuery,
            action: {
              type: 'SWITCH_LOCATION',
              label: `Explore ${rv.name} ➔`,
              locId: rv.id
            }
          });
        });

        actions = [
          { type: 'FILTER_DISCOVERY_RURAL', label: '🌾 Filter Rural Layer' },
          { type: 'ROUTE_CRAFT', label: '🧵 The Craft Trail' }
        ];
        break;
      }

      case 'SHOW_FOOD': {
        const foodSpots = businesses.filter(b => b.category === 'food');
        text = `### 🍛 WHERE LOCALS ACTUALLY EAT IN ${city.toUpperCase()}\n\n` +
          `Skip the sanitized buffet halls. In ${city}, the genuine flavors live in multi-generational gullies, wood-fired heritage bakeries, and brass-pot halwais:`;

        foodSpots.slice(0, 3).forEach(fs => {
          cards.push(this.agent.recommendationEngine.buildStructuredRecommendation(fs, context, `Authentic culinary heritage (${fs.zone})`));
        });

        actions = [
          { type: 'ROUTE_FOOD', label: '🍛 Switch to The Food Trail' },
          { type: 'ADD_BREAK_CHAI', label: '☕ Add Masala Chai Break' }
        ];
        break;
      }

      case 'SHOW_HIDDEN': {
        const hiddenSites = attractions.filter(a => a.status === 'optimal' || a.name.toLowerCase().includes('stepwell') || a.name.toLowerCase().includes('haveli'));
        text = `### 🌿 THE HIDDEN ROUTE: WHAT TOURISTS MISS IN ${city.toUpperCase()}\n\n` +
          `90% of visitors rush between the 3 main postcard monuments. Here is what they miss:\n\n` +
          `• **Acoustic & Thermal Geometry**: Ancient stepwells engineered centuries before air conditioning.\n` +
          `• **Quiet Guild Courtyards**: Living block-print and handloom quarters.\n` +
          `• **Twilight Ramparts**: Experiencing the horizon without megaphone tour groups.`;

        (hiddenSites.length > 0 ? hiddenSites.slice(0, 2) : attractions.slice(0, 2)).forEach(hs => {
          cards.push(this.agent.recommendationEngine.buildStructuredRecommendation(hs, context, 'Quiet heritage sanctuary'));
        });

        actions = [
          { type: 'ROUTE_HIDDEN', label: '🌿 Switch to The Hidden Route' },
          { type: 'ROUTE_PHOTO', label: '📸 The Photography Walk' }
        ];
        break;
      }

      case 'BARGAINING_BUDGET': {
        text = `### 🛍️ BARGAINING DNA & WHAT ₹1,000 GETS YOU IN ${city.toUpperCase()}\n\n` +
          `**ROAM Local Protocol**:\n` +
          `1. **Direct Artisan Cooperatives & Food**: Strictly fixed-price. Do not haggle with master weavers.\n` +
          `2. **Tourist Main-Road Bazaars**: First quotes often include 40-50% markups. Counter at 50% with a smile, settle around 65-70%.\n\n` +
          `**What ₹1,000 Gets You**:\n` +
          `• **ROAM Verified Route**: 1 authentic hand-block stole (₹450) + 1 heritage thali (₹320) + 4 kulhad chais (₹120) + terracotta souvenir (₹80).\n` +
          `• **Tourist Trap**: 1 machine-printed acrylic scarf + 1 marked-up soda.`;

        actions = [
          { type: 'SWITCH_MODE_MARKET', label: '🏪 Open Markets 2.0' },
          { type: 'ROUTE_BUDGET', label: '💰 The Budget Route' }
        ];
        break;
      }

      case 'RIGHT_NOW': {
        const telemetry = travelState.getRightNowTelemetry();
        text = `### 📍 RIGHT NOW IN ${city.toUpperCase()} (${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })})\n\n` +
          `**Flow Status**: ${telemetry?.crowdLoadStatus || 'Moderate Demand'}.\n` +
          `**Weather & Vibe**: ${telemetry?.temperature || '28°C'} • ${telemetry?.weatherDesc || 'Clear'}.\n` +
          `**ROAM Recommended Move**: ${telemetry?.bestWindowNow || 'Artisan Quarters and Quiet Havelis'}.`;

        const quietShop = businesses.find(b => b.activityStatus === 'QUIET') || businesses[0];
        if (quietShop) {
          cards.push(this.agent.recommendationEngine.buildStructuredRecommendation(quietShop, context, 'Tranquil spot to visit right now'));
        }

        actions = [
          { type: 'OPEN_MAP', label: '🧭 Open ROAM Radar' },
          { type: 'OPTIMIZE_DAY', label: '⚡ Balance Day' }
        ];
        break;
      }

      case 'FILL_WINDOW': {
        const slot = context.openSlots[0];
        const whatNext = travelState.getWhatShouldIDoNext();
        if (slot && whatNext) {
          text = `### ⏰ FILLING YOUR ${slot.durationMinutes} MIN OPEN WINDOW (${slot.startTime} — ${slot.endTime})\n\n` +
            `Between ${slot.afterItem?.name || 'morning visits'} and your next stop, ROAM recommends **${whatNext.title}** (${whatNext.specialty}) because it is only ~${whatNext.transitMinutes} min away and unhurried.`;

          cards.push({
            destination: whatNext.title,
            id: whatNext.pick.id,
            category: 'LOCAL SPOT',
            reason: whatNext.why,
            estimatedDuration: `${whatNext.availableMinutes} mins`,
            estimatedCost: '₹150 — ₹350',
            distance: `~${whatNext.distanceKm} km (~${whatNext.transitMinutes}m)`,
            bestTime: slot.startTime,
            crowdStatus: 'Quiet',
            culturalSignificance: whatNext.specialty,
            localRelevance: 'Fits your free window without transit fatigue',
            mapsQuery: `${whatNext.title}, ${city}`,
            action: {
              type: 'ADD_ITINERARY_ITEM',
              label: '+ Add to Window',
              payload: whatNext.pick
            }
          });
        } else {
          text = `### 📅 ITINERARY IS CURRENTLY WELL-PACED\n\nNo transit conflicts detected. You can easily extend durations with the −/+ controls in Plan Mode anytime.`;
        }

        actions = [{ type: 'SWITCH_MODE_PLAN', label: '📅 Open Plan Mode' }];
        break;
      }

      default: {
        text = `### 🧭 ROAM DESTINATION INTELLIGENCE: ${city.toUpperCase()}\n\n` +
          `${loc.culturalDna?.knownFor?.[0] || `${city} is a historic cultural epicentre in ${loc.state}.`}\n\n` +
          `• **Pacing**: Morning monuments (08:00 - 10:30), afternoon indoor havelis & craft guilds (12:00 - 15:30), evening bazaars & sunset ramparts (17:00 - 20:00).\n` +
          `• **Living Insight**: ${loc.heroCopy?.subheadline || 'Explore beyond the tourist trail with verified local intelligence.'}`;

        const topPick = businesses[0];
        if (topPick) {
          cards.push(this.agent.recommendationEngine.buildStructuredRecommendation(topPick, context, 'Verified local destination'));
        }

        actions = [
          { type: 'SWITCH_MODE_PLAN', label: '📅 Plan My Day' },
          { type: 'SWITCH_MODE_MARKET', label: '🏪 Explore Markets' },
          { type: 'OPTIMIZE_DAY', label: '⚡ Balance Day' }
        ];
      }
    }

    return {
      id: 'msg-' + Date.now(),
      sender: 'roam_ai',
      provider: 'LocalROAMProvider',
      text,
      cards,
      suggestedActions: actions,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
  }
}

// ============================================================
// 11. MASTER ROAM AI AGENT CLASS
// ============================================================
export class RoamAIAgent {
  constructor() {
    this.contextEngine = new ContextEngine();
    this.intentEngine = new IntentEngine();
    this.knowledgeEngine = new DestinationKnowledgeEngine();
    this.recommendationEngine = new RecommendationEngine();
    this.itineraryEngine = new ItineraryEngine();
    this.cultureEngine = new CultureEngine();
    this.marketEngine = new MarketEngine();
    this.ruralEngine = new RuralDiscoveryEngine();
    this.routesMapsEngine = new RouteMapsEngine();
    this.localProvider = new LocalROAMProvider(this);
  }

  getSuggestedPrompts() {
    const ctx = this.contextEngine.getSnapshot();
    const city = ctx.city;

    const prompts = [
      { icon: '🧭', text: `Show me ${city} like a local`, type: 'LOCAL' },
      { icon: '🌾', text: `Find village & rural craft experiences`, type: 'RURAL' },
      { icon: '🍛', text: `Where can I eat where locals go?`, type: 'FOOD' },
      { icon: '🛍️', text: `What's the bargaining etiquette in ${city}?`, type: 'MARKET' },
      { icon: '⚡', text: `Optimize today to avoid crowded queues`, type: 'OPTIMIZE' },
      { icon: '🌿', text: `What are tourists missing here?`, type: 'HIDDEN' }
    ];

    if (ctx.openSlots.length > 0) {
      prompts.unshift({
        icon: '⏰',
        text: `Fill my open ${ctx.openSlots[0].startTime} window`,
        type: 'SLOT'
      });
    }

    return prompts.slice(0, 5);
  }

  async processQuery(userInput) {
    if (!userInput || !userInput.trim()) return null;
    const cleanQuery = userInput.trim();

    // 1. Resolve Pronouns & Context
    const resolvedQuery = this.contextEngine.resolvePronouns(cleanQuery);
    const context = this.contextEngine.getSnapshot();

    // 2. Classify Intent
    const intent = this.intentEngine.classify(resolvedQuery);

    // 3. Attempt LLM Provider via backend endpoint (/api/ai/chat)
    try {
      const resp = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: cleanQuery, context: { city: context.city, state: context.state } })
      });
      if (resp.ok) {
        const json = await resp.json();
        if (json && !json.fallback && json.text) {
          const reply = {
            id: 'msg-' + Date.now(),
            sender: 'roam_ai',
            provider: 'LLMProvider',
            text: json.text,
            cards: [],
            suggestedActions: [{ type: 'OPTIMIZE_DAY', label: '⚡ Balance Day' }, { type: 'SWITCH_MODE_PLAN', label: '📅 Open Plan' }],
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          };
          this.contextEngine.recordTurn(cleanQuery, reply.text);
          return reply;
        }
      }
    } catch (e) {
      // Offline or missing endpoint: seamlessly proceed to LocalROAMProvider
    }

    // 4. Generate Deterministic High-Fidelity Local Response
    const reply = await this.localProvider.generateResponse(intent, context, resolvedQuery);
    this.contextEngine.recordTurn(cleanQuery, reply.text);
    return reply;
  }
}

export const roamAIEngine = new RoamAIAgent();
