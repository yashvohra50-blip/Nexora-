/**
 * ROAM — Comprehensive All-India Location Intelligence Registry
 * Authentic, culturally deep data for Urban Metros, Rural Craft Villages, 
 * Himalayan Valleys, Heritage Towns, and Sacred Corridors across all 28 States & 8 UTs.
 */

export const PARTIAL_LOCATIONS = [
  // --- RAJASTHAN ---
  {
    id: 'pushkar',
    name: 'Pushkar',
    type: 'TOWN',
    state: 'Rajasthan',
    district: 'Ajmer',
    region: 'NORTH',
    culturalRegion: 'Thar Desert Fringe & Sacred Lake',
    tagline: 'The Sacred Lotus Lake & Brahma Sanctuary',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'THE SACRED LAKE MEETS DESERT DUNES.',
      subheadline: 'ROAM has mapped partial demand data: 52 sacred bathing ghats, one of the world rare Brahma Temples, and nomadic camel fairs.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 12500,
      averageAttractionLoad: 58,
      visitorConcentration: 74,
      tourismDistributionStatus: 'Moderate Brahma Temple Concentration',
      localBusinessOpportunity: 'High Rose Water & Leather Potential',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 25,
      localEconomyCapturePct: 35
    },
    culturalDNA: {
      knownFor: [
        'World\'s Primary 14th-Century Jagatpita Brahma Temple',
        '52 Sacred Bathing Ghats ringing Pushkar Lake',
        'Annual Pushkar Camel & Livestock Fair (Kartik Purnima)',
        'Pure Organic Damask Rose Water (Gulab Jal) Distilleries'
      ],
      taste: [
        'Pushkar Malpua fried in desi ghee at Halwai Gali',
        'Rabdi with Pistachio & Saffron',
        'Falafel & Lassi in Desert Rooftop Cafes'
      ],
      landscape: [
        'Sacred Lake surrounded by Whitewashed Haveli Ghats',
        'Surrounding Nag Pahar (Snake Mountain) Sand Hills',
        'Semi-Arid Desert scrubland'
      ],
      festivals: [
        'Pushkar Fair (Kartik Purnima camel trading & folk races)',
        'Maha Aarti at Varaha Ghat'
      ]
    }
  },
  {
    id: 'udaipur',
    name: 'Udaipur',
    type: 'CITY',
    state: 'Rajasthan',
    district: 'Udaipur',
    region: 'NORTH',
    culturalRegion: 'Mewar Kingdom & Aravalli Hills',
    tagline: 'The Venice of the East & City of Lakes',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'MARBLE PALACES FLOATING ON LAKE PICHOLA.',
      subheadline: 'ROAM demand telemetry active: City Palace complex, Jag Mandir island, Saheliyon-ki-Bari, and Bagore Ki Haveli folk arts.',
      overloadedCount: 2,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 24000,
      averageAttractionLoad: 68,
      visitorConcentration: 82,
      tourismDistributionStatus: 'High City Palace Morning Queues',
      localBusinessOpportunity: 'High Miniature Painting & Silver Potential',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 35,
      localEconomyCapturePct: 40
    },
    culturalDNA: {
      knownFor: [
        'Majestic 1559 City Palace overlooking Lake Pichola',
        'Lake Palace (Jag Niwas) floating marble sanctuary',
        'Generational Mewar Miniature Painting workshops',
        'Bagore Ki Haveli Dharohar folk dance & puppet theater'
      ],
      taste: ['Dal Baati Churma with garlic chutney', 'Ghevar soaked in saffron syrup', 'Kachoris at Shastri Circle'],
      landscape: ['Interconnected freshwater lakes', 'Rugged Aravalli mountain backdrop', 'Intricate marble jharokhas'],
      festivals: ['Mewar Festival (Gangaur boat procession)', 'Shilpgram Crafts Fair']
    }
  },
  {
    id: 'jodhpur',
    name: 'Jodhpur',
    type: 'CITY',
    state: 'Rajasthan',
    district: 'Jodhpur',
    region: 'NORTH',
    culturalRegion: 'Sun City & Marwar Capital',
    tagline: 'The Indigo City Below Mehrangarh',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'IMPERIAL CLIFFTOP FORTS & INDIGO LANES.',
      subheadline: 'ROAM telemetry active: Mehrangarh Fort ramparts, Jaswant Thada marble cenotaphs, and Clock Tower spice bazaars.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 19500,
      averageAttractionLoad: 61,
      visitorConcentration: 75,
      tourismDistributionStatus: 'Mehrangarh Midday Inflow Peak',
      localBusinessOpportunity: 'High Bandhani Textile & Leather Craft',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 30,
      localEconomyCapturePct: 44
    },
    culturalDNA: {
      knownFor: [
        '1459 Mehrangarh Fort rising 400 feet above the city',
        'Blue-painted Brahmin houses in Navchokiya quarter',
        'Jaswant Thada intricately carved milk-white marble cenotaph',
        'Clock Tower (Ghanta Ghar) & Sardar Market spice stalls'
      ],
      taste: ['Pyaaz Ki Kachori at Janta Sweet Home', 'Makhaniya Lassi at Mishrilal Hotel', 'Mirchi Vada'],
      landscape: ['Volcanic rocky outcrop', 'Labyrinthine cobalt-blue alleyways', 'Vast Thar desert threshold'],
      festivals: ['Rajasthan International Folk Festival (RIFF)', 'Marwar Festival']
    }
  },
  {
    id: 'jaisalmer',
    name: 'Jaisalmer',
    type: 'CITY',
    state: 'Rajasthan',
    district: 'Jaisalmer',
    region: 'NORTH',
    culturalRegion: 'The Golden City of the Great Thar',
    tagline: 'The Living Golden Sandstone Fortress',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'A LIVING FORTRESS RISING FROM GOLDEN DUNES.',
      subheadline: 'Sonar Qila fort citadel, Patwon Ki Haveli filigree stonework, and Sam Sand Dunes camel treks.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 14000,
      averageAttractionLoad: 55,
      visitorConcentration: 70,
      tourismDistributionStatus: 'Fort Entrance & Sunset Dune Traffic',
      localBusinessOpportunity: 'High Camel Wool & Yellow Sandstone Art',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 48
    },
    culturalDNA: {
      knownFor: [
        'Jaisalmer Fort (Sonar Qila) — one of the world\'s last living forts',
        'Seven interconnected 12th-to-15th century Jain Temples',
        'Patwon Ki Haveli 5-storey lace-like sandstone lattice',
        'Sam and Khuri Sand Dunes night desert camping'
      ],
      taste: ['Ker Sangri with Bajra Roti', 'Gatte Ki Khichdi', 'Bhang Lassi (authorized government shops)'],
      landscape: ['Golden yellow Jurassic sandstone architecture', 'Endless undulating desert dunes', 'Oasis lakes (Gadisar)'],
      festivals: ['Jaisalmer Desert Festival (turban tying, folk music)', 'Camel Polo & Dances']
    }
  },
  {
    id: 'khimsar',
    name: 'Khimsar',
    type: 'VILLAGE',
    state: 'Rajasthan',
    district: 'Nagaur',
    region: 'NORTH',
    culturalRegion: 'Heart of the Thar Desert',
    tagline: 'Oasis in the Great Thar Desert',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'A DESERT OASIS OF TRANQUIL DUNES.',
      subheadline: 'ROAM has mapped partial demand data: 16th-century fortress ramparts, mini desert sand dunes, and Blackbuck antelope trails.',
      overloadedCount: 0,
      underutilizedCount: 3
    },
    metrics: {
      totalDailyTourists: 2100,
      averageAttractionLoad: 24,
      visitorConcentration: 38,
      tourismDistributionStatus: 'Tranquil & Balanced',
      localBusinessOpportunity: 'High Nomadic Craft Potential',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 0,
      localEconomyCapturePct: 42
    },
    culturalDNA: {
      knownFor: [
        '16th-Century Khimsar Fort & Heritage Palace',
        'Khimsar Dunes Village secluded around an oasis',
        'Bishnoi community sacred blackbuck protection',
        'Camel safaris across undisturbed undulating sand dunes'
      ],
      taste: ['Ker Sangri desert bean delicacy', 'Bajra Roti with white butter', 'Gatte Ki Sabzi'],
      landscape: ['Golden shifting sand dunes', 'Desert oasis water body', 'Arid thorny scrub'],
      festivals: ['Nagaur Cattle Fair', 'Desert Folk Camp Evenings']
    }
  },
  {
    id: 'khejarli',
    name: 'Khejarli',
    type: 'VILLAGE',
    state: 'Rajasthan',
    district: 'Jodhpur',
    region: 'NORTH',
    culturalRegion: 'Marwar Desert & Bishnoi Heart',
    tagline: 'Birthplace of the World’s First Ecological Movement',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'A SACRED CRADLE OF ENVIRONMENTAL DEFIANCE.',
      subheadline: 'ROAM has mapped partial demand data: Historic 1730 site where Amrita Devi and 363 Bishnois sacrificed their lives to protect Khejri trees.',
      overloadedCount: 0,
      underutilizedCount: 2
    },
    metrics: {
      totalDailyTourists: 650,
      averageAttractionLoad: 12,
      visitorConcentration: 15,
      tourismDistributionStatus: 'Completely Tranquil Sanctuary',
      localBusinessOpportunity: 'Eco-Education Potential',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 0,
      localEconomyCapturePct: 60
    },
    culturalDNA: {
      knownFor: [
        'Historic Amrita Devi Bishnoi Tree Martyr Monument (1730 AD)',
        'Sacred Khejri (Prosopis cineraria) Grove Conservation',
        'Bishnoi 29 Principles of Non-violence and Nature Protection',
        'Wildlife Sanctuary with roaming Chinkaras and Peacocks'
      ],
      taste: ['Sangri sabzi', 'Bajre ki khichdi with chaas', 'Marwari Kadhi'],
      landscape: ['Semi-arid scrubland with green Khejri trees', 'Protected deer sanctuary', 'Rural mud-plastered Bishnoi homes'],
      festivals: ['Khejarli Shaheedi Mela (Annual martyrdom tribute mela in Bhadrapad)']
    }
  },

  // --- KARNATAKA ---
  {
    id: 'hampi',
    name: 'Hampi',
    type: 'TOURIST_SITE',
    state: 'Karnataka',
    district: 'Vijayanagara',
    region: 'SOUTH',
    culturalRegion: 'Tungabhadra River & Vijayanagara Empire',
    tagline: 'The City of Boulders & Ruined Empires',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'A BOULDER-STREWN MONUMENTAL REALM.',
      subheadline: 'ROAM has mapped partial demand data: UNESCO World Heritage stone chariot, Virupaksha Temple, and royal elephant stables.',
      overloadedCount: 1,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 16500,
      averageAttractionLoad: 52,
      visitorConcentration: 78,
      tourismDistributionStatus: 'Virupaksha & Vittala Concentration',
      localBusinessOpportunity: 'Bicycle Tour & Artisan Potential',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 28
    },
    culturalDNA: {
      knownFor: [
        '14th-Century Vijayanagara Empire Capital Ruins',
        'Vittala Temple Stone Chariot & Musical Pillars',
        'Virupaksha Temple functioning continuously for 700+ years',
        'Coracle boat rides across Tungabhadra River rapids'
      ],
      taste: ['Karnataka Bisi Bele Bath', 'Crisp Benne Dosa', 'South Indian Filter Coffee'],
      landscape: ['Ancient granite boulder heaps', 'Tungabhadra River valley', 'Banana plantations and paddy fields'],
      festivals: ['Hampi Utsav (November cultural dance and light festival)', 'Purandara Dasa Aradhana']
    }
  },
  {
    id: 'bengaluru',
    name: 'Bengaluru',
    type: 'CITY',
    state: 'Karnataka',
    district: 'Bengaluru Urban',
    region: 'SOUTH',
    culturalRegion: 'Deccan Plateau Garden City',
    tagline: 'The Garden City & Tech Capital',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'CENTURIES OF BOTANICAL & TECH HERITAGE.',
      subheadline: 'Lalbagh Glass House, Cubbon Park canopy, Bangalore Palace, and historic breakfast darshinis.',
      overloadedCount: 2,
      underutilizedCount: 6
    },
    metrics: {
      totalDailyTourists: 38000,
      averageAttractionLoad: 60,
      visitorConcentration: 72,
      tourismDistributionStatus: 'Weekend Lalbagh & Palace Traffic',
      localBusinessOpportunity: 'High Filter Coffee & Craft Brewery Reach',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 52
    },
    culturalDNA: {
      knownFor: [
        '1760 Lalbagh Botanical Garden & Victorian Glass House',
        'Cubbon Park 300-acre green lung with heritage red buildings',
        'Tudor-style 1887 Bangalore Palace',
        'Historic South Indian tiffin culture (MTR & Vidyarthi Bhavan)'
      ],
      taste: ['Crispy Masala Dosa with ghee', 'Filter Kaapi in stainless steel tumblers', 'Mysore Pak', 'Bisi Bele Bath'],
      landscape: ['Lush tropical tree canopies', 'Granite urban parks', 'Subtropical plateau breeze'],
      festivals: ['Bengaluru Karaga (one of South India\'s oldest festivals)', 'Lalbagh Flower Shows']
    }
  },
  {
    id: 'mysuru',
    name: 'Mysuru',
    type: 'CITY',
    state: 'Karnataka',
    district: 'Mysuru',
    region: 'SOUTH',
    culturalRegion: 'Wodeyar Kingdom & Sandalwood City',
    tagline: 'The City of Palaces & Fragrant Sandalwood',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'ILLUMINATED PALACES & ROYAL HERITAGE.',
      subheadline: 'Mysore Palace 100,000 light bulbs, Chamundi Hill temple, and Devaraja heritage spice market.',
      overloadedCount: 2,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 22000,
      averageAttractionLoad: 65,
      visitorConcentration: 80,
      tourismDistributionStatus: 'Palace Sunday Evening Surge',
      localBusinessOpportunity: 'High Mysore Silk & Sandalwood Soap Sales',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 30,
      localEconomyCapturePct: 45
    },
    culturalDNA: {
      knownFor: [
        'Amba Vilas (Mysore Palace) with 100,000 glowing bulbs on Sundays',
        'Pure Mulberry Mysore Silk Weaving factories',
        'Ancient Sandalwood carving and essential oil distilleries',
        'Devaraja Market — 130-year-old fruit and flower bazaar'
      ],
      taste: ['Original Mysore Pak (rich chickpea fudge)', 'Mylari Dosa with coconut chutney', 'Mysore Filter Coffee'],
      landscape: ['Chamundi Hill ridge', 'Colonial royal boulevards', 'Palace fountains and courtyards'],
      festivals: ['Mysore Dasara (Jumboo Savari grand elephant procession)']
    }
  },

  // --- TAMIL NADU ---
  {
    id: 'madurai',
    name: 'Madurai',
    type: 'CITY',
    state: 'Tamil Nadu',
    district: 'Madurai',
    region: 'SOUTH',
    culturalRegion: 'Sangam Era Temple Capital',
    tagline: 'The Athens of the East & 2,500-Year Temple City',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'THE ANCIENT CITY OF 14 TOWERS & JASMINE.',
      subheadline: 'Meenakshi Amman Temple 14 gopurams, Thirumalai Nayakkar Palace, and 24-hour food lanes.',
      overloadedCount: 2,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 28000,
      averageAttractionLoad: 72,
      visitorConcentration: 85,
      tourismDistributionStatus: 'Temple Corridor Peak at Morning & Evening Aarti',
      localBusinessOpportunity: 'High Madurai Jasmine & Sungudi Saree Trade',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 45,
      localEconomyCapturePct: 42
    },
    culturalDNA: {
      knownFor: [
        'Meenakshi Sundareswarar Temple with 14 colorful towering Gopurams',
        'Thirumalai Nayakkar Palace Indo-Saracenic giant pillars',
        'GI-tagged fragrant Madurai Malli (jasmine flower garlands)',
        'Traditional Sungudi cotton tie-and-dye weaving'
      ],
      taste: ['Jigarthanda cold dessert drink', 'Kari Dosa (spicy minced mutton pancake)', 'Fluffy Idlis with 4 chutneys'],
      landscape: ['Vaigai river basin', 'Concentric lotus-shaped medieval street plan', 'Sculpted granite corridors'],
      festivals: ['Chithirai Festival (Meenakshi celestial wedding & river procession)']
    }
  },
  {
    id: 'chennai',
    name: 'Chennai',
    type: 'CITY',
    state: 'Tamil Nadu',
    district: 'Chennai',
    region: 'SOUTH',
    culturalRegion: 'Coromandel Coast & Carnatic Hub',
    tagline: 'The Cultural Gateway of South India',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: '7TH-CENTURY TEMPLE TOWERS & MARINA COAST.',
      subheadline: 'Kapaleeshwarar Temple in Mylapore, Fort St. George, Marina Beach promenade, and Carnatic sabhas.',
      overloadedCount: 1,
      underutilizedCount: 6
    },
    metrics: {
      totalDailyTourists: 32000,
      averageAttractionLoad: 54,
      visitorConcentration: 68,
      tourismDistributionStatus: 'Marina Beach & Mylapore Evening Crowd',
      localBusinessOpportunity: 'High Carnatic Music & Kanchipuram Silk Reach',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 48
    },
    culturalDNA: {
      knownFor: [
        '7th-Century Kapaleeshwarar Temple Dravidian architecture in Mylapore',
        'Marina Beach — second longest natural urban beach in the world',
        'San Thome Cathedral Basilica over St. Thomas Apostle tomb',
        'December Carnatic Music & Bharatanatyam Margazhi Season'
      ],
      taste: ['Mylapore Filter Coffee', 'Podhi Idlis at Murugan Idli Shop', 'Sundal and fish fry on Marina Beach'],
      landscape: ['Coromandel sandy coastline', 'Bay of Bengal sea breeze', 'Dravidian gopuram silhouettes'],
      festivals: ['Margazhi Music Festival', 'Mylapore Festival', 'Pongal']
    }
  },
  {
    id: 'chettinad',
    name: 'Chettinad (Karaikudi)',
    type: 'RURAL_AREA',
    state: 'Tamil Nadu',
    district: 'Sivaganga',
    region: 'SOUTH',
    culturalRegion: 'Nattukottai Chettiar Heritage Realm',
    tagline: 'Palatial Mansions & Legendary Spices',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: '19TH-CENTURY TEAK MANSIONS & SPICE LEGENDS.',
      subheadline: 'Over 10,000 palatial haveli-mansions with Burma teak, Italian marble, Athangudi handmade tiles, and fiery cuisine.',
      overloadedCount: 0,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 3800,
      averageAttractionLoad: 30,
      visitorConcentration: 45,
      tourismDistributionStatus: 'Tranquil & Serene Corridor',
      localBusinessOpportunity: 'High Athangudi Tile & Culinary Tourism Potential',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 0,
      localEconomyCapturePct: 62
    },
    culturalDNA: {
      knownFor: [
        'Enormous 100-room heritage Chettiar Mansions with Burma teak',
        'Athangudi handmade floral cement tile craft',
        'Kandangi traditional handloom cotton sarees',
        'Authentic Chettinad culinary masterclasses'
      ],
      taste: ['Chettinad Chicken/Mushroom Pepper Fry with stone-ground spices', 'Kavuni Arisi (black sticky rice pudding)', 'Idiyappam with coconut milk'],
      landscape: ['Semi-arid rural terrain with palatial courtyard mansions', 'Sacred Ayyanar terracotta horse shrines'],
      festivals: ['Chettinad Heritage Festival', 'Kottayur Temple Car Festival']
    }
  },

  // --- TELANGANA & ANDHRA PRADESH ---
  {
    id: 'hyderabad',
    name: 'Hyderabad',
    type: 'CITY',
    state: 'Telangana',
    district: 'Hyderabad',
    region: 'SOUTH',
    culturalRegion: 'Qutb Shahi & Asaf Jahi Deccan Capital',
    tagline: 'The City of Pearls & Nizami Splendour',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'THE 400-YEAR MONUMENT OF FOUR MINARETS.',
      subheadline: 'Charminar historic quarter, Golconda Fort acoustic echoes, Chowmahalla Palace, and world-famous Dum Biryani.',
      overloadedCount: 2,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 36000,
      averageAttractionLoad: 68,
      visitorConcentration: 84,
      tourismDistributionStatus: 'Charminar & Laad Bazaar Evening Density',
      localBusinessOpportunity: 'High Lacquer Bangle & Basra Pearl Potential',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 30,
      localEconomyCapturePct: 50
    },
    culturalDNA: {
      knownFor: [
        '1591 Charminar grand triumphal arch in Old City',
        'Golconda Fort with acoustics capable of signaling across 1 km',
        'Chowmahalla Palace & Falaknuma Palace Nizami luxury',
        'Laad Bazaar traditional handcrafted lacquer bangles'
      ],
      taste: ['Hyderabadi Dum Biryani with mirchi ka salan', 'Haleem slow-cooked during Ramadan', 'Osmania Biscuits with Irani Chai', 'Double Ka Meetha'],
      landscape: ['Ancient granitic Deccan boulders', 'Hussain Sagar Lake with monolithic Buddha', 'Mughal-Persian arches'],
      festivals: ['Bonalu (folk goddess festival)', 'Numaish All India Industrial Exhibition', 'Ramadan night bazaars']
    }
  },
  {
    id: 'pochampally',
    name: 'Pochampally',
    type: 'VILLAGE',
    state: 'Telangana',
    district: 'Yadadri Bhuvanagiri',
    region: 'SOUTH',
    culturalRegion: 'Silk City of India & Bhoodan Movement',
    tagline: 'The World Tourism Organization Best Tourism Village',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'MATHEMATICAL IKAT SILK WEAVERS OF TELANGANA.',
      subheadline: 'UNWTO recognized heritage village where 10,000 master weavers create complex double-ikat tie-and-dye silk.',
      overloadedCount: 0,
      underutilizedCount: 3
    },
    metrics: {
      totalDailyTourists: 1500,
      averageAttractionLoad: 20,
      visitorConcentration: 30,
      tourismDistributionStatus: 'Completely Tranquil Craft Village',
      localBusinessOpportunity: 'High Direct Weaver Silk Sales',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 0,
      localEconomyCapturePct: 75
    },
    culturalDNA: {
      knownFor: [
        'Pochampally Ikat (Double-Ikat) UNESCO GI-tagged weaving',
        'Historic Bhoodan Movement birth site by Acharya Vinoba Bhave (1951)',
        'Traditional pit looms operating inside open village verandas',
        'Rural Silk Tourism Park and Craft Museum'
      ],
      taste: ['Telangana Sarva Pindi (spicy rice flour pancake)', 'Sakinalu sesame snacks', 'Gongura Mutton/Dal'],
      landscape: ['Rural Deccan palm fields', 'Open brick courtyards with spinning wheels (charkhas)'],
      festivals: ['Pochampally Handloom Mela', 'Bathukamma floral celebration']
    }
  },

  // --- GUJARAT & MAHARASHTRA ---
  {
    id: 'ahmedabad',
    name: 'Ahmedabad',
    type: 'CITY',
    state: 'Gujarat',
    district: 'Ahmedabad',
    region: 'WEST',
    culturalRegion: 'Sabarmati & UNESCO Walled City',
    tagline: 'India\'s First UNESCO World Heritage City',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'POLS OF WOODEN LATTICE & GANDHIAN SERENITY.',
      subheadline: 'Sabarmati Ashram, Adalaj Stepwell 5-storey subterranean marvel, Sidi Saiyyed Jali stone tree of life, and Manek Chowk night eats.',
      overloadedCount: 1,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 26000,
      averageAttractionLoad: 56,
      visitorConcentration: 72,
      tourismDistributionStatus: 'Adalaj & Sabarmati Riverfront Peak',
      localBusinessOpportunity: 'High Block Print & Khadi Artisan Revenue',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 46
    },
    culturalDNA: {
      knownFor: [
        'UNESCO Walled City with 600-year-old wooden carved Pol communities',
        'Sabarmati Ashram (Hriday Kunj) — Mahatma Gandhi\'s headquarters for 12 years',
        'Adalaj Stepwell — 1498 five-story underground water sanctuary',
        'Sidi Saiyyed Mosque filigree carved sandstone "Tree of Life" window'
      ],
      taste: ['Gujarati Thali with sweet dal & kadhi', 'Khaman & Dhokla with green papaya chutney', 'Manek Chowk midnight butter pav bhaji & chocolate sandwiches'],
      landscape: ['Sabarmati river corridor', 'Intricate subterranean carved stepwells', 'Dense historic urban Pols'],
      festivals: ['International Kite Festival (Uttarayan)', 'Navratri 9-night Garba dances']
    }
  },
  {
    id: 'kutch',
    name: 'Rann of Kutch (Dhordo)',
    type: 'RURAL_AREA',
    state: 'Gujarat',
    district: 'Kutch',
    region: 'WEST',
    culturalRegion: 'The Great White Salt Desert',
    tagline: 'The Endless White Salt Desert & Rogan Art',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'MOONLIT SALT DESERTS & GENERATIONAL CRAFTS.',
      subheadline: 'The Great Rann white salt flats, Dhordo UNWTO village, Nirona village castor oil Rogan art, and nomadic Kutchi embroidery.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 11000,
      averageAttractionLoad: 48,
      visitorConcentration: 76,
      tourismDistributionStatus: 'Sunset Salt Viewpoint Surge',
      localBusinessOpportunity: 'High Rogan Art, Copper Bell & Ajrakh Reach',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 58
    },
    culturalDNA: {
      knownFor: [
        'The Great Rann of Kutch — 7,500 sq km of pure white crystalline salt desert',
        'Nirona Village: World\'s sole surviving generational Rogan Art painters',
        'Ajrakhpur natural indigo wooden block printing',
        'Traditional circular mud huts with mirror-work (Bhunga houses)'
      ],
      taste: ['Kutchi Dabeli with roasted peanuts', 'Bajra no Rotlo with garlic chutney & white butter', 'Mawa sweet from Khavda'],
      landscape: ['Vast shimmering white salt horizon', 'Kala Dungar (Black Hill) overlooking salt marshes', 'Desert camel tracks'],
      festivals: ['Rann Utsav (November to February full moon desert tent festival)']
    }
  },
  {
    id: 'pune',
    name: 'Pune',
    type: 'CITY',
    state: 'Maharashtra',
    district: 'Pune',
    region: 'WEST',
    culturalRegion: 'Maratha Kingdom & Cultural Capital of Maharashtra',
    tagline: 'The Oxford of the East & Maratha Fortress Hub',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'SEAT OF THE PESHWA EMPIRE & MOUNTAIN FORTS.',
      subheadline: 'Shaniwar Wada palace ramparts, Aga Khan Palace Gandhian memorial, Sinhagad mountain fort, and historic Peths.',
      overloadedCount: 1,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 25000,
      averageAttractionLoad: 52,
      visitorConcentration: 70,
      tourismDistributionStatus: 'Sinhagad Weekend Trekker Congestion',
      localBusinessOpportunity: 'High Bakery & Puneri Pheta Craft Trade',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 50
    },
    culturalDNA: {
      knownFor: [
        '1732 Shaniwar Wada 7-storey fortress of the Peshwa rulers',
        'Aga Khan Palace where Mahatma Gandhi & Kasturba were interned',
        'Sinhagad Fort clifftop ruins perched 4,300 feet in the Sahyadris',
        'Traditional Osho International Meditation Resort & Koregaon Park'
      ],
      taste: ['Puneri Misal Pav with fiery tarri', 'Bakharwadi from Chitale Bandhu', 'Shrewsbury Biscuits from Kayani Bakery', 'Mastani thick mango ice cream shake'],
      landscape: ['Sahyadri Western Ghats hills', 'Mula-Mutha river confluence', 'Historic Peth merchant lanes'],
      festivals: ['Pune Ganeshotsav (grand dhol-tasha processions)', 'Sawai Gandharva Bhimsen Mahotsav']
    }
  },

  // --- UTTAR PRADESH & BIHAR ---
  {
    id: 'agra',
    name: 'Agra',
    type: 'CITY',
    state: 'Uttar Pradesh',
    district: 'Agra',
    region: 'NORTH',
    culturalRegion: 'Mughal Imperial Heartland',
    tagline: 'City of the Taj Mahal & Marble Inlay',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'THE POEM IN WHITE MARBLE BY THE YAMUNA.',
      subheadline: 'Taj Mahal sunrise crowd telemetry, Agra Fort red sandstone palaces, Fatehpur Sikri UNESCO city, and Pietra Dura marble artisans.',
      overloadedCount: 3,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 45000,
      averageAttractionLoad: 88,
      visitorConcentration: 94,
      tourismDistributionStatus: 'Extreme Taj Mahal Sunrise/Sunset Bottleneck',
      localBusinessOpportunity: 'High Marble Inlay & Petha Craft Opportunity',
      monumentsAtRisk: 2,
      avgWaitTimeMinutes: 60,
      localEconomyCapturePct: 32
    },
    culturalDNA: {
      knownFor: [
        'UNESCO World Heritage Taj Mahal (1631–1648) white marble mausoleum',
        'Agra Fort massive red sandstone imperial stronghold',
        'Fatehpur Sikri ghost capital of Emperor Akbar with Buland Darwaza',
        'Parchin Kari (Pietra Dura) semi-precious stone marble inlay craft'
      ],
      taste: ['Authentic Agra Petha (crystallized ash gourd sweet) at Panchhi Petha', 'Bedai & Jalebi breakfast', 'Mughlai rich gravies with sheermal'],
      landscape: ['Yamuna river bends with Mehtab Bagh reflection garden', 'Red sandstone and white Makrana marble'],
      festivals: ['Taj Mahotsav (10-day cultural crafts and food festival in February)']
    }
  },
  {
    id: 'lucknow',
    name: 'Lucknow',
    type: 'CITY',
    state: 'Uttar Pradesh',
    district: 'Lucknow',
    region: 'NORTH',
    culturalRegion: 'Awadh Nawabi Realm',
    tagline: 'The City of Nawabs, Tehzeeb & Chikan',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'NAWABI COURTESY, BARA IMBAMBARA & AWADHI AROMAS.',
      subheadline: 'Bara Imambara gravity-defying vaulted halls & Bhool Bhulaiya labyrinth, Rumi Darwaza, and world-famous Galouti Kebabs.',
      overloadedCount: 1,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 24000,
      averageAttractionLoad: 58,
      visitorConcentration: 75,
      tourismDistributionStatus: 'Imambara & Aminabad Evening Crowds',
      localBusinessOpportunity: 'High Chikankari Embroidery & Zardozi Sales',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 45
    },
    culturalDNA: {
      knownFor: [
        'Bara Imambara with its 50-meter unsupported arched hall & Bhool Bhulaiya maze',
        'Rumi Darwaza 60-foot Constantinople-inspired gateway',
        'GI-tagged handcrafted Chikankari & delicate shadow-work embroidery',
        'Legendary Awadhi royal culinary tradition'
      ],
      taste: ['Tunday Kababi Melt-in-mouth Galouti Kebabs', 'Dum Biryani infused with rose water & saffron', 'Sheermal (saffron-flavored sweet flatbread)', 'Kulfi Falooda at Prakash Kulfi'],
      landscape: ['Gomti riverfront', 'Mughal-Baroque hybrid architecture', 'Old Aminabad and Chowk galis'],
      festivals: ['Lucknow Mahotsav', 'Muharram solemn commemorations']
    }
  },
  {
    id: 'bodhgaya',
    name: 'Bodh Gaya',
    type: 'TOWN',
    state: 'Bihar',
    district: 'Gaya',
    region: 'EAST',
    culturalRegion: 'Sacred Cradle of Buddhism',
    tagline: 'The Place of Supreme Enlightenment',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'WHERE GAUTAMA BUDDHA ATTAINED ENLIGHTENMENT.',
      subheadline: 'Mahabodhi Tree direct descendant, 1,500-year UNESCO Mahabodhi Temple, and international Buddhist monasteries from 12 nations.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 16000,
      averageAttractionLoad: 54,
      visitorConcentration: 80,
      tourismDistributionStatus: 'Mahabodhi Temple Evening Meditation Surge',
      localBusinessOpportunity: 'High Buddhist Cultural Artifact & Meditation Tourism',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 50
    },
    culturalDNA: {
      knownFor: [
        'Mahabodhi Tree where Siddhartha Gautama attained enlightenment in 531 BC',
        'UNESCO World Heritage 55-meter Mahabodhi Temple spire',
        '80-Foot Giant Buddha Statue built by Japanese master sculptors',
        'International monasteries: Thai, Tibetan, Bhutanese, Burmese, Sri Lankan'
      ],
      taste: ['Bihari Litti Chokha roasted over cow-dung embers', 'Sattu sherbet', 'Khaja sweet from nearby Silao'],
      landscape: ['Phalgu / Niranjana river banks', 'Sacred lotus ponds (Muchalinda Lake)', 'Peaceful monastery gardens'],
      festivals: ['Buddha Purnima (grand international celebration in May)', 'Kalachakra teachings']
    }
  },

  // --- UTTARAKHAND & HIMACHAL PRADESH ---
  {
    id: 'rishikesh',
    name: 'Rishikesh & Haridwar',
    type: 'TOWN',
    state: 'Uttarakhand',
    district: 'Dehradun & Haridwar',
    region: 'NORTH',
    culturalRegion: 'Gateway to the Garhwal Himalayas & Yoga Capital',
    tagline: 'Yoga Capital of the World & Sacred Ganga',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'WHERE THE EMERALD GANGA EMERGES FROM HIMALAYAS.',
      subheadline: 'Parmarth Niketan & Triveni Ghat evening aarti, Beatles Ashram murals, white-water river rapids, and high suspension bridges.',
      overloadedCount: 2,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 30000,
      averageAttractionLoad: 68,
      visitorConcentration: 86,
      tourismDistributionStatus: 'Har Ki Pauri & Ram Jhula Sunset Gridlock',
      localBusinessOpportunity: 'High Ayurvedic, Yoga & Adventure Sports Revenue',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 30,
      localEconomyCapturePct: 44
    },
    culturalDNA: {
      knownFor: [
        'Global Yoga & Meditation Ashrams (Parmarth Niketan, Sivananda)',
        'Har Ki Pauri & Triveni Ghat spiritual Ganga Aarti at dusk',
        'Beatles Ashram (Chaurasi Kutia) in Rajaji Tiger Reserve',
        'White-water river rafting from Shivpuri through Himalayan gorges'
      ],
      taste: ['Garhwali Aloo Ke Gutke with wild mountain herbs', 'Pahadi Chai with ginger & tulsi', 'Ayurvedic Sattvic thali'],
      landscape: ['Turquoise mountain Ganga river rapids', 'Dense forested Shivalik foothills', 'Iconic suspension bridges (Ram & Laxman Jhula)'],
      festivals: ['International Yoga Festival (March)', 'Kumbh Mela / Ardh Kumbh at Haridwar', 'Kanwar Yatra']
    }
  },
  {
    id: 'spiti',
    name: 'Spiti Valley',
    type: 'RURAL_AREA',
    state: 'Himachal Pradesh',
    district: 'Lahaul and Spiti',
    region: 'NORTH',
    culturalRegion: 'Trans-Himalayan Cold Desert & Tibetan Borderland',
    tagline: 'The Middle Land Between India & Tibet',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: '1,000-YEAR MONASTERIES ON CLIFFTOPS.',
      subheadline: 'Key Monastery perched at 4,166m, Tabo 996 AD UNESCO murals, fossil village of Langza, and highest post office at Hikkim.',
      overloadedCount: 0,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 2200,
      averageAttractionLoad: 28,
      visitorConcentration: 40,
      tourismDistributionStatus: 'Tranquil & Fragile High-Altitude Sanctuary',
      localBusinessOpportunity: 'High Sustainable Homestay & Fossil Guide Revenue',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 0,
      localEconomyCapturePct: 68
    },
    culturalDNA: {
      knownFor: [
        'Key Gompa (Key Monastery) — 11th-century fortress monastery at 4,166m',
        'Tabo Monastery — "Ajanta of the Himalayas" with 996 AD mud clay frescoes',
        'Hikkim — World\'s highest functioning post office (4,440m)',
        'Langza Village prehistoric marine Tethys Ocean ammonite fossils'
      ],
      taste: ['Spitian Thukpa & Steamed Momos with sea buckthorn dip', 'Butter tea with roasted barley Tsampa', 'Spiti Yak Cheese'],
      landscape: ['Barren moonscape canyons and scree slopes', 'Pristine turquoise Spiti river bed', 'Glacial peaks exceeding 6,000m'],
      festivals: ['Spiti Dechhang Festival', 'Ladarcha Fair in Kaza (traditional barter market)']
    }
  },
  {
    id: 'shimla',
    name: 'Shimla',
    type: 'CITY',
    state: 'Himachal Pradesh',
    district: 'Shimla',
    region: 'NORTH',
    culturalRegion: 'Colonial Summer Capital of British India',
    tagline: 'The Queen of Hill Stations',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'PINE RIDGES, TUDOR THEATERS & TOY TRAIN.',
      subheadline: 'UNESCO Kalka-Shimla mountain railway, Mall Road & The Ridge, Viceregal Lodge, and Jakhoo Temple.',
      overloadedCount: 2,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 28000,
      averageAttractionLoad: 70,
      visitorConcentration: 85,
      tourismDistributionStatus: 'Ridge & Mall Road Weekend Gridlock',
      localBusinessOpportunity: 'High Woodcraft, Woolen & Apple Cider Trade',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 25,
      localEconomyCapturePct: 40
    },
    culturalDNA: {
      knownFor: [
        'UNESCO World Heritage Kalka-Shimla Mountain Toy Train (1903)',
        'The Ridge & Neo-Gothic Christ Church (1857)',
        'Viceregal Lodge (Rashtrapati Niwas) Scottish baronial architecture',
        'Jakhoo Temple with giant 108-foot Lord Hanuman statue on the highest peak'
      ],
      taste: ['Himachali Dham (traditional festive feast with Madra)', 'Siddu stuffed with walnuts & poppy seeds', 'Fresh Kinnaur apple pies'],
      landscape: ['Dense deodar and oak forested ridges', 'Snow-capped Shivalik and Pir Panjal views', 'Pedestrianized colonial mall'],
      festivals: ['Shimla Summer Festival (June)', 'Ice Skating Carnival (winter)']
    }
  },

  // --- PUNJAB & KASHMIR ---
  {
    id: 'amritsar',
    name: 'Amritsar',
    type: 'CITY',
    state: 'Punjab',
    district: 'Amritsar',
    region: 'NORTH',
    culturalRegion: 'Sikh Spiritual Heart & Grand Trunk Road',
    tagline: 'The Sacred Golden Pool of Nectar',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'THE GLOWING GOLDEN TEMPLE & WORLD’S LARGEST FREE KITCHEN.',
      subheadline: 'Sri Harmandir Sahib 24/7 Langar serving 100,000 meals daily, Jallianwala Bagh memorial, and Wagah Border ceremony.',
      overloadedCount: 2,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 55000,
      averageAttractionLoad: 80,
      visitorConcentration: 92,
      tourismDistributionStatus: 'Harmandir Sahib Parikrama Peak at Palki Sahib (4 AM & 9:30 PM)',
      localBusinessOpportunity: 'High Phulkari Embroidery & Punjabi Jutti Reach',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 40,
      localEconomyCapturePct: 48
    },
    culturalDNA: {
      knownFor: [
        'Sri Harmandir Sahib (Golden Temple) covered in 500 kg of pure gold leaf',
        'Guru Ka Langar — largest community kitchen on Earth feeding 100,000+ daily',
        'Wagah-Attari Border military retreat ceremony with patriotic crowds',
        'Jallianwala Bagh historic martyr site and Amar Jawan flame'
      ],
      taste: ['Amritsari Crispy Kulcha stuffed with spiced potato & ghee', 'Creamy Lassi in giant brass glasses', 'Makki Di Roti & Sarson Da Saag', 'Kesar Da Dhaba Dal Makhani slow-cooked 12 hours'],
      landscape: ['Sacred holy Sarovar (pool of nectar)', 'Historic walled city katras (bazaars)', 'Lush fertile Punjab wheat fields'],
      festivals: ['Baisakhi (Sikh New Year & Khalsa creation)', 'Guru Nanak Gurpurab with illuminated fireworks']
    }
  },
  {
    id: 'srinagar',
    name: 'Srinagar',
    type: 'CITY',
    state: 'Jammu and Kashmir',
    district: 'Srinagar',
    region: 'NORTH',
    culturalRegion: 'Kashmir Valley & Pir Panjal Paradise',
    tagline: 'Paradise on Earth & The Floating Lake City',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'FLOATING SHIKARAS, MUGHAL GARDENS & WALNUT WOOD.',
      subheadline: 'Dal Lake cedarwood houseboats, floating dawn vegetable market, Shalimar & Nishat Bagh, and Old Downtown wooden mosques.',
      overloadedCount: 2,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 32000,
      averageAttractionLoad: 66,
      visitorConcentration: 80,
      tourismDistributionStatus: 'Boulevard Road & Shikara Ghat Evening Peak',
      localBusinessOpportunity: 'High Pashmina, Saffron & Walnut Wood Craft',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 25,
      localEconomyCapturePct: 52
    },
    culturalDNA: {
      knownFor: [
        'Dal Lake & Nigeen Lake hand-carved cedarwood Houseboats & Shikaras',
        'Floating Vegetable Market at 5 AM on Dal Lake backwaters',
        'UNESCO candidate Mughal Terraced Gardens (Shalimar & Nishat Bagh)',
        'Pashmina hand-spinning and Kashmiri papier-mâché guilds'
      ],
      taste: ['Authentic Kashmiri Wazwan 36-course feast with Rista & Rogan Josh', 'Pink salty Noon Chai with fresh Girda bread', 'Kahwa green tea infused with saffron, cardamom & crushed almonds'],
      landscape: ['Surrounding snow-clad Zabarwan mountain range', 'Still lake reflections with lotus pads and weeping willows', 'Heritage Deodar wooden architecture'],
      festivals: ['Tulip Festival at Indira Gandhi Memorial Garden (April)', 'Shikara Festival']
    }
  },

  // --- EAST & NORTHEAST ---
  {
    id: 'kolkata',
    name: 'Kolkata',
    type: 'CITY',
    state: 'West Bengal',
    district: 'Kolkata',
    region: 'EAST',
    culturalRegion: 'Cultural Capital of India & Hooghly Delta',
    tagline: 'The City of Joy & Intellectual Renaissance',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'WHITE MARBLE MEMORIALS, TRAMS & BOOK STREETS.',
      subheadline: 'Victoria Memorial, cantilevered Howrah Bridge over Hooghly river, Kumartuli idol sculptors, and College Street coffee houses.',
      overloadedCount: 2,
      underutilizedCount: 6
    },
    metrics: {
      totalDailyTourists: 42000,
      averageAttractionLoad: 62,
      visitorConcentration: 75,
      tourismDistributionStatus: 'Victoria Memorial & Park Street Crowds',
      localBusinessOpportunity: 'High Jamdani Silk & Sweet Guild Growth',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 48
    },
    culturalDNA: {
      knownFor: [
        'Victoria Memorial 1921 British imperial marble masterpiece',
        'Iconic 1943 Howrah Bridge — busiest cantilever bridge in the world',
        'Kumartuli clay idol sculptor studios crafting Durga idols from Ganga clay',
        'College Street — world\'s largest secondhand book market'
      ],
      taste: ['Warm spongy Rosogolla & Mishti Doi at KC Das', 'Kolkata Kathi Rolls at Nizam\'s', 'Mustard Hilsa fish (Ilish Macher Jhol)', 'Phuchka with fiery tamarind water'],
      landscape: ['Hooghly (Ganges) river ghats with vintage yellow taxis', 'Colonial neoclassical mansions and wooden shutter balconies', 'Lush Maidan park grounds'],
      festivals: ['UNESCO Intangible Cultural Heritage Kolkata Durga Puja (October)', 'Kolkata International Book Fair']
    }
  },
  {
    id: 'darjeeling',
    name: 'Darjeeling',
    type: 'TOWN',
    state: 'West Bengal',
    district: 'Darjeeling',
    region: 'EAST',
    culturalRegion: 'Eastern Himalayas & Champagne of Teas',
    tagline: 'The Queen of the Hills & Kanchenjunga Vistas',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'TIGER HILL SUNRISE OVER THE WORLD’S THIRD HIGHEST PEAK.',
      subheadline: 'UNESCO Darjeeling Himalayan Toy Train, 87 historic tea estates, Batasia Loop, and Tibetan Refugee Self Help Centre.',
      overloadedCount: 2,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 18000,
      averageAttractionLoad: 65,
      visitorConcentration: 82,
      tourismDistributionStatus: 'Tiger Hill 4:30 AM Traffic Jam',
      localBusinessOpportunity: 'High Muscatel First Flush Tea & Woolen Sales',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 30,
      localEconomyCapturePct: 46
    },
    culturalDNA: {
      knownFor: [
        'Tiger Hill panoramic sunrise over Mt. Kanchenjunga (8,586m)',
        'UNESCO World Heritage 1881 Darjeeling Himalayan Railway (Toy Train)',
        'GI-tagged authentic Darjeeling Orthodox Tea plantations (Makaibari, Happy Valley)',
        'Himalayan Mountaineering Institute (HMI) founded by Tenzing Norgay'
      ],
      taste: ['First Flush Darjeeling Black Tea', 'Darjeeling pork/vegetable Momos with fiery dalle chili sauce', 'Thukpa noodle soup', 'Churpi dried yak cheese'],
      landscape: ['Terraced emerald-green tea gardens draped over steep slopes', 'Majestic Kanchenjunga snow massif', 'Pine-scented colonial hill roads'],
      festivals: ['Darjeeling Tea & Tourism Festival', 'Losar (Tibetan New Year)']
    }
  },
  {
    id: 'puri',
    name: 'Puri & Konark',
    type: 'CITY',
    state: 'Odisha',
    district: 'Puri',
    region: 'EAST',
    culturalRegion: 'Kalinga Sacred Coast & Jagannath Dham',
    tagline: 'The Sacred Abode of Lord Jagannath & Sun Chariot',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'THE 12TH-CENTURY CHODAGANGA TEMPLE & SUN CHARIOT.',
      subheadline: 'Shree Jagannath Temple Mahaprasad, Konark UNESCO 13th-century stone chariot Sun Temple, and Golden Beach.',
      overloadedCount: 2,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 35000,
      averageAttractionLoad: 75,
      visitorConcentration: 88,
      tourismDistributionStatus: 'Jagannath Lion Gate Peak at Sandhya Dhupa',
      localBusinessOpportunity: 'High Pattachitra & Applique Craft Growth',
      monumentsAtRisk: 2,
      avgWaitTimeMinutes: 45,
      localEconomyCapturePct: 40
    },
    culturalDNA: {
      knownFor: [
        '12th-Century Shree Jagannath Temple (One of the four sacred Char Dham)',
        'World\'s Largest Kitchen (Rosaghara) cooking 56 food offerings (Chhapan Bhog)',
        'Konark Sun Temple — 13th-century UNESCO architectural chariot with 24 carved wheels',
        'Blue Flag certified Golden Beach on the Bay of Bengal'
      ],
      taste: ['Mahaprasad Abadha (earthen pot cooked temple rice & dal)', 'Puri Khaja layered crisp sweet', 'Chhena Poda (baked cottage cheese cake)'],
      landscape: ['Bay of Bengal coastal sands', 'Kalinga style towering stone deula spires', 'Casuarina tree coastal groves'],
      festivals: ['World Famous Puri Ratha Yatra (Chariot Festival pulling 3 giant chariots)', 'Konark Dance Festival (December)']
    }
  },
  {
    id: 'raghurajpur',
    name: 'Raghurajpur',
    type: 'VILLAGE',
    state: 'Odisha',
    district: 'Puri',
    region: 'EAST',
    culturalRegion: 'Heritage Crafts Village of Odisha',
    tagline: 'The Master Pattachitra & Gotipua Dance Village',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'AN OPEN-AIR ART GALLERY WHERE EVERY HOME IS A STUDIO.',
      subheadline: '140 generational artisan families painting Pattachitra scroll art on dried palm leaves and training Gotipua dancers.',
      overloadedCount: 0,
      underutilizedCount: 3
    },
    metrics: {
      totalDailyTourists: 1200,
      averageAttractionLoad: 18,
      visitorConcentration: 28,
      tourismDistributionStatus: 'Tranquil & Sustainable Artisan Sanctuary',
      localBusinessOpportunity: 'High Direct Master Artisan Pattachitra Sales',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 0,
      localEconomyCapturePct: 80
    },
    culturalDNA: {
      knownFor: [
        'Traditional Pattachitra scroll painting using natural stone pigments and tamarind gum',
        'Talapatra Chitra (fine needle carving on dried palm leaves)',
        'Gotipua traditional acrobatic temple dance (precursor to Odissi)',
        'Handmade papier-mâché masks, stone carvings, and wooden cow-dung toys'
      ],
      taste: ['Rasabali (fried cottage cheese in cardamom milk)', 'Dalma (lentil vegetable stew)', 'Pithas'],
      landscape: ['Two neat parallel rows of mural-painted village cottages', 'Coconut and betel nut groves', 'Bhargavi river banks'],
      festivals: ['Basant Utsav (Spring festival of colors and Gotipua dance)']
    }
  },
  {
    id: 'shillong',
    name: 'Shillong & Cherrapunji',
    type: 'CITY',
    state: 'Meghalaya',
    district: 'East Khasi Hills',
    region: 'NORTHEAST',
    culturalRegion: 'Scotland of the East & Living Root Bridges',
    tagline: 'The Cloud Abode & Living Root Architecture',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'WHERE TREES GROW INTO BRIDGES ACROSS GORGES.',
      subheadline: 'Nongriat Double Decker Living Root Bridge, Nohkalikai Falls (tallest plunge waterfall in India), Dawki crystal river, and rock music cafes.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 14000,
      averageAttractionLoad: 50,
      visitorConcentration: 70,
      tourismDistributionStatus: 'Double Decker Root Bridge Staircase Bottleneck',
      localBusinessOpportunity: 'High Indigenous Khasi Homestay & Cane Craft Potential',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 56
    },
    culturalDNA: {
      knownFor: [
        'Bio-engineered Living Root Bridges (Jingkieng Jri) grown by Khasi tribes over centuries from Ficus elastica trees',
        'Nohkalikai Falls — 1,115 ft plunge waterfall over misty cliffs',
        'Dawki (Umngot River) — water so crystal transparent boats appear to float on air',
        'Mawlynnong — celebrated as Asia\'s cleanest village with bamboo skywalks'
      ],
      taste: ['Khasi Jadoh (red rice cooked with aromatic herbs and meat)', 'Dohneiiong (pork with black sesame paste)', 'Tungrymbai fermented soy relish', 'Pineapple and wild mountain honey'],
      landscape: ['Lush pine-carpeted rolling hills and canyons', 'Spectacular rainforest clouds and dramatic gorges', 'Limestone caves (Mawsmai & Krem Liat Prah)'],
      festivals: ['Shad Suk Mynsiem (Khasi thanksgiving dance)', 'Nongkrem Dance Festival', 'Shillong Autumn Festival']
    }
  },
  {
    id: 'kaziranga',
    name: 'Kaziranga & Majuli',
    type: 'RURAL_AREA',
    state: 'Assam',
    district: 'Golaghat & Majuli',
    region: 'NORTHEAST',
    culturalRegion: 'Brahmaputra Floodplains & Satra Heart',
    tagline: 'Home of the Great Indian Rhino & Sacred River Island',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'SAVING THE PREHISTORIC RHINO ON THE BRAHMAPUTRA.',
      subheadline: 'UNESCO Kaziranga 2,400+ One-Horned Rhinos, and Majuli (world\'s largest river island with 500-year-old Vaishnavite Satras).',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 8500,
      averageAttractionLoad: 44,
      visitorConcentration: 68,
      tourismDistributionStatus: 'Central Safari Range Morning Queue',
      localBusinessOpportunity: 'High Assam Tea, Muga Golden Silk & Bamboo Craft',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 60
    },
    culturalDNA: {
      knownFor: [
        'UNESCO World Heritage Kaziranga: Houses two-thirds of the world\'s Great One-Horned Rhinoceros',
        'Majuli: World\'s largest inhabited river island preserving 15th-century Neo-Vaishnavite Satras',
        'Samaguri Satra traditional bamboo & clay mask-making art',
        'GI-tagged Muga Silk — shimmering golden wild silk exclusive to Assam'
      ],
      taste: ['Assamese Khaar (alkaline digestive preparation with raw papaya)', 'Masor Tenga (tangy river fish curry with elephant apple)', 'Pitha rice cakes stuffed with sesame & jaggery'],
      landscape: ['Vast Brahmaputra alluvial wetlands and elephant grass marshes', 'Emerald tea plantations on gentle rolling slopes', 'Majuli island serene river channels'],
      festivals: ['Rongali Bihu (Assamese spring festival & energetic dance)', 'Majuli Raas Mahotsav mask festival']
    }
  },

  // --- GOA & UNION TERRITORIES ---
  {
    id: 'goa',
    name: 'Goa (Panaji & Old Goa)',
    type: 'STATE',
    state: 'Goa',
    district: 'North & South Goa',
    region: 'WEST',
    culturalRegion: 'Konkan Coast & Portuguese Heritage',
    tagline: 'UNESCO Baroque Basilicas & Sunkissed Coastline',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: '450 YEARS OF INDO-PORTUGUESE HERITAGE & PALMS.',
      subheadline: 'Old Goa Basilica of Bom Jesus (St. Francis Xavier tomb), Fontainhas pastel Latin Quarter, spice plantations, and serene South Goa beaches.',
      overloadedCount: 2,
      underutilizedCount: 6
    },
    metrics: {
      totalDailyTourists: 48000,
      averageAttractionLoad: 66,
      visitorConcentration: 82,
      tourismDistributionStatus: 'Calangute/Baga Overcrowding vs Serene South Goa',
      localBusinessOpportunity: 'High Feni Distilleries & Portuguese Tile Art',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 44
    },
    culturalDNA: {
      knownFor: [
        'UNESCO World Heritage 1605 Basilica of Bom Jesus & Se Cathedral in Old Goa',
        'Fontainhas in Panaji — Asia\'s only surviving heritage Portuguese Latin Quarter',
        'Sahakari & Savoi organic Spice Plantations in Ponda',
        'Heritage Portuguese Mansions (Palácio do Deão, Bragança House in Chandor)'
      ],
      taste: ['Goan Fish Curry Rice with raw mango & coconut', 'Pork/Chicken Vindaloo with toddy vinegar', 'Bebinca 7-layered coconut egg dessert', 'Cashew Feni'],
      landscape: ['Mandovi and Zuari river estuaries', 'Golden sandy Arabian sea beaches fringed with coconut palms', 'Red laterite stone colonial villas'],
      festivals: ['Goa Carnival (colorful float processions in February)', 'Feast of St. Francis Xavier (December 3)', 'Shigmo folk festival']
    }
  },
  {
    id: 'pondicherry',
    name: 'Puducherry (Pondicherry)',
    type: 'TOWN',
    state: 'Puducherry (UT)',
    district: 'Puducherry',
    region: 'SOUTH',
    culturalRegion: 'French Colonial Riviera & Auroville',
    tagline: 'The French Riviera of the East & City of Dawn',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'PASTEL FRENCH CORRIDORS & SPIRITUAL EXPERIMENTAL COMMUNITIES.',
      subheadline: 'White Town cobblestone boulevards, Sri Aurobindo Ashram, Auroville golden Matrimandir sphere, and Promenade Beach.',
      overloadedCount: 1,
      underutilizedCount: 5
    },
    metrics: {
      totalDailyTourists: 19000,
      averageAttractionLoad: 58,
      visitorConcentration: 76,
      tourismDistributionStatus: 'Promenade Beach & White Town Weekend Surge',
      localBusinessOpportunity: 'High French Bakery, Handmade Paper & Pottery Sales',
      monumentsAtRisk: 0,
      avgWaitTimeMinutes: 15,
      localEconomyCapturePct: 54
    },
    culturalDNA: {
      knownFor: [
        'White Town French Quarter with mustard-yellow colonial villas and bougainvillea gates',
        'Auroville (City of Dawn) & the monumental golden globe Matrimandir',
        'Sri Aurobindo Ashram spiritual retreat founded in 1926',
        'Handmade Paper Factory & traditional ceramic pottery studios'
      ],
      taste: ['French Croissants & Baguettes at Baker Street', 'Franco-Tamil fusion seafood bouillabaisse', 'Crepes with organic passion fruit curd'],
      landscape: ['Bay of Bengal rocky sea wall promenade', 'Grid-planned tree-shaded French avenues', 'Red soil Auroville experimental forest'],
      festivals: ['Pondicherry Heritage Festival', 'Auroville Birthday & Bonfire (February 28)']
    }
  },
  {
    id: 'andaman',
    name: 'Andaman (Havelock & Port Blair)',
    type: 'RURAL_AREA',
    state: 'Andaman and Nicobar Islands (UT)',
    district: 'South Andaman',
    region: 'ISLANDS',
    culturalRegion: 'Bay of Bengal Tropical Archipelago',
    tagline: 'Pristine Coral Atolls & Freedom Struggle History',
    intelligenceTier: 'PARTIAL',
    heroCopy: {
      headline: 'TURQUOISE REEFS & THE HISTORIC CELLULAR JAIL.',
      subheadline: 'Cellular Jail national memorial in Port Blair, Radhanagar Beach (Asia\'s cleanest beach), coral diving at Elephant Beach, and limestone caves.',
      overloadedCount: 1,
      underutilizedCount: 4
    },
    metrics: {
      totalDailyTourists: 7500,
      averageAttractionLoad: 46,
      visitorConcentration: 72,
      tourismDistributionStatus: 'Ferry Terminal & Radhanagar Sunset Crowds',
      localBusinessOpportunity: 'High Scuba Diving & Shell Craft Growth',
      monumentsAtRisk: 1,
      avgWaitTimeMinutes: 20,
      localEconomyCapturePct: 50
    },
    culturalDNA: {
      knownFor: [
        'Historic 1906 Cellular Jail (Kaala Paani) national memorial with sound & light show',
        'Radhanagar Beach (Beach No. 7) on Havelock Island (Swaraj Dweep)',
        'Living Coral Reef scuba diving & snorkeling at Elephant Beach & Neil Island',
        'Baratang Island mangrove boat safari and ancient limestone caves'
      ],
      taste: ['Fresh caught Red Snapper grilled with coastal spices', 'Coconut Prawn Curry', 'Tropical coconut water and wild banana'],
      landscape: ['Dense tropical rainforest meeting powder-white coral sands', 'Bioluminescent night waters', 'Turquoise translucent sea lagoons'],
      festivals: ['Island Tourism Festival (January)', 'Monsoon Music Festival']
    }
  }
];

