/**
 * ROAM Plan Mode Component (V3.5)
 * Central Travel Command Center connecting:
 * PLAN + CROWD FORECAST + MARKET + MAP + "ONE DAY, ONE STORY" + JOURNEY MOOD
 *
 * Features:
 * - "One Day, One Story" Narrative Day Arc Header
 * - 3-Column Command Center (Timeline | Spatial Route Map | Connected Intelligence)
 * - "Why ROAM Picked This" Transparent Scoring Breakdown
 * - Journey Mood Preference Matrix
 * - User Interest Chips (Food, Shopping, History, Architecture, Culture, Nature, Local Life, Relaxed)
 * - Single Simple Day Health Status Chip (Balanced, Too Crowded, Too Much Travel, Good Flow)
 * - Interactive Time Editor Popover with hourly crowd predictions & human labels
 * - Connected Crowd Forecast Curve dynamically highlighting the scheduled time
 * - "Better Time" Proactive Intelligence Layer with 1-click move button
 * - "Balance My Day" Optimizer with Before/After modal
 * - Dynamic "What Should I Do Next?" card
 * - "Open Slot" Detection card with category shortcuts
 * - Working Google Maps links (Open in Maps ↗, Get Directions ↗)
 */

import { travelState } from '../state/travelState.js';
import { formatIndianNumber } from '../utils/formatters.js';

export class PlanModeController {
  constructor(app) {
    this.app = app;
    this.mount = document.getElementById('plan-view-mount');
    this.activeTimeEditorItemId = null;
    this.showDayHealthExplanation = false;
    this.showJourneyMoodDrawer = false;
    this.showStoryDrawer = false;
    this.selectedSlotCategory = null;

    // Subscribe to centralized travelState changes
    travelState.subscribe((event, data) => {
      if (['itinerary:updated', 'focus:changed', 'interests:changed', 'date:changed', 'mood:changed', 'route:changed', 'memories:updated'].includes(event)) {
        if (this.app?.activeMode === 'plan') {
          this.render();
        }
      }
    });
  }

  setDestination(locationData) {
    travelState.setLocation(locationData);
    this.render();
  }

  // --- Actions ---
  toggleInterest(interestId) {
    travelState.toggleInterest(interestId);
  }

  setDate(dateKey) {
    travelState.setDate(dateKey);
  }

  focusItem(id) {
    travelState.setFocusedItem(id);
    this.render();
  }

  openTimeEditor(itemId, event) {
    if (event) event.stopPropagation();
    this.activeTimeEditorItemId = (this.activeTimeEditorItemId === itemId) ? null : itemId;
    this.render();
  }

  setTime(itemId, newTime) {
    travelState.updateItemTime(itemId, newTime);
    this.activeTimeEditorItemId = null;
    if (this.app?.modalController) {
      const item = travelState.itinerary.find(i => i.id === itemId);
      this.app.modalController.showToast(`Updated ${item?.name || 'Stop'} to ${newTime}`);
    }
  }

  setDuration(itemId, durationMinutes) {
    travelState.updateItemDuration(itemId, durationMinutes);
  }

  removeItem(itemId) {
    const item = travelState.itinerary.find(i => i.id === itemId);
    travelState.removeItem(itemId);
    if (this.app?.modalController) {
      this.app.modalController.showToast(`Removed ${item?.name || 'Stop'}`);
    }
  }

  moveItem(itemId, direction) {
    travelState.moveItem(itemId, direction);
  }

  runBalanceMyDay() {
    const comparison = travelState.balanceDay();
    if (!comparison) return;

    if (this.app && this.app.modalController) {
      this.app.modalController.openBalanceModal(
        comparison.currentPlan,
        comparison.balancedPlan,
        () => {
          travelState.applyBalancedSchedule(comparison.balancedPlan);
        }
      );
    }
  }

  addPlace(place) {
    const res = travelState.addPlaceIntelligently(place);
    if (this.app?.modalController) {
      this.app.modalController.showToast(`Added ${res.item.name} at ${res.time} (${res.reason})`);
    }
    this.render();
  }

  // --- Rendering ---
  render() {
    if (!this.mount) {
      this.mount = document.getElementById('plan-view-mount');
      if (!this.mount) return;
    }

    const city = travelState.location?.name || 'Jaipur';
    const itinerary = travelState.itinerary;
    const focusedItem = travelState.getFocusedItem();
    const dayHealth = travelState.dayHealth;
    const betterTime = travelState.getBetterTimeInsight(focusedItem);
    const whatNext = travelState.getWhatShouldIDoNext();
    const openSlots = travelState.openSlots;
    const storyText = travelState.generateOneDayStory();
    const mood = travelState.journeyMood;
    const memories = travelState.tripMemories || [];

    const interestChips = [
      { id: 'food', label: '🍛 Food' },
      { id: 'shopping', label: '🛍️ Shopping' },
      { id: 'history', label: '🏛️ History' },
      { id: 'architecture', label: '🏰 Architecture' },
      { id: 'culture', label: '🎨 Culture' },
      { id: 'nature', label: '🌿 Nature' },
      { id: 'local_life', label: '🧭 Local Life' },
      { id: 'relaxed', label: '☕ Relaxed' }
    ];

    this.mount.innerHTML = `
      <!-- Top Command Center Bar -->
      <div class="plan-header-card">
        <div class="plan-header-top">
          <div>
            <div class="plan-eyebrow">
              PERSONAL TRAVEL COMMAND CENTER
            </div>
            <h2 class="plan-city-title">MY ${city.toUpperCase()} DAY</h2>
            
            <!-- "One Day, One Story" Narrative Day Arc Header -->
            <div class="one-day-story-strip">
              <span class="story-icon">📖</span>
              <span class="story-text"><strong>ONE DAY, ONE STORY:</strong> "${storyText}"</span>
            </div>
          </div>

          <div class="plan-header-actions">
            <button id="plan-story-toggle" class="btn btn-outline" title="Open Your ROAM Story & Memory Journal">
              📖 YOUR STORY
            </button>
            <button id="plan-journey-mood-toggle" class="btn btn-outline" title="Adjust Travel Personality Spectrum">
              🎛️ JOURNEY MOOD
            </button>
            <button id="plan-balance-cta" class="btn btn-primary balance-glow-btn" title="Reorder stops to avoid peak queues and midday heat">
              ⚡ BALANCE MY DAY
            </button>
            <button id="plan-add-place-cta" class="btn btn-secondary">
              + ADD PLACE
            </button>
          </div>
        </div>

        <!-- "Your ROAM Story & Memory Journal" Drawer -->
        ${this.showStoryDrawer ? `
          <div class="roam-story-drawer">
            <div class="story-drawer-header">
              <div>
                <span class="story-drawer-badge">✨ YOUR PERSONAL TRAVEL NARRATIVE</span>
                <h3 class="story-drawer-title">MY ${city.toUpperCase()} MEMORY JOURNAL</h3>
              </div>
              <button class="mood-close-btn" id="story-drawer-close">&times;</button>
            </div>

            <div class="story-narrative-card">
              <div class="story-narrative-quote">"${storyText}"</div>
              <div class="story-narrative-meta">
                <span>📍 ${itinerary.length} Curated Stops</span> • 
                <span>🌿 Direct Artisan Economic Spillover Active</span> • 
                <span>⏱️ ~${Math.round(itinerary.reduce((a, b) => a + (b.durationMinutes || 90), 0) / 60)}h Experience</span>
              </div>
            </div>

            <div class="story-timeline-recap">
              <div class="story-recap-title">ITINERARY HIGHLIGHTS:</div>
              <div class="story-stops-chain">
                ${itinerary.map((st, i) => `
                  <div class="story-stop-pill">
                    <strong>${st.time}</strong> • ${st.name} <em>(${st.category})</em>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Traveler Memory Notes Section -->
            <div class="story-notes-section">
              <label class="story-notes-label">YOUR PERSONAL REFLECTIONS & SOUVENIRS:</label>
              <div class="story-input-row">
                <input type="text" id="story-note-input" class="story-note-field" placeholder="e.g. Learned how natural indigo dyes ferment in Sanganer workshop..." />
                <button id="story-save-note-btn" class="btn btn-sm btn-primary">Save Note</button>
              </div>

              ${memories.length > 0 ? `
                <div class="story-saved-memories-list">
                  ${memories.map((m, idx) => `
                    <div class="story-memory-item">
                      <span class="memory-bullet">🔖</span>
                      <span class="memory-text">${m.text || m}</span>
                    </div>
                  `).join('')}
                </div>
              ` : ''}
            </div>

            <div class="story-drawer-actions">
              <button id="story-copy-btn" class="btn btn-secondary">
                📋 Copy Story & Itinerary to Clipboard
              </button>
              <button id="story-export-btn" class="btn btn-primary">
                💾 Export Story Card
              </button>
            </div>
          </div>
        ` : ''}

        <!-- Journey Mood Slider Drawer -->
        ${this.showJourneyMoodDrawer ? `
          <div class="journey-mood-drawer">
            <div class="mood-drawer-header">
              <span class="mood-title">🎛️ JOURNEY MOOD & TRAVEL PERSONALITY SPECTRUM</span>
              <button class="mood-close-btn" id="mood-drawer-close">&times;</button>
            </div>
            <p class="mood-subtitle">
              ROAM balances crowds, pacing, food recommendations, and artisan routes according to your mood:
            </p>

            <div class="mood-sliders-grid">
              <div class="mood-slider-card">
                <div class="slider-labels">
                  <span>⚡ Maximum Chaos & Excitement</span>
                  <span class="slider-val-tag">${mood.chaosCalm}% Calm</span>
                  <span>🌿 Serene Calm & Quiet</span>
                </div>
                <input type="range" class="mood-range-input" data-mood="chaosCalm" min="0" max="100" value="${mood.chaosCalm}" />
              </div>

              <div class="mood-slider-card">
                <div class="slider-labels">
                  <span>🏛️ Iconic Tourist Highlights</span>
                  <span class="slider-val-tag">${mood.touristLocal}% Local</span>
                  <span>🧭 Deep Local Guilds & Gullies</span>
                </div>
                <input type="range" class="mood-range-input" data-mood="touristLocal" min="0" max="100" value="${mood.touristLocal}" />
              </div>

              <div class="mood-slider-card">
                <div class="slider-labels">
                  <span>🏃 Fast-Paced Action</span>
                  <span class="slider-val-tag">${mood.fastSlow}% Slow Pace</span>
                  <span>☕ Slow Tea Pauses & Wandering</span>
                </div>
                <input type="range" class="mood-range-input" data-mood="fastSlow" min="0" max="100" value="${mood.fastSlow}" />
              </div>

              <div class="mood-slider-card">
                <div class="slider-labels">
                  <span>👑 Royal Heritage Palaces</span>
                  <span class="slider-val-tag">${mood.luxuryRaw}% Raw Authenticity</span>
                  <span>🍛 Raw Street Food & Crafts</span>
                </div>
                <input type="range" class="mood-range-input" data-mood="luxuryRaw" min="0" max="100" value="${mood.luxuryRaw}" />
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Lightweight User Interest Chips Bar -->
        <div class="plan-interests-bar">
          <span class="interests-label">YOUR INTERESTS:</span>
          <div class="interests-chips-wrap">
            ${interestChips.map(c => `
              <button class="interest-chip ${travelState.hasInterest(c.id) ? 'active' : ''}" data-interest="${c.id}">
                ${c.label}
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Date Pills & Simple Day Health Pill -->
        <div class="plan-status-bar">
          <div class="plan-date-wrap">
            <span style="font-size:0.82rem; font-weight:700; color:#fff;">Date:</span>
            <div class="plan-date-pills">
              <button class="plan-date-pill ${travelState.selectedDate === 'today' ? 'active' : ''}" data-date="today">Today</button>
              <button class="plan-date-pill ${travelState.selectedDate === 'tomorrow' ? 'active' : ''}" data-date="tomorrow">Tomorrow</button>
              <button class="plan-date-pill ${travelState.selectedDate === 'your_day' ? 'active' : ''}" data-date="your_day">Your Day 📅</button>
            </div>
          </div>

          <!-- Single Simple DAY HEALTH Indicator -->
          <div class="day-health-wrapper">
            <button id="day-health-chip" class="day-health-chip ${dayHealth.status.toLowerCase()}" style="border-color:${dayHealth.color}; color:${dayHealth.color};">
              <span class="health-pulse-dot" style="background:${dayHealth.color};"></span>
              <span>YOUR DAY: ${dayHealth.status}</span>
              <span class="health-expand-arrow">▾</span>
            </button>
          </div>
        </div>

        <!-- Day Health Explanation Popover -->
        ${this.showDayHealthExplanation ? `
          <div class="day-health-popover">
            <div class="popover-header">
              <span style="color:${dayHealth.color}; font-weight:800; font-size:0.9rem;">${dayHealth.headline}</span>
              <button class="popover-close-btn" id="health-popover-close">&times;</button>
            </div>
            <p class="popover-desc">${dayHealth.description}</p>
            ${dayHealth.fixAction ? `
              <div class="popover-actions">
                <button class="btn btn-sm btn-primary" id="health-quick-fix-btn" data-type="${dayHealth.fixAction.type}">
                  ⚡ ${dayHealth.fixAction.label}
                </button>
              </div>
            ` : ''}
          </div>
        ` : ''}
      </div>

      <!-- 3-Column Responsive Command Center Grid -->
      <div class="plan-command-grid">
        
        <!-- COLUMN 1: ITINERARY TIMELINE -->
        <div class="plan-col-timeline">
          <div class="col-header-strip">
            <span class="col-header-title">ITINERARY SCHEDULE</span>
            <span class="col-header-meta">${itinerary.length} STOPS • ~${Math.round(itinerary.reduce((a, b) => a + (b.durationMinutes || 90), 0) / 60)}H TOTAL</span>
          </div>

          <!-- Quick Timetable Adjuster Toolbar -->
          <div class="plan-timeline-toolbar">
            <div class="timeline-toolbar-group">
              <span class="toolbar-label">Start Day:</span>
              <div class="toolbar-pills">
                <button class="plan-start-time-btn" data-time="07:30">07:30</button>
                <button class="plan-start-time-btn" data-time="08:30">08:30</button>
                <button class="plan-start-time-btn" data-time="09:00">09:00</button>
                <button class="plan-start-time-btn" data-time="10:00">10:00</button>
              </div>
            </div>

            <div class="timeline-toolbar-group">
              <span class="toolbar-label">Shift Day:</span>
              <div class="toolbar-pills">
                <button class="plan-shift-btn" data-shift="-30" title="Shift day 30 minutes earlier">−30m</button>
                <button class="plan-shift-btn" data-shift="-15" title="Shift day 15 minutes earlier">−15m</button>
                <button class="plan-shift-btn" data-shift="15" title="Shift day 15 minutes later">+15m</button>
                <button class="plan-shift-btn" data-shift="30" title="Shift day 30 minutes later">+30m</button>
              </div>
            </div>

            <div class="timeline-toolbar-group">
              <span class="toolbar-label">Add Break:</span>
              <div class="toolbar-pills">
                <button class="plan-quick-break-btn" data-type="chai" title="Insert 30 min Masala Chai Break">+30m Chai ☕</button>
                <button class="plan-quick-break-btn" data-type="lunch" title="Insert 1h Lunch Break">+1h Lunch 🍛</button>
                <button class="plan-quick-break-btn" data-type="sunset" title="Insert 45m Sunset Viewpoint Pause">+45m Sunset 🌄</button>
              </div>
            </div>
          </div>

          <div class="plan-timeline-container">
            ${itinerary.map((item, idx) => {
              const nextItem = itinerary[idx + 1];
              const isSelected = focusedItem && focusedItem.id === item.id;
              const isQuiet = item.crowdStatus === 'optimal';
              const isBusy = item.crowdStatus === 'critical';
              const isEditingTime = this.activeTimeEditorItemId === item.id;
              const whyScore = travelState.getWhyROAMPickedThis(item);

              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(item.name + ', ' + city)}`;
              const directionsUrl = nextItem 
                ? `https://www.google.com/maps/dir/?api=1&origin=${encodeURIComponent(item.name + ', ' + city)}&destination=${encodeURIComponent(nextItem.name + ', ' + city)}`
                : mapsUrl;

              return `
                <div class="plan-timeline-step ${isSelected ? 'selected' : ''}" data-id="${item.id}">
                  
                  <!-- Left: Interactive Time & Duration -->
                  <div class="step-time-col">
                    <button class="step-time-btn ${isBusy ? 'time-busy' : (isQuiet ? 'time-quiet' : 'time-elevated')}" data-id="${item.id}" title="Click to open Time Editor">
                      ${item.time} ▾
                    </button>

                    <!-- Compact Time Editor Popover -->
                    ${isEditingTime ? this.renderTimeEditorPopover(item) : ''}

                    <div class="step-duration-label">
                      <div class="plan-inline-stepper">
                        <button class="plan-stepper-btn" data-id="${item.id}" data-delta="-15" title="Shorten by 15m">−</button>
                        <span class="plan-stepper-val">${item.durationMinutes || 90}m</span>
                        <button class="plan-stepper-btn" data-id="${item.id}" data-delta="15" title="Extend by 15m">+</button>
                      </div>
                    </div>
                  </div>

                  <!-- Center: Node Dot & Smart Route Line -->
                  <div class="step-node-col">
                    <div class="step-dot ${isQuiet ? 'dot-optimal' : (isBusy ? 'dot-critical' : 'dot-elevated')}" data-id="${item.id}">
                      ${idx + 1}
                    </div>
                    ${idx < itinerary.length - 1 ? '<div class="step-connector-line"></div>' : ''}
                  </div>

                  <!-- Right: Activity Card -->
                  <div class="step-card-col">
                    <div class="plan-activity-card ${isSelected ? 'card-focused' : ''}" data-id="${item.id}">
                      
                      <!-- Top Row: Name, Category, Crowd Status -->
                      <div class="activity-top-row">
                        <div>
                          <div class="activity-name">${item.name}</div>
                          <div class="activity-category">${item.category.toUpperCase()} • ${item.durationMinutes} min visit</div>
                        </div>

                        <div class="activity-crowd-tag ${isQuiet ? 'tag-optimal' : (isBusy ? 'tag-critical' : 'tag-elevated')}">
                          <span class="crowd-dot"></span>
                          <span>${item.crowdLabel} (~${formatIndianNumber(item.expectedVisitors)})</span>
                        </div>
                      </div>

                      <!-- Peak Bottleneck Warning inline tag -->
                      ${item.isOvercrowded ? `
                        <div class="peak-warning-pill">
                          ⚠️ Peak queue window (~50+ min line). Click time or Balance My Day to optimize.
                        </div>
                      ` : ''}

                      <!-- "Why ROAM Picked This" Scoring Tag -->
                      ${whyScore ? `
                        <div class="why-roam-picked-pill" title="${whyScore.reasons.join(' | ')}">
                          <span class="roam-match-badge">🎯 ${whyScore.matchScore}% Match</span>
                          <span class="roam-match-reason">${whyScore.reasons[0]}</span>
                        </div>
                      ` : ''}

                      <!-- Item Actions: Order, Remove, Open in Maps -->
                      <div class="activity-actions-row">
                        <div class="activity-order-buttons">
                          <button class="order-btn" data-action="up" data-id="${item.id}" title="Move Up" ${idx === 0 ? 'disabled' : ''}>▲</button>
                          <button class="order-btn" data-action="down" data-id="${item.id}" title="Move Down" ${idx === itinerary.length - 1 ? 'disabled' : ''}>▼</button>
                          <button class="order-btn delete-btn" data-action="remove" data-id="${item.id}" title="Remove Activity">✕</button>
                        </div>

                        <div style="display:flex; align-items:center; gap:12px;">
                          <button class="plan-focus-btn" data-id="${item.id}">
                            ${isSelected ? '● FOCUSING' : 'VIEW CURVE ➔'}
                          </button>
                          <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="plan-maps-link" onclick="event.stopPropagation();">
                            OPEN IN MAPS ↗
                          </a>
                        </div>
                      </div>
                    </div>

                    <!-- Transit Card to Next Stop -->
                    ${nextItem ? `
                      <div class="plan-transit-card">
                        <span class="transit-icon">🚶 / 🚗</span>
                        <span class="transit-info">~${item.transitMinutesToNext || 20} min travel to ${nextItem.name}</span>
                        <a href="${directionsUrl}" target="_blank" rel="noopener noreferrer" class="transit-directions-link">
                          GET DIRECTIONS ↗
                        </a>
                      </div>
                    ` : ''}
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          <!-- Add Stop Bottom CTA -->
          <div style="text-align:center; margin:24px 0;">
            <button id="plan-add-inline-btn" class="btn btn-secondary" style="width:100%;">
              + Add Another Attraction or Bazaar
            </button>
          </div>
        </div>

        <!-- COLUMN 2: SPATIAL ROUTE MAP -->
        <div class="plan-col-map">
          <div class="col-header-strip">
            <span class="col-header-title">SMART ROUTE MAP</span>
            <span class="col-header-meta">INTERACTIVE FLOW</span>
          </div>

          <div class="plan-embedded-map-wrap">
            ${this.renderEmbeddedRouteMap(itinerary, focusedItem)}
          </div>

          <!-- Route Sequence Summary Strip -->
          <div class="smart-route-summary-box">
            <div class="smart-route-title">ROUTE PROGRESSION</div>
            <div class="smart-route-chain">
              ${itinerary.map((it, i) => `
                <span class="route-stop-chip ${focusedItem?.id === it.id ? 'active' : ''}" data-id="${it.id}">
                  ${i + 1}. ${it.name}
                </span>
                ${i < itinerary.length - 1 ? '<span class="route-arrow">↓ ~20m ↓</span>' : ''}
              `).join('')}
            </div>
          </div>
        </div>

        <!-- COLUMN 3: CONNECTED INTELLIGENCE & FORECAST -->
        <div class="plan-col-intel">
          <div class="col-header-strip">
            <span class="col-header-title">ROAM INTELLIGENCE</span>
            <span class="col-header-meta">CONNECTED DEMAND</span>
          </div>

          <!-- 1. Connected Crowd Forecast Component -->
          <div class="connected-forecast-card">
            ${this.renderConnectedCrowdCurve(focusedItem)}
          </div>

          <!-- 2. "Better Time" Proactive Intelligence Layer -->
          ${betterTime ? `
            <div class="better-time-card">
              <div class="better-time-badge">⚡ BETTER TIME RECOMMENDED</div>
              <div class="better-time-title">${focusedItem.name} at ${betterTime.currentHour} is very busy</div>
              <p class="better-time-insight">
                ${betterTime.insight} Expected crowd is ~${formatIndianNumber(betterTime.currentVisitors)} visitors with 50+ min queues.
              </p>
              
              <div class="better-time-highlight-box">
                <div class="better-time-opt-label">BETTER OPTION</div>
                <div class="better-time-opt-val">${betterTime.betterTime} (~${formatIndianNumber(betterTime.betterVisitors)} visitors • ${betterTime.betterLabel})</div>
                <div class="better-time-saving">Save ~${formatIndianNumber(betterTime.savedVisitors)} visitors of crowd exposure</div>
              </div>

              <button class="btn btn-primary better-time-apply-btn" id="better-time-move-cta" data-id="${focusedItem.id}" data-target="${betterTime.betterTime}">
                [ ${betterTime.actionText} ]
              </button>
            </div>
          ` : ''}

          <!-- 3. Dynamic "What Should I Do Next?" Card -->
          ${whatNext ? `
            <div class="what-next-card">
              <div class="what-next-badge">WHAT SHOULD I DO NEXT?</div>
              <div class="what-next-headline">${whatNext.headline}</div>
              
              <div class="what-next-pick">
                <div class="what-next-title">${whatNext.title}</div>
                <div class="what-next-specialty">${whatNext.specialty}</div>
                <div class="what-next-meta">
                  <span>~${formatIndianNumber(whatNext.visitors)} visitors</span> • 
                  <span>~${whatNext.transitMinutes} min away</span>
                </div>
              </div>

              <div class="what-next-why">
                <strong>WHY?</strong> ${whatNext.why}
              </div>

              <div class="what-next-actions">
                <button class="btn btn-sm btn-primary what-next-add-btn" data-id="${whatNext.pick.id}">
                  + ADD TO PLAN
                </button>
                <button class="btn btn-sm btn-secondary what-next-explore-btn" data-id="${whatNext.pick.id}">
                  EXPLORE ↗
                </button>
              </div>
            </div>
          ` : ''}

          <!-- 4. "Open Slot" Detection Card -->
          ${openSlots.length > 0 ? `
            <div class="open-slot-card">
              <div class="open-slot-badge">⏰ OPEN SLOT DETECTED</div>
              <div class="open-slot-title">
                ${Math.round(openSlots[0].durationMinutes / 60)}h ${openSlots[0].durationMinutes % 60 ? (openSlots[0].durationMinutes % 60 + 'm ') : ''}OPEN (${openSlots[0].startTime} — ${openSlots[0].endTime})
              </div>
              <p class="open-slot-desc">
                ROAM can fill this free window near your route without adding transit fatigue.
              </p>

              <div class="open-slot-pills">
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'shopping' ? 'active' : ''}" data-cat="shopping">🛍️ SHOP</button>
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'culture' ? 'active' : ''}" data-cat="culture">🎨 CULTURE</button>
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'food' ? 'active' : ''}" data-cat="food">🍛 FOOD</button>
                <button class="slot-cat-pill ${this.selectedSlotCategory === 'crafts' ? 'active' : ''}" data-cat="crafts">🏺 CRAFTS</button>
              </div>

              <div id="slot-recommendations-list">
                ${this.renderSlotRecommendations(openSlots[0])}
              </div>
            </div>
          ` : ''}

        </div>

      </div>
    `;

    this.attachEventListeners();
  }

  // --- Compact Time Editor Popover ---
  renderTimeEditorPopover(item) {
    const options = travelState.getTimeEditorOptions(item);

    return `
      <div class="time-editor-popover" data-id="${item.id}" onclick="event.stopPropagation();">
        <div class="time-editor-header">
          <div class="time-editor-title">${item.name}</div>
          <div class="time-editor-current">CURRENT: <strong>${item.time}</strong></div>
        </div>

        <div class="time-editor-label">MOVE TO:</div>
        
        <div class="time-editor-options-list">
          ${options.map(opt => `
            <button class="time-opt-btn ${opt.isCurrent ? 'current' : ''}" data-time="${opt.time}" data-id="${item.id}">
              <span class="time-opt-time">${opt.time}</span>
              <span class="time-opt-visitors">~${formatIndianNumber(opt.visitors)} visitors</span>
              <span class="time-opt-badge ${opt.status === 'optimal' ? 'badge-optimal' : (opt.status === 'critical' ? 'badge-critical' : 'badge-elevated')}">
                ${opt.label}
              </span>
            </button>
          `).join('')}
        </div>
      </div>
    `;
  }

  // --- Connected Crowd Curve SVG ---
  renderConnectedCrowdCurve(focusedItem) {
    if (!focusedItem) return '';

    const rawCurve = travelState.getCrowdCurveForItem(focusedItem);
    const curve = (rawCurve && rawCurve.length > 0) ? rawCurve : [
      { hour: '08:00', label: 'Quiet', visitors: 400, pct: 20 },
      { hour: '11:00', label: 'Busy', visitors: 1600, pct: 80 },
      { hour: '14:00', label: 'Peak', visitors: 2000, pct: 100 },
      { hour: '17:00', label: 'Moderate', visitors: 900, pct: 45 }
    ];
    const scheduledHour = focusedItem.time || '09:00';
    const hourNum = parseInt(scheduledHour.split(':')[0], 10) || 9;

    const svgWidth = 440;
    const svgHeight = 110;
    const padX = 35;
    const padY = 20;
    const stepX = (svgWidth - padX * 2) / Math.max(1, curve.length - 1);

    const coords = curve.map((p, i) => {
      const x = padX + i * stepX;
      const y = svgHeight - padY - (p.pct / 100) * (svgHeight - padY * 2);
      const isSelected = Math.abs((parseInt(p.hour.split(':')[0], 10) || 0) - hourNum) <= 1;
      return { x, y, isSelected, ...p };
    });

    let d = `M ${coords[0].x} ${coords[0].y}`;
    for (let i = 0; i < coords.length - 1; i++) {
      const p0 = coords[i];
      const p1 = coords[i + 1];
      const cpX1 = p0.x + (p1.x - p0.x) / 2;
      const cpX2 = cpX1;
      d += ` C ${cpX1} ${p0.y}, ${cpX2} ${p1.y}, ${p1.x} ${p1.y}`;
    }
    const areaD = `${d} L ${coords[coords.length - 1].x} ${svgHeight - padY} L ${coords[0].x} ${svgHeight - padY} Z`;

    const activePoint = coords.find(c => c.isSelected) || coords[0];

    return `
      <div class="crowd-curve-inner">
        <div class="curve-header-row">
          <div>
            <div class="curve-title-eyebrow">CROWD FORECAST • TODAY / YOUR DAY</div>
            <div class="curve-title-name">${focusedItem.name}</div>
          </div>

          <div class="curve-honesty-tag">
            ROAM FORECAST • Modelled estimate
          </div>
        </div>

        <div class="curve-scheduled-indicator">
          <span>Scheduled: <strong style="color:#fff;">${focusedItem.time}</strong> (~${formatIndianNumber(focusedItem.expectedVisitors || 500)} visitors • ${focusedItem.crowdLabel || 'Moderate'})</span>
        </div>

        <div class="curve-svg-container">
          <svg viewBox="0 0 ${svgWidth} ${svgHeight}" class="connected-curve-svg" preserveAspectRatio="none">
            <defs>
              <linearGradient id="planCurveGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stop-color="var(--roam-accent)" stop-opacity="0.35"/>
                <stop offset="100%" stop-color="var(--roam-accent)" stop-opacity="0.0"/>
              </linearGradient>
            </defs>

            <!-- Gradient Area -->
            <path d="${areaD}" fill="url(#planCurveGrad)" />

            <!-- Curve Stroke -->
            <path d="${d}" fill="none" stroke="var(--roam-accent)" stroke-width="2.5" stroke-linecap="round" />

            <!-- Vertical Indicator for Scheduled Time -->
            <line x1="${activePoint.x}" y1="10" x2="${activePoint.x}" y2="${svgHeight - padY}" stroke="#fff" stroke-width="1.5" stroke-dasharray="3,3" opacity="0.8" />

            <!-- Interactive Clickable Points -->
            ${coords.map(c => `
              <g class="curve-node-group" data-hour="${c.hour}" data-id="${focusedItem.id}">
                <circle cx="${c.x}" cy="${c.y}" r="${c.isSelected ? '7' : '4'}" fill="${c.pct > 75 ? '#ef4444' : (c.pct > 40 ? '#f59e0b' : '#10b981')}" stroke="#fff" stroke-width="${c.isSelected ? '3' : '1.5'}" class="${c.isSelected ? 'pulse-point' : ''}" />
              </g>
            `).join('')}
          </svg>

          <!-- Labels Row -->
          <div class="curve-labels-strip">
            ${curve.map(p => `
              <button class="curve-time-chip ${p.hour === activePoint.hour ? 'active' : ''}" data-hour="${p.hour}" data-id="${focusedItem.id}">
                <span class="chip-h">${p.hour}</span>
                <span class="chip-v">~${formatIndianNumber(p.visitors)}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <div class="curve-hint">
          💡 Click any time chip or curve node above to reschedule ${focusedItem.name} immediately.
        </div>
      </div>
    `;
  }

  // --- Embedded Route Map SVG ---
  renderEmbeddedRouteMap(itinerary, focusedItem) {
    const allAttractions = travelState.location?.attractions || [];
    const validItinerary = itinerary.map((item, idx) => ({
      ...item,
      safeCoords: (item.coords && typeof item.coords.x === 'number') 
        ? item.coords 
        : { x: 200 + (idx * 140) % 500, y: 180 + (idx * 100) % 350 }
    }));

    return `
      <svg class="embedded-route-svg" viewBox="0 0 800 600" preserveAspectRatio="xMidYMid meet" role="img" aria-label="Smart Route Map">
        <defs>
          <radialGradient id="planMapGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="var(--roam-accent)" stop-opacity="0.18" />
            <stop offset="100%" stop-color="transparent" />
          </radialGradient>
        </defs>

        <rect width="800" height="600" fill="rgba(8, 12, 20, 0.95)" />
        <circle cx="400" cy="300" r="300" fill="url(#planMapGlow)" />

        <!-- Polyline connecting sequential itinerary stops -->
        ${validItinerary.length > 1 ? `
          <polyline points="${validItinerary.map(i => `${i.safeCoords.x},${i.safeCoords.y}`).join(' ')}" fill="none" stroke="var(--roam-accent)" stroke-width="2.5" stroke-dasharray="6,6" opacity="0.75" />
        ` : ''}

        <!-- Other city sites as subtle reference dots -->
        <g opacity="0.35">
          ${allAttractions.filter(a => a.coords && typeof a.coords.x === 'number').map(a => `
            <circle cx="${a.coords.x}" cy="${a.coords.y}" r="6" fill="#64748b" />
          `).join('')}
        </g>

        <!-- Itinerary Stops with Numbers & Status Glow -->
        <g class="itinerary-map-nodes">
          ${validItinerary.map((item, idx) => {
            const isSelected = focusedItem && focusedItem.id === item.id;
            const isQuiet = item.crowdStatus === 'optimal';
            const isBusy = item.crowdStatus === 'critical';
            const color = isBusy ? '#ef4444' : (isQuiet ? 'var(--load-optimal)' : '#f59e0b');

            return `
              <g class="route-map-node ${isSelected ? 'selected' : ''}" data-id="${item.id}" transform="translate(${item.safeCoords.x}, ${item.safeCoords.y})">
                <circle cx="0" cy="0" r="${isSelected ? 26 : 20}" fill="${color}" opacity="0.22" class="${isSelected ? 'pulse-ring' : ''}" />
                <circle cx="0" cy="0" r="${isSelected ? 18 : 14}" fill="rgba(12, 18, 30, 0.95)" stroke="${color}" stroke-width="${isSelected ? '3' : '2'}" />
                
                <text y="4" text-anchor="middle" fill="#fff" font-size="11" font-weight="900" font-family="var(--font-mono)">
                  ${idx + 1}
                </text>

                <g transform="translate(0, 26)">
                  <rect x="-60" y="-10" width="120" height="20" rx="4" fill="rgba(10, 15, 26, 0.92)" stroke="${color}" stroke-width="1" />
                  <text y="4" text-anchor="middle" fill="#fff" font-size="10" font-weight="700">
                    ${item.name.length > 15 ? item.name.substring(0, 14) + '…' : item.name}
                  </text>
                </g>
              </g>
            `;
          }).join('')}
        </g>
      </svg>
    `;
  }

  // --- Open Slot Recommendations ---
  renderSlotRecommendations(slot) {
    const businesses = travelState.location?.localBusinesses || [];
    const cat = this.selectedSlotCategory || 'shopping';

    const matches = businesses.filter(b => b.category === cat || (cat === 'shopping' && (b.category === 'markets' || b.category === 'shopping'))).slice(0, 2);

    if (matches.length === 0) {
      return `<div style="font-size:0.8rem; color:var(--text-muted); padding:8px 0;">No matching places found for this category.</div>`;
    }

    return matches.map(m => `
      <div class="slot-match-item">
        <div>
          <div class="slot-match-name">${m.name}</div>
          <div class="slot-match-sub">~${formatIndianNumber(m.estimatedActivity)} visitors • ${m.zone}</div>
        </div>
        <button class="btn btn-sm btn-secondary slot-match-add-btn" data-id="${m.id}">
          + Add
        </button>
      </div>
    `).join('');
  }

  // --- Event Listener Attachments ---
  attachEventListeners() {
    if (!this.mount) return;

    // 0a. Story & Memory Journal Drawer Toggle
    const storyToggle = this.mount.querySelector('#plan-story-toggle');
    if (storyToggle) {
      storyToggle.onclick = () => {
        this.showStoryDrawer = !this.showStoryDrawer;
        this.render();
      };
    }
    const storyClose = this.mount.querySelector('#story-drawer-close');
    if (storyClose) {
      storyClose.onclick = () => {
        this.showStoryDrawer = false;
        this.render();
      };
    }
    const storySaveNoteBtn = this.mount.querySelector('#story-save-note-btn');
    if (storySaveNoteBtn) {
      storySaveNoteBtn.onclick = () => {
        const input = this.mount.querySelector('#story-note-input');
        const text = input?.value?.trim();
        if (text) {
          travelState.addTripMemory({ text, timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) });
          if (this.app?.modalController) {
            this.app.modalController.showToast('Travel reflection memory saved to your journal! 📖');
          }
          this.render();
        }
      };
    }
    const storyCopyBtn = this.mount.querySelector('#story-copy-btn');
    if (storyCopyBtn) {
      storyCopyBtn.onclick = () => {
        const city = travelState.location?.name || 'India';
        const story = travelState.generateOneDayStory();
        const itinerary = travelState.itinerary.map(i => `${i.time} — ${i.name} (${i.durationMinutes}m)`).join('\n');
        const text = `📖 MY ${city.toUpperCase()} ROAM STORY\n\n"${story}"\n\nITINERARY:\n${itinerary}\n\nGenerated with ROAM: Don't just visit India. Understand it.`;
        if (navigator.clipboard) {
          navigator.clipboard.writeText(text);
          if (this.app?.modalController) {
            this.app.modalController.showToast('Copied your ROAM Story & Itinerary to clipboard! 📋');
          }
        }
      };
    }
    const storyExportBtn = this.mount.querySelector('#story-export-btn');
    if (storyExportBtn) {
      storyExportBtn.onclick = () => {
        if (this.app?.modalController) {
          this.app.modalController.showToast('Your ROAM Travel Memory Journal exported successfully! 💾');
        }
      };
    }

    // 0b. Journey Mood Toggle
    const moodToggle = this.mount.querySelector('#plan-journey-mood-toggle');
    if (moodToggle) {
      moodToggle.onclick = () => {
        this.showJourneyMoodDrawer = !this.showJourneyMoodDrawer;
        this.render();
      };
    }
    const moodClose = this.mount.querySelector('#mood-drawer-close');
    if (moodClose) {
      moodClose.onclick = () => {
        this.showJourneyMoodDrawer = false;
        this.render();
      };
    }
    this.mount.querySelectorAll('.mood-range-input').forEach(range => {
      range.oninput = (e) => {
        const key = e.currentTarget.dataset.mood;
        const val = e.currentTarget.value;
        travelState.setJourneyMood(key, val);
      };
    });

    // 1. Balance My Day CTA
    const balanceBtn = this.mount.querySelector('#plan-balance-cta');
    if (balanceBtn) balanceBtn.onclick = () => this.runBalanceMyDay();

    // 2. Add Place CTAs
    const addTop = this.mount.querySelector('#plan-add-place-cta');
    const addInline = this.mount.querySelector('#plan-add-inline-btn');
    const openAddModal = () => {
      if (this.app?.modalController && travelState.location) {
        this.app.modalController.openAddPlace(travelState.location);
      }
    };
    if (addTop) addTop.onclick = openAddModal;
    if (addInline) addInline.onclick = openAddModal;

    // 3. User Interest Chips
    this.mount.querySelectorAll('.interest-chip').forEach(btn => {
      btn.onclick = () => {
        this.toggleInterest(btn.dataset.interest);
      };
    });

    // 4. Date Pills
    this.mount.querySelectorAll('.plan-date-pill').forEach(btn => {
      btn.onclick = () => {
        this.setDate(btn.dataset.date);
      };
    });

    // 5. Day Health Chip & Explanation Popover
    const healthChip = this.mount.querySelector('#day-health-chip');
    if (healthChip) {
      healthChip.onclick = () => {
        this.showDayHealthExplanation = !this.showDayHealthExplanation;
        this.render();
      };
    }
    const healthClose = this.mount.querySelector('#health-popover-close');
    if (healthClose) {
      healthClose.onclick = () => {
        this.showDayHealthExplanation = false;
        this.render();
      };
    }
    const healthFix = this.mount.querySelector('#health-quick-fix-btn');
    if (healthFix) {
      healthFix.onclick = () => {
        const type = healthFix.dataset.type;
        if (type === 'move_early') {
          const action = travelState.dayHealth.fixAction;
          if (action?.itemId && action?.targetTime) {
            travelState.updateItemTime(action.itemId, action.targetTime);
            this.showDayHealthExplanation = false;
            if (this.app?.modalController) {
              this.app.modalController.showToast('Amber Fort moved to 08:30 — Day is now BALANCED!');
            }
          }
        } else {
          this.runBalanceMyDay();
          this.showDayHealthExplanation = false;
        }
      };
    }

    // 6. Quick Timetable Adjusters (Toolbar)
    this.mount.querySelectorAll('.plan-start-time-btn').forEach(btn => {
      btn.onclick = () => {
        const time = btn.dataset.time;
        travelState.setStartDayTime(time);
        if (this.app?.modalController) {
          this.app.modalController.showToast(`Day set to start at ${time}`);
        }
      };
    });

    this.mount.querySelectorAll('.plan-shift-btn').forEach(btn => {
      btn.onclick = () => {
        const shift = parseInt(btn.dataset.shift, 10);
        travelState.shiftEntireDay(shift);
        if (this.app?.modalController) {
          this.app.modalController.showToast(`Itinerary shifted by ${shift > 0 ? '+' : ''}${shift} minutes`);
        }
      };
    });

    this.mount.querySelectorAll('.plan-quick-break-btn').forEach(btn => {
      btn.onclick = () => {
        const type = btn.dataset.type;
        travelState.insertBreak(type);
        if (this.app?.modalController) {
          this.app.modalController.showToast(`Added ${type === 'chai' ? 'Masala Chai' : (type === 'lunch' ? 'Lunch' : 'Sunset')} break!`);
        }
      };
    });

    // 7. Time Button (Opens Popover)
    this.mount.querySelectorAll('.step-time-btn').forEach(btn => {
      btn.onclick = (e) => {
        this.openTimeEditor(btn.dataset.id, e);
      };
    });

    // 8. Time Option Selection inside Popover
    this.mount.querySelectorAll('.time-opt-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        this.setTime(btn.dataset.id, btn.dataset.time);
      };
    });

    // 9. Duration Stepper Buttons
    this.mount.querySelectorAll('.plan-stepper-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const id = btn.dataset.id;
        const delta = parseInt(btn.dataset.delta, 10);
        travelState.adjustItemDuration(id, delta);
      };
    });

    // 10. Focus Item click
    this.mount.querySelectorAll('.plan-activity-card, .step-dot, .route-stop-chip, .plan-focus-btn').forEach(el => {
      el.onclick = () => {
        const id = el.dataset.id;
        if (id) this.focusItem(id);
      };
    });

    // 11. Itinerary Re-order and Delete
    this.mount.querySelectorAll('.order-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const action = btn.dataset.action;
        const id = btn.dataset.id;
        if (action === 'up') {
          this.moveItem(id, -1);
        } else if (action === 'down') {
          this.moveItem(id, 1);
        } else if (action === 'remove') {
          this.removeItem(id);
        }
      };
    });

    // 12. Better Time Apply CTA
    const betterTimeCTA = this.mount.querySelector('#better-time-move-cta');
    if (betterTimeCTA) {
      betterTimeCTA.onclick = () => {
        const id = betterTimeCTA.dataset.id;
        const target = betterTimeCTA.dataset.target;
        this.setTime(id, target);
      };
    }

    // 13. What Next Add Button
    this.mount.querySelectorAll('.what-next-add-btn').forEach(btn => {
      btn.onclick = () => {
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop) {
          this.addPlace(shop);
        }
      };
    });

    // 14. Open Slot Category Pills & Add
    this.mount.querySelectorAll('.slot-cat-pill').forEach(btn => {
      btn.onclick = () => {
        this.selectedSlotCategory = btn.dataset.cat;
        this.render();
      };
    });

    this.mount.querySelectorAll('.slot-match-add-btn').forEach(btn => {
      btn.onclick = () => {
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop) {
          this.addPlace(shop);
        }
      };
    });

    // 15. Curve Time Chip Click
    this.mount.querySelectorAll('.curve-time-chip, .curve-node-group').forEach(el => {
      el.onclick = () => {
        const hour = el.dataset.hour;
        const id = el.dataset.id;
        if (hour && id) {
          this.setTime(id, hour);
        }
      };
    });
  }
}
