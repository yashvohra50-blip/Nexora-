/**
 * ROAM City Tourism Control Mode (V2)
 * Human-First Presentation: "VISITOR PRESSURE", "PLACES WITH ROOM", "LOCAL SPENDING"
 * Interactive "What Happens If..." policy slider updating in-place.
 */

import { formatCrowdLevel, formatCapacity, formatIndianNumber, renderTooltip } from '../utils/formatters.js';
import { simulatePolicyImpact } from '../engine/simulator.js';

export class AuthorityModeController {
  constructor() {
    this.locationData = null;
    this.redirectPct = 15;
    this.incentiveTier = 'standard';
  }

  setDestination(locationData) {
    this.locationData = locationData;
    this.render();
  }

  render() {
    const container = document.getElementById('authority-mode-container');
    if (!container) return;

    if (!this.locationData || this.locationData.intelligenceTier === 'PARTIAL') {
      container.innerHTML = `
        <div class="partial-intelligence-card">
          <span class="partial-badge">MUNICIPAL SENSOR INTEGRATION</span>
          <h3 class="partial-title">City Tourism Control for ${this.locationData?.name || 'this District'}</h3>
          <p class="partial-sub">
            Municipal turnstile integrations and heritage preservation models are active in major hubs. In ${this.locationData?.name || 'this zone'}, predictive policy simulations will launch with the upcoming sensor pilot.
          </p>
        </div>
      `;
      return;
    }

    const simulation = simulatePolicyImpact(this.redirectPct, this.incentiveTier);
    const m = simulation.metrics;
    const attractions = this.locationData.attractions || [];
    const criticalCount = attractions.filter(a => a.status === 'critical').length;
    const targetShiftCount = Math.round((this.locationData.metrics?.totalDailyTourists || 48000) * (this.redirectPct / 100));

    container.innerHTML = `
      <div class="authority-grid">
        <!-- Left Column: Visitor Pressure & Heritage Strain -->
        <div class="card">
          <div class="card-header">
            <div>
              <div style="font-size:0.72rem; text-transform:uppercase; color:var(--roam-accent); font-weight:800;">
                VISITOR PRESSURE ${renderTooltip('visitorPressure')}
              </div>
              <h3 class="card-title">${this.locationData.name} Heritage Grid Status</h3>
            </div>
            <span class="badge badge-critical">🚨 ${criticalCount} Monuments Overloaded</span>
          </div>

          <div style="display:flex; flex-direction:column; gap:12px; margin-top:12px;">
            ${attractions.slice(0, 6).map(att => {
              const crowd = formatCrowdLevel(att.loadPercentage);
              return `
                <div>
                  <div style="display:flex; justify-content:space-between; font-size:0.82rem; margin-bottom:3px;">
                    <span style="font-weight:700;">${att.name}</span>
                    <span style="color:${crowd.color}; font-weight:700;">
                      ${formatCapacity(att.currentVisitors, att.capacityMax)}
                    </span>
                  </div>
                  <div class="health-meter-track" style="height:6px;">
                    <div class="health-meter-fill" style="width:${att.loadPercentage}%; background:${crowd.color};"></div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          <div style="margin-top:18px; padding:12px; background:rgba(239,68,68,0.06); border-left:3px solid var(--load-critical); border-radius:0 6px 6px 0; font-size:0.82rem; color:#fca5a5;">
            <strong>Heritage Strain Alert ${renderTooltip('heritageStrain')}:</strong> Key monuments are operating above structural throughput limits. Directing visitor flow to calmer cultural sites preserves centuries-old stonework.
          </div>
        </div>

        <!-- Right Column: Interactive "What Happens If..." Policy Simulator -->
        <div class="card" style="background:linear-gradient(135deg, #111827, #0d121e); border-color:var(--border-medium);">
          <div class="card-header">
            <div>
              <div style="font-size:0.72rem; text-transform:uppercase; color:var(--brand-purple); font-weight:800;">
                WHAT HAPPENS IF... ${renderTooltip('redistribution')}
              </div>
              <h3 class="card-title">Simulate Spreading Visitors</h3>
            </div>
            <span class="badge" style="background:rgba(139,92,246,0.15); color:#c4b5fd; border:1px solid rgba(139,92,246,0.3);">
              PREDICTIVE ENGINE
            </span>
          </div>

          <!-- Policy Slider Box -->
          <div class="policy-slider-box">
            <div style="display:flex; justify-content:space-between; font-size:0.88rem; font-weight:700;">
              <span>Guide visitors to quieter places:</span>
              <span id="slider-val-label" style="font-family:var(--font-mono); color:var(--roam-accent); font-size:1.15rem; font-weight:800;">
                ~${formatIndianNumber(targetShiftCount)} visitors (${this.redirectPct}%)
              </span>
            </div>
            <input id="policy-slider-input" type="range" min="5" max="35" step="1" value="${this.redirectPct}" class="policy-slider">
            <div style="display:flex; justify-content:space-between; font-size:0.72rem; color:var(--text-muted); font-family:var(--font-mono);">
              <span>5% (Gentle Nudge)</span>
              <span>15% (Recommended)</span>
              <span>35% (Aggressive Shift)</span>
            </div>
          </div>

          <!-- Human Result Stat Cards (Updated In-Place) -->
          <div class="policy-impact-cards">
            <div class="policy-stat-card">
              <div id="stat-congestion" class="policy-stat-val">↓ ${m.peakCongestionReductionPct}%</div>
              <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted); font-weight:700; margin-top:2px;">
                Less Peak Crowding
              </div>
            </div>
            <div class="policy-stat-card">
              <div id="stat-delays" class="policy-stat-val">↓ ${m.travelTimeReductionPct}%</div>
              <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted); font-weight:700; margin-top:2px;">
                Shorter Transit Delays
              </div>
            </div>
            <div class="policy-stat-card">
              <div id="stat-uplift" class="policy-stat-val" style="color:var(--load-optimal);">↑ ${m.underutilizedVisitsUpliftPct}%</div>
              <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted); font-weight:700; margin-top:2px;">
                More Visits to Calmer Sites
              </div>
            </div>
            <div class="policy-stat-card">
              <div id="stat-revenue" class="policy-stat-val" style="color:var(--brand-cyan);">↑ ${m.localBusinessExposureUpliftPct}%</div>
              <div style="font-size:0.72rem; text-transform:uppercase; color:var(--text-muted); font-weight:700; margin-top:2px;">
                More Local Artisan Sales
              </div>
            </div>
          </div>

          <div id="simulation-insight-text" style="margin-top:16px; font-size:0.82rem; color:var(--text-secondary); line-height:1.45;">
            <strong>City Benefit:</strong> Guiding ${this.redirectPct}% of peak visitors toward underutilized cultural surrogates eliminates over ${Math.round(this.redirectPct * 210)} tourist delay hours daily while distributing footfall to neighborhood markets.
          </div>
        </div>
      </div>
    `;

    this.attachEvents();
  }

  attachEvents() {
    const slider = document.getElementById('policy-slider-input');
    if (slider) {
      slider.addEventListener('input', (e) => {
        this.redirectPct = parseInt(e.target.value, 10);
        this.updateInPlace();
      });
    }
  }

  updateInPlace() {
    const totalTourists = this.locationData?.metrics?.totalDailyTourists || 48000;
    const targetShiftCount = Math.round(totalTourists * (this.redirectPct / 100));

    const label = document.getElementById('slider-val-label');
    if (label) {
      label.textContent = `~${formatIndianNumber(targetShiftCount)} visitors (${this.redirectPct}%)`;
    }

    const simulation = simulatePolicyImpact(this.redirectPct, this.incentiveTier);
    const m = simulation.metrics;

    const elCongestion = document.getElementById('stat-congestion');
    const elDelays = document.getElementById('stat-delays');
    const elUplift = document.getElementById('stat-uplift');
    const elRevenue = document.getElementById('stat-revenue');
    const elInsight = document.getElementById('simulation-insight-text');

    if (elCongestion) elCongestion.textContent = `↓ ${m.peakCongestionReductionPct}%`;
    if (elDelays) elDelays.textContent = `↓ ${m.travelTimeReductionPct}%`;
    if (elUplift) elUplift.textContent = `↑ ${m.underutilizedVisitsUpliftPct}%`;
    if (elRevenue) elRevenue.textContent = `↑ ${m.localBusinessExposureUpliftPct}%`;

    if (elInsight && this.locationData) {
      elInsight.innerHTML = `<strong>City Benefit:</strong> Guiding ${this.redirectPct}% of peak visitors toward calmer cultural alternatives eliminates over ${Math.round(this.redirectPct * 210)} tourist delay hours daily.`;
    }
  }
}
