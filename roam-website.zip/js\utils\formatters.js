/**
 * ROAM Human-Readable Metric System
 * Translates raw numbers and percentages into everyday human language with Indian formatting.
 */

export function formatIndianNumber(num) {
  if (num === null || num === undefined || isNaN(num)) return '0';
  const n = Math.round(num);
  return n.toLocaleString('en-IN');
}

export function formatCurrency(amountINR) {
  if (amountINR === null || amountINR === undefined || isNaN(amountINR)) return '₹0';
  const val = Math.abs(amountINR);

  if (val >= 10000000) {
    const cr = (val / 10000000).toFixed(1).replace(/\.0$/, '');
    return `₹${cr} crore`;
  } else if (val >= 100000) {
    const lakh = (val / 100000).toFixed(1).replace(/\.0$/, '');
    return `₹${lakh} lakh`;
  } else if (val >= 1000) {
    return `₹${formatIndianNumber(val)}`;
  }
  return `₹${val}`;
}

export function formatCrowdLevel(loadPct) {
  const pct = Math.round(loadPct || 0);
  if (pct >= 80) {
    return {
      status: 'VERY CROWDED',
      badgeClass: 'badge-critical',
      color: 'var(--load-critical)',
      summary: 'Heavy queues & bottleneck conditions',
      dotClass: 'dot-critical',
      iconSvg: '<svg width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="5" fill="#ef4444" /></svg>'
    };
  } else if (pct >= 60) {
    return {
      status: 'BUSY',
      badgeClass: 'badge-elevated',
      color: 'var(--load-elevated)',
      summary: 'Moderate lines forming',
      dotClass: 'dot-elevated',
      iconSvg: '<svg width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="5" fill="#f59e0b" /></svg>'
    };
  } else if (pct >= 35) {
    return {
      status: 'COMFORTABLE',
      badgeClass: 'badge-optimal',
      color: 'var(--load-optimal)',
      summary: 'Plenty of room to walk',
      dotClass: 'dot-optimal',
      iconSvg: '<svg width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="5" fill="#10b981" /></svg>'
    };
  } else {
    return {
      status: 'QUIET RIGHT NOW',
      badgeClass: 'badge-optimal',
      color: 'var(--load-optimal)',
      summary: 'Serene & peaceful experience',
      dotClass: 'dot-optimal',
      iconSvg: '<svg width="12" height="12" viewBox="0 0 12 12"><circle cx="6" cy="6" r="5" fill="#10b981" /></svg>'
    };
  }
}

export function formatVisitorCount(count) {
  if (!count) return '~0 visitors';
  const rounded = Math.round(count / 10) * 10;
  return `~${formatIndianNumber(rounded)} visitors`;
}

export function formatWaitTime(minutes) {
  const m = Math.round(minutes || 0);
  if (m <= 5) return 'No wait (walk right in)';
  if (m >= 50 && m <= 70) return 'About 1 hour wait';
  if (m > 70) {
    const hrs = (m / 60).toFixed(1).replace(/\.0$/, '');
    return `About ${hrs} hours wait`;
  }
  return `~${m} min wait`;
}

export function formatCapacity(current, max) {
  const c = formatIndianNumber(Math.round(current || 0));
  const m = formatIndianNumber(Math.round(max || 0));
  return `~${c} of ${m} spots occupied`;
}

export function formatRedistribution(count) {
  return `Move ~${formatIndianNumber(count)} visitors to calmer spots`;
}

export function formatEconomicImpact(amountINR) {
  return `~${formatCurrency(amountINR)} more local spending`;
}

export function formatDistance(km) {
  if (!km) return 'nearby';
  if (km < 1) {
    return `${Math.round(km * 1000)} m away`;
  }
  return `${km.toFixed(1)} km away`;
}

export const CONCEPT_EXPLANATIONS = {
  demand: 'How many people want to visit this place right now.',
  capacity: 'How many visitors the monument can comfortably handle at once.',
  utilization: 'How busy the site is compared to its comfortable capacity.',
  redistribution: 'Guiding travelers away from bottlenecks toward high-quality alternatives.',
  opportunity: 'How much room there is for grassroots shops and artisans here to benefit from visitor flow.',
  visitorPressure: 'Where tourism traffic is currently concentrating in the city.',
  heritageStrain: 'Physical wear on centuries-old stone, stairways, and ramparts from footfall.',
  localSpending: 'How much tourist money reaches independent local artisans and family kitchens.'
};

export function renderTooltip(conceptKey) {
  const text = CONCEPT_EXPLANATIONS[conceptKey] || '';
  if (!text) return '';
  return `
    <span class="info-tooltip-trigger" tabindex="0" aria-label="${text}">
      <span class="info-icon">i</span>
      <span class="info-tooltip-bubble">${text}</span>
    </span>
  `;
}
