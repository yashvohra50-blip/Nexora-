/**
 * ROAM Spatial & Natural Language Search Component (V4)
 * "WHERE DO YOU WANT TO ROAM?"
 *
 * Supports:
 * - Direct destination search (Jaipur, Varanasi, Mumbai, Kochi, Leh...)
 * - Natural language queries ("quiet mountain village", "best textile markets", "food like locals", "cheap weekend")
 * - 1-Click ROAM AI Deep Agent query integration
 */

import { ALL_INDIAN_LOCATIONS } from '../data/locations/index.js';
import { roamAIEngine } from '../engine/aiAgentEngine.js';

export class SearchBarController {
  constructor(options = {}) {
    this.container = document.getElementById('spatial-search-mount');
    this.onSelectLocation = options.onSelectLocation || (() => {});
    this.onAIQuery = options.onAIQuery || (() => {});
    this.activeLocationId = 'jaipur';
    this.init();
  }

  init() {
    if (!this.container) return;
    this.render();
    this.attachEvents();
  }

  render() {
    this.container.innerHTML = `
      <div class="spatial-search-container">
        <div class="spatial-search-box">
          <span class="search-icon">🔍</span>
          <input 
            type="text" 
            id="spatial-search-input" 
            class="spatial-search-input" 
            placeholder="Search any place or intent in India (e.g. 'Jaipur', 'quiet craft village', 'food like locals')..." 
            autocomplete="off" 
            spellcheck="false"
          />
          <span class="search-shortcut-hint">/</span>
        </div>

        <!-- Quick selection chips -->
        <div class="search-quick-chips">
          <span style="font-size:0.72rem; color:var(--text-muted); font-weight:800; letter-spacing:0.06em;">POPULAR:</span>
          <button class="quick-chip ${this.activeLocationId === 'jaipur' ? 'active' : ''}" data-id="jaipur">Jaipur 🌟</button>
          <button class="quick-chip ${this.activeLocationId === 'varanasi' ? 'active' : ''}" data-id="varanasi">Varanasi 🪔</button>
          <button class="quick-chip ${this.activeLocationId === 'mumbai' ? 'active' : ''}" data-id="mumbai">Mumbai 🌊</button>
          <button class="quick-chip ${this.activeLocationId === 'kochi' ? 'active' : ''}" data-id="kochi">Kochi 🌴</button>
          <button class="quick-chip ${this.activeLocationId === 'leh' ? 'active' : ''}" data-id="leh">Leh Ladakh 🏔️</button>
          <button class="quick-chip ${this.activeLocationId === 'raghurajpur' ? 'active' : ''}" data-id="raghurajpur">Raghurajpur 🌾</button>
          <button class="quick-chip ${this.activeLocationId === 'pochampally' ? 'active' : ''}" data-id="pochampally">Pochampally 🧵</button>
        </div>

        <!-- Autocomplete Dropdown List -->
        <div id="spatial-search-results" class="search-results-dropdown"></div>
      </div>
    `;
  }

  setActive(locId) {
    this.activeLocationId = locId;
    const chips = this.container?.querySelectorAll('.quick-chip');
    if (chips) {
      chips.forEach(c => {
        if (c.dataset.id === locId) {
          c.classList.add('active');
        } else {
          c.classList.remove('active');
        }
      });
    }
  }

  attachEvents() {
    const input = document.getElementById('spatial-search-input');
    const dropdown = document.getElementById('spatial-search-results');

    if (!input || !dropdown) return;

    // Keyboard shortcut "/" to focus search
    window.addEventListener('keydown', (e) => {
      if (e.key === '/' && document.activeElement !== input) {
        e.preventDefault();
        input.focus();
        input.select();
      } else if (e.key === 'Escape') {
        dropdown.classList.remove('visible');
      }
    });

    // Input typeahead search with natural language routing
    input.addEventListener('input', (e) => {
      const q = e.target.value.trim().toLowerCase();
      if (!q) {
        dropdown.classList.remove('visible');
        return;
      }

      // 1. Direct and fuzzy matching across all Indian destinations
      const matches = ALL_INDIAN_LOCATIONS.filter(loc => {
        return loc.name.toLowerCase().includes(q) ||
               loc.state.toLowerCase().includes(q) ||
               loc.type.toLowerCase().includes(q) ||
               loc.tags.some(t => t.toLowerCase().includes(q));
      }).slice(0, 7);

      let html = '';

      // Add AI Agent Prompt Option at the top for conversational/intent queries
      html += `
        <div class="search-result-ai-item" data-query="${q}">
          <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-size:1.1rem;">✨</span>
            <div>
              <div style="font-size:0.86rem; font-weight:800; color:#fff;">Ask ROAM AI: "${q}"</div>
              <div style="font-size:0.72rem; color:var(--roam-accent);">Deep agent intent analysis across 28 states</div>
            </div>
          </div>
          <span style="font-size:0.76rem; font-weight:800; color:var(--roam-accent);">ASK AGENT ➔</span>
        </div>
      `;

      if (matches.length > 0) {
        html += matches.map(m => {
          const isRural = m.tier === 'RURAL' || m.type.includes('VILLAGE');
          const typeClass = 'type-' + m.type.toLowerCase();

          return `
            <div class="search-result-item" data-id="${m.id}">
              <div class="search-item-left">
                <div class="search-item-name">
                  <span>${m.name}</span>
                  ${m.tier === 'FULL' ? '<span style="color:var(--load-optimal); font-size:0.7rem; margin-left:6px;">● Full Telemetry</span>' : ''}
                </div>
                <div class="search-item-state">${m.state} • ${m.region} India</div>
              </div>
              <span class="search-item-badge ${typeClass}">
                ${isRural ? '🌾 RURAL' : m.type.replace(/_/g, ' ')}
              </span>
            </div>
          `;
        }).join('');
      }

      dropdown.innerHTML = html;
      dropdown.classList.add('visible');

      // Attach clicks to items
      dropdown.querySelectorAll('.search-result-item').forEach(item => {
        item.addEventListener('click', () => {
          const locId = item.dataset.id;
          dropdown.classList.remove('visible');
          input.value = '';
          this.onSelectLocation(locId);
        });
      });

      dropdown.querySelectorAll('.search-result-ai-item').forEach(aiItem => {
        aiItem.addEventListener('click', () => {
          const aiQuery = aiItem.dataset.query;
          dropdown.classList.remove('visible');
          input.value = '';
          
          // Trigger ROAM AI companion drawer and send query
          if (window.ROAM?.roamAI) {
            window.ROAM.roamAI.toggleDrawer(true);
            window.ROAM.roamAI.sendQuery(aiQuery);
          }
        });
      });
    });

    // Close dropdown on outside click
    document.addEventListener('click', (e) => {
      if (!this.container.contains(e.target)) {
        dropdown.classList.remove('visible');
      }
    });

    // Quick chips click
    this.container.querySelectorAll('.quick-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const locId = chip.dataset.id;
        this.onSelectLocation(locId);
      });
    });
  }
}
