/**
 * ROAM — Mumbai Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const MUMBAI_DATA = {
  "id": "mumbai",
  "name": "Mumbai",
  "type": "CITY",
  "state": "Maharashtra",
  "district": "Mumbai City & Suburban",
  "region": "WEST",
  "culturalRegion": "Konkan Coast & Salsette Archipelago",
  "tagline": "The City of Dreams",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE ARABIAN SEA METROPOLIS UNDER HIGH PRESSURE.",
    "subheadline": "ROAM detected 4 congested coastal corridors and 6 tranquil heritage & craft enclaves across South Mumbai.",
    "overloadedCount": 4,
    "underutilizedCount": 6
  },
  "metrics": {
    "totalDailyTourists": 85000,
    "averageAttractionLoad": 76,
    "visitorConcentration": 84,
    "tourismDistributionStatus": "Critical Waterfront Concentration",
    "localBusinessOpportunity": "High Urban Craft Potential",
    "monumentsAtRisk": 3,
    "avgWaitTimeMinutes": 50,
    "localEconomyCapturePct": 18
  },
  "culturalDNA": {
    "knownFor": [
      "UNESCO Victorian Gothic & Art Deco Ensemble",
      "Historic Gateway of India Waterfront & Harbor Ferries",
      "Dabbawala Precision Logistics Network",
      "Bustling Street Food Culture & Marine Drive Promenade"
    ],
    "taste": [
      "Vada Pav (Spiced potato patty in bun with fried chili & dry garlic chutney)",
      "Pav Bhaji (Spicy mashed mixed vegetables cooked in butter on tawa)",
      "Bombay Grilled Sandwich (Layered cucumber, beetroot, potato with green mint chutney)",
      "Malvani Seafood (Crisp Bombil fry, Surmai curry & Sol Kadhi)"
    ],
    "architecture": [
      "Gateway of India (Indo-Saracenic basalt arch built 1924)",
      "Chhatrapati Shivaji Maharaj Terminus (Victorian Italianate Gothic)",
      "Marine Drive Art Deco Buildings (Second largest collection worldwide)",
      "Kala Ghoda Heritage District (Colonial blue-synagogue & galleries)",
      "Kanheri Caves (Ancient Buddhist rock-cut monasteries in forest)"
    ],
    "markets": [
      "Crawford Market (Victorian wholesale fresh produce & pet market)",
      "Mangaldas Market (Indoor maze of textiles, silks & fabrics)",
      "Colaba Causeway (Boutiques, street fashion & vintage jewelry)",
      "Zaveri Bazaar (Generational goldsmiths & diamond jewelers)"
    ],
    "festivals": [
      "Ganesh Chaturthi (Spectacular Lalbaugcha Raja immersion processions)",
      "Kala Ghoda Arts Festival (South Mumbai annual pedestrian culture fair)",
      "Bandra Feast & Mount Mary Church Carnival"
    ],
    "localRhythm": "Morning architectural stroll around Fort and Oval Maidan, afternoon gallery hopping in Kala Ghoda with Irani chai, and catching the evening sea breeze along Marine Drive."
  },
  "liveLikeALocal": [
    {
      "icon": "🥪",
      "title": "Churchgate Grilled Sandwich",
      "description": "Order a toasted Bombay cheese-vegetable sandwich from the curbside stalls outside Churchgate station loaded with green chutney."
    },
    {
      "icon": "🏛️",
      "title": "Art Deco Stroll on Oval Maidan",
      "description": "Stand in the center of Oval Maidan to witness Victorian Gothic spires on the east and sleek 1930s Art Deco apartment blocks on the west."
    },
    {
      "icon": "☕",
      "title": "Irani Chai at Kyani & Co.",
      "description": "Visit Mumbai’s oldest operating Irani cafe (est. 1904) near Metro Cinema for warm sweet Irani chai with crunchy mawa cake and bun-muska."
    },
    {
      "icon": "🌇",
      "title": "Queen’s Necklace Sunset",
      "description": "Sit on the tetrapods near Nariman Point around 18:00 as the evening sea breeze picks up and the streetlamps curve into a glowing necklace."
    },
    {
      "icon": "🛍️",
      "title": "Mangaldas Cloth Market",
      "description": "Wander the covered wooden lanes of Mangaldas market where tailors and fabric merchants have traded Malabar cottons since 1893."
    }
  ],
  "attractions": [
    {
      "id": "gateway-of-india",
      "name": "Gateway of India",
      "category": "heritage",
      "coords": {
        "x": 540,
        "y": 480,
        "lat": 18.922,
        "lng": 72.8347
      },
      "capacityMax": 7000,
      "currentVisitors": 6500,
      "loadPercentage": 93,
      "status": "critical",
      "averageVisitMinutes": 60,
      "entryFeeINR": 0,
      "currentWaitMinutes": 45,
      "openHours": "Open 24 Hours",
      "description": "Iconic 26-meter yellow basalt triumphal arch facing the Arabian Sea, flanked by the Taj Mahal Palace Hotel.",
      "whyCongested": "Crowds bottleneck at the single security baggage x-ray scanner; ferry ticket lines for Elephanta Caves block the plaza.",
      "roamResponse": "Redirect to Kala Ghoda Art Precinct (32% load) and Asiatic Library steps.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "kala-ghoda",
      "secondaryAlternativeId": "csmt-heritage",
      "nearbyBusinessIds": [
        "colaba-causeway",
        "britannia-co"
      ],
      "bestTime": {
        "bestHours": "06:30 — 08:30",
        "avoidHours": "16:00 — 19:30",
        "why": "Sunrise provides cool maritime breezes, early morning seagulls, and nearly empty plaza grounds."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 780,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 780,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 780,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 780,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 812,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 1070,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 1327,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 1585,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 1842,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "17:00",
          "visitors": 2100,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 1842,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 1585,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "20:00",
          "visitors": 1327,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    },
    {
      "id": "marine-drive",
      "name": "Marine Drive & Queen’s Necklace",
      "category": "nature",
      "coords": {
        "x": 420,
        "y": 440,
        "lat": 18.9432,
        "lng": 72.823
      },
      "capacityMax": 10000,
      "currentVisitors": 8800,
      "loadPercentage": 88,
      "status": "critical",
      "averageVisitMinutes": 75,
      "entryFeeINR": 0,
      "currentWaitMinutes": 0,
      "openHours": "Open 24 Hours",
      "description": "3.6-kilometer seaside promenade curving along Back Bay, celebrated for its dramatic Arabian Sea sunsets.",
      "whyCongested": "Peak crowds gather around Nariman Point between 17:30 and 20:00.",
      "roamResponse": "Suggest walking the northern Chowpatty stretch or exploring Malabar Hill hanging gardens.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "malabar-hill",
      "secondaryAlternativeId": "kala-ghoda",
      "nearbyBusinessIds": [
        "crawford-market"
      ],
      "bestTime": {
        "bestHours": "06:00 — 08:30",
        "avoidHours": "17:30 — 20:00",
        "why": "Morning joggers and tranquil Arabian sea waves with no traffic smog."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 942,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 942,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 942,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 942,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 942,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 980,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 1284,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 1588,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 1892,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 2196,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 2500,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 2196,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "20:00",
          "visitors": 1892,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    },
    {
      "id": "kala-ghoda",
      "name": "Kala Ghoda Art Precinct",
      "category": "culture",
      "coords": {
        "x": 510,
        "y": 440,
        "lat": 18.9287,
        "lng": 72.8331
      },
      "capacityMax": 3500,
      "currentVisitors": 1120,
      "loadPercentage": 32,
      "status": "optimal",
      "averageVisitMinutes": 90,
      "entryFeeINR": 0,
      "currentWaitMinutes": 0,
      "openHours": "10:00 — 20:00",
      "description": "Mumbai’s premier arts district lined with heritage colonial facades, contemporary art galleries, indie boutiques, and designer cafes.",
      "whyCongested": "Spacious pedestrian sidewalks easily absorb footfall; unhurried atmosphere.",
      "roamResponse": "PRIMARY SURROGATE: Shaded streets, high-quality museums, indie bookstores, and world-class heritage architecture.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "gateway-of-india",
      "nearbyBusinessIds": [
        "colaba-causeway"
      ],
      "bestTime": {
        "bestHours": "11:00 — 16:00",
        "avoidHours": "None (Pleasant all day)",
        "why": "Galleries are open, cafes have open seating, and pedestrian sidewalks are shaded."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 281,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 281,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 290,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 362,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 434,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "13:00",
          "visitors": 506,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 578,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "15:00",
          "visitors": 650,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "16:00",
          "visitors": 578,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "17:00",
          "visitors": 506,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "18:00",
          "visitors": 434,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "19:00",
          "visitors": 362,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "20:00",
          "visitors": 290,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "colaba-causeway",
      "name": "Colaba Causeway Bazaars & Cafes",
      "category": "shopping",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Shahid Bhagat Singh Road",
      "coords": {
        "x": 530,
        "y": 510,
        "lat": 18.9185,
        "lng": 72.8315
      },
      "distanceKm": 0.6,
      "transitMinutes": 7,
      "estimatedActivity": 2200,
      "activityStatus": "BUSY",
      "bestTime": "11:00 — 13:30",
      "quietestTime": "15:00 — 17:00",
      "specialty": "Vintage Brass Curios, Silver Jewelry & Bohemian Fashion",
      "priceRange": "₹150 — ₹3,200",
      "rating": 4.8,
      "reviewsCount": 3410,
      "whyRecommended": [
        "7 min walk from Gateway of India",
        "Iconic shopping boulevard blending heritage cafes with street markets",
        "Unrivaled selection of handcrafted leather bags and brassware",
        "Home to iconic heritage hangouts like Cafe Mondegar and Leopold"
      ],
      "roamSays": "The essential Mumbai street shopping experience. Wander beneath the old colonial arcades to discover brass pocket watches, silver earrings, and vintage movie posters.",
      "googleMapsQuery": "Colaba Causeway, Mumbai"
    },
    {
      "id": "crawford-market",
      "name": "Crawford Market (Mahatma Jyotiba Phule)",
      "category": "markets",
      "badge": "POPULAR MARKET",
      "badgeClass": "badge-elevated",
      "zone": "Fort North Axis",
      "coords": {
        "x": 490,
        "y": 360,
        "lat": 18.9482,
        "lng": 72.8344
      },
      "distanceKm": 1.8,
      "transitMinutes": 14,
      "estimatedActivity": 2800,
      "activityStatus": "VERY BUSY",
      "bestTime": "10:00 — 12:00",
      "quietestTime": "14:00 — 16:00",
      "specialty": "Spices, Dry Fruits, Alphonso Mangoes & Victorian Reliefs",
      "priceRange": "₹100 — ₹2,500",
      "rating": 4.7,
      "reviewsCount": 4120,
      "whyRecommended": [
        "Built in 1869 with friezes designed by Lockwood Kipling",
        "Historic wholesale market under high vaulted iron beams",
        "Great prices for Konkan spices, dry fruits, and seasonal mangoes",
        "Immense historic and architectural value"
      ],
      "roamSays": "Look up above the entrance arches to see the original stone carvings sculpted by Rudyard Kipling’s father before immersing yourself in the spice aisles.",
      "googleMapsQuery": "Crawford Market, Mumbai"
    },
    {
      "id": "britannia-co",
      "name": "Britannia & Co. Parsi Restaurant",
      "category": "food",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Ballard Estate Heritage Quarter",
      "coords": {
        "x": 530,
        "y": 420,
        "lat": 18.9348,
        "lng": 72.8392
      },
      "distanceKm": 1.2,
      "transitMinutes": 11,
      "estimatedActivity": 520,
      "activityStatus": "QUIET",
      "bestTime": "12:00 — 14:00",
      "quietestTime": "14:00 — 15:30",
      "specialty": "Berry Pulao, Mutton Dhansak & Caramel Custard",
      "priceRange": "₹350 — ₹950",
      "rating": 4.9,
      "reviewsCount": 2890,
      "whyRecommended": [
        "100-year-old heritage Parsi culinary landmark in quiet Ballard Estate",
        "Original recipe Berry Pulao with imported Iranian barberries",
        "Charming vintage wooden interiors and high ceilings",
        "Far less hectic than tourist waterfront restaurants"
      ],
      "roamSays": "A true Mumbai time capsule. Order the Berry Pulao with chilled raspberry soda in this quiet neo-classical European port quarter.",
      "googleMapsQuery": "Britannia & Co Restaurant, Ballard Estate, Mumbai"
    },
    {
      "id": "yazdani-bakery-fort",
      "name": "Yazdani Bakery & Irani Chai",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Fort Heritage Precinct",
      "coords": {
        "x": 510,
        "y": 440,
        "lat": 18.9322,
        "lng": 72.8335
      },
      "distanceKm": 0.8,
      "transitMinutes": 8,
      "estimatedActivity": 610,
      "activityStatus": "QUIET",
      "bestTime": "08:00 — 11:30",
      "quietestTime": "14:00 — 16:30",
      "specialty": "Crusty Brun Maska, Apple Pie & Wood-Fired Chai",
      "priceRange": "₹40 — ₹180",
      "rating": 4.9,
      "reviewsCount": 3120,
      "whyRecommended": [
        "Legendary wood-fired stone ovens operating continuously since 1953",
        "Crispy crust brun pav loaded with rich slabs of fresh butter",
        "Homey retro ambiance with vintage posters and antique weight scales",
        "Charming, slow-paced sanctuary in the middle of the banking district"
      ],
      "roamSays": "Dip the crunchy warm brun pav directly into a cup of hot brewed ginger chai. A legendary Mumbai breakfast experience loved by locals.",
      "googleMapsQuery": "Yazdani Bakery, Fort, Mumbai"
    },
    {
      "id": "sassoon-docks-wharf",
      "name": "Sassoon Docks Fish Wharf & Art District",
      "category": "crafts",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Colaba Port Waterfront",
      "coords": {
        "x": 550,
        "y": 560,
        "lat": 18.9118,
        "lng": 72.8258
      },
      "distanceKm": 1.4,
      "transitMinutes": 12,
      "estimatedActivity": 740,
      "activityStatus": "QUIET",
      "bestTime": "06:30 — 09:30",
      "quietestTime": "11:00 — 14:00",
      "specialty": "Koli Community Fishing Fleet, Morning Auction & Massive Art Murals",
      "priceRange": "Free / Cultural",
      "rating": 4.8,
      "reviewsCount": 1640,
      "whyRecommended": [
        "Built in 1875 as Mumbai’s first commercial wet dock",
        "Epicenter of the indigenous Koli fisherfolk community",
        "Vibrant open-air maritime murals painted by international street artists",
        "Vibrant morning boat arrivals with colorful wooden trawlers"
      ],
      "roamSays": "Visit early in the morning to see the indigenous Koli fishing trawlers unload the night's catch against a backdrop of striking dockland art murals.",
      "googleMapsQuery": "Sassoon Dock, Colaba, Mumbai"
    },
    {
      "id": "chor-bazaar-antiques",
      "name": "Chor Bazaar (Mutton Street Antiques)",
      "category": "shopping",
      "badge": "CULTURAL SHOPPING",
      "badgeClass": "badge-optimal",
      "zone": "Kumbharwada / Null Bazaar Axis",
      "coords": {
        "x": 460,
        "y": 320,
        "lat": 18.9582,
        "lng": 72.8285
      },
      "distanceKm": 2.6,
      "transitMinutes": 18,
      "estimatedActivity": 1500,
      "activityStatus": "MODERATE",
      "bestTime": "11:00 — 14:30",
      "quietestTime": "12:00 — 15:00",
      "specialty": "Vintage Gramophones, Brass Clocks, Bollywood Posters & Art Deco Lamps",
      "priceRange": "₹200 — ₹15,000",
      "rating": 4.7,
      "reviewsCount": 2480,
      "whyRecommended": [
        "Over 150 years of curio and vintage treasure trading",
        "Mutton Street shops overflowing with Victorian brassware and antique vinyl records",
        "Original hand-painted vintage Bollywood posters from the 1960s and 70s",
        "Direct barter with generational antique restorers"
      ],
      "roamSays": "A labyrinth for vintage lovers. You can find restored 1940s brass ship chronometers, valve radios, and genuine hand-painted cinematic memorabilia.",
      "googleMapsQuery": "Chor Bazaar, Mutton Street, Mumbai"
    },
    {
      "id": "kyani-and-co-marine",
      "name": "Kyani & Co. Heritage Bakery (Est. 1904)",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Dhobi Talao / Marine Lines",
      "coords": {
        "x": 480,
        "y": 420,
        "lat": 18.9415,
        "lng": 72.8288
      },
      "distanceKm": 1.5,
      "transitMinutes": 11,
      "estimatedActivity": 980,
      "activityStatus": "MODERATE",
      "bestTime": "08:30 — 11:00",
      "quietestTime": "15:00 — 17:00",
      "specialty": "Mutton Puffs, Khari Biscuits, Akuri on Toast & Cream Rolls",
      "priceRange": "₹40 — ₹220",
      "rating": 4.8,
      "reviewsCount": 3890,
      "whyRecommended": [
        "The oldest operational Irani cafe in Mumbai, serving since 1904",
        "Classic bentwood Thonet chairs and checkered tablecloths under high ceilings",
        "Fresh bakery counter with crispy khari biscuits and sweet mawa cakes",
        "Unchanged colonial charm at very affordable local prices"
      ],
      "roamSays": "Order their signature Parsi Akuri (spiced scrambled eggs) with toasted butter pav, followed by sweet mawa cake and a glass of hot Irani chai.",
      "googleMapsQuery": "Kyani & Co, Marine Lines, Mumbai"
    }
  ]
};
