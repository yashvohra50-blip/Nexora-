/**
 * ROAM — Visitor Flow Intelligence Data Engine (V4)
 * Real-time Spatial Crowd Movement, Bottleneck Corridors & Intelligent Redistribution Lenses
 *
 * Supported Dedicated Cities:
 * - Jaipur (Pink City Heritage & Dhundhar Corridor)
 * - Varanasi (Ghats, Gallis, Weavers & Sarnath)
 * - Mumbai (Colaba, Fort, Heritage Hamlets & Coastal Trails)
 * - Kochi (Fort Kochi, Mattancherry, Dhobi Khana & Mangrove Islands)
 * - Leh (Monasteries, High Passes, Stok Village & Traditional Hamlets)
 * - Delhi (Mughal Axis, Sufi Bastis, Mehrauli Forest & Tibetan Quarters)
 *
 * + Universal Dynamic Generator for all 60+ Indian Destinations & Rural Regions
 */

export const VISITOR_FLOW_REGISTRY = {
  jaipur: {
    destinationId: 'jaipur',
    city: 'Jaipur',
    state: 'Rajasthan',
    regionTag: 'Dhundhar & Shekhawati Gateway',
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 76,
      optimizedConcentration: 48,
      bottleneckReductionPct: 28,
      underVisitedGainPct: 34,
      artisanRevenueGainPct: 24,
      culturalDiscoveryPct: 36,
      alertPrompt: {
        message: 'Amber Fort & Hawa Mahal corridors are reaching 94% peak load. ROAM suggests distributing via Kishanpole Craft Guild & Panna Meena Kund.',
        targetSegmentId: 'hawa-citypalace',
        targetAlternativeId: 'kishanpole-craft'
      }
    },
    timeProfiles: {
      '08:00': {
        label: 'Morning Tranquility & Temple Aarti',
        headline: 'Early morning tranquility across the walled city',
        summary: 'Govind Dev Ji temple and Nahargarh sunrise bastions active. Monument gates just opening; ideal time for photography.',
        avgCityLoadPct: 24
      },
      '10:00': {
        label: 'Peak Morning Heritage Surge',
        headline: 'Tour buses converging at Suraj Pol and Hawa Mahal',
        summary: 'Heavy congestion on Suraj Pol ramparts (Amber Fort) and Badi Choupad. 78% of incoming tourists in linear monument axis.',
        avgCityLoadPct: 84
      },
      '12:00': {
        label: 'Midday Heat & Indoor Migration',
        headline: 'Visitors shifting toward indoor courtyards and thali lanes',
        summary: 'Exposed stone ramparts reaching high temperatures; indoor museums, Johari Bazaar covered arcades, and traditional bhojanalayas active.',
        avgCityLoadPct: 72
      },
      '14:00': {
        label: 'Post-Lunch Cultural Stroll',
        headline: 'Museum discovery and shaded artisan workshops',
        summary: 'Albert Hall Museum and Kishanpole block-print ateliers operating at peak craft activity with minimal queues.',
        avgCityLoadPct: 62
      },
      '16:00': {
        label: 'Afternoon Golden Hour',
        headline: 'Palace courtyards and photography movement',
        summary: 'City Palace Peacock Courtyard and Jantar Mantar sundials bathed in soft light. Footfall climbing at Bapu Bazaar.',
        avgCityLoadPct: 78
      },
      '18:00': {
        label: 'Sunset Ramparts & Evening Bazaars',
        headline: 'Nahargarh sunset rush and vibrant spice lanes',
        summary: 'Severe vehicular queue on Nahargarh winding road. Bapu and Johari Bazaars brimming with evening shoppers and street food stalls.',
        avgCityLoadPct: 88
      },
      '20:00': {
        label: 'Illuminated Heritage & Night Dining',
        headline: 'Illuminated facades and traditional dinner courtyards',
        summary: 'Albert Hall floodlit facade, night market along Tripolia Bazaar, and rooftop dining overlooking the glowing pink battlements.',
        avgCityLoadPct: 65
      }
    },
    nodes: [
      {
        id: 'hawa-mahal',
        name: 'Hawa Mahal',
        shortName: 'Hawa Mahal',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 420, y: 310 },
        baseVisitors: 2850,
        capacity: 1200,
        dwellTimeMinutes: 45,
        culturalScore: 98,
        localImpactINR: 120,
        status: 'critical',
        description: 'Iconic 5-story pink sandstone palace with 953 latticed honeycomb jharokhas built in 1799.',
        reason: 'Severe morning queue at front road facade; tour buses cause pedestrian gridlock.'
      },
      {
        id: 'city-palace',
        name: 'City Palace',
        shortName: 'City Palace',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 370, y: 260 },
        baseVisitors: 3200,
        capacity: 1500,
        dwellTimeMinutes: 90,
        culturalScore: 96,
        localImpactINR: 220,
        status: 'critical',
        description: 'Royal residence blend of Rajasthani and Mughal architecture with Chandra Mahal and Peacock Courtyard.',
        reason: 'Second stop on standard tourist bus route; long ticket queue at Virendra Pol.'
      },
      {
        id: 'amber-fort',
        name: 'Amber Fort',
        shortName: 'Amber Fort',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 570, y: 110 },
        baseVisitors: 4800,
        capacity: 2200,
        dwellTimeMinutes: 140,
        culturalScore: 99,
        localImpactINR: 310,
        status: 'critical',
        description: 'Hilltop fort palace known for Sheesh Mahal mirror mosaic and sweeping Maota Lake ramparts.',
        reason: 'Suraj Pol elephant ramp and ticket gate bottleneck creates 65-minute wait.'
      },
      {
        id: 'jantar-mantar',
        name: 'Jantar Mantar',
        shortName: 'Jantar Mantar',
        category: 'heritage',
        type: 'corridor',
        coords: { x: 390, y: 230 },
        baseVisitors: 1650,
        capacity: 1400,
        dwellTimeMinutes: 60,
        culturalScore: 94,
        localImpactINR: 150,
        status: 'elevated',
        description: 'UNESCO World Heritage 18th-century stone astronomical observatory with world’s largest stone sundial.',
        reason: 'Connected to City Palace precinct; moderate line during midday guides tour.'
      },
      {
        id: 'kishanpole-craft',
        name: 'Kishanpole Artisan Woodcraft & Block-Print Guild',
        shortName: 'Kishanpole Craft Guild',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 280, y: 340 },
        baseVisitors: 340,
        capacity: 1200,
        dwellTimeMinutes: 50,
        culturalScore: 96,
        localImpactINR: 580,
        status: 'optimal',
        description: 'Quiet heritage street where 5th-generation master woodcarvers and block-print dyers work in open verandahs.',
        reason: 'Zero wait time, direct artisan engagement, 4-generation chai stall next door.'
      },
      {
        id: 'anokhi-museum',
        name: 'Anokhi Museum of Hand Printing',
        shortName: 'Anokhi Hand-Print Museum',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 620, y: 80 },
        baseVisitors: 280,
        capacity: 600,
        dwellTimeMinutes: 55,
        culturalScore: 95,
        localImpactINR: 420,
        status: 'optimal',
        description: 'Restored 16th-century stone haveli in Amber village dedicated to traditional block printing with live master demonstrations.',
        reason: 'Just 800m north of Amber Fort main gate; peaceful courtyard with master artisan demonstrations.'
      },
      {
        id: 'panna-meena',
        name: 'Panna Meena Ka Kund Stepwell',
        shortName: 'Panna Meena Stepwell',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 650, y: 130 },
        baseVisitors: 410,
        capacity: 900,
        dwellTimeMinutes: 35,
        culturalScore: 92,
        localImpactINR: 180,
        status: 'optimal',
        description: 'Magnificent 16th-century geometric stepwell with crisscross symmetrical staircases and quiet temple alcoves.',
        reason: '5 minutes from Amber Fort, tranquil morning light, no admission queues.'
      },
      {
        id: 'albert-hall',
        name: 'Albert Hall Museum & Ram Niwas Gardens',
        shortName: 'Albert Hall Museum',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 440, y: 470 },
        baseVisitors: 620,
        capacity: 2000,
        dwellTimeMinutes: 80,
        culturalScore: 91,
        localImpactINR: 240,
        status: 'optimal',
        description: 'Indo-Saracenic royal museum housing miniature paintings, antique weaponry, and Egyptian artifacts.',
        reason: 'Broad courtyards, beautiful evening pigeon flight, 18% capacity load.'
      },
      {
        id: 'bapu-bazaar',
        name: 'Bapu Bazaar Textile Corridor',
        shortName: 'Bapu Bazaar',
        category: 'markets',
        type: 'corridor',
        coords: { x: 470, y: 370 },
        baseVisitors: 1950,
        capacity: 2500,
        dwellTimeMinutes: 75,
        culturalScore: 89,
        localImpactINR: 750,
        status: 'elevated',
        description: 'Vibrant pink arcade market for authentic block-print cottons, leheriya dupattas, and camel leather juttis.',
        reason: 'Lively local trading; best visited between 15:30 and 17:30 before evening crowd rush.'
      },
      {
        id: 'nahargarh',
        name: 'Nahargarh Fort Sunset Ramparts',
        shortName: 'Nahargarh Ramparts',
        category: 'nature',
        type: 'hotspot',
        coords: { x: 260, y: 150 },
        baseVisitors: 2100,
        capacity: 1500,
        dwellTimeMinutes: 90,
        culturalScore: 93,
        localImpactINR: 200,
        status: 'elevated',
        description: 'Aravalli hilltop fortress overlooking the entire Pink City with dramatic panoramic sunset views.',
        reason: 'Heavy vehicular climb between 17:00 and 18:30; visit before 16:30 or explore stepwell side.'
      },
      {
        id: 'old-city-food-lane',
        name: 'Chawri Bazaar Heritage Food Lane',
        shortName: 'Heritage Food Lane',
        category: 'food',
        type: 'surrogate',
        coords: { x: 340, y: 380 },
        baseVisitors: 450,
        capacity: 1000,
        dwellTimeMinutes: 40,
        culturalScore: 94,
        localImpactINR: 320,
        status: 'optimal',
        description: 'Centuries-old culinary alley famous for fresh khoya kulfi, hot dal kachori, and mawa sweets.',
        reason: 'Legendary generational recipes away from tourist bus traps; 100% authentic flavor.'
      },
      {
        id: 'ghat-ki-guni',
        name: 'Ghat Ki Guni Heritage Terraced Gardens',
        shortName: 'Ghat Ki Guni',
        category: 'rural',
        type: 'surrogate',
        coords: { x: 670, y: 440 },
        baseVisitors: 180,
        capacity: 800,
        dwellTimeMinutes: 60,
        culturalScore: 90,
        localImpactINR: 260,
        status: 'optimal',
        description: 'Picturesque mountain pass filled with 18th-century Rajput-Mughal summer pleasure pavilions and stepped gardens.',
        reason: 'Completely uncrowded, exquisite restored frescoes, peaceful valley breeze.'
      }
    ],
    segments: [
      {
        id: 'hawa-citypalace',
        name: 'Hawa Mahal ➔ City Palace Express Corridor',
        fromNodeId: 'hawa-mahal',
        toNodeId: 'city-palace',
        mode: 'current',
        flowType: 'visitors',
        categories: ['heritage'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 420,
          '10:00': 1842,
          '12:00': 1650,
          '14:00': 1320,
          '16:00': 1480,
          '18:00': 1100,
          '20:00': 620
        },
        dwellTime: '34m',
        peakPeriod: '09:30 — 12:30',
        touristPct: 84,
        localPct: 16,
        whyHappening: 'Tour bus operators drop groups at Badi Choupad at 09:30 AM and march them in a direct single-file line to City Palace Virendra Pol gate. 84% follow this identical linear axis, ignoring all adjoining cultural side-lanes.',
        roamOpportunity: 'REDIRECT 22% OF FLOW: Divert 400 visitors/hr via Kishanpole Woodcraft Alley & Old City Food Lane, reducing gate queue by 25 minutes and generating ₹1.8L daily revenue for local artisan guilds.',
        surrogates: ['kishanpole-craft', 'old-city-food-lane', 'albert-hall']
      },
      {
        id: 'citypalace-amber',
        name: 'City Palace ➔ Amber Fort Highway Surge',
        fromNodeId: 'city-palace',
        toNodeId: 'amber-fort',
        mode: 'current',
        flowType: 'visitors',
        categories: ['heritage'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 580,
          '10:00': 2140,
          '12:00': 1980,
          '14:00': 1420,
          '16:00': 1250,
          '18:00': 780,
          '20:00': 310
        },
        dwellTime: '65m',
        peakPeriod: '10:00 — 13:00',
        touristPct: 89,
        localPct: 11,
        whyHappening: 'Standard tour itineraries schedule Amber Fort immediately following City Palace, causing high vehicular congestion along Amer Road and 65-minute ticketing queues at Suraj Pol.',
        roamOpportunity: 'REDIRECT 28% OF FLOW: Route morning travelers to Panna Meena Kund and Anokhi Museum first; visit Amber Fort through the north courtyard at 14:30 with zero queue.',
        surrogates: ['anokhi-museum', 'panna-meena', 'ghat-ki-guni']
      },
      {
        id: 'amber-nahargarh',
        name: 'Amber Fort ➔ Nahargarh Fort Sunset Route',
        fromNodeId: 'amber-fort',
        toNodeId: 'nahargarh',
        mode: 'current',
        flowType: 'visitors',
        categories: ['nature', 'heritage'],
        densityState: 'high',
        hourlyFlow: {
          '08:00': 210,
          '10:00': 640,
          '12:00': 480,
          '14:00': 820,
          '16:00': 1680,
          '18:00': 2250,
          '20:00': 940
        },
        dwellTime: '45m',
        peakPeriod: '16:30 — 18:45',
        touristPct: 76,
        localPct: 24,
        whyHappening: 'Social media sunset photography prompts a massive rush up the narrow single-lane Aravalli winding ghat between 17:00 and 18:30.',
        roamOpportunity: 'REDIRECT 20% OF FLOW: Encourage early arrival at 16:00 or distribute evening sunset viewers toward Ghat Ki Guni pavilions and Albert Hall lit gardens.',
        surrogates: ['ghat-ki-guni', 'albert-hall', 'bapu-bazaar']
      },

      // ROAM OPTIMIZED CORRIDORS
      {
        id: 'hawa-foodlane',
        name: 'Hawa Mahal ➔ Heritage Food & Spice Lane',
        fromNodeId: 'hawa-mahal',
        toNodeId: 'old-city-food-lane',
        mode: 'optimized',
        flowType: 'both',
        categories: ['food', 'culture'],
        densityState: 'moderate',
        hourlyFlow: {
          '08:00': 340,
          '10:00': 520,
          '12:00': 780,
          '14:00': 490,
          '16:00': 610,
          '18:00': 740,
          '20:00': 580
        },
        dwellTime: '30m',
        peakPeriod: '11:30 — 14:00',
        touristPct: 52,
        localPct: 48,
        whyHappening: 'ROAM balances morning monument traffic by guiding curious travelers into authentic culinary lanes for hot kachoris and generational kulfi.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Distributes 480 visitors away from main gate bottlenecks and injects ₹1.4L directly into family-run food stalls.',
        surrogates: ['kishanpole-craft', 'bapu-bazaar']
      },
      {
        id: 'foodlane-kishanpole',
        name: 'Old City ➔ Kishanpole Woodcraft & Dyers Guild',
        fromNodeId: 'old-city-food-lane',
        toNodeId: 'kishanpole-craft',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'markets'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 180,
          '10:00': 340,
          '12:00': 420,
          '14:00': 380,
          '16:00': 450,
          '18:00': 390,
          '20:00': 210
        },
        dwellTime: '45m',
        peakPeriod: '14:00 — 17:00',
        touristPct: 45,
        localPct: 55,
        whyHappening: 'ROAM connects food explorers directly with master block printers and woodcarvers along Kishanpole Bazaar.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: High-value cultural immersion; zero queues, direct artisan purchases, 96/100 cultural DNA match.',
        surrogates: ['albert-hall', 'bapu-bazaar']
      },
      {
        id: 'kishanpole-alberthall',
        name: 'Kishanpole ➔ Albert Hall Museum Courtyard',
        fromNodeId: 'kishanpole-craft',
        toNodeId: 'albert-hall',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'heritage'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 190,
          '10:00': 380,
          '12:00': 510,
          '14:00': 620,
          '16:00': 580,
          '18:00': 460,
          '20:00': 320
        },
        dwellTime: '60m',
        peakPeriod: '13:30 — 16:30',
        touristPct: 48,
        localPct: 52,
        whyHappening: 'Spacious Indo-Saracenic museum and breezy gardens absorb afternoon visitors with zero queue strain.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Smooth transition from craft lanes to royal artifacts; saves 45 minutes of line waiting compared to main palaces.',
        surrogates: ['ghat-ki-guni', 'bapu-bazaar']
      },
      {
        id: 'alberthall-anokhi',
        name: 'Albert Hall ➔ Anokhi Museum Craft Hamlet',
        fromNodeId: 'albert-hall',
        toNodeId: 'anokhi-museum',
        mode: 'optimized',
        flowType: 'visitors',
        categories: ['culture', 'heritage'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 120,
          '10:00': 280,
          '12:00': 340,
          '14:00': 390,
          '16:00': 310,
          '18:00': 180,
          '20:00': 60
        },
        dwellTime: '55m',
        peakPeriod: '11:00 — 15:30',
        touristPct: 62,
        localPct: 38,
        whyHappening: 'Quiet 16th-century stone haveli in historic Amber village featuring master block carvers and natural indigo vats.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: World-class textile heritage experience; completely eliminates crowding friction.',
        surrogates: ['panna-meena', 'amber-fort']
      },
      {
        id: 'anokhi-pannameena',
        name: 'Anokhi Museum ➔ Panna Meena Ka Kund Stepwell',
        fromNodeId: 'anokhi-museum',
        toNodeId: 'panna-meena',
        mode: 'optimized',
        flowType: 'both',
        categories: ['heritage'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 150,
          '10:00': 310,
          '12:00': 360,
          '14:00': 320,
          '16:00': 410,
          '18:00': 280,
          '20:00': 90
        },
        dwellTime: '35m',
        peakPeriod: '08:30 — 11:00 & 16:00 — 17:30',
        touristPct: 58,
        localPct: 42,
        whyHappening: 'Architectural marvel of 16th-century stepped geometric architecture with cool subterranean breezes.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Absorbs visitors before Amber Fort; magnificent photography without single-file line delays.',
        surrogates: ['amber-fort', 'ghat-ki-guni']
      },
      {
        id: 'pannameena-amber',
        name: 'Panna Meena ➔ Amber Fort North Gate (Off-Peak)',
        fromNodeId: 'panna-meena',
        toNodeId: 'amber-fort',
        mode: 'optimized',
        flowType: 'visitors',
        categories: ['heritage'],
        densityState: 'moderate',
        hourlyFlow: {
          '08:00': 280,
          '10:00': 620,
          '12:00': 540,
          '14:00': 890,
          '16:00': 780,
          '18:00': 420,
          '20:00': 120
        },
        dwellTime: '90m',
        peakPeriod: '14:00 — 16:00 (Post-Surge Window)',
        touristPct: 70,
        localPct: 30,
        whyHappening: 'Entering Amber Fort in the afternoon via the quiet village side cuts wait time from 65m down to under 8m.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Optimal timing saves 57 minutes of standing in heat.',
        surrogates: ['ghat-ki-guni', 'nahargarh']
      },
      {
        id: 'amber-ghatguni',
        name: 'Amber Fort ➔ Ghat Ki Guni Valley Pavilions',
        fromNodeId: 'amber-fort',
        toNodeId: 'ghat-ki-guni',
        mode: 'optimized',
        flowType: 'both',
        categories: ['rural', 'nature'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 90,
          '10:00': 210,
          '12:00': 260,
          '14:00': 310,
          '16:00': 390,
          '18:00': 340,
          '20:00': 110
        },
        dwellTime: '60m',
        peakPeriod: '16:00 — 18:30',
        touristPct: 35,
        localPct: 65,
        whyHappening: 'Shaded Rajput-Mughal terraced pleasure gardens with mountain breezes, completely off the standard tourist bus radar.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Tranquil sunset alternative to congested Nahargarh ramparts; authentic royal garden architecture.',
        surrogates: ['albert-hall', 'bapu-bazaar']
      }
    ]
  },

  varanasi: {
    destinationId: 'varanasi',
    city: 'Varanasi',
    state: 'Uttar Pradesh',
    regionTag: 'Ganga Ghats & Ancient Kashi Corridor',
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 82,
      optimizedConcentration: 44,
      bottleneckReductionPct: 38,
      underVisitedGainPct: 42,
      artisanRevenueGainPct: 31,
      culturalDiscoveryPct: 45,
      alertPrompt: {
        message: 'Dashashwamedh & Kashi Vishwanath corridors at 96% peak density. ROAM recommends distributing via Kabir Chaura Music Quarter & Madanpura Weaver Looms.',
        targetSegmentId: 'kashi-dashashwamedh',
        targetAlternativeId: 'kabir-chaura'
      }
    },
    timeProfiles: {
      '08:00': {
        label: 'Subah-e-Banaras & Dawn Ghat Aarti',
        headline: 'Spiritual dawn rituals, morning boat rows & temple bells',
        summary: 'Assi Ghat morning yoga and classical music recitals. Boat traffic dense near Dashashwamedh; quiet mist along southern ghats.',
        avgCityLoadPct: 68
      },
      '10:00': {
        label: 'Peak Temple Gali Surge',
        headline: 'Heavy pedestrian congestion in Vishwanath Gali',
        summary: 'Pilgrim queues extending into narrow stone alleys. High queue wait at Kashi Vishwanath Corridor entrance.',
        avgCityLoadPct: 92
      },
      '12:00': {
        label: 'Midday Banarasi Lassi & Kachori Hours',
        headline: 'Visitors gathering around legendary sweet and kachori shops',
        summary: 'Thateri Bazaar and Kachori Gali bustling with lunch crowds. Sarnath heritage stupas serene and breezy.',
        avgCityLoadPct: 70
      },
      '14:00': {
        label: 'Afternoon Handloom Silk & Music Haveli Trail',
        headline: 'Master weavers operating handlooms in shaded courtyard lanes',
        summary: 'Madanpura and Kabir Chaura classical music ashrams at optimal visiting conditions with zero crowd friction.',
        avgCityLoadPct: 54
      },
      '16:00': {
        label: 'Pre-Aarti Ghat Strolls & Boat Boarding',
        headline: 'Visitors gathering along the riverfront stone steps',
        summary: 'Boats starting to anchor near Dashashwamedh Ghat. Southern ghats (Tulsi, Harishchandra, Assi) offer peaceful strolls.',
        avgCityLoadPct: 79
      },
      '18:00': {
        label: 'Grand Ganga Aarti Surge',
        headline: 'Extreme concentration at Dashashwamedh & Rajendra Prasad Ghats',
        summary: 'Thousands packed onto stone steps and tied boats for evening Aarti. ROAM recommends viewing from Assi Ghat or quiet southern boats.',
        avgCityLoadPct: 96
      },
      '20:00': {
        label: 'Night Gali Strolls & Banarasi Paan',
        headline: 'Cool evening breeze along silent northern ghats and sweet shops',
        summary: 'Ghats quiet down after Aarti. Chowk and Godowlia food vendors active with malaiyo and Banarasi paan.',
        avgCityLoadPct: 62
      }
    },
    nodes: [
      {
        id: 'dashashwamedh',
        name: 'Dashashwamedh Ghat',
        shortName: 'Dashashwamedh',
        category: 'spiritual',
        type: 'hotspot',
        coords: { x: 440, y: 320 },
        baseVisitors: 5400,
        capacity: 2200,
        dwellTimeMinutes: 70,
        culturalScore: 99,
        localImpactINR: 150,
        status: 'critical',
        description: 'Varanasi’s most famous main ghat where the grand evening Maha Aarti takes place daily.',
        reason: 'Extreme pedestrian and boat congestion; standing-room only during evening Aarti.'
      },
      {
        id: 'kashi-vishwanath',
        name: 'Kashi Vishwanath Temple Corridor',
        shortName: 'Kashi Vishwanath',
        category: 'spiritual',
        type: 'hotspot',
        coords: { x: 400, y: 260 },
        baseVisitors: 6200,
        capacity: 2500,
        dwellTimeMinutes: 80,
        culturalScore: 100,
        localImpactINR: 200,
        status: 'critical',
        description: 'Sacred golden temple dedicated to Lord Shiva, one of the twelve holy Jyotirlingas.',
        reason: 'Pilgrim queues stretch for 300 meters through narrow security corridors between 09:00 and 12:00.'
      },
      {
        id: 'assi-ghat',
        name: 'Assi Ghat Cultural Recitals',
        shortName: 'Assi Ghat',
        category: 'culture',
        type: 'corridor',
        coords: { x: 310, y: 510 },
        baseVisitors: 1800,
        capacity: 2000,
        dwellTimeMinutes: 65,
        culturalScore: 95,
        localImpactINR: 320,
        status: 'optimal',
        description: 'Southernmost ghat famous for morning Subah-e-Banaras classical recitals, yoga, and student cafes.',
        reason: 'Spacious steps, open river breeze, serene morning rituals without tour bus congestion.'
      },
      {
        id: 'kabir-chaura',
        name: 'Kabir Chaura Classical Music & Poet Quarter',
        shortName: 'Kabir Chaura',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 260, y: 220 },
        baseVisitors: 260,
        capacity: 800,
        dwellTimeMinutes: 50,
        culturalScore: 98,
        localImpactINR: 480,
        status: 'optimal',
        description: 'Historic neighborhood of legendary Banaras Gharana tabla masters, shehnai maestros, and Sant Kabir ashram.',
        reason: 'Zero tourist congestion; intimate music havelis and direct interaction with classical lineage musicians.'
      },
      {
        id: 'madanpura-weavers',
        name: 'Madanpura Master Handloom Silk Colony',
        shortName: 'Madanpura Silk Weavers',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 330, y: 390 },
        baseVisitors: 310,
        capacity: 900,
        dwellTimeMinutes: 60,
        culturalScore: 97,
        localImpactINR: 1250,
        status: 'optimal',
        description: 'Ancient residential weaver gali where master Muslim weavers create real gold zari Katan silk sarees on wooden pit looms.',
        reason: 'Direct artisan pricing with zero middleman commissions; rhythmic clatter of centuries-old handlooms.'
      },
      {
        id: 'tulsi-ghat',
        name: 'Tulsi Ghat & Traditional Akhara',
        shortName: 'Tulsi Ghat Akhara',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 340, y: 460 },
        baseVisitors: 280,
        capacity: 800,
        dwellTimeMinutes: 40,
        culturalScore: 94,
        localImpactINR: 190,
        status: 'optimal',
        description: 'Where Goswami Tulsidas composed the Ramcharitmanas; home to a 450-year-old traditional mud wrestling akhara.',
        reason: 'Serene stone pavilions, morning clay wrestlers, deep spiritual calm.'
      },
      {
        id: 'sarnath',
        name: 'Sarnath Dhamek Stupa & Deer Park',
        shortName: 'Sarnath Stupa',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 590, y: 90 },
        baseVisitors: 750,
        capacity: 3000,
        dwellTimeMinutes: 110,
        culturalScore: 96,
        localImpactINR: 340,
        status: 'optimal',
        description: 'Where Lord Buddha preached his first sermon after enlightenment; magnificent 5th-century cylindrical stupa.',
        reason: '10km north of the crowded ghats; lush shaded lawns, ancient Ashokan pillars, and absolute tranquility.'
      },
      {
        id: 'kachori-gali',
        name: 'Kachori Gali & Blue Lassi Heritage Lane',
        shortName: 'Kachori Gali',
        category: 'food',
        type: 'surrogate',
        coords: { x: 420, y: 220 },
        baseVisitors: 680,
        capacity: 1100,
        dwellTimeMinutes: 35,
        culturalScore: 93,
        localImpactINR: 220,
        status: 'moderate',
        description: 'Medieval narrow stone lane renowned for hot round kachoris served on leaf plates with spicy potato gravy.',
        reason: 'Unmatched culinary heritage; authentic morning breakfast away from main commercial roads.'
      }
    ],
    segments: [
      {
        id: 'kashi-dashashwamedh',
        name: 'Kashi Vishwanath ➔ Dashashwamedh Main Alley',
        fromNodeId: 'kashi-vishwanath',
        toNodeId: 'dashashwamedh',
        mode: 'current',
        flowType: 'visitors',
        categories: ['spiritual'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 850,
          '10:00': 2650,
          '12:00': 2100,
          '14:00': 1450,
          '16:00': 2200,
          '18:00': 3400,
          '20:00': 1200
        },
        dwellTime: '45m',
        peakPeriod: '09:00 — 12:00 & 17:30 — 19:30',
        touristPct: 82,
        localPct: 18,
        whyHappening: 'Pilgrims and tourist groups funnel directly between Kashi Vishwanath temple exit and Dashashwamedh main ghat steps, creating severe pedestrian gridlock in the 6-foot wide stone galis.',
        roamOpportunity: 'REDIRECT 35% OF FLOW: Divert visitors via Kachori Gali to Kabir Chaura music quarter, then follow southern river path from Tulsi Ghat to Assi Ghat.',
        surrogates: ['kabir-chaura', 'madanpura-weavers', 'tulsi-ghat']
      },
      {
        id: 'kashi-kachorigali',
        name: 'Vishwanath ➔ Kachori Gali & Heritage Food Path',
        fromNodeId: 'kashi-vishwanath',
        toNodeId: 'kachori-gali',
        mode: 'optimized',
        flowType: 'both',
        categories: ['food', 'culture'],
        densityState: 'moderate',
        hourlyFlow: {
          '08:00': 420,
          '10:00': 610,
          '12:00': 750,
          '14:00': 410,
          '16:00': 520,
          '18:00': 480,
          '20:00': 390
        },
        dwellTime: '30m',
        peakPeriod: '08:30 — 11:30',
        touristPct: 46,
        localPct: 54,
        whyHappening: 'ROAM guides visitors into shaded culinary galis for breakfast and artisanal lassi, bypassing congested main lanes.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Relieves pressure on main temple exit while celebrating generational Banaras food traditions.',
        surrogates: ['kabir-chaura', 'madanpura-weavers']
      },
      {
        id: 'kachori-kabirchaura',
        name: 'Kachori Gali ➔ Kabir Chaura Music Quarter',
        fromNodeId: 'kachori-gali',
        toNodeId: 'kabir-chaura',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 110,
          '10:00': 320,
          '12:00': 380,
          '14:00': 340,
          '16:00': 390,
          '18:00': 280,
          '20:00': 140
        },
        dwellTime: '50m',
        peakPeriod: '13:00 — 16:30',
        touristPct: 40,
        localPct: 60,
        whyHappening: 'Cultural immersion in the legendary home of Pandit Kishan Maharaj and Bismillah Khan’s contemporaries.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: 98/100 cultural DNA match; intimate baithak listening with zero tourist crowding.',
        surrogates: ['madanpura-weavers', 'sarnath']
      },
      {
        id: 'kabir-madanpura',
        name: 'Kabir Chaura ➔ Madanpura Silk Weavers Guild',
        fromNodeId: 'kabir-chaura',
        toNodeId: 'madanpura-weavers',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'markets'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 90,
          '10:00': 290,
          '12:00': 350,
          '14:00': 380,
          '16:00': 410,
          '18:00': 300,
          '20:00': 110
        },
        dwellTime: '60m',
        peakPeriod: '14:00 — 17:30',
        touristPct: 45,
        localPct: 55,
        whyHappening: 'Visitors witness authentic pit loom silk jacquard weaving directly in weaver courtyards.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Channels average spend of ₹1,250 directly into artisan families without middleman cuts.',
        surrogates: ['tulsi-ghat', 'assi-ghat']
      },
      {
        id: 'madanpura-tulsighat',
        name: 'Madanpura ➔ Tulsi Ghat & Ancient Akhara Riverfront',
        fromNodeId: 'madanpura-weavers',
        toNodeId: 'tulsi-ghat',
        mode: 'optimized',
        flowType: 'both',
        categories: ['heritage', 'spiritual'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 180,
          '10:00': 340,
          '12:00': 310,
          '14:00': 290,
          '16:00': 420,
          '18:00': 390,
          '20:00': 240
        },
        dwellTime: '40m',
        peakPeriod: '07:30 — 09:30 & 16:30 — 18:00',
        touristPct: 52,
        localPct: 48,
        whyHappening: 'Connects the silk guild directly to the historic southern ghats where the sacred river is peaceful.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Bypasses overcrowded central ghats entirely while providing deep historical resonance.',
        surrogates: ['assi-ghat', 'sarnath']
      },
      {
        id: 'tulsighat-assighat',
        name: 'Tulsi Ghat ➔ Assi Ghat Evening Music Corridor',
        fromNodeId: 'tulsi-ghat',
        toNodeId: 'assi-ghat',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'spiritual'],
        densityState: 'moderate',
        hourlyFlow: {
          '08:00': 390,
          '10:00': 480,
          '12:00': 410,
          '14:00': 450,
          '16:00': 680,
          '18:00': 850,
          '20:00': 590
        },
        dwellTime: '65m',
        peakPeriod: '17:30 — 20:00',
        touristPct: 50,
        localPct: 50,
        whyHappening: 'Spacious stone steps at Assi Ghat host peaceful evening Aarti and classical sitar/flute recitals.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: High visitor satisfaction, ample seating space, and vibrant local student cafe ecosystem.',
        surrogates: ['sarnath', 'kabir-chaura']
      }
    ]
  },

  mumbai: {
    destinationId: 'mumbai',
    city: 'Mumbai',
    state: 'Maharashtra',
    regionTag: 'Konkan Coast & Historic Island City',
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 78,
      optimizedConcentration: 46,
      bottleneckReductionPct: 32,
      underVisitedGainPct: 38,
      artisanRevenueGainPct: 26,
      culturalDiscoveryPct: 40,
      alertPrompt: {
        message: 'Gateway of India & Colaba Causeway corridors reaching high saturation. ROAM recommends Khotachiwadi Heritage Hamlet & Banganga Tank.',
        targetSegmentId: 'gateway-colaba',
        targetAlternativeId: 'khotachiwadi'
      }
    },
    timeProfiles: {
      '08:00': {
        label: 'Dawn Sassoon Docks & Marine Promenade',
        headline: 'Early morning fish auction and serene sea breeze',
        summary: 'Koli fisherwomen and vibrant boat arrivals at Sassoon Docks. Marine Drive joggers and quiet heritage architecture strolls.',
        avgCityLoadPct: 35
      },
      '10:00': {
        label: 'Colaba Tourist Rush & Ferry Departures',
        headline: 'Long ferry queues at Gateway for Elephanta Caves',
        summary: 'Heavy pedestrian footfall at Gateway of India plaza and Causeway sidewalk stalls.',
        avgCityLoadPct: 82
      },
      '12:00': {
        label: 'Midday Irani Cafes & Kala Ghoda Galleries',
        headline: 'Visitors seeking shaded heritage cafes and art spaces',
        summary: 'Kala Ghoda art galleries, Jehangir Art Gallery, and legacy Irani chai cafes buzzing with lunch patrons.',
        avgCityLoadPct: 74
      },
      '14:00': {
        label: 'Historic Fort Quarter & Heritage Enclaves',
        headline: 'Khotachiwadi Portuguese cottages and Asiatic Library',
        summary: 'Horniman Circle and Victorian Gothic arcades at pleasant quiet hours; heritage architecture walking trails active.',
        avgCityLoadPct: 58
      },
      '16:00': {
        label: 'Afternoon Street Food & Bazaar Migration',
        headline: 'Crawford Market and Matunga filter coffee corridors',
        summary: 'Textile and spice traders at Crawford Market. Matunga South Indian culinary trail at peak freshness.',
        avgCityLoadPct: 76
      },
      '18:00': {
        label: 'Queen’s Necklace Sunset & Chowpatty Rush',
        headline: 'Massive sunset gathering along Marine Drive sea wall',
        summary: 'Thousands enjoying evening breeze from Nariman Point to Girgaon Chowpatty. Street vendors serving pav bhaji and bhel puri.',
        avgCityLoadPct: 94
      },
      '20:00': {
        label: 'Night Illuminations & Coastal Dining',
        headline: 'Illuminated Victoria Terminus and coastal rooftop dining',
        summary: 'CST building illuminated in dynamic colors; Fort district quietens down for heritage dining.',
        avgCityLoadPct: 68
      }
    },
    nodes: [
      {
        id: 'gateway-of-india',
        name: 'Gateway of India',
        shortName: 'Gateway of India',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 490, y: 480 },
        baseVisitors: 4500,
        capacity: 2000,
        dwellTimeMinutes: 50,
        culturalScore: 98,
        localImpactINR: 140,
        status: 'critical',
        description: 'Iconic 26m basalt arch monument overlooking Mumbai Harbour built in 1924.',
        reason: 'Severe plaza crowding, long security lines, and high ferry boarding congestion.'
      },
      {
        id: 'colaba-causeway',
        name: 'Colaba Causeway Shopping Strip',
        shortName: 'Colaba Causeway',
        category: 'markets',
        type: 'hotspot',
        coords: { x: 470, y: 520 },
        baseVisitors: 3600,
        capacity: 1800,
        dwellTimeMinutes: 75,
        culturalScore: 88,
        localImpactINR: 650,
        status: 'critical',
        description: 'High-energy commercial artery famous for street fashion, antique stalls, and Leopold Cafe.',
        reason: 'Narrow sidewalk pedestrian bottlenecks between 11:00 and 17:00.'
      },
      {
        id: 'marine-drive',
        name: 'Marine Drive (Queen’s Necklace)',
        shortName: 'Marine Drive',
        category: 'nature',
        type: 'hotspot',
        coords: { x: 380, y: 390 },
        baseVisitors: 5200,
        capacity: 3500,
        dwellTimeMinutes: 80,
        culturalScore: 94,
        localImpactINR: 180,
        status: 'critical',
        description: '3.6km C-shaped concrete promenade along the Arabian Sea with world’s second largest Art Deco collection.',
        reason: 'Severe congestion along promenade seawall during sunset hours (17:30 to 19:30).'
      },
      {
        id: 'khotachiwadi',
        name: 'Khotachiwadi 18th-Century Heritage Village',
        shortName: 'Khotachiwadi Village',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 390, y: 320 },
        baseVisitors: 240,
        capacity: 700,
        dwellTimeMinutes: 55,
        culturalScore: 97,
        localImpactINR: 520,
        status: 'optimal',
        description: 'Hidden heritage precinct of two-story wooden Portuguese-Goan style cottages with verandahs and quiet cobblestone lanes.',
        reason: 'Zero tourist crowding, living heritage community, local bakery and art studios.'
      },
      {
        id: 'banganga-tank',
        name: 'Banganga Ancient Sacred Water Tank',
        shortName: 'Banganga Tank',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 320, y: 350 },
        baseVisitors: 280,
        capacity: 800,
        dwellTimeMinutes: 45,
        culturalScore: 96,
        localImpactINR: 210,
        status: 'optimal',
        description: '12th-century rectangular freshwater tank surrounded by ancient temples, dharamsalas, and migrating ducks in Walkeshwar.',
        reason: 'Oldest surviving inhabited heritage structure in Mumbai; serene, contemplative atmosphere.'
      },
      {
        id: 'sassoon-docks',
        name: 'Sassoon Docks Artisan Fishery & Street Art',
        shortName: 'Sassoon Docks',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 500, y: 560 },
        baseVisitors: 320,
        capacity: 1000,
        dwellTimeMinutes: 50,
        culturalScore: 95,
        localImpactINR: 440,
        status: 'optimal',
        description: 'One of the oldest open docks in Mumbai built in 1875, hosting indigenous Koli fishing culture and giant mural installations.',
        reason: 'Fascinating authentic working harbor; vibrant photo opportunities at sunrise and early morning.'
      },
      {
        id: 'horniman-circle',
        name: 'Horniman Circle & Asiatic Library Precinct',
        shortName: 'Horniman Circle',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 470, y: 430 },
        baseVisitors: 540,
        capacity: 1600,
        dwellTimeMinutes: 60,
        culturalScore: 92,
        localImpactINR: 280,
        status: 'optimal',
        description: 'Grand neoclassical circular arcade with landscaped central park and monumental Greek Doric Asiatic Society portico.',
        reason: 'Spacious pedestrian arcades with vintage bookstores and historic cafes.'
      }
    ],
    segments: [
      {
        id: 'gateway-colaba',
        name: 'Gateway of India ➔ Colaba Causeway Axis',
        fromNodeId: 'gateway-of-india',
        toNodeId: 'colaba-causeway',
        mode: 'current',
        flowType: 'visitors',
        categories: ['heritage', 'markets'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 520,
          '10:00': 2100,
          '12:00': 1850,
          '14:00': 1620,
          '16:00': 2350,
          '18:00': 2600,
          '20:00': 1400
        },
        dwellTime: '40m',
        peakPeriod: '10:00 — 13:00 & 16:30 — 19:30',
        touristPct: 78,
        localPct: 22,
        whyHappening: 'Visitors disembarking at Gateway directly funnel into the narrow sidewalk corridor of Causeway, causing sidewalk gridlock.',
        roamOpportunity: 'REDIRECT 30% OF FLOW: Divert visitors through Horniman Circle neoclassical arcades to Khotachiwadi Portuguese heritage hamlet.',
        surrogates: ['khotachiwadi', 'banganga-tank', 'sassoon-docks']
      },
      {
        id: 'gateway-horniman',
        name: 'Gateway ➔ Horniman Circle & Asiatic Precinct',
        fromNodeId: 'gateway-of-india',
        toNodeId: 'horniman-circle',
        mode: 'optimized',
        flowType: 'both',
        categories: ['heritage', 'culture'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 240,
          '10:00': 480,
          '12:00': 520,
          '14:00': 460,
          '16:00': 550,
          '18:00': 410,
          '20:00': 260
        },
        dwellTime: '45m',
        peakPeriod: '11:00 — 15:30',
        touristPct: 48,
        localPct: 52,
        whyHappening: 'ROAM guides visitors north into shaded Victorian Gothic and Neoclassical streets with broad walkways.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Disperses crowd into quiet heritage gardens and vintage bookshops.',
        surrogates: ['khotachiwadi', 'sassoon-docks']
      },
      {
        id: 'horniman-khotachiwadi',
        name: 'Horniman Circle ➔ Khotachiwadi Heritage Quarter',
        fromNodeId: 'horniman-circle',
        toNodeId: 'khotachiwadi',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'heritage'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 120,
          '10:00': 260,
          '12:00': 310,
          '14:00': 350,
          '16:00': 380,
          '18:00': 270,
          '20:00': 150
        },
        dwellTime: '55m',
        peakPeriod: '13:30 — 17:00',
        touristPct: 42,
        localPct: 58,
        whyHappening: 'Serene exploration of 18th-century heritage cottages, family bakeries, and local textile ateliers.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: 97/100 cultural DNA match; directly supports indigenous architectural preservation.',
        surrogates: ['banganga-tank', 'sassoon-docks']
      },
      {
        id: 'khotachiwadi-banganga',
        name: 'Khotachiwadi ➔ Banganga Ancient Sacred Tank',
        fromNodeId: 'khotachiwadi',
        toNodeId: 'banganga-tank',
        mode: 'optimized',
        flowType: 'both',
        categories: ['heritage', 'spiritual'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 150,
          '10:00': 290,
          '12:00': 260,
          '14:00': 310,
          '16:00': 420,
          '18:00': 380,
          '20:00': 190
        },
        dwellTime: '45m',
        peakPeriod: '08:30 — 10:30 & 16:00 — 17:45',
        touristPct: 40,
        localPct: 60,
        whyHappening: 'Hidden 12th-century water temple oasis right in the heart of south Mumbai.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Tranquil alternative to the congested Marine Drive sea wall.',
        surrogates: ['sassoon-docks', 'horniman-circle']
      }
    ]
  },

  kochi: {
    destinationId: 'kochi',
    city: 'Kochi',
    state: 'Kerala',
    regionTag: 'Malabar Coast & Backwater Gateway',
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 74,
      optimizedConcentration: 42,
      bottleneckReductionPct: 32,
      underVisitedGainPct: 36,
      artisanRevenueGainPct: 28,
      culturalDiscoveryPct: 42,
      alertPrompt: {
        message: 'Chinese Fishing Nets & Mattancherry Palace experiencing peak queue density. ROAM suggests Dhobi Khana Heritage Laundry & Kumbalangi Craft Village.',
        targetSegmentId: 'nets-mattancherry',
        targetAlternativeId: 'dhobi-khana'
      }
    },
    timeProfiles: {
      '08:00': {
        label: 'Dawn Fisherman Nets & Spice Warehouse Waking',
        headline: 'Silhouetted cantilevered nets lifting fresh morning catch',
        summary: 'Chinese fishing nets operating in golden morning light. Jew Town antique shops just opening shutters.',
        avgCityLoadPct: 38
      },
      '10:00': {
        label: 'Mattancherry Palace & Synagogue Surge',
        headline: 'Tour groups entering Dutch Palace and Jew Town lane',
        summary: 'Heavy pedestrian line at Paradesi Synagogue ticketing booth. Tourist autos causing congestion on Synagogue Lane.',
        avgCityLoadPct: 86
      },
      '12:00': {
        label: 'Midday Spices & Seafood Heritage',
        headline: 'Visitors sampling Malabar fish curry and ginger warehouse air',
        summary: 'Bazaar Road spice merchants sorting pepper, cardamom, and cinnamon. Air thick with aromatic oils.',
        avgCityLoadPct: 72
      },
      '14:00': {
        label: 'Dhobi Khana Guild & Quiet Courtyard Walk',
        headline: 'Traditional Vannan community outdoor washing ghats active',
        summary: 'Dhobi Khana and Bastion Bungalow shaded museums offering serene cultural immersion with zero lines.',
        avgCityLoadPct: 52
      },
      '16:00': {
        label: 'Kumbalangi Backwater & Coir Weaving Trail',
        headline: 'Mangrove country craft village and canoe rides',
        summary: 'Crab farming and coir yarn spinning in Kumbalangi model village; golden sunlight filtering through coconut fronds.',
        avgCityLoadPct: 68
      },
      '18:00': {
        label: 'Fort Kochi Beach Sunset & Kathakali Makeup',
        headline: 'Sunset promenade crowds and Kathakali facial painting',
        summary: 'Fort Kochi beach packed for sunset behind fishing nets. Kathakali cultural centers open for green-room makeup viewing.',
        avgCityLoadPct: 90
      },
      '20:00': {
        label: 'Night Heritage Courtyards & Coastline Dinners',
        headline: 'Colonial boutique cafe dining and waterfront breeze',
        summary: 'Princess Street illuminated by lantern lights; traditional Kerala sadhya and grilled sea bass dinners.',
        avgCityLoadPct: 64
      }
    },
    nodes: [
      {
        id: 'chinese-fishing-nets',
        name: 'Chinese Fishing Nets (Cheena Vala)',
        shortName: 'Chinese Fishing Nets',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 380, y: 220 },
        baseVisitors: 3800,
        capacity: 1500,
        dwellTimeMinutes: 45,
        culturalScore: 98,
        localImpactINR: 180,
        status: 'critical',
        description: 'Iconic 14th-century cantilevered fishing nets introduced by Chinese explorer Zheng He.',
        reason: 'Heavy tourist group crowding along the narrow concrete walkway, especially at sunset.'
      },
      {
        id: 'mattancherry-palace',
        name: 'Mattancherry Palace (Dutch Palace)',
        shortName: 'Mattancherry Palace',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 520, y: 350 },
        baseVisitors: 3200,
        capacity: 1400,
        dwellTimeMinutes: 60,
        culturalScore: 96,
        localImpactINR: 150,
        status: 'critical',
        description: '16th-century palace built by Portuguese and renovated by Dutch, housing exquisite Ramayana murals.',
        reason: 'Single-file wooden staircases create slow queues between 10:00 and 13:00.'
      },
      {
        id: 'jew-town-synagogue',
        name: 'Paradesi Synagogue & Jew Town',
        shortName: 'Jew Town & Synagogue',
        category: 'culture',
        type: 'hotspot',
        coords: { x: 550, y: 390 },
        baseVisitors: 2900,
        capacity: 1200,
        dwellTimeMinutes: 55,
        culturalScore: 95,
        localImpactINR: 550,
        status: 'elevated',
        description: '1568 Jewish synagogue with hand-painted Chinese willow tiles and historic antique shops.',
        reason: 'Narrow Synagogue Lane fills up with auto-rickshaws and souvenir shoppers.'
      },
      {
        id: 'dhobi-khana',
        name: 'Dhobi Khana Heritage Laundry Enclave',
        shortName: 'Dhobi Khana',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 390, y: 320 },
        baseVisitors: 210,
        capacity: 600,
        dwellTimeMinutes: 40,
        culturalScore: 94,
        localImpactINR: 350,
        status: 'optimal',
        description: 'Historic settlement of the Vannan community who iron with heavy brass irons filled with burning coconut charcoal.',
        reason: 'Zero queues; authentic living heritage community with welcoming artisans.'
      },
      {
        id: 'kumbalangi-craft',
        name: 'Kumbalangi Integrated Rural Craft Village',
        shortName: 'Kumbalangi Craft Village',
        category: 'rural',
        type: 'surrogate',
        coords: { x: 620, y: 520 },
        baseVisitors: 340,
        capacity: 1200,
        dwellTimeMinutes: 90,
        culturalScore: 97,
        localImpactINR: 850,
        status: 'optimal',
        description: 'India’s first designated ecotourism village showcasing coir yarn spinning, crab farming, and backwater canoe trails.',
        reason: 'Magnificent backwater tranquility; 100% direct community tourism benefits.'
      },
      {
        id: 'spice-bazaar-road',
        name: 'Bazaar Road Historic Spice Warehouses',
        shortName: 'Bazaar Road Spices',
        category: 'markets',
        type: 'surrogate',
        coords: { x: 480, y: 290 },
        baseVisitors: 450,
        capacity: 1500,
        dwellTimeMinutes: 45,
        culturalScore: 93,
        localImpactINR: 620,
        status: 'optimal',
        description: '2km ancient trading street lined with Dutch and British era warehouses sorting black pepper, dry ginger, and nutmeg.',
        reason: 'Authentic wholesale spice trading away from tourist boutique markups.'
      }
    ],
    segments: [
      {
        id: 'nets-mattancherry',
        name: 'Fishing Nets ➔ Mattancherry Palace Bus Run',
        fromNodeId: 'chinese-fishing-nets',
        toNodeId: 'mattancherry-palace',
        mode: 'current',
        flowType: 'visitors',
        categories: ['heritage'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 450,
          '10:00': 1950,
          '12:00': 1680,
          '14:00': 1350,
          '16:00': 1750,
          '18:00': 1200,
          '20:00': 420
        },
        dwellTime: '45m',
        peakPeriod: '09:30 — 12:30',
        touristPct: 86,
        localPct: 14,
        whyHappening: 'Tour coaches move bulk passenger groups between Fort Kochi beach and Mattancherry parking lot, causing street bottlenecks.',
        roamOpportunity: 'REDIRECT 28% OF FLOW: Route morning travelers through Dhobi Khana and Bazaar Road spice warehouses first.',
        surrogates: ['dhobi-khana', 'kumbalangi-craft', 'spice-bazaar-road']
      },
      {
        id: 'nets-dhobikhana',
        name: 'Fishing Nets ➔ Dhobi Khana Heritage Enclave',
        fromNodeId: 'chinese-fishing-nets',
        toNodeId: 'dhobi-khana',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 180,
          '10:00': 360,
          '12:00': 420,
          '14:00': 390,
          '16:00': 410,
          '18:00': 280,
          '20:00': 110
        },
        dwellTime: '40m',
        peakPeriod: '10:00 — 14:00',
        touristPct: 45,
        localPct: 55,
        whyHappening: 'ROAM diverts foot traffic into shaded community quarters where traditional laundry artisans work.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Peaceful walking trail, zero ticket friction, high cultural storytelling value.',
        surrogates: ['spice-bazaar-road', 'kumbalangi-craft']
      },
      {
        id: 'dhobikhana-spiceroad',
        name: 'Dhobi Khana ➔ Bazaar Road Spice Warehouses',
        fromNodeId: 'dhobi-khana',
        toNodeId: 'spice-bazaar-road',
        mode: 'optimized',
        flowType: 'both',
        categories: ['markets', 'food'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 140,
          '10:00': 310,
          '12:00': 480,
          '14:00': 420,
          '16:00': 450,
          '18:00': 320,
          '20:00': 160
        },
        dwellTime: '45m',
        peakPeriod: '11:30 — 15:30',
        touristPct: 50,
        localPct: 50,
        whyHappening: 'Traders sort cardamom and ginger in 200-year-old wooden gables along the waterfront.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Direct spice purchases at honest wholesale prices with zero commercial gimmicks.',
        surrogates: ['kumbalangi-craft', 'mattancherry-palace']
      },
      {
        id: 'spiceroad-kumbalangi',
        name: 'Bazaar Road ➔ Kumbalangi Mangrove Craft Village',
        fromNodeId: 'spice-bazaar-road',
        toNodeId: 'kumbalangi-craft',
        mode: 'optimized',
        flowType: 'visitors',
        categories: ['rural', 'nature'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 90,
          '10:00': 240,
          '12:00': 280,
          '14:00': 340,
          '16:00': 420,
          '18:00': 310,
          '20:00': 80
        },
        dwellTime: '90m',
        peakPeriod: '14:30 — 17:30',
        touristPct: 60,
        localPct: 40,
        whyHappening: 'Escape city traffic for traditional country canoe rides, coir spinning, and organic backwater seafood.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Disperses tourists into rural Kerala while ensuring eco-responsible community revenues.',
        surrogates: ['chinese-fishing-nets', 'jew-town-synagogue']
      }
    ]
  },

  leh: {
    destinationId: 'leh',
    city: 'Leh',
    state: 'Ladakh',
    regionTag: 'Trans-Himalayan Buddhist Silk Route',
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 75,
      optimizedConcentration: 45,
      bottleneckReductionPct: 30,
      underVisitedGainPct: 35,
      artisanRevenueGainPct: 25,
      culturalDiscoveryPct: 38,
      alertPrompt: {
        message: 'Shanti Stupa & Leh Palace corridors experiencing high sunset congestion. ROAM recommends Stok Royal Village & Alchi Choskor.',
        targetSegmentId: 'palace-shanti',
        targetAlternativeId: 'stok-village'
      }
    },
    timeProfiles: {
      '08:00': {
        label: 'Dawn Monastic Chants & Morning Puja',
        headline: 'Early morning butter lamps and resonant horn calls',
        summary: 'Thiksey and Hemis morning prayers. Crisp Himalayan morning air; high acclimatization rest period.',
        avgCityLoadPct: 32
      },
      '10:00': {
        label: 'Leh Palace & Old Town Heritage Trail',
        headline: 'Visitors climbing historic mud-brick staircase alleys',
        summary: 'Footfall at 9-story Leh Palace. Old Town LAMO heritage arts center hosting traditional Ladakhi exhibits.',
        avgCityLoadPct: 78
      },
      '12:00': {
        label: 'Midday Apricot & Thukpa Courtyards',
        headline: 'Garden cafes serving seabuckthorn juice and momos',
        summary: 'Shaded courtyard cafes in Changspa and Main Bazaar serving authentic herbal teas and barley tsampa.',
        avgCityLoadPct: 65
      },
      '14:00': {
        label: 'Stok Palace & Traditional Farmstead Trail',
        headline: 'Royal museum and organic village farm walks in Stok',
        summary: 'Stok royal residence and Choglamsar Tibetan craft workshops operating with peaceful mountain views.',
        avgCityLoadPct: 50
      },
      '16:00': {
        label: 'Afternoon Monastery Architecture Stroll',
        headline: 'Shey Palace fish pond and ancient Kashmiri-Tibetan murals',
        summary: 'Alchi and Shey monasteries bathed in clear mountain light; zero tourist crowding.',
        avgCityLoadPct: 62
      },
      '18:00': {
        label: 'Shanti Stupa Sunset Surge',
        headline: 'Vehicular gridlock on Shanti Stupa hill road',
        summary: 'Hundreds gathering at white-domed stupa for panoramic sunset across Zanskar range.',
        avgCityLoadPct: 92
      },
      '20:00': {
        label: 'Leh Main Bazaar Pedestrian Evening',
        headline: 'Stargazing, Tibetan singing bowls and warm soups',
        summary: 'Leh Main Bazaar pedestrian plaza filled with night walkers, pashmina artisans, and apricot vendors.',
        avgCityLoadPct: 58
      }
    },
    nodes: [
      {
        id: 'leh-palace',
        name: 'Leh Palace & Tsemo Fort',
        shortName: 'Leh Palace',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 440, y: 240 },
        baseVisitors: 2800,
        capacity: 1200,
        dwellTimeMinutes: 70,
        culturalScore: 98,
        localImpactINR: 150,
        status: 'critical',
        description: '17th-century 9-story mud-brick palace built by King Sengge Namgyal offering views of the Indus Valley.',
        reason: 'Steep narrow entry ramps and parking bottleneck in Old Leh.'
      },
      {
        id: 'shanti-stupa',
        name: 'Shanti Stupa Viewpoint',
        shortName: 'Shanti Stupa',
        category: 'spiritual',
        type: 'hotspot',
        coords: { x: 380, y: 190 },
        baseVisitors: 3200,
        capacity: 1400,
        dwellTimeMinutes: 60,
        culturalScore: 94,
        localImpactINR: 120,
        status: 'critical',
        description: 'White-domed Buddhist stupa atop Changspa hill holding relics of the Buddha consecrated by 14th Dalai Lama.',
        reason: 'Massive sunset vehicle congestion along the 500-step staircase between 17:30 and 19:00.'
      },
      {
        id: 'stok-village',
        name: 'Stok Royal Village & Heritage Farmstead',
        shortName: 'Stok Village',
        category: 'rural',
        type: 'surrogate',
        coords: { x: 520, y: 440 },
        baseVisitors: 260,
        capacity: 900,
        dwellTimeMinutes: 80,
        culturalScore: 97,
        localImpactINR: 680,
        status: 'optimal',
        description: 'Living royal village across the Indus with 200-year-old mud farmsteads, barley fields, and royal crown jewels museum.',
        reason: 'Absolute Himalayan serenity, organic farm-to-table meals, 0% crowd friction.'
      },
      {
        id: 'alchi-choskor',
        name: 'Alchi Choskor Ancient Temple Enclave',
        shortName: 'Alchi Monastery',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 230, y: 310 },
        baseVisitors: 290,
        capacity: 800,
        dwellTimeMinutes: 75,
        culturalScore: 99,
        localImpactINR: 420,
        status: 'optimal',
        description: '11th-century monastic complex renowned for exquisite Kashmiri-style Buddhist wood carvings and miniature frescoes.',
        reason: 'Rare pre-Tibetan artistic style nestled in an apricot orchard village along the Indus River.'
      },
      {
        id: 'choglamsar-crafts',
        name: 'Choglamsar Tibetan Carpet & Woodcarving Guild',
        shortName: 'Choglamsar Crafts',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 490, y: 360 },
        baseVisitors: 210,
        capacity: 600,
        dwellTimeMinutes: 50,
        culturalScore: 95,
        localImpactINR: 920,
        status: 'optimal',
        description: 'Artisan training center for authentic Tibetan hand-knotted wool rugs, thangka scroll painting, and wooden folding tables.',
        reason: 'Direct artisan purchase at genuine cooperative prices.'
      }
    ],
    segments: [
      {
        id: 'palace-shanti',
        name: 'Leh Palace ➔ Shanti Stupa Sunset Axis',
        fromNodeId: 'leh-palace',
        toNodeId: 'shanti-stupa',
        mode: 'current',
        flowType: 'visitors',
        categories: ['heritage', 'spiritual'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 310,
          '10:00': 1420,
          '12:00': 1100,
          '14:00': 950,
          '16:00': 1650,
          '18:00': 2400,
          '20:00': 780
        },
        dwellTime: '45m',
        peakPeriod: '16:30 — 19:00',
        touristPct: 88,
        localPct: 12,
        whyHappening: 'Nearly all tourist cabs drive the exact same circuit between Leh Palace and Shanti Stupa during golden hour.',
        roamOpportunity: 'REDIRECT 30% OF FLOW: Redirect sunset travelers across the Indus bridge to Stok Royal Village for quiet Himalayan views.',
        surrogates: ['stok-village', 'alchi-choskor', 'choglamsar-crafts']
      },
      {
        id: 'palace-stok',
        name: 'Leh Palace ➔ Stok Royal Village & Farmstead',
        fromNodeId: 'leh-palace',
        toNodeId: 'stok-village',
        mode: 'optimized',
        flowType: 'both',
        categories: ['rural', 'culture'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 120,
          '10:00': 280,
          '12:00': 340,
          '14:00': 390,
          '16:00': 420,
          '18:00': 360,
          '20:00': 110
        },
        dwellTime: '80m',
        peakPeriod: '13:00 — 17:30',
        touristPct: 55,
        localPct: 45,
        whyHappening: 'Crosses the Indus River into pristine willow and poplar groves with views of Stok Kangri peak.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: 97/100 cultural DNA; supports rural heritage conservation and homestays.',
        surrogates: ['alchi-choskor', 'choglamsar-crafts']
      },
      {
        id: 'stok-choglamsar',
        name: 'Stok Village ➔ Choglamsar Tibetan Carpet Guild',
        fromNodeId: 'stok-village',
        toNodeId: 'choglamsar-crafts',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'markets'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 90,
          '10:00': 220,
          '12:00': 270,
          '14:00': 310,
          '16:00': 340,
          '18:00': 210,
          '20:00': 80
        },
        dwellTime: '50m',
        peakPeriod: '11:00 — 15:00',
        touristPct: 50,
        localPct: 50,
        whyHappening: 'Direct access to authentic master wool weavers and wooden handicraft guilds.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: High artisan revenue capture; zero commercial middleman fees.',
        surrogates: ['alchi-choskor', 'leh-palace']
      }
    ]
  },

  delhi: {
    destinationId: 'delhi',
    city: 'Delhi',
    state: 'Delhi NCR',
    regionTag: 'Yamuna Plains & 7 Historical Cities',
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 77,
      optimizedConcentration: 45,
      bottleneckReductionPct: 32,
      underVisitedGainPct: 37,
      artisanRevenueGainPct: 27,
      culturalDiscoveryPct: 39,
      alertPrompt: {
        message: 'Red Fort & Chandni Chowk corridors at peak load (92%). ROAM suggests Mehrauli Archeological Forest & Nizamuddin Sufi Basti.',
        targetSegmentId: 'redfort-chandni',
        targetAlternativeId: 'mehrauli-forest'
      }
    },
    timeProfiles: {
      '08:00': {
        label: 'Dawn Heritage Stroll & Jama Masjid Peace',
        headline: 'Early morning birdsong over sandstone minarets and gardens',
        summary: 'Lodhi Garden walkers and Jama Masjid early prayer quietness. Best time for heritage photography.',
        avgCityLoadPct: 30
      },
      '10:00': {
        label: 'Red Fort & Qutub Minar Peak Gates',
        headline: 'Heavy tourist coach arrivals at Lahori Gate and Qutub complex',
        summary: 'Long ticket and security queues at primary Mughal monuments. Chandni Chowk main road bustling with cycle rickshaws.',
        avgCityLoadPct: 88
      },
      '12:00': {
        label: 'Midday Old Delhi Paranthe & Nihari Trail',
        headline: 'Visitors crowding into legendary Paranthe Wali Gali and Matia Mahal',
        summary: 'Scent of bubbling ghee and slow-cooked spices in Old Delhi food alleys. Sunder Nursery offers shaded Mughal pavilion dining.',
        avgCityLoadPct: 76
      },
      '14:00': {
        label: 'Mehrauli Archaeological Forest & Sufi Baolis',
        headline: 'Shaded 200-acre medieval heritage park with 100+ hidden monuments',
        summary: 'Mehrauli Forest and Jamali Kamali tomb with zero visitor queues. Nizamuddin Basti craft guild active.',
        avgCityLoadPct: 50
      },
      '16:00': {
        label: 'Humayun Tomb Golden Hour & Craft Markets',
        headline: 'Mughal charbagh water channels reflecting soft afternoon sun',
        summary: 'Humayun’s Tomb gardens at golden hour; Dilli Haat artisan stalls welcoming evening craft enthusiasts.',
        avgCityLoadPct: 72
      },
      '18:00': {
        label: 'India Gate & Kartavya Path Sunset Promenade',
        headline: 'Massive evening public gathering along illuminated lawns',
        summary: 'Kartavya Path and India Gate lawns filled with ice cream vendors and families enjoying the breeze.',
        avgCityLoadPct: 92
      },
      '20:00': {
        label: 'Night Sufi Qawwali & Kebab Feasts',
        headline: 'Nizamuddin Dargah soul-stirring qawwalis and Old Delhi night street food',
        summary: 'Qawwali recitals in Nizamuddin courtyard; illuminated facades across Central Vista.',
        avgCityLoadPct: 66
      }
    },
    nodes: [
      {
        id: 'red-fort',
        name: 'Red Fort (Lal Qila)',
        shortName: 'Red Fort',
        category: 'heritage',
        type: 'hotspot',
        coords: { x: 480, y: 220 },
        baseVisitors: 5800,
        capacity: 2500,
        dwellTimeMinutes: 90,
        culturalScore: 99,
        localImpactINR: 160,
        status: 'critical',
        description: 'Massive 17th-century red sandstone fortress palace built by Mughal Emperor Shah Jahan.',
        reason: 'Lahori Gate security line often exceeds 45 minutes on mornings and weekends.'
      },
      {
        id: 'chandni-chowk',
        name: 'Chandni Chowk Main Bazaar & Paranthe Gali',
        shortName: 'Chandni Chowk',
        category: 'markets',
        type: 'hotspot',
        coords: { x: 440, y: 200 },
        baseVisitors: 6400,
        capacity: 3000,
        dwellTimeMinutes: 75,
        culturalScore: 96,
        localImpactINR: 520,
        status: 'critical',
        description: 'Historic 17th-century marketplace known for spices at Khari Baoli, jewelry at Dariba Kalan, and street delicacies.',
        reason: 'Extreme pedestrian and rickshaw crowding in central corridor.'
      },
      {
        id: 'mehrauli-forest',
        name: 'Mehrauli Archaeological Park & Forest',
        shortName: 'Mehrauli Park',
        category: 'heritage',
        type: 'surrogate',
        coords: { x: 360, y: 520 },
        baseVisitors: 320,
        capacity: 2500,
        dwellTimeMinutes: 85,
        culturalScore: 98,
        localImpactINR: 280,
        status: 'optimal',
        description: '200-acre peaceful forested archaeological park holding over 100 historical monuments dating from 1060 AD.',
        reason: 'Adjacent to crowded Qutub Minar but virtually empty; stunning stepwells and medieval tombs in nature.'
      },
      {
        id: 'nizamuddin-basti',
        name: 'Nizamuddin Basti & Sufi Baoli',
        shortName: 'Nizamuddin Basti',
        category: 'culture',
        type: 'surrogate',
        coords: { x: 490, y: 360 },
        baseVisitors: 480,
        capacity: 1200,
        dwellTimeMinutes: 65,
        culturalScore: 97,
        localImpactINR: 490,
        status: 'optimal',
        description: '700-year-old living medieval Sufi settlement with Amir Khusro tomb, historic stepwell, and generational attar perfumers.',
        reason: 'Living musical and culinary heritage with direct local community economic support.'
      },
      {
        id: 'sunder-nursery',
        name: 'Sunder Nursery Heritage Mughal Gardens',
        shortName: 'Sunder Nursery',
        category: 'nature',
        type: 'surrogate',
        coords: { x: 520, y: 380 },
        baseVisitors: 750,
        capacity: 3500,
        dwellTimeMinutes: 90,
        culturalScore: 94,
        localImpactINR: 350,
        status: 'optimal',
        description: '90-acre restored UNESCO-recognized heritage park containing 15 Mughal monuments, water cascades, and nursery gardens.',
        reason: 'Spacious lawns, tranquil lake, artisanal weekend farmers market, zero crowding friction.'
      }
    ],
    segments: [
      {
        id: 'redfort-chandni',
        name: 'Red Fort ➔ Chandni Chowk Express Corridor',
        fromNodeId: 'red-fort',
        toNodeId: 'chandni-chowk',
        mode: 'current',
        flowType: 'visitors',
        categories: ['heritage', 'markets'],
        densityState: 'overloaded',
        hourlyFlow: {
          '08:00': 620,
          '10:00': 2850,
          '12:00': 2400,
          '14:00': 1950,
          '16:00': 2700,
          '18:00': 3100,
          '20:00': 1400
        },
        dwellTime: '55m',
        peakPeriod: '10:00 — 13:30 & 16:30 — 19:30',
        touristPct: 85,
        localPct: 15,
        whyHappening: 'Standard tour groups walk directly from Red Fort parking into Chandni Chowk pedestrian avenue, creating dense crowd bottlenecks.',
        roamOpportunity: 'REDIRECT 32% OF FLOW: Route travelers to Sunder Nursery gardens and Nizamuddin Sufi settlement, cutting queue times by 40 minutes.',
        surrogates: ['mehrauli-forest', 'sunder-nursery', 'nizamuddin-basti']
      },
      {
        id: 'redfort-sundernursery',
        name: 'Red Fort ➔ Sunder Nursery Heritage Park',
        fromNodeId: 'red-fort',
        toNodeId: 'sunder-nursery',
        mode: 'optimized',
        flowType: 'both',
        categories: ['nature', 'heritage'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 210,
          '10:00': 480,
          '12:00': 620,
          '14:00': 580,
          '16:00': 720,
          '18:00': 550,
          '20:00': 240
        },
        dwellTime: '75m',
        peakPeriod: '11:00 — 16:00',
        touristPct: 52,
        localPct: 48,
        whyHappening: 'Serene 90-acre Mughal charbagh garden with restored tombs and flowing water channels.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Bypasses heavy street gridlock; outstanding ecological and historical restoration.',
        surrogates: ['nizamuddin-basti', 'mehrauli-forest']
      },
      {
        id: 'sundernursery-nizamuddin',
        name: 'Sunder Nursery ➔ Nizamuddin Basti & Baoli',
        fromNodeId: 'sunder-nursery',
        toNodeId: 'nizamuddin-basti',
        mode: 'optimized',
        flowType: 'both',
        categories: ['culture', 'spiritual'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 150,
          '10:00': 340,
          '12:00': 410,
          '14:00': 450,
          '16:00': 520,
          '18:00': 640,
          '20:00': 480
        },
        dwellTime: '65m',
        peakPeriod: '16:00 — 20:30',
        touristPct: 45,
        localPct: 55,
        whyHappening: 'Just across the road from Sunder Nursery, visitors experience 700 years of living Sufi poetry, artisanal attar, and kebabs.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: 97/100 cultural DNA match; direct community economic inclusion.',
        surrogates: ['mehrauli-forest', 'chandni-chowk']
      },
      {
        id: 'nizamuddin-mehrauli',
        name: 'Nizamuddin ➔ Mehrauli Forest Archaeological Trail',
        fromNodeId: 'nizamuddin-basti',
        toNodeId: 'mehrauli-forest',
        mode: 'optimized',
        flowType: 'visitors',
        categories: ['heritage', 'nature'],
        densityState: 'low',
        hourlyFlow: {
          '08:00': 110,
          '10:00': 260,
          '12:00': 310,
          '14:00': 380,
          '16:00': 440,
          '18:00': 280,
          '20:00': 90
        },
        dwellTime: '85m',
        peakPeriod: '13:30 — 17:00',
        touristPct: 48,
        localPct: 52,
        whyHappening: 'Escape monument ticket lines into 200 acres of tranquil forested ruins from Delhi’s earliest Sultanate eras.',
        roamOpportunity: 'ACTIVE OPTIMIZATION: Zero ticket queue; extraordinary medieval stepwells, tombs, and forest paths.',
        surrogates: ['sunder-nursery', 'red-fort']
      }
    ]
  }
};

/**
 * Universal Dynamic Generator:
 * Automatically builds high-fidelity visitor flow networks for ANY Indian destination or rural district
 */
export function generateVisitorFlowForLocation(loc) {
  if (!loc) return VISITOR_FLOW_REGISTRY.jaipur;

  const locId = (loc.id || loc.name || '').toLowerCase().replace(/[^a-z0-9]/g, '-');
  if (VISITOR_FLOW_REGISTRY[locId]) {
    return VISITOR_FLOW_REGISTRY[locId];
  }

  const city = loc.name || 'Regional Destination';
  const state = loc.state || 'India';
  const regionTag = loc.culturalRegion || `${state} Cultural Corridor`;
  const attractions = Array.isArray(loc.attractions) && loc.attractions.length > 0 ? loc.attractions : [];

  // Generate 6-8 nodes from attractions & cultural DNA
  const nodes = [];
  const coordsList = [
    { x: 440, y: 220 }, // Node 0: Top-Center
    { x: 550, y: 310 }, // Node 1: East-Center
    { x: 480, y: 460 }, // Node 2: South-East
    { x: 330, y: 410 }, // Node 3: South-West
    { x: 270, y: 260 }, // Node 4: West-Center
    { x: 380, y: 140 }, // Node 5: North-West
    { x: 620, y: 190 }  // Node 6: North-East
  ];

  if (attractions.length > 0) {
    attractions.slice(0, 7).forEach((att, idx) => {
      const isCritical = att.status === 'critical' || idx === 0 || idx === 1;
      const isOptimal = att.status === 'optimal' || idx >= 3;
      const c = coordsList[idx] || { x: 300 + idx * 50, y: 200 + idx * 40 };

      nodes.push({
        id: att.id || `node-${idx}`,
        name: att.name,
        shortName: att.name.length > 18 ? att.name.substring(0, 16) + '…' : att.name,
        category: att.category || (idx === 2 ? 'markets' : (idx === 3 ? 'food' : 'heritage')),
        type: isCritical ? 'hotspot' : (isOptimal ? 'surrogate' : 'corridor'),
        coords: c,
        baseVisitors: isCritical ? 2800 : (isOptimal ? 450 : 1200),
        capacity: isCritical ? 1400 : 1800,
        dwellTimeMinutes: att.averageVisitMinutes || 60,
        culturalScore: 90 + (idx % 8),
        localImpactINR: 200 + (idx * 110),
        status: isCritical ? 'critical' : (isOptimal ? 'optimal' : 'elevated'),
        description: att.description || `Historic landmark celebrating the living heritage of ${city}.`,
        reason: isCritical
          ? `Primary landmark experiencing heavy morning tour arrivals and queue bottlenecks.`
          : `Tranquil surrogate with rich local culture, zero waiting time, and direct artisan impact.`
      });
    });
  } else {
    // Dynamic generation from city name
    const defaultPlaces = [
      { name: `${city} Heritage Monument`, cat: 'heritage', isCrit: true },
      { name: `${city} Central Bazaar & Crafts`, cat: 'markets', isCrit: true },
      { name: `Old ${city} Traditional Food Gali`, cat: 'food', isCrit: false },
      { name: `${city} Artisan Guild & Weavers`, cat: 'culture', isCrit: false },
      { name: `${city} Riverfront / Nature Trail`, cat: 'nature', isCrit: false },
      { name: `Rural ${city} Craft Village`, cat: 'rural', isCrit: false }
    ];

    defaultPlaces.forEach((p, idx) => {
      const c = coordsList[idx] || { x: 300 + idx * 50, y: 200 + idx * 40 };
      nodes.push({
        id: `node-${idx}`,
        name: p.name,
        shortName: p.name,
        category: p.cat,
        type: p.isCrit ? 'hotspot' : 'surrogate',
        coords: c,
        baseVisitors: p.isCrit ? 2600 : 380,
        capacity: 1500,
        dwellTimeMinutes: 50,
        culturalScore: 92 + idx,
        localImpactINR: 300 + idx * 100,
        status: p.isCrit ? 'critical' : 'optimal',
        description: `Historic cultural destination in ${city}, ${state}.`,
        reason: p.isCrit ? 'Primary destination bottleneck corridor.' : 'Authentic uncrowded local experience.'
      });
    });
  }

  // Create segments linking nodes
  const segments = [];
  if (nodes.length >= 3) {
    // Current bottleneck segment (Node 0 -> Node 1)
    segments.push({
      id: `current-seg-main`,
      name: `${nodes[0].name} ➔ ${nodes[1].name} Corridor`,
      fromNodeId: nodes[0].id,
      toNodeId: nodes[1].id,
      mode: 'current',
      flowType: 'visitors',
      categories: ['heritage'],
      densityState: 'overloaded',
      hourlyFlow: {
        '08:00': 410,
        '10:00': 1850,
        '12:00': 1620,
        '14:00': 1300,
        '16:00': 1550,
        '18:00': 1420,
        '20:00': 620
      },
      dwellTime: '45m',
      peakPeriod: '10:00 — 12:30',
      touristPct: 84,
      localPct: 16,
      whyHappening: `78% of incoming tourist vehicles follow the linear route between ${nodes[0].name} and ${nodes[1].name}, skipping adjoining cultural quarters.`,
      roamOpportunity: `REDIRECT 25% OF FLOW: Divert 350 visitors/hr via ${nodes[2]?.name || 'the heritage craft lane'}, reducing bottleneck line by 24m.`,
      surrogates: nodes.slice(2, 5).map(n => n.id)
    });

    // ROAM Optimized corridor segments
    for (let i = 0; i < nodes.length - 1; i++) {
      const from = nodes[i];
      const to = nodes[(i + 2) % nodes.length];
      if (from.id !== to.id) {
        segments.push({
          id: `opt-seg-${i}`,
          name: `${from.shortName} ➔ ${to.shortName} Cultural Path`,
          fromNodeId: from.id,
          toNodeId: to.id,
          mode: 'optimized',
          flowType: 'both',
          categories: [to.category || 'culture'],
          densityState: 'low',
          hourlyFlow: {
            '08:00': 150 + i * 20,
            '10:00': 320 + i * 30,
            '12:00': 410 + i * 25,
            '14:00': 390 + i * 20,
            '16:00': 440 + i * 30,
            '18:00': 360 + i * 25,
            '20:00': 180 + i * 15
          },
          dwellTime: '40m',
          peakPeriod: '11:00 — 16:00',
          touristPct: 48,
          localPct: 52,
          whyHappening: `ROAM distributes visitors through local food, craft, and tranquil heritage corridors.`,
          roamOpportunity: `ACTIVE OPTIMIZATION: Balances footfall across ${city} while supporting local family businesses.`,
          surrogates: [to.id]
        });
      }
    }
  }

  return {
    destinationId: locId,
    city: city,
    state: state,
    regionTag: regionTag,
    defaultTime: '10:00',
    metrics: {
      currentConcentration: 75,
      optimizedConcentration: 46,
      bottleneckReductionPct: 29,
      underVisitedGainPct: 36,
      artisanRevenueGainPct: 26,
      culturalDiscoveryPct: 38,
      alertPrompt: {
        message: `${nodes[0]?.name || city} is experiencing peak morning congestion. ROAM recommends distributing via ${nodes[2]?.name || 'the artisan corridor'}.`,
        targetSegmentId: segments[0]?.id || '',
        targetAlternativeId: nodes[2]?.id || ''
      }
    },
    timeProfiles: {
      '08:00': {
        label: `Morning Tranquility in ${city}`,
        headline: `Early morning quietness across ${city}`,
        summary: `Temples, riverfronts, and local walking trails active before primary tour arrivals.`,
        avgCityLoadPct: 30
      },
      '10:00': {
        label: `Peak Monument & Sightseeing Surge`,
        headline: `High congestion at primary attractions in ${city}`,
        summary: `Peak vehicular and pedestrian lines at main entrance gates.`,
        avgCityLoadPct: 86
      },
      '12:00': {
        label: `Midday Traditional Culinary Hours`,
        headline: `Visitors exploring local food lanes and indoor courtyards`,
        summary: `Traditional regional eateries and covered bazaar arcades bustling with lunch patrons.`,
        avgCityLoadPct: 70
      },
      '14:00': {
        label: `Afternoon Artisan & Museum Discovery`,
        headline: `Quiet artisan quarters and heritage galleries`,
        summary: `Master craft guilds operating with minimal queue friction.`,
        avgCityLoadPct: 54
      },
      '16:00': {
        label: `Afternoon Golden Hour & Viewpoints`,
        headline: `Heritage architecture and scenic viewpoints active`,
        summary: `Pleasant sunlight on historic facades; footfall climbing in bazaars.`,
        avgCityLoadPct: 74
      },
      '18:00': {
        label: `Evening Sunset & Market Rush`,
        headline: `Bazaars and sunset viewpoints at peak energy`,
        summary: `Local markets buzzing with shoppers, street food stalls, and evening strollers.`,
        avgCityLoadPct: 90
      },
      '20:00': {
        label: `Night Illuminations & Dining`,
        headline: `Illuminated monuments and dinner courtyards`,
        summary: `Cool evening breeze; heritage dining and cultural performances.`,
        avgCityLoadPct: 62
      }
    },
    nodes: nodes,
    segments: segments
  };
}

/**
 * Helper to fetch visitor flow data for any destination by ID or location object
 */
export function getVisitorFlowData(locationOrId) {
  if (!locationOrId) return VISITOR_FLOW_REGISTRY.jaipur;

  if (typeof locationOrId === 'string') {
    const key = locationOrId.toLowerCase().replace(/[^a-z0-9]/g, '-');
    if (VISITOR_FLOW_REGISTRY[key]) {
      return VISITOR_FLOW_REGISTRY[key];
    }
    return generateVisitorFlowForLocation({ id: key, name: locationOrId });
  }

  const locId = (locationOrId.id || locationOrId.name || '').toLowerCase();
  if (VISITOR_FLOW_REGISTRY[locId]) {
    return VISITOR_FLOW_REGISTRY[locId];
  }

  return generateVisitorFlowForLocation(locationOrId);
}
