/**
 * ROAM Centralized Travel Planning Reactive State (V3.5)
 * Single Source of Truth connecting:
 * PLAN + CROWD FORECAST + MARKET + MAP + ROAM AI + JOURNEY MOOD + MEMORIES
 *
 * Manages:
 * - currentLocation (28 States & 8 UTs across India)
 * - selectedDate ('today', 'tomorrow', 'your_day')
 * - userInterests (Set: 'food', 'shopping', 'history', 'architecture', 'culture', 'nature', 'local_life', 'relaxed')
 * - journeyMood (7-point preference spectrum)
 * - activeRoute ('all', 'local', 'food', 'craft', 'hidden', 'slow', 'night', 'photo', 'budget')
 * - itinerary (array of sequential stops with dynamic start times, transit, crowds, status)
 * - focusedItemId (ID of item whose crowd curve & map node are highlighted)
 * - dayHealth (BALANCED | TOO CROWDED | TOO MUCH TRAVEL | GOOD FLOW with actionable reasoning)
 * - openSlots (free gaps >= 60m between stops)
 * - tripMemories (Journal entries & saved travel moments)
 * - rightNowTelemetry (Simulated real-time live pulse)
 * - dynamic recommendations & "What Should I Do Next?"
 */

import { formatIndianNumber } from '../utils/formatters.js';

class TravelStateManager {
  constructor() {
    this.location = null;
    this.selectedDate = 'today';
    this.userInterests = new Set(['history', 'culture', 'shopping', 'food']);
    
    // Journey Mood Matrix (7 continuous spectrums 0-100)
    this.journeyMood = {
      chaosCalm: 65,            // 0: Maximum Rush -> 100: Deep Peace
      touristLocal: 85,         // 0: Famous Icons -> 100: Deep Local Guilds
      fastSlow: 45,             // 0: Action-Packed -> 100: Unhurried Chai Pace
      luxuryRaw: 30,            // 0: Royal Heritage Palaces -> 100: Raw Street Authenticity
      spontaneousPlanned: 60,   // 0: Pure Spontaneity -> 100: Meticulous Flow
      cultureAdventure: 75,     // 0: Nature/Adventure -> 100: Living Arts & Heritage
      foodHistory: 50           // 0: Culinary Focused -> 100: Ancient History
    };

    // Active ROAM Thematic Lens
    this.activeRoute = 'all'; // 'all' | 'local' | 'food' | 'craft' | 'hidden' | 'slow' | 'night' | 'photo' | 'budget'

    this.itinerary = [];
    this.focusedItemId = null;
    this.dayHealth = {
      status: 'BALANCED',
      label: '● BALANCED',
      headline: 'Schedule is Well-Paced',
      description: 'Stops are planned during optimal hours with smooth transit and low queue fatigue.',
      color: '#10b981',
      fixAction: null
    };
    this.openSlots = [];
    this.tripMemories = [];
    this.subscribers = [];
  }

  // --- Subscription Management ---
  subscribe(fn) {
    this.subscribers.push(fn);
    return () => {
      this.subscribers = this.subscribers.filter(sub => sub !== fn);
    };
  }

  notify(event, data = {}) {
    this.subscribers.forEach(fn => {
      try {
        fn(event, { state: this, ...data });
      } catch (err) {
        console.error('[TravelState] Subscriber error:', err);
      }
    });
  }

  // --- Location & Schedule Initialization ---
  setLocation(locationData) {
    this.location = locationData;
    this.buildDefaultSchedule();
    this.recalculate();
    this.notify('location:changed', { location: locationData });
  }

  buildDefaultSchedule() {
    if (!this.location) return;
    const city = this.location.id;

    if (city === 'jaipur') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '09:00',
          durationMinutes: 120,
          name: 'Amber Fort',
          category: 'heritage',
          icon: '🏛️',
          expectedVisitors: 420,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet',
          coords: { x: 550, y: 110, lat: 26.9855, lng: 75.8513 }
        },
        {
          id: 'step-2',
          time: '11:45',
          durationMinutes: 60,
          name: 'Rawat Mishthan Bhandar',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 680,
          crowdStatus: 'optimal',
          crowdLabel: 'Fresh & Uncrowded',
          coords: { x: 420, y: 460, lat: 26.9196, lng: 75.7994 }
        },
        {
          id: 'step-3',
          time: '13:15',
          durationMinutes: 90,
          name: 'Albert Hall Museum',
          category: 'culture',
          icon: '🎨',
          expectedVisitors: 310,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet & Cool',
          coords: { x: 480, y: 550, lat: 26.9116, lng: 75.8195 }
        },
        {
          id: 'step-4',
          time: '16:00',
          durationMinutes: 75,
          name: 'Bapu Bazaar Traditional Shopping',
          category: 'shopping',
          icon: '🛍️',
          expectedVisitors: 700,
          crowdStatus: 'optimal',
          crowdLabel: 'Moderate',
          coords: { x: 490, y: 440, lat: 26.9182, lng: 75.8224 }
        },
        {
          id: 'step-5',
          time: '18:00',
          durationMinutes: 90,
          name: 'Sunset at Nahargarh Ramparts',
          category: 'nature',
          icon: '🌅',
          expectedVisitors: 650,
          crowdStatus: 'optimal',
          crowdLabel: 'Golden Hour View',
          coords: { x: 450, y: 280, lat: 26.9388, lng: 75.8183 }
        }
      ];
    } else if (city === 'varanasi') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '06:00',
          durationMinutes: 90,
          name: 'Assi Ghat Sunrise & Rowing Boat',
          category: 'spiritual',
          icon: '🚣',
          expectedVisitors: 320,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Dawn',
          coords: { x: 540, y: 550, lat: 25.2895, lng: 83.0068 }
        },
        {
          id: 'step-2',
          time: '08:00',
          durationMinutes: 60,
          name: 'Morning Hing Kachori in Thatheri Gali',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 450,
          crowdStatus: 'optimal',
          crowdLabel: 'Fresh & Quiet',
          coords: { x: 490, y: 310, lat: 25.3122, lng: 83.0118 }
        },
        {
          id: 'step-3',
          time: '13:30',
          durationMinutes: 90,
          name: 'Kashi Vishwanath Temple Corridor',
          category: 'spiritual',
          icon: '🏛️',
          expectedVisitors: 850,
          crowdStatus: 'optimal',
          crowdLabel: 'Off-Peak Midday',
          coords: { x: 505, y: 320, lat: 25.3109, lng: 83.0107 }
        },
        {
          id: 'step-4',
          time: '15:30',
          durationMinutes: 90,
          name: 'Madanpura Handloom Silk Guild',
          category: 'crafts',
          icon: '🧵',
          expectedVisitors: 280,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Workshop',
          coords: { x: 470, y: 360, lat: 25.3025, lng: 83.0035 }
        },
        {
          id: 'step-5',
          time: '18:00',
          durationMinutes: 90,
          name: 'Ganga Maha Aarti from Riverboat',
          category: 'spiritual',
          icon: '🪔',
          expectedVisitors: 2100,
          crowdStatus: 'critical',
          crowdLabel: 'Very Busy',
          coords: { x: 520, y: 340, lat: 25.3075, lng: 83.0105 }
        }
      ];
    } else if (city === 'mumbai') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '08:00',
          durationMinutes: 90,
          name: 'Marine Drive & Art Deco Promenade',
          category: 'heritage',
          icon: '🌊',
          expectedVisitors: 450,
          crowdStatus: 'optimal',
          crowdLabel: 'Tranquil Morning Breeze',
          coords: { x: 490, y: 440, lat: 18.9432, lng: 72.8235 }
        },
        {
          id: 'step-2',
          time: '10:00',
          durationMinutes: 45,
          name: 'Yazdani Bakery & Irani Chai',
          category: 'food',
          icon: '☕',
          expectedVisitors: 320,
          crowdStatus: 'optimal',
          crowdLabel: 'Fresh Wood-Fired Pav',
          coords: { x: 510, y: 440, lat: 18.9322, lng: 72.8335 }
        },
        {
          id: 'step-3',
          time: '11:15',
          durationMinutes: 90,
          name: 'CSMVS Museum Heritage Galleries',
          category: 'culture',
          icon: '🎨',
          expectedVisitors: 620,
          crowdStatus: 'optimal',
          crowdLabel: 'Cool & Spacious',
          coords: { x: 525, y: 480, lat: 18.9269, lng: 72.8327 }
        },
        {
          id: 'step-4',
          time: '13:15',
          durationMinutes: 60,
          name: 'Britannia & Co. Parsi Heritage Lunch',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 410,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Colonial Hall',
          coords: { x: 530, y: 420, lat: 18.9348, lng: 72.8392 }
        },
        {
          id: 'step-5',
          time: '15:30',
          durationMinutes: 75,
          name: 'Colaba Causeway Bazaars & Curios',
          category: 'shopping',
          icon: '🛍️',
          expectedVisitors: 1250,
          crowdStatus: 'optimal',
          crowdLabel: 'Moderate',
          coords: { x: 530, y: 510, lat: 18.9185, lng: 72.8315 }
        },
        {
          id: 'step-6',
          time: '17:30',
          durationMinutes: 60,
          name: 'Gateway of India Waterfront',
          category: 'heritage',
          icon: '🏛️',
          expectedVisitors: 2800,
          crowdStatus: 'critical',
          crowdLabel: 'Evening Sunset Crowd',
          coords: { x: 540, y: 490, lat: 18.9220, lng: 72.8347 }
        }
      ];
    } else if (city === 'kochi') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '07:30',
          durationMinutes: 75,
          name: 'Fort Kochi Chinese Fishing Nets',
          category: 'heritage',
          icon: '🎣',
          expectedVisitors: 280,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Morning Light',
          coords: { x: 450, y: 320, lat: 9.9675, lng: 76.2415 }
        },
        {
          id: 'step-2',
          time: '09:15',
          durationMinutes: 45,
          name: 'Kashi Art Cafe & Courtyard Coffee',
          category: 'food',
          icon: '☕',
          expectedVisitors: 210,
          crowdStatus: 'optimal',
          crowdLabel: 'Peaceful Oasis',
          coords: { x: 470, y: 340, lat: 9.9652, lng: 76.2432 }
        },
        {
          id: 'step-3',
          time: '10:30',
          durationMinutes: 90,
          name: 'Mattancherry Palace & Jew Town Antiques',
          category: 'culture',
          icon: '🏛️',
          expectedVisitors: 550,
          crowdStatus: 'optimal',
          crowdLabel: 'Pleasant Shaded Walk',
          coords: { x: 560, y: 410, lat: 9.9575, lng: 76.2598 }
        },
        {
          id: 'step-4',
          time: '12:30',
          durationMinutes: 60,
          name: 'Kayees Rahmathulla Malabar Biryani',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 480,
          crowdStatus: 'optimal',
          crowdLabel: 'Fresh Copper Deg Lunch',
          coords: { x: 540, y: 440, lat: 9.9545, lng: 76.2575 }
        },
        {
          id: 'step-5',
          time: '14:30',
          durationMinutes: 60,
          name: 'Bazaar Road Historic Spice Warehouses',
          category: 'shopping',
          icon: '🛍️',
          expectedVisitors: 320,
          crowdStatus: 'optimal',
          crowdLabel: 'Aromatic & Quiet',
          coords: { x: 550, y: 380, lat: 9.9612, lng: 76.2542 }
        },
        {
          id: 'step-6',
          time: '17:00',
          durationMinutes: 90,
          name: 'Kerala Kathakali Centre Sacred Arts',
          category: 'crafts',
          icon: '🎭',
          expectedVisitors: 240,
          crowdStatus: 'optimal',
          crowdLabel: 'Live Mineral Painting',
          coords: { x: 480, y: 360, lat: 9.9645, lng: 76.2448 }
        }
      ];
    } else if (city === 'leh') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '08:00',
          durationMinutes: 60,
          name: 'Sankar Monastery Village & Morning Bakery',
          category: 'food',
          icon: '🍵',
          expectedVisitors: 150,
          crowdStatus: 'optimal',
          crowdLabel: 'Crisp Mountain Dawn',
          coords: { x: 510, y: 240, lat: 34.1755, lng: 77.5892 }
        },
        {
          id: 'step-2',
          time: '09:30',
          durationMinutes: 90,
          name: 'Leh Royal Palace & Tsemo Ridge',
          category: 'heritage',
          icon: '🏛️',
          expectedVisitors: 310,
          crowdStatus: 'optimal',
          crowdLabel: 'Quiet Morning Climb',
          coords: { x: 505, y: 310, lat: 34.1648, lng: 77.5847 }
        },
        {
          id: 'step-3',
          time: '11:30',
          durationMinutes: 60,
          name: 'Lala’s Art Cafe & Old Town Gallery',
          category: 'culture',
          icon: '🎨',
          expectedVisitors: 190,
          crowdStatus: 'optimal',
          crowdLabel: 'Sunny Mudbrick Rooftop',
          coords: { x: 510, y: 320, lat: 34.1662, lng: 77.5855 }
        },
        {
          id: 'step-4',
          time: '13:00',
          durationMinutes: 60,
          name: 'Alchi Kitchen Traditional Buckwheat Stew',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 260,
          crowdStatus: 'optimal',
          crowdLabel: 'Indigenous Tribal Lunch',
          coords: { x: 520, y: 300, lat: 34.1675, lng: 77.5862 }
        },
        {
          id: 'step-5',
          time: '15:00',
          durationMinutes: 60,
          name: 'Changpa Nomadic Pashmina Guild',
          category: 'crafts',
          icon: '🧣',
          expectedVisitors: 180,
          crowdStatus: 'optimal',
          crowdLabel: 'Authentic Handlooms',
          coords: { x: 460, y: 420, lat: 34.1512, lng: 77.5755 }
        },
        {
          id: 'step-6',
          time: '17:30',
          durationMinutes: 75,
          name: 'Shanti Stupa Panoramic Sunset',
          category: 'nature',
          icon: '🌄',
          expectedVisitors: 450,
          crowdStatus: 'optimal',
          crowdLabel: 'Panoramic Karakoram View',
          coords: { x: 420, y: 260, lat: 34.1695, lng: 77.5742 }
        }
      ];
    } else if (city === 'delhi') {
      this.itinerary = [
        {
          id: 'step-1',
          time: '08:00',
          durationMinutes: 90,
          name: 'Humayun’s Tomb Persian Charbagh Gardens',
          category: 'heritage',
          icon: '🏛️',
          expectedVisitors: 510,
          crowdStatus: 'optimal',
          crowdLabel: 'Serene Morning Walk',
          coords: { x: 525, y: 480, lat: 28.5933, lng: 77.2507 }
        },
        {
          id: 'step-2',
          time: '10:15',
          durationMinutes: 90,
          name: 'Chandni Chowk & Dariba Kalan Silver Alley',
          category: 'shopping',
          icon: '🛍️',
          expectedVisitors: 1100,
          crowdStatus: 'optimal',
          crowdLabel: 'Historic Haveli Walk',
          coords: { x: 515, y: 290, lat: 28.6528, lng: 77.2341 }
        },
        {
          id: 'step-3',
          time: '12:15',
          durationMinutes: 60,
          name: 'Karim Hotel Gali Kababian Lunch',
          category: 'food',
          icon: '🍛',
          expectedVisitors: 820,
          crowdStatus: 'optimal',
          crowdLabel: 'Legendary Mughlai Deg',
          coords: { x: 520, y: 300, lat: 28.6508, lng: 77.2335 }
        },
        {
          id: 'step-4',
          time: '14:00',
          durationMinutes: 60,
          name: 'Khari Baoli Spice Merchants Guild',
          category: 'markets',
          icon: '🏺',
          expectedVisitors: 980,
          crowdStatus: 'optimal',
          crowdLabel: 'Aromatic Spice Haveli',
          coords: { x: 495, y: 280, lat: 28.6565, lng: 77.2245 }
        },
        {
          id: 'step-5',
          time: '16:00',
          durationMinutes: 90,
          name: 'Dilli Haat Crafts & Handloom Village',
          category: 'crafts',
          icon: '🎨',
          expectedVisitors: 750,
          crowdStatus: 'optimal',
          crowdLabel: 'Rural Artisan Stalls',
          coords: { x: 490, y: 530, lat: 28.5731, lng: 77.2081 }
        },
        {
          id: 'step-6',
          time: '18:15',
          durationMinutes: 60,
          name: 'India Gate Illuminated Promenade',
          category: 'heritage',
          icon: '🏛️',
          expectedVisitors: 2900,
          crowdStatus: 'critical',
          crowdLabel: 'Lively Evening Promenade',
          coords: { x: 510, y: 440, lat: 28.6129, lng: 77.2295 }
        }
      ];
    } else {
      const atts = (this.location.attractions || []).slice(0, 4);
      let hour = 9;
      this.itinerary = atts.map((a, idx) => {
        const timeStr = `${hour < 10 ? '0' : ''}${hour}:00`;
        hour += 2;
        return {
          id: `step-${idx + 1}`,
          time: timeStr,
          durationMinutes: a.averageVisitMinutes || 90,
          name: a.name || `Heritage Site ${idx + 1}`,
          category: a.category || 'heritage',
          icon: a.category === 'nature' ? '🌿' : (a.category === 'food' ? '🍛' : '🏛️'),
          expectedVisitors: a.currentVisitors || 500,
          crowdStatus: a.status || 'optimal',
          crowdLabel: a.status === 'optimal' ? 'Quiet' : (a.status === 'critical' ? 'Very Busy' : 'Moderate'),
          coords: a.coords || { x: 400 + idx * 30, y: 300 + idx * 40, lat: 26.9, lng: 75.8 }
        };
      });
    }

    this.focusedItemId = this.itinerary[0] ? this.itinerary[0].id : null;
  }

  // --- Journey Mood & Route Lens Controls ---
  setJourneyMood(key, value) {
    if (this.journeyMood[key] !== undefined) {
      this.journeyMood[key] = Math.max(0, Math.min(100, parseInt(value, 10)));
      this.recalculate();
      this.notify('mood:changed', { mood: this.journeyMood });
    }
  }

  setActiveRoute(routeId) {
    this.activeRoute = routeId;
    this.notify('route:changed', { route: routeId });
  }

  // --- Travel Memories Journal ---
  addTripMemory(entry) {
    const memory = {
      id: 'mem-' + Date.now(),
      title: entry.title || 'ROAM Discovery Moment',
      placeName: entry.placeName || this.location?.name || 'India',
      timestamp: new Date().toLocaleString(),
      notes: entry.notes || '',
      tags: entry.tags || ['Authentic', 'Local']
    };
    this.tripMemories.unshift(memory);
    this.notify('memory:added', { memory });
    return memory;
  }

  // --- Real-Time Destination Telemetry ---
  getRightNowTelemetry() {
    const loc = this.location;
    if (!loc) return null;

    const baseCrowd = loc.totalDailyTourists || 35000;
    const hour = new Date().getHours();
    const isPeak = hour >= 11 && hour <= 16;

    return {
      cityName: loc.name,
      stateName: loc.state,
      temperature: loc.temperature || '28°C',
      weatherDesc: loc.weather || 'Clear & Pleasant',
      crowdLoadStatus: isPeak ? 'HIGH DEMAND CORRIDOR' : 'TRANQUIL LOCAL FLOW',
      crowdLoadColor: isPeak ? '#f59e0b' : '#10b981',
      bestWindowNow: isPeak ? 'Artisan Haveli & Courtyards' : 'Open Ramparts & Ghats',
      liveScore: loc.liveScore || 88
    };
  }

  // --- Transparent Scoring for Recommendations ---
  getWhyROAMPickedThis(item) {
    if (!item) return null;
    const mood = this.journeyMood;
    const cat = item.category || 'heritage';

    let localWeight = Math.round(mood.touristLocal * 0.4);
    let calmWeight = Math.round(mood.chaosCalm * 0.3);
    let cultureWeight = Math.round(mood.cultureAdventure * 0.3);

    const matchPct = Math.min(99, Math.max(78, localWeight + calmWeight + cultureWeight));

    return {
      matchScore: matchPct,
      reasons: [
        `${matchPct}% Alignment with your ${mood.touristLocal > 60 ? 'Authentic Local' : 'Iconic Landmark'} journey personality`,
        `Low queue bottleneck during scheduled time (${item.time || 'off-peak'})`,
        `Direct economic spillover to verified local guild craftspeople`,
        `Safe, walkable transit route with zero congested roadblocks`
      ]
    };
  }

  // --- "One Day, One Story" Narrative Day Arc ---
  generateOneDayStory() {
    const city = this.location?.name || 'Jaipur';
    const stops = this.itinerary;
    if (stops.length === 0) return 'Add places to begin your narrative journey.';

    const firstStop = stops[0]?.name;
    const midStop = stops[Math.floor(stops.length / 2)]?.name;
    const lastStop = stops[stops.length - 1]?.name;

    return `Awaken at dawn in ${city} starting at ${firstStop}, slipping through historic artisan alleyways for midday culinary heritage at ${midStop}, and concluding as twilight settles over ${lastStop}.`;
  }

  // --- Time Helpers ---
  timeToMins(tStr) {
    if (!tStr) return 9 * 60;
    const parts = tStr.split(':').map(Number);
    return (parts[0] || 0) * 60 + (parts[1] || 0);
  }

  minsToTime(mins) {
    mins = (mins + 24 * 60) % (24 * 60);
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return `${h < 10 ? '0' : ''}${h}:${m < 10 ? '0' : ''}${m}`;
  }

  // --- Preferences & Date ---
  setDate(dateKey) {
    this.selectedDate = dateKey;
    this.recalculate();
    this.notify('date:changed', { date: dateKey });
  }

  toggleInterest(interestId) {
    if (this.userInterests.has(interestId)) {
      if (this.userInterests.size > 1) {
        this.userInterests.delete(interestId);
      }
    } else {
      this.userInterests.add(interestId);
    }
    this.recalculate();
    this.notify('interests:changed', { interests: Array.from(this.userInterests) });
  }

  hasInterest(interestId) {
    return this.userInterests.has(interestId);
  }

  // --- Focused Item for Connected Curve & Map ---
  setFocusedItem(id) {
    this.focusedItemId = id;
    this.notify('focus:changed', { id });
  }

  getFocusedItem() {
    return this.itinerary.find(item => item.id === this.focusedItemId) || this.itinerary[0] || null;
  }

  // --- Recalculation Engine ---
  recalculate() {
    if (!this.itinerary || this.itinerary.length === 0) {
      this.dayHealth = {
        status: 'BALANCED',
        label: '● BALANCED',
        headline: 'No Activities Scheduled',
        description: 'Add places to your day to begin intelligent crowd and transit analysis.',
        color: '#10b981',
        fixAction: null
      };
      this.openSlots = [];
      return;
    }

    let currentMins = this.timeToMins(this.itinerary[0].time || '09:00');
    let totalTransitMins = 0;
    const conflicts = [];
    this.openSlots = [];

    this.itinerary.forEach((item, idx) => {
      if (idx > 0) {
        const prevItem = this.itinerary[idx - 1];
        const prevEndMins = this.timeToMins(prevItem.time) + (prevItem.durationMinutes || 90);
        
        const explicitMins = this.timeToMins(item.time);
        const autoMins = prevEndMins + (prevItem.transitMinutesToNext || 20);

        if (explicitMins > autoMins) {
          const gapDuration = explicitMins - prevEndMins;
          if (gapDuration >= 60) {
            this.openSlots.push({
              startMins: prevEndMins,
              endMins: explicitMins,
              startTime: this.minsToTime(prevEndMins),
              endTime: this.minsToTime(explicitMins),
              durationMinutes: gapDuration,
              afterItem: prevItem,
              beforeItem: item
            });
          }
          currentMins = explicitMins;
        } else {
          currentMins = autoMins;
          item.time = this.minsToTime(currentMins);
        }
      } else {
        currentMins = this.timeToMins(item.time);
      }

      const hourNum = Math.floor(currentMins / 60);

      const transitToNext = (idx < this.itinerary.length - 1) ? 20 : 0;
      item.transitMinutesToNext = transitToNext;
      totalTransitMins += transitToNext;

      const curve = this.getCrowdCurveForItem(item);
      const scheduledPoint = curve.find(p => {
        const pHour = parseInt(p.hour.split(':')[0], 10);
        return pHour === hourNum || pHour === hourNum - 1 || pHour === hourNum + 1;
      }) || curve[Math.min(curve.length - 1, Math.max(0, Math.floor((hourNum - 8) / 2)))];

      if (scheduledPoint) {
        item.expectedVisitors = scheduledPoint.visitors;
        item.crowdStatus = scheduledPoint.status;
        item.crowdLabel = scheduledPoint.label;
      }

      const isHeritagePeak = (item.category === 'heritage' || item.name.toLowerCase().includes('fort') || item.name.toLowerCase().includes('temple')) &&
                             (hourNum >= 11 && hourNum <= 14) &&
                             (item.expectedVisitors >= 1400 || item.crowdStatus === 'critical');

      if (isHeritagePeak) {
        item.isOvercrowded = true;
        conflicts.push({
          item,
          reason: `Peak queue bottleneck at ${item.time} (~${formatIndianNumber(item.expectedVisitors)} visitors, 50+ min queue)`
        });
      } else {
        item.isOvercrowded = false;
      }
    });

    const lastItem = this.itinerary[this.itinerary.length - 1];
    if (lastItem) {
      const lastEndMins = this.timeToMins(lastItem.time) + (lastItem.durationMinutes || 90);
      if (lastEndMins <= 16 * 60) {
        this.openSlots.push({
          startMins: lastEndMins,
          endMins: 19 * 60,
          startTime: this.minsToTime(lastEndMins),
          endTime: '19:00',
          durationMinutes: (19 * 60) - lastEndMins,
          afterItem: lastItem,
          beforeItem: null
        });
      }
    }

    if (conflicts.length > 0) {
      const conflictItem = conflicts[0].item;
      this.dayHealth = {
        status: 'TOO CROWDED',
        label: '● TOO CROWDED',
        color: '#ef4444',
        headline: `${conflictItem.name} Scheduled at Peak Congestion`,
        description: `Visiting ${conflictItem.name} at ${conflictItem.time} exposes you to ~${formatIndianNumber(conflictItem.expectedVisitors)} visitors and 50+ min wait times. ROAM recommends moving this visit to 08:30.`,
        fixAction: {
          type: 'move_early',
          itemId: conflictItem.id,
          targetTime: '08:30',
          label: 'Move to 08:30 (Quiet)'
        }
      };
    } else if (totalTransitMins > 90) {
      this.dayHealth = {
        status: 'TOO MUCH TRAVEL',
        label: '● TOO MUCH TRAVEL',
        color: '#f59e0b',
        headline: 'High Cross-City Transit Time (~' + totalTransitMins + ' min)',
        description: 'Your route crisscrosses different parts of the city. Re-ordering stops by geographical proximity will save over 35 minutes of transit.',
        fixAction: {
          type: 'balance',
          label: 'Cluster Stops by Zone'
        }
      };
    } else {
      this.dayHealth = {
        status: 'BALANCED',
        label: '● BALANCED',
        color: '#10b981',
        headline: 'Schedule is Well-Paced',
        description: 'Stops are planned during optimal hours with minimal queues, comfortable transit, and room for local exploration.',
        fixAction: null
      };
    }
  }

  // --- Dynamic Crowd Curves for Attractions AND Markets ---
  getCrowdCurveForItem(itemOrId) {
    const item = typeof itemOrId === 'string' 
      ? this.itinerary.find(i => i.id === itemOrId)
      : itemOrId;

    const itemName = item?.name || '';

    const att = (this.location?.attractions || []).find(a => 
      a.id === item?.id || a.name.toLowerCase() === itemName.toLowerCase()
    );
    if (att && att.crowdCurve && att.crowdCurve.length > 0) {
      return att.crowdCurve.map(p => ({
        hour: p.hour,
        visitors: p.visitors,
        status: p.status,
        label: p.label,
        pct: Math.min(100, Math.round((p.visitors / (att.capacityMax || 2500)) * 100))
      }));
    }

    const shop = (this.location?.localBusinesses || []).find(b => 
      b.id === item?.id || b.name.toLowerCase() === itemName.toLowerCase()
    );

    const baseActivity = shop?.estimatedActivity || item?.expectedVisitors || 600;
    const cat = item?.category || shop?.category || 'shopping';

    if (cat === 'markets' || cat === 'shopping' || cat === 'crafts') {
      return [
        { hour: '08:00', visitors: Math.round(baseActivity * 0.35), status: 'optimal', label: 'Quiet', pct: 25 },
        { hour: '10:00', visitors: Math.round(baseActivity * 0.65), status: 'optimal', label: 'Quiet', pct: 45 },
        { hour: '13:00', visitors: Math.round(baseActivity * 0.95), status: 'elevated', label: 'Moderate', pct: 65 },
        { hour: '16:00', visitors: Math.round(baseActivity * 0.85), status: 'optimal', label: 'Quieter', pct: 55 },
        { hour: '18:00', visitors: Math.round(baseActivity * 1.35), status: 'critical', label: 'Busy', pct: 88 },
        { hour: '20:00', visitors: Math.round(baseActivity * 0.70), status: 'optimal', label: 'Quiet', pct: 40 }
      ];
    } else if (cat === 'food') {
      return [
        { hour: '08:00', visitors: Math.round(baseActivity * 0.85), status: 'elevated', label: 'Moderate', pct: 60 },
        { hour: '10:30', visitors: Math.round(baseActivity * 0.40), status: 'optimal', label: 'Quiet', pct: 30 },
        { hour: '13:00', visitors: Math.round(baseActivity * 1.40), status: 'critical', label: 'Very Busy', pct: 90 },
        { hour: '16:00', visitors: Math.round(baseActivity * 0.35), status: 'optimal', label: 'Quiet', pct: 25 },
        { hour: '19:30', visitors: Math.round(baseActivity * 1.30), status: 'critical', label: 'Busy', pct: 85 },
        { hour: '21:30', visitors: Math.round(baseActivity * 0.60), status: 'optimal', label: 'Quiet', pct: 40 }
      ];
    }

    return [
      { hour: '08:30', visitors: Math.round(baseActivity * 0.28), status: 'optimal', label: 'Quiet', pct: 22 },
      { hour: '10:00', visitors: Math.round(baseActivity * 0.75), status: 'elevated', label: 'Moderate', pct: 58 },
      { hour: '12:00', visitors: Math.round(baseActivity * 1.30), status: 'critical', label: 'Very Busy', pct: 94 },
      { hour: '14:00', visitors: Math.round(baseActivity * 1.10), status: 'critical', label: 'Busy', pct: 78 },
      { hour: '16:00', visitors: Math.round(baseActivity * 0.60), status: 'elevated', label: 'Moderate', pct: 46 },
      { hour: '18:00', visitors: Math.round(baseActivity * 0.30), status: 'optimal', label: 'Quiet', pct: 24 }
    ];
  }

  getTimeEditorOptions(item) {
    const curve = this.getCrowdCurveForItem(item);
    return curve.map(p => ({
      time: p.hour,
      visitors: p.visitors,
      status: p.status,
      label: p.label,
      isCurrent: p.hour === item.time || (parseInt(p.hour.split(':')[0], 10) === parseInt(item.time.split(':')[0], 10))
    }));
  }

  getBetterTimeInsight(item) {
    if (!item) return null;
    const curve = this.getCrowdCurveForItem(item);
    const hourNum = parseInt(item.time.split(':')[0], 10);

    if (item.crowdStatus === 'critical' || (hourNum >= 11 && hourNum <= 14)) {
      const quietOption = curve.find(p => p.status === 'optimal') || curve[0];
      const savedVisitors = Math.max(0, item.expectedVisitors - quietOption.visitors);

      return {
        hasBetterTime: true,
        currentHour: item.time,
        currentVisitors: item.expectedVisitors,
        insight: "You're visiting during the busiest part of the day.",
        betterTime: quietOption.hour,
        betterVisitors: quietOption.visitors,
        betterLabel: quietOption.label,
        savedVisitors: savedVisitors,
        actionText: `MOVE TO ${quietOption.hour}`
      };
    }

    return null;
  }

  getWhatShouldIDoNext() {
    if (!this.location) return null;

    const businesses = this.location.localBusinesses || [];
    const existingNames = new Set(this.itinerary.map(i => i.name.toLowerCase()));
    const unvisited = businesses.filter(b => !existingNames.has(b.name.toLowerCase()));

    const matches = unvisited.map(b => {
      let score = 10;
      if (this.userInterests.has(b.category)) score += 20;
      if (b.activityStatus === 'QUIET') score += 15;
      if (b.distanceKm <= 1.5) score += 10;
      return { ...b, matchScore: score };
    }).sort((a, b) => b.matchScore - a.matchScore);

    const topPick = matches[0] || businesses[0];
    if (!topPick) return null;

    const activeSlot = this.openSlots[0];
    const availableMinutes = activeSlot ? activeSlot.durationMinutes : 90;

    return {
      availableMinutes,
      pick: topPick,
      headline: `YOU HAVE ${availableMinutes} MINUTES BEFORE YOUR NEXT STOP.`,
      title: topPick.name,
      visitors: topPick.estimatedActivity || 700,
      distanceKm: topPick.distanceKm || 1.2,
      transitMinutes: topPick.transitMinutes || 12,
      specialty: topPick.specialty || 'Traditional Artisanal Experience',
      why: `It fits your available ${availableMinutes} min free window and is expected to be quieter than main corridors.`
    };
  }

  addPlaceIntelligently(place) {
    const category = place.category || 'shopping';
    const duration = place.durationMinutes || (category === 'food' ? 60 : 75);
    const placeName = place.name;

    let targetSlot = this.openSlots.find(s => s.durationMinutes >= duration);

    let insertedTime = '16:00';
    let slotReason = 'Placed in your afternoon open window.';

    if (targetSlot) {
      insertedTime = targetSlot.startTime;
      slotReason = `Fits between ${targetSlot.afterItem?.name || 'morning visits'} and ${targetSlot.beforeItem?.name || 'evening dinner'}.`;
    } else {
      if (category === 'food') {
        insertedTime = '12:30';
        slotReason = 'Scheduled for midday lunch.';
      } else if (category === 'shopping' || category === 'markets' || category === 'crafts') {
        insertedTime = '16:00';
        slotReason = 'Scheduled for late afternoon bazaar walk.';
      } else {
        const lastItem = this.itinerary[this.itinerary.length - 1];
        if (lastItem) {
          const nextMins = this.timeToMins(lastItem.time) + (lastItem.durationMinutes || 90) + 20;
          insertedTime = this.minsToTime(nextMins);
          slotReason = `Added after ${lastItem.name}.`;
        } else {
          insertedTime = '10:00';
          slotReason = 'Starting your day schedule.';
        }
      }
    }

    const newItem = {
      id: place.id || ('step-' + Date.now()),
      time: insertedTime,
      durationMinutes: duration,
      name: placeName,
      category: category,
      isBreak: Boolean(place.isBreak || category === 'break'),
      icon: place.icon || (category === 'food' ? '🍛' : (category === 'markets' || category === 'shopping' ? '🛍️' : (category === 'nature' ? '🌿' : '🏛️'))),
      expectedVisitors: place.estimatedActivity || place.visitors || 650,
      crowdStatus: place.status || 'optimal',
      crowdLabel: 'Quiet',
      coords: place.coords || { x: 490, y: 440, lat: 26.9182, lng: 75.8224 }
    };

    this.itinerary.push(newItem);
    this.itinerary.sort((a, b) => this.timeToMins(a.time) - this.timeToMins(b.time));

    this.focusedItemId = newItem.id;
    this.recalculate();
    this.notify('itinerary:updated', { addedItem: newItem, slotReason });

    return {
      item: newItem,
      time: insertedTime,
      reason: slotReason
    };
  }

  updateItemTime(id, newTimeStr) {
    const item = this.itinerary.find(i => i.id === id);
    if (item) {
      item.time = newTimeStr;
      this.recalculate();
      this.notify('itinerary:updated', { updatedId: id });
    }
  }

  updateItemDuration(id, newDurationMinutes) {
    const item = this.itinerary.find(i => i.id === id);
    if (item) {
      item.durationMinutes = parseInt(newDurationMinutes, 10);
      this.recalculate();
      this.notify('itinerary:updated', { updatedId: id });
    }
  }

  removeItem(id) {
    this.itinerary = this.itinerary.filter(i => i.id !== id);
    if (this.focusedItemId === id) {
      this.focusedItemId = this.itinerary[0]?.id || null;
    }
    this.recalculate();
    this.notify('itinerary:updated', { removedId: id });
  }

  moveItem(id, direction) {
    const idx = this.itinerary.findIndex(i => i.id === id);
    if (idx === -1) return;
    const targetIdx = idx + direction;
    if (targetIdx < 0 || targetIdx >= this.itinerary.length) return;

    const temp = this.itinerary[idx];
    this.itinerary[idx] = this.itinerary[targetIdx];
    this.itinerary[targetIdx] = temp;

    this.recalculate();
    this.notify('itinerary:updated', { movedId: id });
  }

  // --- Timetable Quick Shift & Break Adjusters ---
  setStartDayTime(timeStr) {
    if (!this.itinerary || this.itinerary.length === 0) return;
    const targetMins = this.timeToMins(timeStr);
    const currentFirstMins = this.timeToMins(this.itinerary[0].time);
    const delta = targetMins - currentFirstMins;
    this.shiftEntireDay(delta);
  }

  shiftEntireDay(deltaMinutes) {
    if (!this.itinerary || this.itinerary.length === 0) return;
    this.itinerary.forEach(item => {
      const currentMins = this.timeToMins(item.time);
      const newMins = Math.max(7 * 60, Math.min(22 * 60, currentMins + deltaMinutes));
      item.time = this.minsToTime(newMins);
    });
    this.recalculate();
    this.notify('itinerary:updated', { shifted: deltaMinutes });
  }

  adjustItemDuration(id, deltaMinutes) {
    const item = this.itinerary.find(i => i.id === id);
    if (!item) return;
    const currentDuration = item.durationMinutes || 90;
    const newDuration = Math.max(30, Math.min(240, currentDuration + deltaMinutes));
    item.durationMinutes = newDuration;
    this.recalculate();
    this.notify('itinerary:updated', { updatedId: id, durationChanged: true });
  }

  insertBreak(breakType = 'chai') {
    let name = 'Masala Chai & Refreshment Break ☕';
    let duration = 30;
    let icon = '☕';

    if (breakType === 'lunch') {
      name = 'Authentic Local Lunch Break 🍛';
      duration = 60;
      icon = '🍛';
    } else if (breakType === 'sunset') {
      name = 'Sunset Viewpoint & Tea Pause 🌄';
      duration = 45;
      icon = '🌄';
    }

    const breakItem = {
      id: 'break-' + Date.now(),
      name,
      category: 'break',
      isBreak: true,
      durationMinutes: duration,
      icon,
      status: 'optimal',
      estimatedActivity: 350,
      coords: this.itinerary[0]?.coords || { x: 450, y: 450, lat: 26.9, lng: 75.8 }
    };

    return this.addPlaceIntelligently(breakItem);
  }

  balanceDay() {
    if (!this.itinerary || this.itinerary.length === 0) return null;

    const currentPlan = JSON.parse(JSON.stringify(this.itinerary));
    const balancedPlan = JSON.parse(JSON.stringify(this.itinerary));

    const categoryPriority = {
      spiritual: 1,
      heritage: 1,
      food: 2,
      culture: 3,
      shopping: 4,
      markets: 4,
      crafts: 4,
      nature: 5
    };

    balancedPlan.sort((a, b) => {
      const pA = categoryPriority[a.category] || 3;
      const pB = categoryPriority[b.category] || 3;
      return pA - pB;
    });

    let currentMins = 8 * 60 + 30; // 08:30 AM
    balancedPlan.forEach((item, idx) => {
      item.time = this.minsToTime(currentMins);
      item.crowdStatus = 'optimal';
      item.crowdLabel = 'Quiet & Cool';
      item.isOvercrowded = false;
      currentMins += (item.durationMinutes || 90) + 25;
    });

    const whyPoints = [
      'Less crowd: Major monument moved to 08:30 skips tour bus convoys and 65-minute ticketing queues.',
      'Less waiting: Scheduled visits coincide with off-peak lulls.',
      'Better travel flow: Stops flow geographically from north fortress to central old city to southern ramparts.',
      'More time for local experiences: An open late-afternoon window enables unhurried artisan guild exploration.'
    ];

    return {
      currentPlan,
      balancedPlan,
      whyPoints
    };
  }

  applyBalancedSchedule(newSchedule) {
    this.itinerary = newSchedule;
    this.recalculate();
    this.notify('itinerary:updated', { balanced: true });
  }
}

export const travelState = new TravelStateManager();
