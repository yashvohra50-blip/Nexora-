const http = require('http');
const fs = require('fs');
const path = require('path');
const https = require('https');

const PORT = 3000;
const PUBLIC_DIR = 'C:/Users/Yash Vohra/.gemini/antigravity/scratch/roam';

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.ico': 'image/x-icon'
};

// Optional LLM Proxy Endpoint for ROAM V4 (Zero Key Exposure in Frontend)
function handleApiAiChat(req, res) {
  let body = '';
  req.on('data', chunk => { body += chunk; });
  req.on('end', () => {
    let payload = {};
    try {
      payload = JSON.parse(body || '{}');
    } catch (e) {
      payload = {};
    }

    const apiKey = process.env.ROAM_AI_API_KEY || process.env.GEMINI_API_KEY;
    
    // If no API key is configured in env, immediately return fallback indicator
    if (!apiKey) {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        provider: 'local_deterministic',
        fallback: true,
        message: 'No external LLM key provided. Using deterministic LocalROAMProvider.'
      }));
      return;
    }

    // Call Gemini API if key is present
    const promptText = `You are ROAM AI, India's Living Destination Intelligence Agent.
Destination: ${payload.context?.city || 'Jaipur'}, ${payload.context?.state || 'Rajasthan'}.
User Query: "${payload.query || ''}"
Respond with warm, culturally intelligent advice. If proposing a stop, suggest a name, category, and why.`;

    const requestData = JSON.stringify({
      contents: [{ parts: [{ text: promptText }] }],
      generationConfig: { maxOutputTokens: 600, temperature: 0.7 }
    });

    const options = {
      hostname: 'generativelanguage.googleapis.com',
      path: `/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(requestData)
      }
    };

    const upstreamReq = https.request(options, upstreamRes => {
      let upData = '';
      upstreamRes.on('data', c => { upData += c; });
      upstreamRes.on('end', () => {
        try {
          const parsed = JSON.parse(upData);
          const replyText = parsed?.candidates?.[0]?.content?.parts?.[0]?.text;
          if (replyText) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
              provider: 'llm_gemini',
              fallback: false,
              text: replyText
            }));
            return;
          }
        } catch (err) {}
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ provider: 'local_deterministic', fallback: true }));
      });
    });

    upstreamReq.on('error', () => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ provider: 'local_deterministic', fallback: true }));
    });

    upstreamReq.write(requestData);
    upstreamReq.end();
  });
}

const server = http.createServer((req, res) => {
  let reqPath = req.url.split('?')[0];

  // API Endpoints
  if (reqPath === '/api/ai/chat' && req.method === 'POST') {
    handleApiAiChat(req, res);
    return;
  }

  if (reqPath === '/api/status') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status: 'online',
      version: 'ROAM V4 (Living Destination Intelligence Layer)',
      hasApiKey: Boolean(process.env.ROAM_AI_API_KEY || process.env.GEMINI_API_KEY)
    }));
    return;
  }

  // Static File Serving
  if (reqPath === '/' || reqPath === '') reqPath = '/index.html';

  const filePath = path.join(PUBLIC_DIR, reqPath);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('404 Not Found: ' + reqPath);
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    res.writeHead(200, {
      'Content-Type': contentType,
      'Cache-Control': 'no-cache'
    });

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

server.listen(PORT, '127.0.0.1', () => {
  console.log('[SERVER_READY] ROAM V4 running at http://127.0.0.1:' + PORT + '/');
});
