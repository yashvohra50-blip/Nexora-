/**
 * ROAM — Location Visual Identity System (V2)
 * High-Quality Cinematic Photography + Ambient SVG Silhouettes (at 5–15% opacity)
 */

export const LOCATION_THEMES = {
  jaipur: {
    id: 'jaipur',
    name: 'Jaipur',
    photoUrl: 'https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Hawa Mahal Palace of Winds • Walled City of Jaipur',
    photoCredit: 'Photo by Annie Spratt on Unsplash',
    colors: {
      bg: '#0e0a0d',
      bgSurface: '#160f14',
      bgCard: '#1e141c',
      bgElevated: '#281b26',
      accent: '#f472b6',        // Rose pink
      accentSoft: 'rgba(244, 114, 182, 0.12)',
      accentBorder: 'rgba(244, 114, 182, 0.35)',
      activeGlow: 'rgba(244, 114, 182, 0.22)',
      textPrimary: '#fcfaf7',
      textSecondary: '#a89aa5',
      mapGlow: 'rgba(244, 114, 182, 0.18)'
    },
    atmosphere: 'Dusty Rose • Terracotta Sandstone • Royal Rajputana',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#f472b6" stroke-width="1.5" fill="none">
        <path d="M 400,600 L 400,320 Q 400,300 420,300 L 580,300 Q 600,300 600,320 L 600,600 Z" />
        <path d="M 440,300 L 440,240 Q 440,220 460,220 L 540,220 Q 560,220 560,240 L 560,300" />
        <path d="M 470,220 L 470,180 Q 470,165 485,165 L 515,165 Q 530,165 530,180 L 530,220" />
        <path d="M 430,360 C 430,340 470,340 470,360 L 470,400 L 430,400 Z" />
        <path d="M 530,360 C 530,340 570,340 570,360 L 570,400 L 530,400 Z" />
        <path d="M 480,350 C 480,330 520,330 520,350 L 520,390 L 480,390 Z" />
        <path d="M 150,550 Q 250,500 350,530 T 550,500 T 750,530 T 950,500" stroke-width="2" />
        <circle cx="500" cy="150" r="8" fill="#f472b6" opacity="0.12" />
      </g>
    `
  },
  varanasi: {
    id: 'varanasi',
    name: 'Varanasi',
    photoUrl: 'https://images.unsplash.com/photo-1561361513-2d000a50f0dc?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Ancient River Ghats at Dawn • River Ganga, Kashi',
    photoCredit: 'Photo by Jyoti Singh on Unsplash',
    colors: {
      bg: '#070a13',
      bgSurface: '#0d1222',
      bgCard: '#13192f',
      bgElevated: '#1a223e',
      accent: '#f59e0b',        // Sacred Saffron
      accentSoft: 'rgba(245, 158, 11, 0.12)',
      accentBorder: 'rgba(245, 158, 11, 0.35)',
      activeGlow: 'rgba(245, 158, 11, 0.22)',
      textPrimary: '#faf8f4',
      textSecondary: '#94a0b8',
      mapGlow: 'rgba(245, 158, 11, 0.18)'
    },
    atmosphere: 'Sacred Saffron • Deep River Indigo • Ancient Temples',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#f59e0b" stroke-width="1.5" fill="none">
        <path d="M 0,550 C 250,530 450,570 700,540 C 850,520 950,540 1000,535" stroke-width="2" />
        <path d="M 200,545 L 200,480 L 320,480 L 320,545" />
        <path d="M 220,480 L 260,340 L 300,480" />
        <circle cx="260" cy="330" r="5" fill="#f59e0b" opacity="0.2" />
        <path d="M 500,540 L 500,440 L 640,440 L 640,540" />
        <path d="M 530,440 L 570,280 L 610,440" stroke-width="2" />
        <circle cx="570" cy="270" r="6" fill="#f59e0b" opacity="0.2" />
      </g>
    `
  },
  mumbai: {
    id: 'mumbai',
    name: 'Mumbai',
    photoUrl: 'https://images.unsplash.com/photo-1570168007204-dfb528c6958f?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Gateway of India • Arabian Sea Harbor',
    photoCredit: 'Photo by Hardik Joshi on Unsplash',
    colors: {
      bg: '#080d16',
      bgSurface: '#0f1624',
      bgCard: '#151f33',
      bgElevated: '#1d2a44',
      accent: '#38bdf8',        // Marine sky / gold
      accentSoft: 'rgba(56, 189, 248, 0.12)',
      accentBorder: 'rgba(56, 189, 248, 0.35)',
      activeGlow: 'rgba(56, 189, 248, 0.22)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      mapGlow: 'rgba(56, 189, 248, 0.18)'
    },
    atmosphere: 'Art Deco Gold • Arabian Sea Navy • Coastal Energy',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#38bdf8" stroke-width="1.5" fill="none">
        <path d="M 360,560 L 360,340 Q 360,320 380,320 L 620,320 Q 640,320 640,340 L 640,560" stroke-width="2" />
        <path d="M 440,560 L 440,380 Q 440,370 450,370 L 550,370 Q 560,370 560,380 L 560,560" />
        <path d="M 400,320 L 400,260 L 600,260 L 600,320" />
        <path d="M 470,260 Q 500,220 530,260" fill="none" stroke-width="2" />
        <path d="M 0,580 Q 250,560 500,580 T 1000,580" stroke-width="2" />
      </g>
    `
  },
  kochi: {
    id: 'kochi',
    name: 'Kochi',
    photoUrl: 'https://images.unsplash.com/photo-1602216056096-3b40cc0c9944?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Cheena Vala Chinese Fishing Nets • Fort Kochi Coastline',
    photoCredit: 'Photo by Vivek Kumar on Unsplash',
    colors: {
      bg: '#071210',
      bgSurface: '#0c1b18',
      bgCard: '#122521',
      bgElevated: '#18312b',
      accent: '#10b981',        // Emerald green
      accentSoft: 'rgba(16, 185, 129, 0.12)',
      accentBorder: 'rgba(16, 185, 129, 0.35)',
      activeGlow: 'rgba(16, 185, 129, 0.22)',
      textPrimary: '#f7faf8',
      textSecondary: '#9cb3ab',
      mapGlow: 'rgba(16, 185, 129, 0.18)'
    },
    atmosphere: 'Spice Emerald • Backwater Teal • Colonial Malabar',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#10b981" stroke-width="1.5" fill="none">
        <line x1="250" y1="560" x2="420" y2="340" stroke-width="2.5" />
        <line x1="420" y1="340" x2="680" y2="400" stroke-width="1.8" />
        <line x1="420" y1="340" x2="640" y2="520" stroke-width="1.8" />
        <path d="M 450,440 Q 560,520 650,450" stroke-dasharray="4,4" />
        <path d="M 0,570 Q 300,555 600,570 T 1000,570" stroke-width="2" />
      </g>
    `
  },
  leh: {
    id: 'leh',
    name: 'Leh Ladakh',
    photoUrl: 'https://images.unsplash.com/photo-1581793745862-99fde7fa73d2?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Thiksey Hilltop Monastery • Trans-Himalayan Range',
    photoCredit: 'Photo by Anirudh Sharma on Unsplash',
    colors: {
      bg: '#080d16',
      bgSurface: '#0e1625',
      bgCard: '#152136',
      bgElevated: '#1d2c47',
      accent: '#38bdf8',        // High-altitude azure
      accentSoft: 'rgba(56, 189, 248, 0.12)',
      accentBorder: 'rgba(56, 189, 248, 0.35)',
      activeGlow: 'rgba(56, 189, 248, 0.22)',
      textPrimary: '#f8fafc',
      textSecondary: '#9bb0ca',
      mapGlow: 'rgba(56, 189, 248, 0.18)'
    },
    atmosphere: 'High Altitude Azure • Stupa Gold • Mountain Silence',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#38bdf8" stroke-width="1.5" fill="none">
        <path d="M 0,520 L 180,340 L 320,440 L 520,240 L 700,420 L 860,310 L 1000,480" stroke-width="2.5" />
        <path d="M 480,560 L 480,470 L 560,470 L 560,560" />
        <path d="M 500,470 L 520,400 L 540,470" />
        <circle cx="520" cy="390" r="5" fill="#38bdf8" opacity="0.2" />
      </g>
    `
  },
  delhi: {
    id: 'delhi',
    name: 'Delhi',
    photoUrl: 'https://images.unsplash.com/photo-1587474260584-136574528ed5?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Humayun\'s Tomb Mughal Gardens • Historic Delhi',
    photoCredit: 'Photo by Naveen Sharma on Unsplash',
    colors: {
      bg: '#100a0c',
      bgSurface: '#181013',
      bgCard: '#21161b',
      bgElevated: '#2c1e24',
      accent: '#fb7185',        // Sandstone crimson
      accentSoft: 'rgba(251, 113, 133, 0.12)',
      accentBorder: 'rgba(251, 113, 133, 0.35)',
      activeGlow: 'rgba(251, 113, 133, 0.22)',
      textPrimary: '#fdf8f8',
      textSecondary: '#ad9aa0',
      mapGlow: 'rgba(251, 113, 133, 0.18)'
    },
    atmosphere: 'Imperial Sandstone • Mughal Jade • Broad Boulevards',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#fb7185" stroke-width="1.5" fill="none">
        <path d="M 380,560 L 380,330 L 620,330 L 620,560" stroke-width="2" />
        <path d="M 450,560 L 450,420 Q 500,380 550,420 L 550,560" />
        <path d="M 430,330 Q 500,280 570,330" fill="none" stroke-width="2" />
        <circle cx="500" cy="270" r="6" fill="#fb7185" opacity="0.2" />
      </g>
    `
  },
  pushkar: {
    id: 'pushkar',
    name: 'Pushkar',
    photoUrl: 'https://images.unsplash.com/photo-1597074866923-dc0589150358?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Sacred Pushkar Lake & Desert Hills',
    photoCredit: 'Photo by Gaurav Saini on Unsplash',
    colors: {
      bg: '#0f0c08',
      bgSurface: '#19150e',
      bgCard: '#231d14',
      bgElevated: '#2f271c',
      accent: '#fbbf24',        // Warm desert gold
      accentSoft: 'rgba(251, 191, 36, 0.12)',
      accentBorder: 'rgba(251, 191, 36, 0.35)',
      activeGlow: 'rgba(251, 191, 36, 0.22)',
      textPrimary: '#faf8f4',
      textSecondary: '#a89f8f',
      mapGlow: 'rgba(251, 191, 36, 0.18)'
    },
    atmosphere: 'Desert Oasis • Sacred Ghats • Saffron & Sand',
    silhouetteSvg: `
      <g opacity="0.10" stroke="#fbbf24" stroke-width="1.5" fill="none">
        <path d="M 100,560 Q 300,510 500,550 T 900,520" stroke-width="2" />
        <path d="M 440,540 L 440,480 L 560,480 L 560,540" />
        <path d="M 470,480 L 500,410 L 530,480" />
      </g>
    `
  },
  udaipur: {
    id: 'udaipur',
    name: 'Udaipur',
    photoUrl: 'https://images.unsplash.com/photo-1615836245337-f5b9b2303f10?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'City Palace on Lake Pichola • Udaipur, Rajasthan',
    photoCredit: 'Photo by Sayan Nath on Unsplash',
    colors: {
      bg: '#0a0d14',
      bgSurface: '#101622',
      bgCard: '#172030',
      bgElevated: '#202b40',
      accent: '#38bdf8',
      accentSoft: 'rgba(56, 189, 248, 0.12)',
      accentBorder: 'rgba(56, 189, 248, 0.35)',
      activeGlow: 'rgba(56, 189, 248, 0.22)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      mapGlow: 'rgba(56, 189, 248, 0.18)'
    },
    atmosphere: 'Lake Pichola Azure • Mewar Marble • Aravalli Mountain Breeze',
    silhouetteSvg: `<g opacity="0.10" stroke="#38bdf8" stroke-width="1.5" fill="none"><path d="M 200,560 L 200,420 L 400,420 L 400,560 Z" /><path d="M 500,560 L 500,380 L 800,380 L 800,560 Z" /></g>`
  },
  jodhpur: {
    id: 'jodhpur',
    name: 'Jodhpur',
    photoUrl: 'https://images.unsplash.com/photo-1598974357801-cbca100e65d3?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Mehrangarh Fort & Blue City • Jodhpur, Rajasthan',
    photoCredit: 'Photo by Hardik Joshi on Unsplash',
    colors: {
      bg: '#070c18',
      bgSurface: '#0d152a',
      bgCard: '#131e3b',
      bgElevated: '#1a284e',
      accent: '#60a5fa',        // Indigo Blue
      accentSoft: 'rgba(96, 165, 250, 0.12)',
      accentBorder: 'rgba(96, 165, 250, 0.35)',
      activeGlow: 'rgba(96, 165, 250, 0.22)',
      textPrimary: '#f8fafc',
      textSecondary: '#93c5fd',
      mapGlow: 'rgba(96, 165, 250, 0.18)'
    },
    atmosphere: 'Indigo Blue City • Mehrangarh Cliff • Sun City Amber',
    silhouetteSvg: `<g opacity="0.10" stroke="#60a5fa" stroke-width="1.5" fill="none"><path d="M 300,560 L 300,300 L 700,300 L 700,560 Z" /></g>`
  },
  hampi: {
    id: 'hampi',
    name: 'Hampi',
    photoUrl: 'https://images.unsplash.com/photo-1600100397608-f010f443b740?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Stone Chariot & Vijayanagara Ruins • Hampi, Karnataka',
    photoCredit: 'Photo by Vinay S on Unsplash',
    colors: {
      bg: '#120c06',
      bgSurface: '#1c130b',
      bgCard: '#271a10',
      bgElevated: '#342316',
      accent: '#f59e0b',        // Stone amber gold
      accentSoft: 'rgba(245, 158, 11, 0.12)',
      accentBorder: 'rgba(245, 158, 11, 0.35)',
      activeGlow: 'rgba(245, 158, 11, 0.22)',
      textPrimary: '#faf8f4',
      textSecondary: '#baad9c',
      mapGlow: 'rgba(245, 158, 11, 0.18)'
    },
    atmosphere: 'Ancient Granite Gold • Tungabhadra River • Ruined Empire Chariots',
    silhouetteSvg: `<g opacity="0.10" stroke="#f59e0b" stroke-width="1.5" fill="none"><circle cx="500" cy="450" r="80" /></g>`
  },
  agra: {
    id: 'agra',
    name: 'Agra',
    photoUrl: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Taj Mahal at Sunrise • Agra, Uttar Pradesh',
    photoCredit: 'Photo by Jovyn Chamb on Unsplash',
    colors: {
      bg: '#0e0b10',
      bgSurface: '#16111a',
      bgCard: '#1f1824',
      bgElevated: '#2a2130',
      accent: '#f472b6',        // Rose marble
      accentSoft: 'rgba(244, 114, 182, 0.12)',
      accentBorder: 'rgba(244, 114, 182, 0.35)',
      activeGlow: 'rgba(244, 114, 182, 0.22)',
      textPrimary: '#faf8f6',
      textSecondary: '#a597a0',
      mapGlow: 'rgba(244, 114, 182, 0.18)'
    },
    atmosphere: 'White Marble Poetry • Yamuna Dawn Mist • Mughal Grandeur',
    silhouetteSvg: `<g opacity="0.10" stroke="#f472b6" stroke-width="1.5" fill="none"><path d="M 400,560 L 400,320 Q 500,220 600,320 L 600,560" /></g>`
  },
  amritsar: {
    id: 'amritsar',
    name: 'Amritsar',
    photoUrl: 'https://images.unsplash.com/photo-1514222134-b57cbb8ce073?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Sri Harmandir Sahib (Golden Temple) • Amritsar, Punjab',
    photoCredit: 'Photo by Peter George on Unsplash',
    colors: {
      bg: '#0f0c05',
      bgSurface: '#181409',
      bgCard: '#241e0f',
      bgElevated: '#312915',
      accent: '#fbbf24',        // Pure temple gold
      accentSoft: 'rgba(251, 191, 36, 0.12)',
      accentBorder: 'rgba(251, 191, 36, 0.35)',
      activeGlow: 'rgba(251, 191, 36, 0.22)',
      textPrimary: '#faf8f4',
      textSecondary: '#b0a692',
      mapGlow: 'rgba(251, 191, 36, 0.18)'
    },
    atmosphere: 'Pure Golden Dome • Holy Amrit Sarovar • Langar Harmony',
    silhouetteSvg: `<g opacity="0.10" stroke="#fbbf24" stroke-width="1.5" fill="none"><path d="M 380,560 L 380,400 L 620,400 L 620,560 Z" /></g>`
  },
  srinagar: {
    id: 'srinagar',
    name: 'Srinagar',
    photoUrl: 'https://images.unsplash.com/photo-1598091383021-15ddea10925d?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Shikaras on Dal Lake • Srinagar, Kashmir',
    photoCredit: 'Photo by Imad Clicks on Unsplash',
    colors: {
      bg: '#080e14',
      bgSurface: '#0f1722',
      bgCard: '#162130',
      bgElevated: '#1f2d40',
      accent: '#38bdf8',        // Lake Azure
      accentSoft: 'rgba(56, 189, 248, 0.12)',
      accentBorder: 'rgba(56, 189, 248, 0.35)',
      activeGlow: 'rgba(56, 189, 248, 0.22)',
      textPrimary: '#f8fafc',
      textSecondary: '#94a3b8',
      mapGlow: 'rgba(56, 189, 248, 0.18)'
    },
    atmosphere: 'Dal Lake Calm • Snow Peaks of Pir Panjal • Floating Lotus Meadows',
    silhouetteSvg: `<g opacity="0.10" stroke="#38bdf8" stroke-width="1.5" fill="none"><path d="M 0,540 Q 500,480 1000,540" /></g>`
  },
  goa: {
    id: 'goa',
    name: 'Goa',
    photoUrl: 'https://images.unsplash.com/photo-1512343879784-a960bf40e7f2?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Goan Coastal Palms & Architecture • Goa',
    photoCredit: 'Photo by Aleksandr Popelier on Unsplash',
    colors: {
      bg: '#061010',
      bgSurface: '#0c1b1a',
      bgCard: '#132725',
      bgElevated: '#1b3431',
      accent: '#10b981',        // Palm Emerald
      accentSoft: 'rgba(16, 185, 129, 0.12)',
      accentBorder: 'rgba(16, 185, 129, 0.35)',
      activeGlow: 'rgba(16, 185, 129, 0.22)',
      textPrimary: '#f8faf9',
      textSecondary: '#9ab3ae',
      mapGlow: 'rgba(16, 185, 129, 0.18)'
    },
    atmosphere: 'Baroque Latin Quarter • Sunkissed Arabian Sea • Coastal Palm Groves',
    silhouetteSvg: `<g opacity="0.10" stroke="#10b981" stroke-width="1.5" fill="none"><path d="M 0,550 Q 500,520 1000,550" /></g>`
  },
  kolkata: {
    id: 'kolkata',
    name: 'Kolkata',
    photoUrl: 'https://images.unsplash.com/photo-1558431382-27e303142255?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Victoria Memorial & Howrah Bridge • Kolkata, West Bengal',
    photoCredit: 'Photo by Anirban Ghosh on Unsplash',
    colors: {
      bg: '#0f0a0c',
      bgSurface: '#181014',
      bgCard: '#22171c',
      bgElevated: '#2d1e25',
      accent: '#fb7185',        // Terracotta crimson
      accentSoft: 'rgba(251, 113, 133, 0.12)',
      accentBorder: 'rgba(251, 113, 133, 0.35)',
      activeGlow: 'rgba(251, 113, 133, 0.22)',
      textPrimary: '#fdf8f9',
      textSecondary: '#ad9aa1',
      mapGlow: 'rgba(251, 113, 133, 0.18)'
    },
    atmosphere: 'Colonial White Marble • Hooghly River Cantilevers • Cultural Renaissance',
    silhouetteSvg: `<g opacity="0.10" stroke="#fb7185" stroke-width="1.5" fill="none"><path d="M 200,560 L 500,350 L 800,560" /></g>`
  },
  default: {
    id: 'default',
    name: 'India',
    photoUrl: 'https://images.unsplash.com/photo-1524492412937-b28074a5d7da?auto=format&fit=crop&w=1600&q=80',
    photoCaption: 'Historic Heritage Corridors of India',
    photoCredit: 'Photo by Sylwia Bartyzel on Unsplash',
    colors: {
      bg: '#0c0d12',
      bgSurface: '#13151f',
      bgCard: '#181b28',
      bgElevated: '#262a3e',
      accent: '#f472b6',
      accentSoft: 'rgba(244, 114, 182, 0.12)',
      accentBorder: 'rgba(244, 114, 182, 0.35)',
      activeGlow: 'rgba(244, 114, 182, 0.22)',
      textPrimary: '#fcfaf7',
      textSecondary: '#9ea4b6',
      mapGlow: 'rgba(244, 114, 182, 0.18)'
    },
    atmosphere: 'Living Digital Layer • Cultural Heritage Across India',
    silhouetteSvg: `
      <g opacity="0.08" stroke="#f472b6" stroke-width="1.5" fill="none">
        <path d="M 200,560 L 500,320 L 800,560 Z" />
      </g>
    `
  }
};
