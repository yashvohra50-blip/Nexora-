/**
 * ROAM Modals & Popups (V3)
 * Shop Detail Modal, Add Place Picker Modal, Balance Day Comparison Modal, and Toast
 * Fully integrated with travelState
 */

import { travelState } from '../state/travelState.js';
import { formatIndianNumber } from '../utils/formatters.js';

export class ModalController {
  constructor(app) {
    this.app = app;
    this.backdrop = document.getElementById('roam-modal-backdrop');
    this.toastContainer = document.getElementById('roam-toast-container');
    this.init();
  }

  init() {
    if (this.backdrop) {
      this.backdrop.addEventListener('click', (e) => {
        if (e.target === this.backdrop) {
          this.closeAll();
        }
      });
    }

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') this.closeAll();
    });
  }

  showToast(message, icon = '✓') {
    if (!this.toastContainer) {
      let c = document.createElement('div');
      c.id = 'roam-toast-container';
      c.className = 'roam-toast-container';
      document.body.appendChild(c);
      this.toastContainer = c;
    }

    const toast = document.createElement('div');
    toast.className = 'roam-toast';
    toast.innerHTML = `
      <span class="toast-icon">${icon}</span>
      <span class="toast-msg">${message}</span>
    `;
    this.toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('fade-out');
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  closeAll() {
    if (this.backdrop) {
      this.backdrop.classList.remove('active');
      this.backdrop.innerHTML = '';
    }
    document.body.classList.remove('modal-open');
  }

  // --- Shop / Market Detail Modal (Requirement 16) ---
  openShopDetail(shop, cityName) {
    if (!this.backdrop) return;

    const city = cityName || travelState.location?.name || 'Jaipur';
    const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(shop.name + ', ' + city)}`;
    const isQuiet = shop.activityStatus === 'QUIET';

    this.backdrop.innerHTML = `
      <div class="roam-modal-dialog shop-detail-dialog" role="dialog" aria-modal="true">
        <button class="modal-close-btn" aria-label="Close">&times;</button>
        
        <div class="modal-header-strip">
          <span class="badge ${shop.badgeClass || 'badge-optimal'}">${shop.badge || 'ROAM CURATED'}</span>
          <span style="font-size:0.75rem; color:var(--text-muted); font-family:var(--font-mono);">
            ROAM FORECAST • MODELLED ESTIMATE
          </span>
        </div>

        <div class="modal-body-content">
          <div class="shop-modal-headline">
            <h2 class="shop-modal-title">${shop.name}</h2>
            <div class="shop-modal-zone">📍 ${shop.zone} • ${shop.category ? shop.category.toUpperCase() : 'LOCAL SHOPPING'}</div>
          </div>

          <!-- Activity & Hours Grid (Requirement 16) -->
          <div class="shop-stats-grid">
            <div class="shop-stat-box">
              <div class="shop-stat-label">EXPECTED ACTIVITY</div>
              <div class="shop-stat-val" style="color: ${isQuiet ? 'var(--load-optimal)' : '#f59e0b'};">
                ~${formatIndianNumber(shop.estimatedActivity || 700)} visitors
              </div>
              <div class="shop-stat-sub">${shop.activityStatus || 'QUIETER'}</div>
            </div>

            <div class="shop-stat-box">
              <div class="shop-stat-label">BEST VISITING HOURS</div>
              <div class="shop-stat-val" style="color:#fff;">
                ${shop.bestTime || '15:00 — 17:00'}
              </div>
              <div class="shop-stat-sub">Avoid: 18:00 — 19:30</div>
            </div>

            <div class="shop-stat-box">
              <div class="shop-stat-label">FROM YOUR PLAN</div>
              <div class="shop-stat-val" style="color:var(--brand-cyan);">
                ~${shop.transitMinutes || 12} min
              </div>
              <div class="shop-stat-sub">${shop.distanceKm || '1.2'} km transit</div>
            </div>
          </div>

          <!-- Why ROAM Recommends This -->
          <div class="shop-modal-section">
            <div class="shop-section-title">WHY ROAM RECOMMENDS THIS</div>
            <ul class="why-list">
              ${(shop.whyRecommended || [
                `Traditional ${city} shopping and cultural heritage`,
                'Fits your available free schedule window',
                'Expected activity is lower than main monument corridors',
                'Strong cultural authenticity without middleman commissions'
              ]).map(w => `<li><span class="why-check">✓</span> ${w}</li>`).join('')}
            </ul>
          </div>

          <!-- Specialty & Price Range -->
          <div style="display:flex; justify-content:space-between; align-items:center; padding:12px 16px; background:rgba(255,255,255,0.03); border:1px solid var(--border-subtle); border-radius:var(--radius-md); margin-top:16px;">
            <div>
              <div style="font-size:0.75rem; color:var(--text-muted); text-transform:uppercase;">Specialty</div>
              <div style="font-size:0.9rem; font-weight:700; color:#fff;">${shop.specialty || 'Traditional Crafts'}</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:0.75rem; color:var(--text-muted); text-transform:uppercase;">Typical Price</div>
              <div style="font-size:0.9rem; font-weight:800; color:var(--brand-cyan); font-family:var(--font-mono);">${shop.priceRange || '₹200 — ₹2,000'}</div>
            </div>
          </div>

          <!-- Modal Action Buttons (Requirement 17 & 18) -->
          <div class="modal-actions-row">
            <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary modal-map-btn">
              OPEN IN GOOGLE MAPS ↗
            </a>
            <button class="btn btn-primary modal-add-plan-btn" id="modal-add-plan-btn">
              + ADD TO PLAN
            </button>
          </div>
        </div>
      </div>
    `;

    this.backdrop.classList.add('active');
    document.body.classList.add('modal-open');

    this.backdrop.querySelector('.modal-close-btn').onclick = () => this.closeAll();
    const addBtn = this.backdrop.querySelector('#modal-add-plan-btn');
    if (addBtn) {
      addBtn.onclick = () => {
        const res = travelState.addPlaceIntelligently({
          name: shop.name,
          category: shop.category || 'shopping',
          durationMinutes: 75,
          zone: shop.zone,
          coords: shop.coords,
          distanceKm: shop.distanceKm || 1.5,
          estimatedActivity: shop.estimatedActivity
        });
        this.showToast(`Added ${shop.name} at ${res.time} (${res.reason})`);
        this.closeAll();
        if (this.app) this.app.switchMode('plan');
      };
    }
  }

  // --- Add Place Picker Modal (Requirement 3, 18) ---
  openAddPlace(locationData) {
    if (!this.backdrop || !locationData) return;

    const attractions = locationData.attractions || [];
    const businesses = locationData.localBusinesses || [];

    const categories = [
      { id: 'all', name: 'All' },
      { id: 'heritage', name: '🏛️ Landmarks' },
      { id: 'food', name: '🍛 Food' },
      { id: 'markets', name: '🛍️ Markets' },
      { id: 'crafts', name: '🏺 Crafts' },
      { id: 'culture', name: '🎨 Culture' },
      { id: 'nature', name: '🌿 Nature' }
    ];

    const allItems = [
      ...attractions.map(a => ({
        id: a.id,
        name: a.name,
        category: a.category || 'heritage',
        type: 'attraction',
        subtitle: a.description || '',
        status: a.status,
        visitors: a.currentVisitors,
        durationMinutes: a.averageVisitMinutes || 90,
        coords: a.coords
      })),
      ...businesses.map(b => ({
        id: b.id,
        name: b.name,
        category: b.category || 'shopping',
        type: 'business',
        subtitle: b.specialty || b.zone || '',
        status: b.activityStatus === 'QUIET' ? 'optimal' : 'elevated',
        visitors: b.estimatedActivity,
        durationMinutes: 75,
        coords: b.coords
      }))
    ];

    let currentFilter = 'all';

    const renderList = (filter, search = '') => {
      let filtered = allItems;
      if (filter !== 'all') {
        filtered = filtered.filter(i => i.category === filter || (filter === 'markets' && i.category === 'shopping'));
      }
      if (search.trim()) {
        const q = search.toLowerCase();
        filtered = filtered.filter(i => i.name.toLowerCase().includes(q) || i.subtitle.toLowerCase().includes(q));
      }

      const listMount = document.getElementById('add-place-items-list');
      if (!listMount) return;

      if (filtered.length === 0) {
        listMount.innerHTML = `<div style="text-align:center; padding:32px; color:var(--text-muted);">No places matching your search.</div>`;
        return;
      }

      listMount.innerHTML = filtered.map(item => `
        <div class="add-place-card" data-id="${item.id}">
          <div class="add-place-info">
            <div class="add-place-name">${item.name}</div>
            <div class="add-place-sub">${item.subtitle}</div>
            <div class="add-place-meta">
              <span class="badge ${item.status === 'optimal' ? 'badge-optimal' : 'badge-elevated'}">
                ${item.status === 'optimal' ? 'Quiet (Has Room)' : 'Popular'}
              </span>
              <span style="font-size:0.75rem; color:var(--text-muted); font-family:var(--font-mono);">
                ~${item.durationMinutes} min visit
              </span>
            </div>
          </div>
          <button class="btn btn-secondary btn-sm add-place-action-btn" data-id="${item.id}">
            + Add to Plan
          </button>
        </div>
      `).join('');

      listMount.querySelectorAll('.add-place-action-btn').forEach(btn => {
        btn.onclick = () => {
          const it = allItems.find(x => x.id === btn.dataset.id);
          if (it) {
            const res = travelState.addPlaceIntelligently(it);
            this.showToast(`Added ${it.name} at ${res.time} (${res.reason})`);
            this.closeAll();
            if (this.app) this.app.switchMode('plan');
          }
        };
      });
    };

    this.backdrop.innerHTML = `
      <div class="roam-modal-dialog add-place-dialog" role="dialog" aria-modal="true">
        <button class="modal-close-btn" aria-label="Close">&times;</button>
        
        <div class="modal-header-strip">
          <span style="font-size:0.8rem; font-weight:800; color:var(--roam-accent); letter-spacing:0.1em; text-transform:uppercase;">
            DISCOVER & SCHEDULE
          </span>
          <span style="font-size:0.75rem; color:var(--text-muted); font-family:var(--font-mono);">
            ${locationData.name.toUpperCase()} CURATION
          </span>
        </div>

        <div class="modal-body-content">
          <h2 style="font-size:1.4rem; font-weight:900; color:#fff; margin-bottom:8px;">ADD PLACE TO YOUR DAY</h2>
          <p style="font-size:0.85rem; color:var(--text-secondary); margin-bottom:16px;">
            ROAM automatically determines the optimal time slot to minimize queue congestion and travel backtracking.
          </p>

          <input type="text" id="add-place-search-input" class="search-input" placeholder="Search by name, craft, or neighborhood..." style="margin-bottom:12px;">

          <div class="modal-filter-tabs">
            ${categories.map(c => `
              <button class="modal-tab-btn ${c.id === 'all' ? 'active' : ''}" data-cat="${c.id}">
                ${c.name}
              </button>
            `).join('')}
          </div>

          <div id="add-place-items-list" class="add-place-items-scroll"></div>
        </div>
      </div>
    `;

    this.backdrop.classList.add('active');
    document.body.classList.add('modal-open');

    this.backdrop.querySelector('.modal-close-btn').onclick = () => this.closeAll();

    const searchInput = this.backdrop.querySelector('#add-place-search-input');
    searchInput.oninput = () => renderList(currentFilter, searchInput.value);

    this.backdrop.querySelectorAll('.modal-tab-btn').forEach(tb => {
      tb.onclick = () => {
        this.backdrop.querySelectorAll('.modal-tab-btn').forEach(b => b.classList.remove('active'));
        tb.classList.add('active');
        currentFilter = tb.dataset.cat;
        renderList(currentFilter, searchInput.value);
      };
    });

    renderList('all');
  }

  // --- Balance My Day Before/After Modal (Requirement 7) ---
  openBalanceModal(currentPlan, balancedPlan, onAccept) {
    if (!this.backdrop) return;

    this.backdrop.innerHTML = `
      <div class="roam-modal-dialog balance-dialog" role="dialog" aria-modal="true">
        <button class="modal-close-btn" aria-label="Close">&times;</button>
        
        <div class="modal-header-strip">
          <span style="font-size:0.8rem; font-weight:800; color:var(--roam-accent); letter-spacing:0.1em; text-transform:uppercase;">
            ⚡ SCHEDULE OPTIMIZER
          </span>
          <span style="font-size:0.75rem; color:var(--load-optimal); font-weight:700; font-family:var(--font-mono);">
            SAVES ~50 MIN QUEUE TIME
          </span>
        </div>

        <div class="modal-body-content">
          <h2 style="font-size:1.5rem; font-weight:900; color:#fff; margin-bottom:8px;">ROAM DAY REBALANCING</h2>
          <p style="font-size:0.88rem; color:var(--text-secondary); margin-bottom:16px;">
            We analyzed crowd curves, midday heat peaks, and travel distances across your itinerary to eliminate queue fatigue and cross-city backtracking.
          </p>

          <div class="balance-compare-grid">
            <div class="balance-col current-col">
              <div class="balance-col-header">YOUR CURRENT DAY</div>
              <div class="balance-col-list">
                ${currentPlan.map(item => `
                  <div class="balance-plan-item">
                    <span class="balance-time">${item.time}</span>
                    <span class="balance-name">${item.name}</span>
                    <span class="balance-badge ${item.isOvercrowded ? 'badge-critical' : 'badge-optimal'}">
                      ${item.isOvercrowded ? 'Very Busy' : 'Quiet'}
                    </span>
                  </div>
                `).join('')}
              </div>
            </div>

            <div class="balance-col optimized-col">
              <div class="balance-col-header" style="color:var(--load-optimal);">ROAM SUGGESTS</div>
              <div class="balance-col-list">
                ${balancedPlan.map(item => `
                  <div class="balance-plan-item">
                    <span class="balance-time" style="color:var(--load-optimal); font-weight:800;">${item.time}</span>
                    <span class="balance-name">${item.name}</span>
                    <span class="balance-badge badge-optimal">
                      Quiet & Cool
                    </span>
                  </div>
                `).join('')}
              </div>
            </div>
          </div>

          <!-- Why ROAM Recommends This (Requirement 7) -->
          <div class="roam-says-box" style="margin-top:16px;">
            <div class="roam-says-label">WHY?</div>
            <ul class="why-list" style="margin-top:6px;">
              <li><span class="why-check">✓</span> <strong>Less crowd:</strong> Heavy monuments moved to 08:30 skips tour bus surges and ticketing queues.</li>
              <li><span class="why-check">✓</span> <strong>Less waiting:</strong> Avoids midday peak hours (11:30–14:00) where waiting times exceed 50 minutes.</li>
              <li><span class="why-check">✓</span> <strong>Better travel flow:</strong> Groups sites geographically to reduce transit backtracking.</li>
              <li><span class="why-check">✓</span> <strong>More time for local experiences:</strong> Unlocks relaxed afternoon windows for artisan bazaars.</li>
            </ul>
          </div>

          <div class="modal-actions-row">
            <button class="btn btn-secondary modal-cancel-btn" id="balance-cancel-btn">
              Keep Current Schedule
            </button>
            <button class="btn btn-primary modal-apply-btn" id="balance-apply-btn">
              ⚡ ACCEPT CHANGES
            </button>
          </div>
        </div>
      </div>
    `;

    this.backdrop.classList.add('active');
    document.body.classList.add('modal-open');

    this.backdrop.querySelector('.modal-close-btn').onclick = () => this.closeAll();
    this.backdrop.querySelector('#balance-cancel-btn').onclick = () => this.closeAll();
    
    const applyBtn = this.backdrop.querySelector('#balance-apply-btn');
    applyBtn.onclick = () => {
      if (onAccept) onAccept();
      this.showToast('Day schedule successfully rebalanced!');
      this.closeAll();
    };
  }
}
