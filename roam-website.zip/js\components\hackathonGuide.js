/**
 * ROAM 90-Second Hackathon Demo Tour Guide
 * Interactive walkthrough guiding judges through the complete thesis & platform.
 */

export class HackathonGuide {
  constructor(appController) {
    this.app = appController;
    this.currentStep = 0;
    this.steps = [
      {
        step: 1,
        title: 'Step 1: Destination Load Map & ROAM Radar',
        badge: 'LIVING DESTINATION INTELLIGENCE',
        desc: 'Observe the ROAM Radar & Load Map. In Jaipur, Amber Fort (94%) and Hawa Mahal (91%) suffer extreme congestion while underutilized master craft clusters and tranquil stepwells sit at under 25% capacity.',
        actionLabel: 'Next: Explore "Beyond The City" Rural Layer ➔',
        run: () => {
          this.app.switchMode('discover');
          window.scrollTo({ top: 350, behavior: 'smooth' });
        }
      },
      {
        step: 2,
        title: 'Step 2: "Beyond The City" Rural & Craft Guilds',
        badge: 'RURAL EXPLORATION LAYER',
        desc: 'ROAM elevates rural villages like Bagru (natural indigo block printing), Salawas (durrie handweavers), and Kumbalangi (backwaters agro-tourism) as first-class destinations with direct artisan economic spillover.',
        actionLabel: 'Next: Engage ROAM AI Central Agent ➔',
        run: () => {
          this.app.switchMode('discover');
          const ruralEl = document.getElementById('national-discover-mount');
          if (ruralEl) ruralEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      },
      {
        step: 3,
        title: 'Step 3: ROAM AI Central Action Agent',
        badge: 'INTELLIGENT AGENT',
        desc: 'ROAM AI isn\'t just a chat bot—it is an action-dispatching engine powered by 10 sub-engines. It analyzes crowd telemetry and user mood to generate actionable recommendation cards with 1-click itinerary integration.',
        actionLabel: 'Next: Experience "One Day, One Story" ➔',
        run: () => {
          const aiBtn = document.getElementById('roam-ai-floating-cta');
          if (aiBtn) aiBtn.click();
        }
      },
      {
        step: 4,
        title: 'Step 4: "One Day, One Story" & 1-Click Balancing',
        badge: 'DYNAMIC TRAVEL COMMAND CENTER',
        desc: 'In Plan Mode, ROAM structures each day with a narrative arc ("Dawn Rhythms & Royal Fortresses"). When bottlenecks occur, 1-click \'BALANCE MY DAY\' optimizes timing, saving 47+ minutes of queue time.',
        actionLabel: 'Next: Inspect Markets 2.0 & Purchasing Power ➔',
        run: () => {
          this.app.switchMode('plan');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      },
      {
        step: 5,
        title: 'Step 5: Markets 2.0 & "What ₹1,000 Gets You"',
        badge: 'ARTISAN DIRECT ECONOMY',
        desc: 'Discover fair prices and market DNA across Indian cities. The interactive ₹1,000 simulator proves that avoiding tourist commission traps allows travelers to buy authentic handmade goods directly from working families.',
        actionLabel: 'Next: Tourism Demand Equilibrium ➔',
        run: () => {
          this.app.switchMode('market');
          window.scrollTo({ top: 300, behavior: 'smooth' });
        }
      },
      {
        step: 6,
        title: 'Step 6: India\'s Living Destination Intelligence Layer',
        badge: 'FINAL THESIS',
        desc: 'Don\'t just visit India. Understand it. ROAM balances demand across travelers, local businesses, and destination authorities to create a sustainable, culturally deep travel future.',
        actionLabel: 'Complete Tour & Explore ROAM Freely ✓',
        run: () => {
          this.app.switchMode('discover');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }
      }
    ];
  }

  start() {
    this.currentStep = 0;
    this.render();
  }

  next() {
    this.currentStep++;
    if (this.currentStep >= this.steps.length) {
      this.close();
    } else {
      this.render();
    }
  }

  close() {
    const modal = document.getElementById('tour-modal-backdrop');
    if (modal) modal.classList.remove('active');
  }

  render() {
    const modal = document.getElementById('tour-modal-backdrop');
    if (!modal) return;

    const step = this.steps[this.currentStep];
    step.run();

    modal.innerHTML = `
      <div class="tour-modal-card" style="background:var(--roam-card); border:1px solid var(--roam-accent-border); border-radius:var(--radius-lg); padding:var(--space-xl); max-width:540px; margin:10vh auto; box-shadow:var(--shadow-lg);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <span class="badge badge-optimal">${step.badge} • STEP ${step.step} OF ${this.steps.length}</span>
          <button id="tour-close-x" style="background:none; border:none; color:var(--text-muted); font-size:1.4rem; cursor:pointer;">✕</button>
        </div>
        <h3 style="font-size:1.3rem; font-weight:800; color:#fff; margin-bottom:8px;">${step.title}</h3>
        <p style="font-size:0.9rem; color:var(--text-secondary); line-height:1.5; margin-bottom:18px;">${step.desc}</p>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span style="font-size:0.75rem; color:var(--text-muted); font-family:var(--font-mono);">
            90-Sec Hackathon Walkthrough
          </span>
          <button id="tour-next-btn" class="reroute-btn" style="padding:8px 18px; font-size:0.85rem;">
            ${step.actionLabel}
          </button>
        </div>
      </div>
    `;

    modal.classList.add('active');

    document.getElementById('tour-close-x')?.addEventListener('click', () => this.close());
    document.getElementById('tour-next-btn')?.addEventListener('click', () => this.next());
  }
}
