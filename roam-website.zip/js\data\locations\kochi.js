/**
 * ROAM — Kochi Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const KOCHI_DATA = {
  "id": "kochi",
  "name": "Kochi",
  "type": "CITY",
  "state": "Kerala",
  "district": "Ernakulam",
  "region": "SOUTH",
  "culturalRegion": "Malabar Coast & Vembanad Estuary",
  "tagline": "Queen of the Arabian Sea",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE SPICE COAST HAS NATURAL BALANCE.",
    "subheadline": "ROAM detected heavy visitor concentration at Fort Kochi beachfront and open capacity in the heritage spice warehouses of Mattancherry.",
    "overloadedCount": 1,
    "underutilizedCount": 4
  },
  "metrics": {
    "totalDailyTourists": 38000,
    "averageAttractionLoad": 52,
    "visitorConcentration": 72,
    "tourismDistributionStatus": "Beachfront Fishing Nets Bottleneck",
    "localBusinessOpportunity": "High Spice & Antique Craft Value",
    "monumentsAtRisk": 1,
    "avgWaitTimeMinutes": 30,
    "localEconomyCapturePct": 22
  },
  "culturalDNA": {
    "knownFor": [
      "Cantilevered Chinese Fishing Nets (Cheena Vala)",
      "Historic Mattancherry Spice Bazaars & Pepper Warehouses",
      "Jewish Synagogue & Jew Town Antique Warehouses",
      "Classical Kathakali & Kalaripayattu Martial Arts"
    ],
    "taste": [
      "Appam with Vegetable / Chicken Stew in coconut milk",
      "Kerala Sadya served on fresh banana leaf with 24 curries",
      "Karimeen Pollichathu (Pearl spot fish baked in banana leaf with shallots)",
      "Puttu with Kadala Curry & steamed banana"
    ],
    "architecture": [
      "Chinese Fishing Nets (Teak wood counterbalanced sea rigs)",
      "Paradesi Synagogue (1568 glass chandeliers & Chinese porcelain tiles)",
      "Mattancherry Palace / Dutch Palace (Murals depicting Ramayana)",
      "Santa Cruz Basilica (Heritage Gothic cathedral)",
      "Dutch and Portuguese colonial bungalows with terracotta tile roofs"
    ],
    "markets": [
      "Jew Town (Centuries-old antique shops, brass urulis & teak furniture)",
      "Broadway Ernakulam (Bustling local trade in spices, fabrics & copper)",
      "Bazaar Road Mattancherry (Aromatic ginger, pepper & clove warehouses)",
      "Fort Kochi Beach Artisan Shacks (Shell crafts & handloom cotton)"
    ],
    "festivals": [
      "Kochi-Muziris Biennale (International contemporary art festival)",
      "Cochin Carnival (New Year vibrant street pageantry & giant Pappanji)",
      "Uthralikkavu Pooram (Temple elephant & Panchavadyam percussion)"
    ],
    "localRhythm": "Morning walk past the Chinese fishing nets at sunrise, slow bicycle exploration of Mattancherry spice lanes, afternoon courtyard cafe lunch, and evening Kathakali makeup viewing."
  },
  "liveLikeALocal": [
    {
      "icon": "🐟",
      "title": "Fresh Catch from the Nets",
      "description": "Buy fish directly from the Cheena Vala fishermen as the nets rise at 08:00 AM, and take it to the family cook-shacks 50 meters away to have it grilled with fresh Malabar masala."
    },
    {
      "icon": "🌿",
      "title": "Smell Pure Black Pepper on Bazaar Road",
      "description": "Cycle down Bazaar Road in Mattancherry where gunny sacks of green cardamom, cloves, and Malabar black pepper are weighed on vintage scales."
    },
    {
      "icon": "☕",
      "title": "Iced Spiced Coffee at Kashi",
      "description": "Cool down in the shaded sculpture courtyard of Kashi Art Cafe with iced cinnamon filter coffee and their signature dense chocolate cake."
    },
    {
      "icon": "🛶",
      "title": "Ro-Ro Ferry to Vypin",
      "description": "Skip costly tourist cruises; take the public Ro-Ro ferry across the harbor channel to Vypin island for ₹6 for a stunning view of container ships and fishing boats."
    },
    {
      "icon": "🎭",
      "title": "Watch Kathakali Makeup at 17:00",
      "description": "Arrive at the Kerala Kathakali Centre an hour before the show to watch the actors grind natural mineral pigments and paint their own faces in silent meditation."
    }
  ],
  "attractions": [
    {
      "id": "chinese-fishing-nets",
      "name": "Chinese Fishing Nets (Cheena Vala)",
      "category": "nature",
      "coords": {
        "x": 460,
        "y": 320,
        "lat": 9.9675,
        "lng": 76.2415
      },
      "capacityMax": 3500,
      "currentVisitors": 3100,
      "loadPercentage": 88,
      "status": "critical",
      "averageVisitMinutes": 60,
      "entryFeeINR": 0,
      "currentWaitMinutes": 20,
      "openHours": "Open 24 Hours",
      "description": "Iconic 14th-century cantilevered sea nets operating with counterweighted stones and bamboo poles along Fort Kochi beachfront.",
      "whyCongested": "Tourists gather tightly along the promenade at sunset; touts push fish-pulling photo fees.",
      "roamResponse": "Redirect to Dutch Palace Mattancherry and Jew Town heritage district.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "mattancherry-palace",
      "secondaryAlternativeId": "jew-town",
      "nearbyBusinessIds": [
        "jew-town-antiques",
        "kashi-art-cafe"
      ],
      "bestTime": {
        "bestHours": "06:30 — 08:30",
        "avoidHours": "17:00 — 19:00",
        "why": "Fishermen are actively landing early morning catches; soft dawn mist without the sunset tourist crowd."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 446,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 464,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 611,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 758,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 906,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 1053,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 1200,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 1053,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "20:00",
          "visitors": 906,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    },
    {
      "id": "mattancherry-palace",
      "name": "Mattancherry Palace (Dutch Palace)",
      "category": "heritage",
      "coords": {
        "x": 550,
        "y": 390,
        "lat": 9.9583,
        "lng": 76.2592
      },
      "capacityMax": 2000,
      "currentVisitors": 620,
      "loadPercentage": 31,
      "status": "optimal",
      "averageVisitMinutes": 75,
      "entryFeeINR": 10,
      "currentWaitMinutes": 0,
      "openHours": "09:45 — 13:00, 14:00 — 16:45 (Closed Fri)",
      "description": "Portuguese-built, Dutch-renovated royal palace with magnificent 16th-century tempera murals depicting the Ramayana.",
      "whyCongested": "Shaded courtyard design and museum security manage flow comfortably with no outdoor line.",
      "roamResponse": "PRIMARY SURROGATE: World-class murals, serene wooden architecture, and ₹10 entry.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "chinese-fishing-nets",
      "nearbyBusinessIds": [
        "jew-town-antiques"
      ],
      "bestTime": {
        "bestHours": "10:00 — 12:30",
        "avoidHours": "None (Very comfortable)",
        "why": "Quiet galleries with rich natural ventilation."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 266,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 314,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 362,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "11:00",
          "visitors": 410,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "12:00",
          "visitors": 362,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "13:00",
          "visitors": 314,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 266,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 218,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 170,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 164,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "jew-town-antiques",
      "name": "Jew Town Heritage Antiques & Spices",
      "category": "markets",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Synagogue Lane, Mattancherry",
      "coords": {
        "x": 560,
        "y": 410,
        "lat": 9.9575,
        "lng": 76.2598
      },
      "distanceKm": 1.4,
      "transitMinutes": 12,
      "estimatedActivity": 820,
      "activityStatus": "QUIET",
      "bestTime": "10:30 — 13:00",
      "quietestTime": "14:30 — 17:00",
      "specialty": "Carved Teak Doors, Brass Urulis, Spices & Vintage Maps",
      "priceRange": "₹200 — ₹18,000",
      "rating": 4.9,
      "reviewsCount": 1450,
      "whyRecommended": [
        "Historic 500-year-old Jewish merchant street",
        "Incredible collection of Kerala temple woodwork and colonial artifacts",
        "Direct spice merchants selling export-grade Tellicherry peppercorns",
        "Leisurely, peaceful atmosphere away from vehicular traffic"
      ],
      "roamSays": "A treasure trove of maritime and colonial history. Walk among giant brass cooking vessels (urulis), carved snake-boat prows, and the unmistakable scent of dried ginger.",
      "googleMapsQuery": "Jew Town, Mattancherry, Kochi"
    },
    {
      "id": "kashi-art-cafe",
      "name": "Kashi Art Cafe & Gallery",
      "category": "food",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Burgher Street, Fort Kochi",
      "coords": {
        "x": 470,
        "y": 340,
        "lat": 9.9652,
        "lng": 76.2432
      },
      "distanceKm": 0.4,
      "transitMinutes": 5,
      "estimatedActivity": 450,
      "activityStatus": "QUIET",
      "bestTime": "11:00 — 14:30",
      "quietestTime": "15:00 — 17:00",
      "specialty": "Organic Kerala Roast Coffee & Farm Fresh Lunches",
      "priceRange": "₹180 — ₹550",
      "rating": 4.8,
      "reviewsCount": 2190,
      "whyRecommended": [
        "The heart of Fort Kochi’s contemporary art movement",
        "Relaxed open-air courtyard with rotating sculpture installations",
        "Freshly baked artisan breads and locally sourced organic ingredients",
        "Ideal cool sanctuary during midday tropical humidity"
      ],
      "roamSays": "Step off the sun-drenched street into this leafy, tranquil courtyard cafe for great locally roasted Malabar coffee and inspiring contemporary art.",
      "googleMapsQuery": "Kashi Art Cafe, Fort Kochi"
    },
    {
      "id": "kayees-rahmathulla-hotel",
      "name": "Kayees Rahmathulla Hotel (Est. 1948)",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Mattancherry Heritage Quarter",
      "coords": {
        "x": 540,
        "y": 440,
        "lat": 9.9545,
        "lng": 9.9545,
        "lng": 76.2575
      },
      "distanceKm": 1.6,
      "transitMinutes": 12,
      "estimatedActivity": 690,
      "activityStatus": "MODERATE",
      "bestTime": "12:00 — 14:00",
      "quietestTime": "14:00 — 15:30",
      "specialty": "Legendary Malabar Mutton Dum Biryani cooked with Kaima rice",
      "priceRange": "₹220 — ₹450",
      "rating": 4.9,
      "reviewsCount": 3890,
      "whyRecommended": [
        "Founded by V.K. Kayee in 1948, celebrated as Kerala’s finest dum biryani",
        "Cooked with fragrant short-grain Kaima rice, ghee, and tender local mutton",
        "Beloved by Malayalam film stars, sailors, and local merchant families",
        "Served with homemade date pickle, mint chammanthi, and spiced curd"
      ],
      "roamSays": "Arrive promptly around 12:30 PM for lunch. Their aromatic mutton biryani sells out daily within two hours of the copper deg opening.",
      "googleMapsQuery": "Kayees Rahmathulla Hotel, Mattancherry, Kochi"
    },
    {
      "id": "spice-market-bazaar-road",
      "name": "Bazaar Road Historic Spice Warehouses",
      "category": "markets",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Bazaar Road Maritime Wharf",
      "coords": {
        "x": 550,
        "y": 380,
        "lat": 9.9612,
        "lng": 76.2542
      },
      "distanceKm": 1.1,
      "transitMinutes": 8,
      "estimatedActivity": 480,
      "activityStatus": "QUIET",
      "bestTime": "10:00 — 14:00",
      "quietestTime": "11:00 — 15:00",
      "specialty": "Sun-dried Malabar Peppercorns, Cardamom, Nutmeg & Cinnamon",
      "priceRange": "₹150 — ₹3,200",
      "rating": 4.8,
      "reviewsCount": 980,
      "whyRecommended": [
        "Centuries-old trade strip where spices are weighed on huge antique scales",
        "Aroma of cloves, turmeric, and star anise filling open warehouse doorways",
        "Wholesale direct pricing with master spice graders",
        "Walkable cobbled lane connecting Fort Kochi to Mattancherry"
      ],
      "roamSays": "Watch workers sort fresh sun-dried black pepper into jute sacks in old Dutch-era tile roof godowns along the backwater wharf.",
      "googleMapsQuery": "Bazaar Road Spice Market, Mattancherry, Kochi"
    },
    {
      "id": "coir-village-crafts",
      "name": "Kerala Coir & Handloom Guild",
      "category": "crafts",
      "badge": "COMMUNITY GUILD",
      "badgeClass": "badge-optimal",
      "zone": "Princess Street Enclave",
      "coords": {
        "x": 460,
        "y": 350,
        "lat": 9.9665,
        "lng": 76.2425
      },
      "distanceKm": 0.5,
      "transitMinutes": 6,
      "estimatedActivity": 320,
      "activityStatus": "QUIET",
      "bestTime": "10:30 — 16:30",
      "quietestTime": "11:30 — 15:00",
      "specialty": "Coconut Fibre Mats, Hand-Woven Kasavu Cotton & Teak Spoons",
      "priceRange": "₹80 — ₹1,400",
      "rating": 5.0,
      "reviewsCount": 420,
      "whyRecommended": [
        "Non-profit artisan cooperative supporting rural women weavers",
        "100% natural, biodegradable coconut husk fibre carpets and baskets",
        "Traditional gold-bordered Kasavu handloom cotton sarees and stoles",
        "Direct ethical craft trade without dealer markups"
      ],
      "roamSays": "Purchase authentic, sustainable coconut coir crafts and handloom Kerala cotton directly from the artisan guild.",
      "googleMapsQuery": "Kerala Coir Village Crafts, Fort Kochi"
    },
    {
      "id": "kathakali-centre-kochi",
      "name": "Kerala Kathakali Centre (Est. 1990)",
      "category": "crafts",
      "badge": "SACRED ARTS",
      "badgeClass": "badge-optimal",
      "zone": "KB Jacob Road, Fort Kochi",
      "coords": {
        "x": 480,
        "y": 360,
        "lat": 9.9645,
        "lng": 76.2448
      },
      "distanceKm": 0.4,
      "transitMinutes": 5,
      "estimatedActivity": 260,
      "activityStatus": "QUIET",
      "bestTime": "17:00 — 19:30",
      "quietestTime": "17:00 — 18:00",
      "specialty": "Live Kathakali Facial Mineral Painting, Kalaripayattu Martial Arts & Carnatic Music",
      "priceRange": "₹400 — ₹600",
      "rating": 4.9,
      "reviewsCount": 2150,
      "whyRecommended": [
        "Intimate traditional wooden theater with oil lamps",
        "Arrive at 5:00 PM to observe artists apply natural mineral face paint in silent meditation",
        "English explanations of facial mudras and storytelling eye movements",
        "World-class preservation of UNESCO intangible cultural heritage"
      ],
      "roamSays": "Arrive early at 5 PM to sit inches away from the stage and witness the hypnotic, meditative transformation as performers apply natural mineral pigments.",
      "googleMapsQuery": "Kerala Kathakali Centre, Fort Kochi"
    },
    {
      "id": "malabar-banana-chips",
      "name": "A-One Fresh Malabar Banana Chips & Halwa",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Mattancherry Clock Tower Strip",
      "coords": {
        "x": 570,
        "y": 420,
        "lat": 9.9582,
        "lng": 76.2612
      },
      "distanceKm": 1.5,
      "transitMinutes": 11,
      "estimatedActivity": 580,
      "activityStatus": "MODERATE",
      "bestTime": "11:00 — 16:00",
      "quietestTime": "12:00 — 14:00",
      "specialty": "Hot Raw Nendran Banana Chips fried in Pure Coconut Oil & Kozhikode Halwa",
      "priceRange": "₹80 — ₹350",
      "rating": 4.8,
      "reviewsCount": 1650,
      "whyRecommended": [
        "Crispy wafer-thin Nendran raw plantains sliced directly into bubbling coconut oil",
        "Piped hot and salted right in front of your eyes without preservatives",
        "Assorted traditional Kozhikode wheat halwa infused with jaggery and cashews",
        "Authentic aroma of fresh Malabar coconut oil"
      ],
      "roamSays": "Get a bag of warm, freshly fried banana chips straight from the brass kadai. The crunch and authentic coconut aroma are unmatched.",
      "googleMapsQuery": "Banana Chips, Mattancherry, Kochi"
    }
  ]
};
