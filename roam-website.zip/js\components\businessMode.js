/**
 * ROAM Business & Market Mode Component (V3.5)
 * "Markets 2.0 — What ₹1,000 Gets You & Artisan Direct Economy"
 *
 * Connected Features:
 * - Market DNA Breakdown (Artisan Guild, Heritage Street Bazaar, Wholesaler)
 * - "What to Buy / What NOT to Buy" Insider Guide
 * - Bargaining Risk Meter & Fair Price Transparency
 * - Interactive "WHAT ₹1,000 GETS YOU" Purchasing Power Simulator
 * - Direct Economic Spillover Telemetry to Local Craftsmen
 * - Intelligent Slot Placement into User's Itinerary
 * - Working Google Maps links (Open in Maps ↗, Get Directions ↗)
 */

import { travelState } from '../state/travelState.js';
import { formatIndianNumber } from '../utils/formatters.js';

// Multi-City "What ₹1,000 Gets You" Purchasing Power Database
const CITY_BUDGET_SIMULATOR = {
  jaipur: {
    cityName: 'Jaipur',
    local: {
      items: [
        { icon: '🧵', name: 'Authentic Hand-Block Cotton Stole', cost: '₹450', note: 'Bought directly from master artisan guild in Old City' },
        { icon: '🍛', name: 'Heritage Dal Baati / Thali Lunch', cost: '₹320', note: 'Authentic multi-generational dining hall' },
        { icon: '☕', name: '4x Fresh Kulhad Masala Chai & Samosa', cost: '₹120', note: 'Brewed fresh in brass deg over slow coal fire' },
        { icon: '🏺', name: 'Handmade Terracotta Diya Souvenir', cost: '₹80', note: 'Hand-molded in Kumhar potter colony' }
      ],
      total: '₹970',
      summary: '100% of spending went directly to local working families and generational guilds.'
    },
    tourist: {
      items: [
        { icon: '🧣', name: 'Machine-Printed Synthetic Scarf', cost: '₹850', note: 'Sold at monument entrance (40% driver kickback built-in)' },
        { icon: '🥤', name: '1 Bottled Soda at Highway Buffet', cost: '₹150', note: 'Marked up 300% over printed MRP' }
      ],
      total: '₹1,000',
      summary: 'You received 1 synthetic item and 60% of value was lost to tour commissions.'
    }
  },
  jodhpur: {
    cityName: 'Jodhpur',
    local: {
      items: [
        { icon: '🧵', name: 'Handwoven Durrie Rug Coaster Set', cost: '₹400', note: 'Salawas village weaver cooperative direct purchase' },
        { icon: '🥟', name: 'Pyaaz Kachori & Mirchi Vada Feast', cost: '₹160', note: 'Generational sweet shop in Clock Tower bazaar' },
        { icon: '☕', name: 'Authentic Mawa Kachori & Masala Chai', cost: '₹180', note: 'Freshly fried in pure desi ghee' },
        { icon: '🐫', name: 'Hand-cast Brass Camel Souvenir', cost: '₹240', note: 'Old City metalcraft guild workshop' }
      ],
      total: '₹980',
      summary: 'Direct economic injection into Salawas village weavers and Old City sweetmakers.'
    },
    tourist: {
      items: [
        { icon: '🎁', name: 'Mass-Produced Plastic Trinket & Magnet', cost: '₹750', note: 'Sold at fort exit plaza with tour guide referral fee' },
        { icon: '💧', name: 'Overpriced Bottled Mineral Water', cost: '₹250', note: 'High-margin tourist restaurant markup' }
      ],
      total: '₹1,000',
      summary: 'Zero artisan benefit: 75% retained by commercial intermediary.'
    }
  },
  kochi: {
    cityName: 'Kochi',
    local: {
      items: [
        { icon: '🌿', name: '500g Tellicherry Pepper & Cardamom', cost: '₹420', note: 'Mattancherry spice warehouse cooperative direct' },
        { icon: '🐟', name: 'Banana Leaf Kerala Fish Curry Meal', cost: '₹260', note: 'Harbour-side generational cookhouse' },
        { icon: '☕', name: '4x Steaming Filter Coffee & Hot Appam', cost: '₹140', note: 'Heritage Fort Kochi roadside tea stall' },
        { icon: '🥥', name: 'Hand-carved Coconut Shell Craft', cost: '₹160', note: 'Direct from Fort Kochi women’s craft guild' }
      ],
      total: '₹980',
      summary: '100% direct value to Malabar spice growers and coastal fisherfolk.'
    },
    tourist: {
      items: [
        { icon: '🧴', name: 'Industrial Scented Mineral Oil "Elixir"', cost: '₹850', note: 'Fake Ayurvedic bottle sold with 50% taxi commission' },
        { icon: '🧃', name: 'Packaged Soda & Factory Biscuits', cost: '₹150', note: 'Highway tourist rest-stop markup' }
      ],
      total: '₹1,000',
      summary: 'Commercial trap: chemical perfume oil with no therapeutic origin.'
    }
  },
  varanasi: {
    cityName: 'Varanasi',
    local: {
      items: [
        { icon: '🧵', name: 'Handwoven Banarasi Brocade Silk Scarf', cost: '₹550', note: 'Madanpura pit-loom master weaver direct' },
        { icon: '🍲', name: 'Kachori Sabzi, Poori & Cloud Malaiyo', cost: '₹220', note: 'Generational Chaukhamba gali morning breakfast' },
        { icon: '☕', name: '4x Assi Ghat Dawn Kulhad Chai', cost: '₹100', note: 'Brewed with fresh buffalo milk & riverfront spices' },
        { icon: '🪔', name: 'Handmade Terracotta Ganga Diya Set', cost: '₹100', note: 'Traditional Dom Raja clay potter community' }
      ],
      total: '₹970',
      summary: 'Supported 2 hereditary weaver families and 1 sacred ghat clay artisan.'
    },
    tourist: {
      items: [
        { icon: '🥻', name: 'Synthetic Polyester Scarf', cost: '₹900', note: 'Sold as "Pure Antique Silk" with 50% commission' },
        { icon: '🥤', name: '1 Packaged Bottled Water & Soft Drink', cost: '₹100', note: 'Commercial hotel markup' }
      ],
      total: '₹1,000',
      summary: 'Zero genuine silk: machine synthetic fabric imported from industrial mills.'
    }
  },
  delhi: {
    cityName: 'Delhi',
    local: {
      items: [
        { icon: '🌶️', name: 'Grade-A Kashmiri Saffron & Whole Spices', cost: '₹480', note: 'Khari Baoli wholesale spice gully direct' },
        { icon: '🍛', name: 'Slow-Cooked Nihari & Khameeri Roti Feast', cost: '₹280', note: '100-year-old Old Delhi culinary institution' },
        { icon: '🍯', name: 'Fresh Jalebi with Rabri & Kulhad Chai', cost: '₹150', note: 'Chandni Chowk pure ghee sweetmaker' },
        { icon: '📖', name: 'Handmade Recycled Paper Diary & Bookmark', cost: '₹90', note: 'Crafts Museum artisan demonstration shed' }
      ],
      total: '₹1,000',
      summary: '100% value captured by wholesale spice traders and legacy cooks.'
    },
    tourist: {
      items: [
        { icon: '🗽', name: 'Resin Molded Miniature Taj Monument', cost: '₹800', note: 'Plastic souvenir sold at monument parking lot' },
        { icon: '🥤', name: '1 Commercial Soda in Tourist Foodcourt', cost: '₹200', note: 'Marked up 250% over street retail' }
      ],
      total: '₹1,000',
      summary: 'Factory plastic trinket manufactured in industrial plant.'
    }
  },
  mumbai: {
    cityName: 'Mumbai',
    local: {
      items: [
        { icon: '🍞', name: 'Brun Maska, Keema Pav & Sweet Irani Chai', cost: '₹290', note: '110-year-old heritage Persian Irani cafe' },
        { icon: '🐟', name: 'Fresh Catch Koli Seafood Lunch Thali', cost: '₹380', note: 'Indigenous Versova Koliwada fishing village cook' },
        { icon: '👡', name: 'Handcrafted Leather Kolhapuri Chappals', cost: '₹280', note: 'Fort heritage leather craft arcade direct' },
        { icon: '🥥', name: '2x Fresh Sweet Tender Coconut Water', cost: '₹50', note: 'Sourced from coastal Maharashtra palms' }
      ],
      total: '₹1,000',
      summary: 'Supported indigenous Koli fisherwomen, heritage Irani bakeries, and leather tanners.'
    },
    tourist: {
      items: [
        { icon: '🔮', name: 'Gateway of India Souvenir Snowglobe', cost: '₹850', note: 'Touted at tourist pier with 40% commission' },
        { icon: '🥤', name: '1 Canned Iced Tea at Tour Bus Stop', cost: '₹150', note: 'Standard tourist transport markup' }
      ],
      total: '₹1,000',
      summary: 'Plastic snowglobe made in bulk factory: no artisanal provenance.'
    }
  }
};

export class BusinessModeController {
  constructor(appInstance) {
    this.app = appInstance;
    this.activeCategory = 'fits_plan';
    this.activeBudgetTab = 'local'; // 'local' | 'tourist'
    this.activeBudgetCity = 'jaipur'; // default simulator city
    this.mount = document.getElementById('market-view-mount');

    // Subscribe to travelState changes
    travelState.subscribe((event) => {
      if (['itinerary:updated', 'interests:changed', 'location:changed', 'route:changed'].includes(event)) {
        if (this.app?.activeMode === 'market') {
          this.render();
        }
      }
    });
  }

  setDestination(locationData) {
    this.activeCategory = 'fits_plan';
    if (locationData && CITY_BUDGET_SIMULATOR[locationData.id]) {
      this.activeBudgetCity = locationData.id;
    }
    this.render();
  }

  render() {
    if (!this.mount) {
      this.mount = document.getElementById('market-view-mount');
      if (!this.mount) return;
    }

    const location = travelState.location;
    const city = location?.name || 'Jaipur';
    const locId = location?.id || 'jaipur';
    const businesses = location?.localBusinesses || [];
    const openSlots = travelState.openSlots;
    const activeSlot = openSlots[0];
    const activeRoute = travelState.activeRoute || 'all';

    // Current budget data
    const budgetData = CITY_BUDGET_SIMULATOR[this.activeBudgetCity] || CITY_BUDGET_SIMULATOR[locId] || CITY_BUDGET_SIMULATOR.jaipur;
    const budgetCityDisplay = budgetData.cityName.toUpperCase();
    const budgetPlan = this.activeBudgetTab === 'local' ? budgetData.local : budgetData.tourist;

    // Enrich businesses with dynamic ROAM intelligence & Market DNA
    const enriched = businesses.map(shop => {
      let score = 20;
      const whyList = [];

      const distMin = shop.transitMinutes || 12;
      whyList.push(`${distMin} min from your itinerary corridor`);
      score += Math.max(0, 30 - distMin);

      if (activeSlot) {
        whyList.push(`Fits your ${activeSlot.startTime} open free window`);
        score += 25;
      } else {
        whyList.push(`Comfortable visit duration (~${shop.durationMinutes || 75}m)`);
      }

      whyList.push(`Authentic ${city} ${shop.specialty || 'cultural heritage'}`);

      if (shop.activityStatus === 'QUIET') {
        whyList.push(`Activity is ~${formatIndianNumber(shop.estimatedActivity)} (significantly quieter than monuments)`);
        score += 20;
      } else {
        whyList.push(`Best visited during ${shop.bestTime || 'off-peak hours'}`);
      }

      if (travelState.hasInterest(shop.category) || travelState.hasInterest('shopping')) {
        whyList.push(`Matches your active interest in ${shop.category}`);
        score += 15;
      }

      // Determine Market DNA type
      let marketDna = 'HERITAGE STREET BAZAAR';
      let bargainingRisk = 'Moderate (20-30% flexibility)';
      let bargainingRiskColor = '#f59e0b';

      if (shop.category === 'crafts' || shop.name.toLowerCase().includes('guild') || shop.name.toLowerCase().includes('handloom') || shop.name.toLowerCase().includes('pottery')) {
        marketDna = 'DIRECT ARTISAN GUILD';
        bargainingRisk = 'Low (Fair fixed artisan pricing)';
        bargainingRiskColor = '#10b981';
      } else if (shop.category === 'food' || shop.category === 'dining') {
        marketDna = 'LEGENDARY HERITAGE EATERY';
        bargainingRisk = 'Zero (Strictly fixed menu pricing)';
        bargainingRiskColor = '#10b981';
      } else if (shop.name.toLowerCase().includes('causeway') || shop.name.toLowerCase().includes('chowk') || shop.name.toLowerCase().includes('bazaar')) {
        marketDna = 'HISTORIC WHOLESALE & RETAIL BAZAAR';
        bargainingRisk = 'High (Quote marked up 40-50%)';
        bargainingRiskColor = '#ef4444';
      }

      return {
        ...shop,
        roamScore: score,
        dynamicWhy: whyList,
        marketDna,
        bargainingRisk,
        bargainingRiskColor
      };
    });

    // Filter businesses
    let filtered = enriched;
    if (this.activeCategory === 'fits_plan') {
      filtered = enriched.sort((a, b) => b.roamScore - a.roamScore);
    } else if (this.activeCategory === 'quieter_now') {
      filtered = enriched.filter(b => b.activityStatus === 'QUIET');
    } else if (this.activeCategory === 'crafts') {
      filtered = enriched.filter(b => b.category === 'crafts');
    } else if (this.activeCategory === 'food') {
      filtered = enriched.filter(b => b.category === 'food' || b.category === 'dining');
    } else if (this.activeCategory === 'markets') {
      filtered = enriched.filter(b => b.category === 'markets' || b.category === 'shopping');
    } else if (this.activeCategory === 'local_favourites') {
      filtered = enriched.filter(b => b.badge === 'LOCAL FAVOURITE' || b.badge === 'ROAM CURATED');
    }

    const categories = [
      { id: 'fits_plan', label: '🎯 Fits Your Plan' },
      { id: 'quieter_now', label: '🟢 Quieter Now' },
      { id: 'crafts', label: '🏺 Direct Artisan Guilds' },
      { id: 'food', label: '🍛 Authentic Eateries' },
      { id: 'markets', label: '🛍️ Historic Bazaars' },
      { id: 'local_favourites', label: '⭐ Local Favourites' },
      { id: 'all', label: 'All Curated' }
    ];

    const budgetCityKeys = ['jaipur', 'jodhpur', 'kochi', 'varanasi', 'delhi', 'mumbai'];

    this.mount.innerHTML = `
      <!-- Market Hero Section -->
      <div class="market-hero-card">
        <div class="market-hero-top">
          <div>
            <div class="plan-eyebrow">
              MARKETS 2.0 • DIRECT ARTISAN ECONOMY
            </div>
            <h2 class="market-hero-title">WHERE DO LOCALS GO IN ${city.toUpperCase()}?</h2>
            <p class="market-hero-subtitle">
              Generational craft workshops, authentic bazaar lanes, and heritage eateries recommended for cultural authenticity rather than tour guide kickbacks.
            </p>
          </div>

          <div class="market-honesty-pill">
            <span class="honesty-dot"></span>
            <span>DIRECT ECONOMIC TELEMETRY • NO KICKBACKS</span>
          </div>
        </div>

        <!-- Interactive "WHAT ₹1,000 GETS YOU" Component -->
        <div class="what-1000-gets-you-card">
          <div class="what-1000-header">
            <div style="display:flex; align-items:center; gap:10px;">
              <span style="font-size:1.6rem;">💰</span>
              <div>
                <div class="what-1000-title">WHAT ₹1,000 GETS YOU IN ${budgetCityDisplay}</div>
                <div class="what-1000-sub">Comparing the Tourist Commission Trap vs. The ROAM Verified Route</div>
              </div>
            </div>

            <!-- Route Mode Toggle -->
            <div class="what-1000-pills">
              <button class="budget-toggle-pill ${this.activeBudgetTab === 'local' ? 'active' : ''}" data-tab="local">
                🌿 ROAM Verified Route
              </button>
              <button class="budget-toggle-pill ${this.activeBudgetTab === 'tourist' ? 'active' : ''}" data-tab="tourist">
                ⚠️ Standard Tourist Trap
              </button>
            </div>
          </div>

          <!-- Multi-City Selector Pills Bar -->
          <div class="budget-city-selector-bar">
            <span class="budget-city-label">SELECT CITY:</span>
            <div class="budget-city-pills">
              ${budgetCityKeys.map(k => `
                <button class="budget-city-pill ${this.activeBudgetCity === k ? 'active' : ''}" data-city="${k}">
                  ${CITY_BUDGET_SIMULATOR[k].cityName}
                </button>
              `).join('')}
            </div>
          </div>

          <!-- Simulator Content Card -->
          <div class="what-1000-content">
            <div class="budget-items-grid">
              ${budgetPlan.items.map(it => `
                <div class="budget-item-card ${this.activeBudgetTab === 'tourist' ? 'trap-item' : ''}">
                  <div class="budget-item-icon">${it.icon}</div>
                  <div class="budget-item-name">${it.name}</div>
                  <div class="budget-item-cost">${it.cost}</div>
                  <div class="budget-item-note">${it.note}</div>
                </div>
              `).join('')}
            </div>
            <div class="budget-summary-banner ${this.activeBudgetTab === 'tourist' ? 'trap-summary' : ''}">
              <strong>TOTAL: ${budgetPlan.total}</strong> — ${budgetPlan.summary}
            </div>
          </div>
        </div>

        <!-- Plan-Aware Context Banner -->
        ${activeSlot ? `
          <div class="plan-aware-banner">
            <div class="banner-sparkle">💡</div>
            <div class="banner-content">
              <div class="banner-title">YOU HAVE ${Math.round(activeSlot.durationMinutes / 60)} HOURS OPEN NEAR CENTRAL ${city.toUpperCase()} (${activeSlot.startTime} — ${activeSlot.endTime}).</div>
              <div class="banner-desc">
                Between ${activeSlot.afterItem?.name || 'morning visits'} and ${activeSlot.beforeItem?.name || 'evening activities'}, ROAM recommends exploring these authentic local bazaars and craft guilds with minimal queues.
              </div>
            </div>
          </div>
        ` : ''}

        <!-- Category Filter Pills -->
        <div class="market-filter-bar">
          ${categories.map(c => `
            <button class="market-filter-btn ${this.activeCategory === c.id ? 'active' : ''}" data-category="${c.id}">
              ${c.label}
            </button>
          `).join('')}
        </div>
      </div>

      <!-- Market Recommendations Grid -->
      <div class="market-cards-grid">
        ${filtered.map(shop => {
          const isQuiet = shop.activityStatus === 'QUIET';
          const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(shop.name + ', ' + city)}`;

          return `
            <div class="market-card" data-id="${shop.id}">
              
              <!-- Card Top Strip -->
              <div class="market-card-top">
                <div>
                  <span class="badge ${shop.badgeClass || 'badge-optimal'}">${shop.badge || 'ROAM CURATED'}</span>
                  <span class="market-zone-label">${shop.zone}</span>
                </div>

                <div class="market-distance-pill">
                  📍 ~${shop.distanceKm || 1.2} km (~${shop.transitMinutes || 12} min)
                </div>
              </div>

              <!-- Shop Title & Specialty -->
              <div style="margin: 10px 0 12px;">
                <h3 class="market-card-title">${shop.name}</h3>
                <div class="market-card-specialty">${shop.specialty}</div>
              </div>

              <!-- Market DNA & Bargaining Risk Meter -->
              <div class="market-dna-box">
                <div class="dna-row">
                  <span class="dna-label">MARKET DNA:</span>
                  <span class="dna-val">${shop.marketDna}</span>
                </div>
                <div class="dna-row">
                  <span class="dna-label">BARGAINING RISK:</span>
                  <span class="dna-val" style="color:${shop.bargainingRiskColor};">${shop.bargainingRisk}</span>
                </div>
              </div>

              <!-- Estimated Area Activity Strip -->
              <div class="activity-strip">
                <div class="activity-strip-left">
                  <div class="activity-strip-label">ESTIMATED ACTIVITY (ROAM FORECAST)</div>
                  <div class="activity-strip-value" style="color:${isQuiet ? 'var(--load-optimal)' : '#f59e0b'};">
                    ~${formatIndianNumber(shop.estimatedActivity)} people • ${shop.activityStatus}
                  </div>
                </div>

                <div class="activity-strip-right">
                  <div class="activity-strip-label">BEST VISITING HOURS</div>
                  <div class="activity-strip-hours">${shop.bestTime || '11:00 — 14:00'}</div>
                </div>
              </div>

              <!-- Why ROAM Recommends This -->
              <div class="why-recommends-box">
                <div class="why-recommends-label">WHY ROAM RECOMMENDS THIS</div>
                <ul class="why-recommends-list">
                  ${shop.dynamicWhy.slice(0, 4).map(w => `<li><span class="why-check">✓</span> ${w}</li>`).join('')}
                </ul>
              </div>

              <!-- Bottom Actions -->
              <div class="market-card-actions">
                <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="market-maps-link" onclick="event.stopPropagation();">
                  OPEN IN MAPS ↗
                </a>

                <div style="display:flex; gap:8px;">
                  <button class="btn btn-sm btn-secondary market-view-btn" data-id="${shop.id}">
                    Details
                  </button>
                  <button class="btn btn-sm btn-primary market-add-plan-btn" data-id="${shop.id}">
                    + Add to Plan
                  </button>
                </div>
              </div>

            </div>
          `;
        }).join('')}
      </div>
    `;

    this.attachEventListeners();
  }

  attachEventListeners() {
    if (!this.mount) return;
    const city = travelState.location?.name || 'Jaipur';

    // Budget Tab Switcher
    this.mount.querySelectorAll('.budget-toggle-pill').forEach(btn => {
      btn.onclick = () => {
        this.activeBudgetTab = btn.dataset.tab;
        this.render();
      };
    });

    // Budget City Switcher
    this.mount.querySelectorAll('.budget-city-pill').forEach(btn => {
      btn.onclick = () => {
        this.activeBudgetCity = btn.dataset.city;
        this.render();
      };
    });

    // Category Filter Buttons
    this.mount.querySelectorAll('.market-filter-btn').forEach(btn => {
      btn.onclick = () => {
        this.activeCategory = btn.dataset.category;
        this.render();
      };
    });

    // Card Details Click
    this.mount.querySelectorAll('.market-card').forEach(card => {
      card.onclick = () => {
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === card.dataset.id);
        if (shop && this.app?.modalController) {
          this.app.modalController.openShopDetail(shop, city);
        }
      };
    });

    // Details Button Click
    this.mount.querySelectorAll('.market-view-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop && this.app?.modalController) {
          this.app.modalController.openShopDetail(shop, city);
        }
      };
    });

    // Add to Plan Button Click
    this.mount.querySelectorAll('.market-add-plan-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        const shop = (travelState.location?.localBusinesses || []).find(b => b.id === btn.dataset.id);
        if (shop) {
          const res = travelState.addPlaceIntelligently({
            name: shop.name,
            category: shop.category || 'shopping',
            durationMinutes: 75,
            zone: shop.zone,
            coords: shop.coords,
            distanceKm: shop.distanceKm || 1.2,
            estimatedActivity: shop.estimatedActivity
          });

          if (this.app?.modalController) {
            this.app.modalController.showToast(`Added ${shop.name} at ${res.time} (${res.reason})`);
          }
          this.app.switchMode('plan');
        }
      };
    });
  }
}
