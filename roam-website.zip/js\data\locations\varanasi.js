/**
 * ROAM — Varanasi Destination Intelligence (V3)
 * Full Intelligence Tier: Attractions with Crowd Curves, Curated Bazaars, Cultural DNA
 */

export const VARANASI_DATA = {
  "id": "varanasi",
  "name": "Varanasi",
  "type": "CITY",
  "state": "Uttar Pradesh",
  "district": "Varanasi",
  "region": "NORTH",
  "culturalRegion": "Kashi Riverfront & Bhojpuri Belt",
  "tagline": "The Eternal River City",
  "intelligenceTier": "FULL",
  "heroCopy": {
    "headline": "THE ANCIENT RIVER NEVER STOPS MOVING.",
    "subheadline": "ROAM detected 2 critical riverfront bottlenecks and 5 peaceful sacred sanctuaries along the Ganga corridor.",
    "overloadedCount": 2,
    "underutilizedCount": 5
  },
  "metrics": {
    "totalDailyTourists": 62000,
    "averageAttractionLoad": 71,
    "visitorConcentration": 86,
    "tourismDistributionStatus": "Severe Riverfront Bottleneck",
    "localBusinessOpportunity": "High Artisan Potential",
    "monumentsAtRisk": 2,
    "avgWaitTimeMinutes": 55,
    "localEconomyCapturePct": 16
  },
  "culturalDNA": {
    "knownFor": [
      "84 Ancient Stone Riverfront Ghats on the sacred Ganga",
      "Kashi Vishwanath Jyotirlinga Temple & River Corridor",
      "Centuries-old Banarasi Zari & Kadhwa Silk Handloom Weaving",
      "Evening Ganga Maha Aarti with Brass Incense Lamps"
    ],
    "taste": [
      "Kachori Sabzi & Jalebi (Spiced hing kachori with aloo curry)",
      "Tamatar Chaat (Warm spiced tomato mash with cashews & hing)",
      "Banarasi Meetha Paan (Betel leaf with gulkand & silver foil)",
      "Malaiyo & Blue Lassi (Pistachio saffron froth in terracotta)"
    ],
    "architecture": [
      "Dashashwamedh Ghat (Monumental river steps)",
      "Assi Ghat (Expansive southern sunrise confluence)",
      "Chet Singh Fort Ghat (18th-century fortified river citadel)",
      "Manikarnika & Harishchandra Ghats (Eternal sacred fire grounds)",
      "Kashi Vishwanath Temple (Golden spire sacred sanctum)"
    ],
    "markets": [
      "Thatheri Bazaar (Generational brassware, copper & antiques)",
      "Vishwanath Gali (Puja items, wooden toys & glass bangles)",
      "Madanpura & Chowk Silk Guilds (Master handloom weavers)",
      "Godowlia Market (Lively street shopping & winter shawls)"
    ],
    "festivals": [
      "Dev Deepawali (Over 1 million earthen diyas lighting all 84 ghats)",
      "Maha Shivaratri (All-night procession from Kashi Vishwanath)",
      "Ganga Mahotsav (Classical vocal concerts & river boat races)"
    ],
    "localRhythm": "Wake before dawn for an unmotorized wooden boat row at 05:45 AM, explore winding stone galis for breakfast kachori, rest midday, and view evening aarti from a riverboat."
  },
  "liveLikeALocal": [
    {
      "icon": "🚣",
      "title": "Dawn Wooden Rowboat from Assi",
      "description": "Avoid noisy motorboats; hire a traditional wooden oar-boat at Assi Ghat at 05:45 AM to watch dawn bathe the 84 ghats in rose-gold silence."
    },
    {
      "icon": "🍲",
      "title": "Morning Hing Kachori in Thatheri Gali",
      "description": "Squeeze through the narrow stone lane to Ram Bhandar for piping hot kachoris topped with dry methi chutney on sal-leaf plates."
    },
    {
      "icon": "🧵",
      "title": "Weavers of Madanpura",
      "description": "Walk past commercial tourist showrooms into Madanpura to hear the rhythmic clatter of pit-looms and meet master Ansari weavers directly."
    },
    {
      "icon": "🌅",
      "title": "Quiet Sunset at Chet Singh Ghat",
      "description": "Escape the Dashashwamedh microphone noise and sit on the ramparts of Chet Singh Fort Ghat as local classical musicians practice sitar."
    },
    {
      "icon": "🍃",
      "title": "Keshav Tambool Meetha Paan",
      "description": "End your night near Ravidas Gate with a hand-folded sweet Banarasi paan infused with real gulkand, kattha, and pure silver varq."
    }
  ],
  "attractions": [
    {
      "id": "dashashwamedh-ghat",
      "name": "Dashashwamedh Ghat",
      "category": "spiritual",
      "coords": {
        "x": 520,
        "y": 340,
        "lat": 25.3075,
        "lng": 83.0105
      },
      "capacityMax": 8000,
      "currentVisitors": 7600,
      "loadPercentage": 95,
      "status": "critical",
      "averageVisitMinutes": 90,
      "entryFeeINR": 0,
      "currentWaitMinutes": 50,
      "openHours": "Open 24 Hours • Aarti at 18:30",
      "description": "The most sacred and famous ghat in Kashi, renowned for its choreographed evening brass-lamp Ganga Maha Aarti.",
      "whyCongested": "Tourists, pilgrims, and VIP boats converge between 17:30 and 19:30; stone steps and river surface become completely gridlocked.",
      "roamResponse": "Redirect to Assi Ghat for Subah-e-Banaras morning aarti, or view evening aarti from Chet Singh Ghat.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "assi-ghat",
      "secondaryAlternativeId": "chet-singh",
      "nearbyBusinessIds": [
        "thatheri-bazaar",
        "deena-chaat"
      ],
      "bestTime": {
        "bestHours": "05:30 — 07:30",
        "avoidHours": "17:30 — 19:45",
        "why": "Dawn hours offer gentle morning bathing rituals and soft chanting with 80% fewer tourists than the evening aarti crush."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 822,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 822,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 822,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 822,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 822,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 856,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 1125,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 1394,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 1662,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "17:00",
          "visitors": 1931,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 2200,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 1931,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "20:00",
          "visitors": 1662,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    },
    {
      "id": "kashi-vishwanath",
      "name": "Kashi Vishwanath Temple Corridor",
      "category": "spiritual",
      "coords": {
        "x": 505,
        "y": 320,
        "lat": 25.3109,
        "lng": 83.0107
      },
      "capacityMax": 6000,
      "currentVisitors": 5400,
      "loadPercentage": 90,
      "status": "critical",
      "averageVisitMinutes": 120,
      "entryFeeINR": 0,
      "currentWaitMinutes": 70,
      "openHours": "03:00 — 23:00",
      "description": "One of the 12 sacred Jyotirlingas, recently revitalized with an expansive sandstone corridor connecting temple to Ganga riverfront.",
      "whyCongested": "Pilgrim security queues at Gate 4 back up for hundreds of meters during Mangala and Sandhya aarti times.",
      "roamResponse": "Recommend visiting during off-peak afternoon (14:00 - 15:30) or explore Sarnath Buddhist heritage park.",
      "crowdTrend": "peaking",
      "pairedAlternativeId": "sarnath",
      "secondaryAlternativeId": "assi-ghat",
      "nearbyBusinessIds": [
        "vishwanath-gali",
        "chowk-silk"
      ],
      "bestTime": {
        "bestHours": "13:30 — 15:30",
        "avoidHours": "04:00 — 08:00 & 18:00 — 21:00",
        "why": "The early afternoon window between prayer services has significantly shorter security lines."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 1631,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "09:00",
          "visitors": 1412,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 1192,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 973,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "12:00",
          "visitors": 754,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "15:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "16:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 727,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "assi-ghat",
      "name": "Assi Ghat",
      "category": "spiritual",
      "coords": {
        "x": 540,
        "y": 550,
        "lat": 25.2895,
        "lng": 83.0068
      },
      "capacityMax": 5000,
      "currentVisitors": 1600,
      "loadPercentage": 32,
      "status": "optimal",
      "averageVisitMinutes": 90,
      "entryFeeINR": 0,
      "currentWaitMinutes": 0,
      "openHours": "Open 24 Hours • Subah-e-Banaras 05:30",
      "description": "Southernmost sacred ghat where the Assi river meets the Ganga; famous for sunrise yoga, classical music, and relaxed riverfront cafes.",
      "whyCongested": "Large open stone plaza disperses crowds easily; much less compressed than Dashashwamedh.",
      "roamResponse": "PRIMARY SURROGATE: Sublime morning music concerts, spacious seating, and peaceful boat departures.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "dashashwamedh-ghat",
      "nearbyBusinessIds": [
        "kashi-tea-stall"
      ],
      "bestTime": {
        "bestHours": "05:30 — 08:30 or 16:30 — 18:30",
        "avoidHours": "None (Room all day)",
        "why": "Dawn Subah-e-Banaras features soulful shehnai and morning havana over mist-shrouded river."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 514,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "09:00",
          "visitors": 430,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "10:00",
          "visitors": 347,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "11:00",
          "visitors": 264,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "14:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "15:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "16:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "17:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "18:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "19:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "20:00",
          "visitors": 254,
          "status": "optimal",
          "label": "Quiet"
        }
      ]
    },
    {
      "id": "chet-singh",
      "name": "Chet Singh Ghat & Fort",
      "category": "heritage",
      "coords": {
        "x": 535,
        "y": 460,
        "lat": 25.2977,
        "lng": 83.0084
      },
      "capacityMax": 2500,
      "currentVisitors": 450,
      "loadPercentage": 18,
      "status": "optimal",
      "averageVisitMinutes": 50,
      "entryFeeINR": 0,
      "currentWaitMinutes": 0,
      "openHours": "Open 24 Hours",
      "description": "Imposing 18th-century river fortress where Maharaja Chet Singh defended Kashi against Warren Hastings’ British forces.",
      "whyCongested": "Tour groups rarely stop here, leaving the grand stone towers and wide ghat steps peaceful.",
      "roamResponse": "PRIMARY SURROGATE: Majestic fort architecture, zero crowd pressure, and panoramic river perspectives.",
      "crowdTrend": "steady",
      "pairedAlternativeId": null,
      "isAlternativeFor": "dashashwamedh-ghat",
      "nearbyBusinessIds": [
        "thatheri-bazaar"
      ],
      "bestTime": {
        "bestHours": "16:00 — 18:30",
        "avoidHours": "None (Very quiet)",
        "why": "Golden sunset hour highlights the weathered stone battlements across the river curve."
      },
      "crowdCurve": [
        {
          "hour": "08:00",
          "visitors": 115,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "09:00",
          "visitors": 115,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "10:00",
          "visitors": 115,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "11:00",
          "visitors": 115,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "12:00",
          "visitors": 120,
          "status": "optimal",
          "label": "Quiet"
        },
        {
          "hour": "13:00",
          "visitors": 160,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "14:00",
          "visitors": 200,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "15:00",
          "visitors": 240,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "16:00",
          "visitors": 280,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "17:00",
          "visitors": 320,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "18:00",
          "visitors": 280,
          "status": "critical",
          "label": "Very Busy"
        },
        {
          "hour": "19:00",
          "visitors": 240,
          "status": "elevated",
          "label": "Moderate"
        },
        {
          "hour": "20:00",
          "visitors": 200,
          "status": "elevated",
          "label": "Moderate"
        }
      ]
    }
  ],
  "localBusinesses": [
    {
      "id": "thatheri-bazaar",
      "name": "Thatheri Bazaar Brass & Antiques",
      "category": "markets",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Chowk Historic Metal Guild",
      "coords": {
        "x": 490,
        "y": 310,
        "lat": 25.3122,
        "lng": 83.0118
      },
      "distanceKm": 0.5,
      "transitMinutes": 7,
      "estimatedActivity": 850,
      "activityStatus": "QUIET",
      "bestTime": "11:00 — 14:00",
      "quietestTime": "15:00 — 17:30",
      "specialty": "Hand-beaten Brass Idols, Bells & Antique Copper Cookware",
      "priceRange": "₹150 — ₹8,500",
      "rating": 4.8,
      "reviewsCount": 630,
      "whyRecommended": [
        "Medieval brass-beaters alleyway active for over 400 years",
        "Direct prices from artisan metal smiths without middlemen",
        "Fascinating acoustic and sensory walk through historic stone galis",
        "Authentic temple bells and cast brass artifacts"
      ],
      "roamSays": "Step into this acoustic alley where artisans still hand-hammer sacred brass bells and temple lotas just as they did in Kabir’s era.",
      "googleMapsQuery": "Thatheri Bazaar, Varanasi"
    },
    {
      "id": "chowk-silk",
      "name": "Madanpura & Chowk Handloom Silk Guild",
      "category": "crafts",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Madanpura Weavers Quarter",
      "coords": {
        "x": 470,
        "y": 360,
        "lat": 25.3025,
        "lng": 83.0035
      },
      "distanceKm": 1.1,
      "transitMinutes": 12,
      "estimatedActivity": 620,
      "activityStatus": "QUIET",
      "bestTime": "11:30 — 15:30",
      "quietestTime": "12:00 — 16:00",
      "specialty": "Pure Kadhwa Zari Banarasi Silk Sarees & Brocades",
      "priceRange": "₹3,500 — ₹45,000",
      "rating": 5,
      "reviewsCount": 480,
      "whyRecommended": [
        "Direct weaver cooperative bypassing tout commissions (up to 40% savings)",
        "See master weavers operating intricate jacquard punch-card looms",
        "Certified Silk Mark pure mulberry and tussar silks",
        "Deep cultural heritage preservation"
      ],
      "roamSays": "Avoid the street commission agents around the main ghats; visit Madanpura directly to purchase certified handwoven Banarasi sarees straight from the weaver family.",
      "googleMapsQuery": "Madanpura Weavers, Varanasi"
    },
    {
      "id": "deena-chaat",
      "name": "Deena Chaat Bhandar",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Luxa Road",
      "coords": {
        "x": 450,
        "y": 330,
        "lat": 25.3102,
        "lng": 83.0014
      },
      "distanceKm": 0.9,
      "transitMinutes": 10,
      "estimatedActivity": 1950,
      "activityStatus": "BUSY",
      "bestTime": "16:00 — 18:00",
      "quietestTime": "15:00 — 16:30",
      "specialty": "Signature Tamatar Chaat & Palak Chaat",
      "priceRange": "₹40 — ₹160",
      "rating": 4.9,
      "reviewsCount": 3120,
      "whyRecommended": [
        "Varanasi’s most celebrated culinary institution",
        "Inventors of hot, tangy Tamatar Chaat served in earthen clay pots",
        "Cooked with pure desi ghee, cumin, cashews, and sugar syrup",
        "Unmatched flavor burst unique to Kashi cuisine"
      ],
      "roamSays": "An absolute must-visit. Their sizzling earthen pot of tomato chaat with crunchy sev and spiced sugar drizzle will redefine Indian street food for you.",
      "googleMapsQuery": "Deena Chaat Bhandar, Luxa Road, Varanasi"
    },
    {
      "id": "vishwanath-gali",
      "name": "Vishwanath Gali Sacred Bazaars",
      "category": "shopping",
      "badge": "POPULAR MARKET",
      "badgeClass": "badge-elevated",
      "zone": "Old Vishwanath Gali Axis",
      "coords": {
        "x": 500,
        "y": 325,
        "lat": 25.3105,
        "lng": 83.0112
      },
      "distanceKm": 0.2,
      "transitMinutes": 3,
      "estimatedActivity": 3100,
      "activityStatus": "VERY BUSY",
      "bestTime": "09:00 — 11:30",
      "quietestTime": "13:00 — 15:00",
      "specialty": "Rudraksha Mala, Glass Bangles & Brass Pooja Items",
      "priceRange": "₹50 — ₹1,500",
      "rating": 4.7,
      "reviewsCount": 1890,
      "whyRecommended": [
        "Vibrant medieval pedestrian lane leading to the Golden Temple",
        "Colorful glass bangles, sandalwood paste, and sacred beads",
        "Immense cultural energy and aroma of incense",
        "Best explored in the calm morning hours"
      ],
      "roamSays": "The sensory heart of Kashi’s temple life. Browse prayer beads and hand-carved soapstone murtis before the afternoon crowd peaks.",
      "googleMapsQuery": "Vishwanath Gali, Varanasi"
    },
    {
      "id": "blue-lassi-shop",
      "name": "Blue Lassi Shop (Est. 1925)",
      "category": "food",
      "badge": "LOCAL FAVOURITE",
      "badgeClass": "badge-optimal",
      "zone": "Manikarnika Gali Lane",
      "coords": {
        "x": 510,
        "y": 300,
        "lat": 25.3115,
        "lng": 83.0135
      },
      "distanceKm": 0.3,
      "transitMinutes": 4,
      "estimatedActivity": 680,
      "activityStatus": "MODERATE",
      "bestTime": "11:00 — 14:00",
      "quietestTime": "15:00 — 17:00",
      "specialty": "Hand-churned Thick Curd Lassi with Pomegranate, Mango & Rabri",
      "priceRange": "₹60 — ₹180",
      "rating": 4.9,
      "reviewsCount": 4200,
      "whyRecommended": [
        "Century-old tiny blue-painted storefront tucked in historic alleyway",
        "Lassi hand-churned in traditional clay pots with wooden whisks",
        "Topped with fresh pomegranate arils, crushed pistachios, and thick malai",
        "Walls covered in passport photos left by world travelers over decades"
      ],
      "roamSays": "A quintessential Varanasi culinary experience. Grab a wooden bench and watch three generations of lassi makers create velvety dessert lassis in terracotta cups.",
      "googleMapsQuery": "Blue Lassi Shop, Bangali Tola, Varanasi"
    },
    {
      "id": "shreeji-malaiyo-sweet",
      "name": "Shreeji Sweets & Chaukhamba Malaiyo",
      "category": "food",
      "badge": "HERITAGE SWEETS",
      "badgeClass": "badge-optimal",
      "zone": "Chaukhamba Sacred Alley",
      "coords": {
        "x": 480,
        "y": 280,
        "lat": 25.3155,
        "lng": 83.0102
      },
      "distanceKm": 0.8,
      "transitMinutes": 9,
      "estimatedActivity": 420,
      "activityStatus": "QUIET",
      "bestTime": "07:30 — 11:00",
      "quietestTime": "08:00 — 10:00",
      "specialty": "Winter Dew-Whipped Saffron Malaiyo & Kashi Lal Peda",
      "priceRange": "₹40 — ₹200",
      "rating": 5.0,
      "reviewsCount": 1150,
      "whyRecommended": [
        "Master creators of Varanasi’s celestial winter delicacy Malaiyo",
        "Whipped milk foam infused with pure saffron and green cardamom",
        "Ancient Chaukhamba market location with authentic generational vibe",
        "Traditional caramelised Lal Peda made on iron karahis"
      ],
      "roamSays": "Malaiyo is ethereal—it vanishes on your palate like a cloud of saffron-flavored morning mist. Best enjoyed early in the morning with a fresh kulhad.",
      "googleMapsQuery": "Shreeji Sweets, Chaukhamba, Varanasi"
    },
    {
      "id": "pappu-chai-assi",
      "name": "Pappu Chai Stall & Discussion Adda",
      "category": "food",
      "badge": "CULTURAL HUB",
      "badgeClass": "badge-optimal",
      "zone": "Assi Ghat Crossing",
      "coords": {
        "x": 430,
        "y": 550,
        "lat": 25.2895,
        "lng": 82.9998
      },
      "distanceKm": 0.2,
      "transitMinutes": 3,
      "estimatedActivity": 550,
      "activityStatus": "QUIET",
      "bestTime": "06:30 — 09:00",
      "quietestTime": "13:00 — 16:00",
      "specialty": "Lemon Chai, Strong Adrak Chai & Banarasi Adda",
      "priceRange": "₹15 — ₹40",
      "rating": 4.8,
      "reviewsCount": 1820,
      "whyRecommended": [
        "The legendary intellectual debate and tea salon of Assi Ghat",
        "Frequented by BHU professors, classical musicians, and local sadhus",
        "Distinctive spiced lemon tea with fresh mint and rock salt",
        "Unfiltered window into Varanasi’s daily philosophical and cultural life"
      ],
      "roamSays": "After watching the sunrise at Assi Ghat, pull up a plastic stool here. The conversations on music, politics, and philosophy are as rich as the tea.",
      "googleMapsQuery": "Pappu Tea Stall, Assi Ghat, Varanasi"
    },
    {
      "id": "ramnagar-wooden-toys",
      "name": "Ramnagar Lacquered Wooden Toy Guild",
      "category": "crafts",
      "badge": "ROAM CURATED",
      "badgeClass": "badge-optimal",
      "zone": "Ramnagar Fort Heritage Zone",
      "coords": {
        "x": 620,
        "y": 620,
        "lat": 25.2685,
        "lng": 83.0255
      },
      "distanceKm": 4.5,
      "transitMinutes": 18,
      "estimatedActivity": 190,
      "activityStatus": "QUIET",
      "bestTime": "11:00 — 16:00",
      "quietestTime": "12:00 — 15:00",
      "specialty": "GI-Tagged Lacquered Wooden Birds, Musicians & Sacred Figurines",
      "priceRange": "₹100 — ₹2,200",
      "rating": 4.9,
      "reviewsCount": 290,
      "whyRecommended": [
        "Geographical Indication (GI) tagged traditional toy craft",
        "Hand-turned on wood lathes using Wrightia tinctoria (ivory wood)",
        "Colored with non-toxic natural lac and stone burnishing",
        "Direct artisan purchase supporting 60 master woodturner families"
      ],
      "roamSays": "A quiet craft sanctuary across the river. Watch artisans spin wooden blocks on lathes and apply natural shimmering lac colors in seconds.",
      "googleMapsQuery": "Ramnagar Wooden Toy Artisans, Varanasi"
    }
  ]
};
