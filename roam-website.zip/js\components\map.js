/**
 * ROAM — Visitor Flow Intelligence Map Component (V4)
 * "ROAM doesn't just show where people are. It understands how visitors move through a destination — and helps redistribute that movement intelligently."
 *
 * Core Capabilities:
 * - Living Visitor Flow Layer: Dynamic SVG flow vectors with animated directional particle pulses
 * - Master Toggle: CURRENT FLOW (congested bottlenecks) ↔ ROAM OPTIMIZED (distributed cultural corridors)
 * - Dynamic Density States: 🟢 LOW, 🟡 MODERATE, 🟠 HIGH, 🔴 OVERLOADED
 * - Time Controls: 08:00, 10:00, 12:00, 14:00, 16:00, 18:00, 20:00 with auto-play timeline
 * - Movement Lens: VISITORS, LOCALS, BOTH
 * - Multi-Category Filters: ALL, CULTURE, FOOD, MARKETS, HERITAGE, NATURE, RURAL, NIGHT, HIDDEN
 * - Clickable Flow Segments: Flow volume, Dwell time, Peak window, Demographics, "Why is this happening?", "ROAM Opportunity"
 * - "ROAM Can Redirect This Flow": 2–4 smart alternatives with + Add to Plan, Ask ROAM AI, and Directions
 * - Flow Impact Panel: Real-time before/after concentration metrics
 * - Integrated with centralized travelState & ROAM AI companion
 */

import { travelState } from '../state/travelState.js';
import { getVisitorFlowData } from '../data/visitorFlowData.js';
import { formatVisitorCount, formatWaitTime } from '../utils/formatters.js';

export class DestinationLoadMap {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.onNodeClick = options.onNodeClick || (() => {});
    
    this.locationData = null;
    this.flowData = null;
    
    // Core Interactive State
    this.flowMode = 'current'; // 'current' | 'optimized'
    this.selectedHour = '10:00'; // '08:00' | '10:00' | '12:00' | '14:00' | '16:00' | '18:00' | '20:00'
    this.movementLens = 'both'; // 'both' | 'visitors' | 'locals'
    this.categoryFilter = 'all'; // 'all' | 'culture' | 'food' | 'markets' | 'heritage' | 'nature' | 'rural' | 'night' | 'hidden'
    this.selectedSegmentId = null;
    this.selectedNodeId = null;
    this.isPlayingTimeline = false;
    this.timelineInterval = null;

    // Subscribe to travelState changes
    travelState.subscribe((event) => {
      if (event === 'focus:changed') {
        const focused = travelState.getFocusedItem();
        if (focused && this.flowData && this.flowData.nodes) {
          const match = this.flowData.nodes.find(n => n.id === focused.id || n.name.toLowerCase().includes(focused.name.toLowerCase()));
          if (match) {
            this.selectedNodeId = match.id;
            this.render();
          }
        }
      } else if (event === 'location:changed') {
        if (travelState.location && travelState.location.id !== this.locationData?.id) {
          this.setDestination(travelState.location);
        }
      }
    });
  }

  setDestination(locationData) {
    this.locationData = locationData;
    this.flowData = getVisitorFlowData(locationData);
    this.flowMode = 'current';
    this.selectedHour = this.flowData.defaultTime || '10:00';
    this.movementLens = 'both';
    this.categoryFilter = 'all';
    this.selectedSegmentId = this.flowData.segments?.[0]?.id || null;
    this.selectedNodeId = this.flowData.nodes?.[0]?.id || null;
    
    if (this.timelineInterval) {
      clearInterval(this.timelineInterval);
      this.isPlayingTimeline = false;
    }

    this.render();
  }

  setFlowMode(mode) {
    if (this.flowMode !== mode) {
      this.flowMode = mode;
      // If switching to optimized and current segment is not in optimized mode, select first optimized segment
      if (this.flowData?.segments) {
        const available = this.flowData.segments.filter(s => s.mode === mode || s.mode === 'both');
        if (available.length > 0 && !available.some(s => s.id === this.selectedSegmentId)) {
          this.selectedSegmentId = available[0].id;
        }
      }
      this.render();
    }
  }

  setSelectedHour(hour) {
    this.selectedHour = hour;
    this.render();
  }

  setMovementLens(lens) {
    this.movementLens = lens;
    this.render();
  }

  setCategoryFilter(filter) {
    this.categoryFilter = filter;
    this.render();
  }

  setFilter(filterType) {
    if (filterType === 'critical') {
      this.setFlowMode('current');
    } else if (filterType === 'optimal') {
      this.setFlowMode('optimized');
    } else {
      this.setCategoryFilter(filterType);
    }
  }

  selectSegment(segmentId) {
    this.selectedSegmentId = segmentId;
    const seg = this.flowData?.segments?.find(s => s.id === segmentId);
    if (seg) {
      this.selectedNodeId = seg.fromNodeId;
    }
    this.render();
  }

  selectNode(nodeId) {
    this.selectedNodeId = nodeId;
    // Find segment originating or terminating at this node
    if (this.flowData?.segments) {
      const seg = this.flowData.segments.find(s => 
        (s.mode === this.flowMode || s.mode === 'both') && 
        (s.fromNodeId === nodeId || s.toNodeId === nodeId)
      );
      if (seg) {
        this.selectedSegmentId = seg.id;
      }
    }
    const node = this.flowData?.nodes?.find(n => n.id === nodeId);
    if (node) {
      this.onNodeClick(node);
    }
    this.render();
  }

  toggleTimelinePlay() {
    this.isPlayingTimeline = !this.isPlayingTimeline;
    if (this.isPlayingTimeline) {
      const hours = ['08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00'];
      let idx = hours.indexOf(this.selectedHour);
      this.timelineInterval = setInterval(() => {
        idx = (idx + 1) % hours.length;
        this.selectedHour = hours[idx];
        this.render();
      }, 2200);
    } else {
      if (this.timelineInterval) {
        clearInterval(this.timelineInterval);
        this.timelineInterval = null;
      }
      this.render();
    }
  }

  render() {
    if (!this.container) return;

    if (!this.locationData || !this.flowData) {
      this.flowData = getVisitorFlowData('jaipur');
    }

    const flow = this.flowData;
    const city = flow.city || this.locationData?.name || 'Jaipur';
    const state = flow.state || this.locationData?.state || 'Rajasthan';
    const timeProfile = flow.timeProfiles?.[this.selectedHour] || {
      label: 'Visitor Flow Dynamics',
      headline: 'Live tourism movement simulation',
      summary: 'Monitoring movement across corridors and cultural quarters.',
      avgCityLoadPct: 60
    };

    // Filter segments by mode, lens, and category
    let activeSegments = (flow.segments || []).filter(s => {
      // 1. Mode check (current vs optimized)
      if (s.mode !== this.flowMode && s.mode !== 'both') return false;
      // 2. Movement Lens check
      if (this.movementLens !== 'both' && s.flowType !== 'both' && s.flowType !== this.movementLens) return false;
      // 3. Category Filter check
      if (this.categoryFilter !== 'all') {
        const cats = s.categories || [];
        if (!cats.includes(this.categoryFilter)) return false;
      }
      return true;
    });

    // If filtering left zero segments, fall back to all mode segments
    if (activeSegments.length === 0) {
      activeSegments = (flow.segments || []).filter(s => s.mode === this.flowMode || s.mode === 'both');
    }

    // Filter nodes by category if active
    let activeNodes = flow.nodes || [];
    if (this.categoryFilter !== 'all') {
      activeNodes = activeNodes.filter(n => {
        if (this.categoryFilter === 'hidden' || this.categoryFilter === 'rural') {
          return n.type === 'surrogate' || n.category === 'rural';
        }
        return n.category === this.categoryFilter || n.type === 'hotspot';
      });
    }

    const selectedSegment = flow.segments?.find(s => s.id === this.selectedSegmentId) || activeSegments[0] || flow.segments?.[0];
    const selectedNode = flow.nodes?.find(n => n.id === this.selectedNodeId) || flow.nodes?.[0];

    // Surrogate places for selected segment or node
    const surrogateIds = selectedSegment?.surrogates || [];
    const surrogateNodes = surrogateIds
      .map(id => flow.nodes.find(n => n.id === id))
      .filter(Boolean)
      .slice(0, 4);

    // If no surrogate nodes found for segment, pick 3 non-hotspot nodes
    const fallbackSurrogates = flow.nodes.filter(n => n.type === 'surrogate' || n.status === 'optimal').slice(0, 3);
    const displaySurrogates = surrogateNodes.length > 0 ? surrogateNodes : fallbackSurrogates;

    // Concentration values
    const currentConc = flow.metrics?.currentConcentration || 76;
    const optConc = flow.metrics?.optimizedConcentration || 48;
    const displayedConc = this.flowMode === 'optimized' ? optConc : currentConc;

    // Main HTML Assembly
    this.container.innerHTML = `
      <div class="roam-visitor-flow-intelligence">
        
        <!-- 1. Header & Living Intelligence Narrative -->
        <div class="flow-header-section">
          <div class="flow-header-top">
            <div>
              <div class="flow-kicker">
                <span class="flow-live-pulsar"></span>
                <span>VISITOR FLOW INTELLIGENCE</span>
                <span class="flow-honesty-badge">DEMO INTELLIGENCE · SIMULATED VISITOR FLOW</span>
              </div>
              <h2 class="flow-headline">${city.toUpperCase()} · LIVING TOURISM MOVEMENT</h2>
              <p class="flow-subtext">See where visitors are moving, where pressure is building, and where ROAM can redistribute demand.</p>
            </div>

            <!-- Master Toggle Switch: CURRENT FLOW <-> ROAM OPTIMIZED -->
            <div class="flow-master-toggle-wrap">
              <div class="flow-toggle-container">
                <button 
                  class="flow-toggle-btn ${this.flowMode === 'current' ? 'active current-active' : ''}" 
                  id="flow-toggle-current"
                  data-mode="current"
                >
                  <span class="toggle-icon">⚠️</span>
                  <span class="toggle-label">CURRENT FLOW</span>
                  <span class="toggle-sub">Peak Congestion</span>
                </button>
                <button 
                  class="flow-toggle-btn ${this.flowMode === 'optimized' ? 'active opt-active' : ''}" 
                  id="flow-toggle-optimized"
                  data-mode="optimized"
                >
                  <span class="toggle-icon">⚡</span>
                  <span class="toggle-label">ROAM OPTIMIZED</span>
                  <span class="toggle-sub">Distributed Movement</span>
                </button>
              </div>
            </div>
          </div>

          <!-- 2. Controls Toolbar: Time Chips + Movement Lens + Categories -->
          <div class="flow-toolbar-row">
            
            <!-- Time Chips Row -->
            <div class="flow-time-selector-group">
              <button class="flow-time-play-btn ${this.isPlayingTimeline ? 'is-playing' : ''}" id="flow-timeline-play-toggle" title="Play 24hr Visitor Flow Simulation">
                ${this.isPlayingTimeline ? '❚❚ Pause' : '▶ Play Flow'}
              </button>
              <div class="flow-time-chips">
                ${['08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00'].map(hr => `
                  <button class="flow-time-chip ${this.selectedHour === hr ? 'active' : ''}" data-hour="${hr}">
                    ${hr}
                  </button>
                `).join('')}
              </div>
            </div>

            <!-- Movement Lens (Visitors / Locals / Both) -->
            <div class="flow-lens-group">
              <span class="lens-label">LENS:</span>
              <button class="flow-lens-btn ${this.movementLens === 'both' ? 'active' : ''}" data-lens="both">BOTH</button>
              <button class="flow-lens-btn ${this.movementLens === 'visitors' ? 'active' : ''}" data-lens="visitors">VISITORS</button>
              <button class="flow-lens-btn ${this.movementLens === 'locals' ? 'active' : ''}" data-lens="locals">LOCALS</button>
            </div>

          </div>

          <!-- Category Filters Row -->
          <div class="flow-category-filters">
            ${[
              { id: 'all', label: 'ALL FLOWS' },
              { id: 'heritage', label: '🏛️ HERITAGE' },
              { id: 'culture', label: '🎨 CULTURE' },
              { id: 'food', label: '🍛 FOOD LANES' },
              { id: 'markets', label: '🛍️ BAZAARS' },
              { id: 'nature', label: '🌿 NATURE' },
              { id: 'rural', label: '🌾 RURAL' },
              { id: 'hidden', label: '✨ HIDDEN GEMS' }
            ].map(cat => `
              <button class="flow-cat-chip ${this.categoryFilter === cat.id ? 'active' : ''}" data-cat="${cat.id}">
                ${cat.label}
              </button>
            `).join('')}
          </div>

          <!-- Time Narrative Strip -->
          <div class="flow-time-narrative-bar">
            <div class="time-bar-left">
              <span class="time-clock-pill">⏰ ${this.selectedHour}</span>
              <span class="time-label-title">${timeProfile.label}</span>
              <span class="time-sub-desc">— ${timeProfile.summary}</span>
            </div>
            <div class="time-bar-right">
              <span class="flow-density-badge ${timeProfile.avgCityLoadPct > 75 ? 'density-high' : (timeProfile.avgCityLoadPct > 45 ? 'density-med' : 'density-low')}">
                CITY LOAD: ${timeProfile.avgCityLoadPct}%
              </span>
            </div>
          </div>

        </div>

        <!-- 3. Interactive Living SVG Canvas -->
        <div class="flow-canvas-wrapper" id="flow-svg-container">
          ${this.renderFlowSvg(flow, activeNodes, activeSegments, selectedSegment, selectedNode)}
          
          <!-- Floating Canvas Overlay Legend -->
          <div class="flow-canvas-legend">
            <div class="legend-pill"><span class="flow-dot dot-low"></span> 🟢 LOW (Room available)</div>
            <div class="legend-pill"><span class="flow-dot dot-mod"></span> 🟡 MODERATE (Smooth flow)</div>
            <div class="legend-pill"><span class="flow-dot dot-high"></span> 🟠 HIGH (Building waits)</div>
            <div class="legend-pill"><span class="flow-dot dot-crit"></span> 🔴 OVERLOADED (Bottleneck)</div>
          </div>
        </div>

        <!-- 4. Bottleneck Alert Banner with 1-Click Action -->
        ${flow.metrics?.alertPrompt ? `
          <div class="flow-alert-banner ${this.flowMode === 'optimized' ? 'alert-optimized' : 'alert-critical'}">
            <div class="alert-icon-col">
              ${this.flowMode === 'optimized' ? '✓' : '⚡'}
            </div>
            <div class="alert-content-col">
              <div class="alert-title">
                ${this.flowMode === 'optimized' 
                  ? 'ROAM REDISTRIBUTION ACTIVE — CROWD SPREAD ACROSS 6 CULTURAL CORRIDORS' 
                  : 'CRITICAL BOTTLENECK DETECTED IN LINEAR MONUMENT AXIS'}
              </div>
              <div class="alert-body">${flow.metrics.alertPrompt.message}</div>
            </div>
            <div class="alert-actions-col">
              ${this.flowMode === 'current' ? `
                <button class="btn btn-sm btn-primary flow-action-redirect-btn" id="flow-banner-redirect-btn">
                  ⚡ REDIRECT WITH ROAM
                </button>
              ` : `
                <button class="btn btn-sm btn-outline flow-action-ai-btn" id="flow-banner-ai-btn">
                  ✨ Ask ROAM AI
                </button>
              `}
            </div>
          </div>
        ` : ''}

        <!-- 5. Segment Intelligence Drawer / Inspector -->
        ${this.renderSegmentInspector(selectedSegment, flow, displaySurrogates)}

        <!-- 6. Flow Impact Panel (Before ↔ After Comparison) -->
        <div class="flow-impact-panel">
          <div class="impact-panel-header">
            <div>
              <span class="impact-kicker">COMMUNITY & VISITOR IMPACT</span>
              <h3 class="impact-title">HOW ROAM TRANSFORMS ${city.toUpperCase()}'S VISITOR MOVEMENT</h3>
            </div>
            <div class="impact-badge-pill">
              ${this.flowMode === 'optimized' ? '🟢 REAL-TIME BALANCING' : '⚠️ UNMANAGED CONCENTRATION'}
            </div>
          </div>

          <div class="impact-metrics-grid">
            
            <div class="impact-metric-card">
              <span class="impact-metric-label">TOURIST CONCENTRATION</span>
              <div class="impact-metric-val-row">
                <span class="val-before">${currentConc}%</span>
                <span class="val-arrow">➔</span>
                <span class="val-after val-green">${optConc}%</span>
              </div>
              <span class="impact-metric-sub">−${flow.metrics?.bottleneckReductionPct || 28}% peak pressure</span>
            </div>

            <div class="impact-metric-card">
              <span class="impact-metric-label">BOTTLENECK QUEUE REDUCTION</span>
              <div class="impact-metric-val-row">
                <span class="val-after val-green">−${flow.metrics?.bottleneckReductionPct || 28}%</span>
              </div>
              <span class="impact-metric-sub">Save ~42 mins of gate wait</span>
            </div>

            <div class="impact-metric-card">
              <span class="impact-metric-label">UNDER-VISITED HERITAGE VISITS</span>
              <div class="impact-metric-val-row">
                <span class="val-after val-cyan">+${flow.metrics?.underVisitedGainPct || 34}%</span>
              </div>
              <span class="impact-metric-sub">Exposure to hidden havelis & kunds</span>
            </div>

            <div class="impact-metric-card">
              <span class="impact-metric-label">LOCAL ARTISAN REVENUE CAPTURE</span>
              <div class="impact-metric-val-row">
                <span class="val-after val-amber">+${flow.metrics?.artisanRevenueGainPct || 24}%</span>
              </div>
              <span class="impact-metric-sub">Direct purchase from master guilds</span>
            </div>

            <div class="impact-metric-card">
              <span class="impact-metric-label">CULTURAL DISCOVERY SCORE</span>
              <div class="impact-metric-val-row">
                <span class="val-after val-purple">+${flow.metrics?.culturalDiscoveryPct || 36}%</span>
              </div>
              <span class="impact-metric-sub">Beyond generic tourist traps</span>
            </div>

          </div>
        </div>

      </div>
    `;

    this.attachEventListeners();
  }

  renderFlowSvg(flow, nodes, segments, selectedSegment, selectedNode) {
    const isOpt = this.flowMode === 'optimized';

    return `
      <svg class="map-svg roam-living-flow-svg" viewBox="0 0 900 620" preserveAspectRatio="xMidYMid meet" role="img" aria-label="ROAM Living Visitor Flow Intelligence Radar">
        <defs>
          <!-- Radial ambient sweep -->
          <radialGradient id="flowRadarSweep" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stop-color="${isOpt ? 'rgba(16, 185, 129, 0.18)' : 'rgba(235, 94, 40, 0.18)'}" />
            <stop offset="60%" stop-color="${isOpt ? 'rgba(6, 182, 212, 0.05)' : 'rgba(239, 68, 68, 0.05)'}" />
            <stop offset="100%" stop-color="transparent" />
          </radialGradient>

          <!-- Spatial Grid Pattern -->
          <pattern id="flowGrid" width="45" height="45" patternUnits="userSpaceOnUse">
            <path d="M 45 0 L 0 0 0 45" fill="none" stroke="rgba(255, 255, 255, 0.028)" stroke-width="1" />
          </pattern>

          <!-- Path Gradients -->
          <linearGradient id="gradOverloaded" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#ef4444" />
            <stop offset="100%" stop-color="#f97316" />
          </linearGradient>

          <linearGradient id="gradHigh" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#f59e0b" />
            <stop offset="100%" stop-color="#fbbf24" />
          </linearGradient>

          <linearGradient id="gradOptimal" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stop-color="#10b981" />
            <stop offset="50%" stop-color="#06b6d4" />
            <stop offset="100%" stop-color="#3b82f6" />
          </linearGradient>

          <!-- Flow Arrow Marker -->
          <marker id="arrowOptimal" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 9 5 L 0 9 z" fill="#10b981" />
          </marker>
          <marker id="arrowOverloaded" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 9 5 L 0 9 z" fill="#ef4444" />
          </marker>
          <marker id="arrowHigh" viewBox="0 0 10 10" refX="6" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
            <path d="M 0 1 L 9 5 L 0 9 z" fill="#f59e0b" />
          </marker>
        </defs>

        <!-- Ambient Background Grid & Concentric Radar Rings -->
        <rect width="900" height="620" fill="url(#flowGrid)" />
        <circle cx="450" cy="310" r="300" fill="url(#flowRadarSweep)" />
        <circle cx="450" cy="310" r="280" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="1" stroke-dasharray="6,6" />
        <circle cx="450" cy="310" r="200" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="1" />
        <circle cx="450" cy="310" r="110" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="1" stroke-dasharray="4,4" />

        <!-- Spatial Zone Tags -->
        <text x="50" y="45" fill="rgba(255,255,255,0.25)" font-size="11" font-weight="700" letter-spacing="1.5">
          ${flow.city.toUpperCase()} CULTURAL ZONE MAP · ${isOpt ? 'ROAM REDISTRIBUTION LAYER' : 'RAW TOURIST CONCENTRATION'}
        </text>

        <!-- 1. FLOW ARCS & PARTICLE STREAMS -->
        <g class="flow-routes-layer">
          ${segments.map(seg => {
            const fromNode = flow.nodes.find(n => n.id === seg.fromNodeId);
            const toNode = flow.nodes.find(n => n.id === seg.toNodeId);
            if (!fromNode?.coords || !toNode?.coords) return '';

            const isSelected = selectedSegment?.id === seg.id;
            const x1 = fromNode.coords.x;
            const y1 = fromNode.coords.y;
            const x2 = toNode.coords.x;
            const y2 = toNode.coords.y;

            // Compute bezier curve midpoint with arc offset for cinematic curved trajectory
            const dx = x2 - x1;
            const dy = y2 - y1;
            const cx = (x1 + x2) / 2 - dy * 0.18;
            const cy = (y1 + y2) / 2 + dx * 0.18;
            const pathD = `M ${x1} ${y1} Q ${cx} ${cy} ${x2} ${y2}`;

            const isOverloaded = seg.densityState === 'overloaded';
            const isHigh = seg.densityState === 'high';
            const isOptimalSeg = seg.densityState === 'low' || isOpt;

            const strokeColor = isOverloaded ? 'url(#gradOverloaded)' : (isHigh ? 'url(#gradHigh)' : 'url(#gradOptimal)');
            const markerId = isOverloaded ? 'url(#arrowOverloaded)' : (isHigh ? 'url(#arrowHigh)' : 'url(#arrowOptimal)');
            const strokeWidth = isSelected ? 6.5 : (isOverloaded ? 5 : (isHigh ? 4 : 3));
            const particleSpeed = isOverloaded ? '1.2s' : (isHigh ? '2s' : '3s');

            // Compute hour-adjusted flow count
            const hourFlow = seg.hourlyFlow?.[this.selectedHour] || 500;

            return `
              <g class="flow-segment-group ${isSelected ? 'selected' : ''}" data-segment-id="${seg.id}" style="cursor:pointer;">
                <!-- Broad Invisible Hit Area for Easy Touch & Click -->
                <path d="${pathD}" fill="none" stroke="transparent" stroke-width="26" class="segment-hitbox" />

                <!-- Glow Aura for Active/Selected Corridors -->
                <path 
                  d="${pathD}" 
                  fill="none" 
                  stroke="${isOverloaded ? 'rgba(239,68,68,0.22)' : (isHigh ? 'rgba(245,158,11,0.2)' : 'rgba(16,185,129,0.22)')}" 
                  stroke-width="${strokeWidth + 8}" 
                  class="flow-glow-path"
                />

                <!-- Primary Base Flow Path -->
                <path 
                  d="${pathD}" 
                  fill="none" 
                  stroke="${strokeColor}" 
                  stroke-width="${strokeWidth}" 
                  stroke-linecap="round"
                  marker-end="${markerId}"
                  opacity="${isSelected ? '1' : '0.85'}"
                />

                <!-- Flowing Directional Particle Dash Layer -->
                <path 
                  d="${pathD}" 
                  fill="none" 
                  stroke="#ffffff" 
                  stroke-width="${strokeWidth - 1}" 
                  stroke-dasharray="4, 18" 
                  class="flow-particles-animated"
                  style="animation-duration: ${particleSpeed}; opacity: ${isOverloaded ? '0.9' : '0.7'};"
                />

                <!-- Flow Volume Pill Tag on Curve Center -->
                <g transform="translate(${cx}, ${cy})" class="flow-pill-tag">
                  <rect x="-38" y="-11" width="76" height="22" rx="11" fill="rgba(10, 14, 24, 0.95)" stroke="${isOverloaded ? '#ef4444' : (isHigh ? '#f59e0b' : '#10b981')}" stroke-width="${isSelected ? '2' : '1'}" />
                  <text y="4" text-anchor="middle" fill="#fff" font-size="9.5" font-weight="800" font-family="monospace">
                    ${hourFlow}/hr
                  </text>
                </g>
              </g>
            `;
          }).join('')}
        </g>

        <!-- 2. SPATIAL NODES & RADAR PULSES -->
        <g class="flow-nodes-layer">
          ${nodes.map(node => {
            if (!node.coords) return '';
            const isSelected = selectedNode?.id === node.id;
            const isCrit = node.status === 'critical' && !isOpt;
            const isOptNode = node.status === 'optimal' || isOpt;
            const isElev = node.status === 'elevated';

            const color = isCrit ? '#ef4444' : (isOptNode ? '#10b981' : '#f59e0b');
            const pulseClass = isCrit ? 'pulse-crit' : (isOptNode ? 'pulse-opt' : 'pulse-elev');
            const icon = node.category === 'food' ? '🍛' : (node.category === 'markets' ? '🛍️' : (node.category === 'nature' ? '🌿' : (node.category === 'rural' ? '🌾' : (node.category === 'spiritual' ? '🪔' : '🏛️'))));

            // Load indicator calculations
            const loadVal = isCrit ? '94%' : (isOptNode ? '18%' : '62%');

            return `
              <g class="flow-node-group ${isSelected ? 'selected' : ''}" data-node-id="${node.id}" transform="translate(${node.coords.x}, ${node.coords.y})" style="cursor:pointer;">
                <!-- Outer Pulsing Radar Waves -->
                <circle cx="0" cy="0" r="${isSelected ? '32' : '22'}" class="node-radar-wave ${pulseClass}" fill="${color}" opacity="0.2" />
                <circle cx="0" cy="0" r="${isSelected ? '20' : '15'}" class="node-radar-wave" fill="${color}" opacity="0.3" />

                <!-- Node Core Body -->
                <circle cx="0" cy="0" r="${isSelected ? '16' : '12'}" fill="rgba(10, 15, 26, 0.96)" stroke="${color}" stroke-width="${isSelected ? '3.5' : '2.5'}" />
                
                <!-- Category Icon -->
                <text y="4" text-anchor="middle" font-size="${isSelected ? '12' : '10'}" fill="#fff" font-family="system-ui">
                  ${icon}
                </text>

                <!-- Floating Name Badge & Load Percentage -->
                <g transform="translate(0, ${isSelected ? '28' : '24'})" class="node-label-group">
                  <rect x="-65" y="-10" width="130" height="22" rx="6" fill="rgba(10, 14, 24, 0.94)" stroke="${isSelected ? color : 'rgba(255,255,255,0.15)'}" stroke-width="${isSelected ? '1.5' : '1'}" />
                  <text y="4" text-anchor="middle" fill="#fff" font-size="10.5" font-weight="700">
                    ${node.shortName || node.name}
                  </text>
                  
                  <!-- Capacity status dot -->
                  <circle cx="54" cy="1" r="3.5" fill="${color}" />
                </g>
              </g>
            `;
          }).join('')}
        </g>
      </svg>
    `;
  }

  renderSegmentInspector(segment, flow, surrogates) {
    if (!segment) return '';

    const fromNode = flow.nodes.find(n => n.id === segment.fromNodeId);
    const toNode = flow.nodes.find(n => n.id === segment.toNodeId);
    const hourFlow = segment.hourlyFlow?.[this.selectedHour] || 1200;
    const isOverloaded = segment.densityState === 'overloaded';
    const city = flow.city || 'Jaipur';

    return `
      <div class="flow-segment-inspector">
        <div class="inspector-header">
          <div class="inspector-title-row">
            <span class="badge ${isOverloaded ? 'badge-critical' : 'badge-optimal'}">
              ${isOverloaded ? '🔴 BOTTLENECK CORRIDOR' : '🟢 DISTRIBUTED CULTURAL CORRIDOR'}
            </span>
            <span class="inspector-route-tag">${segment.name}</span>
          </div>
          <p class="inspector-subtext">Clicking any route segment reveals telemetry, root causes, and ROAM redistribution paths.</p>
        </div>

        <!-- 4-Stat Metric Strip -->
        <div class="inspector-stats-grid">
          <div class="inspector-stat-box">
            <span class="stat-box-label">ESTIMATED FLOW VOLUME</span>
            <span class="stat-box-val font-mono">~${formatVisitorCount(hourFlow)} / hr</span>
            <span class="stat-box-sub">At ${this.selectedHour} window</span>
          </div>

          <div class="inspector-stat-box">
            <span class="stat-box-label">AVERAGE DWELL TIME</span>
            <span class="stat-box-val">${segment.dwellTime || '34m'}</span>
            <span class="stat-box-sub">Queue + corridor transit</span>
          </div>

          <div class="inspector-stat-box">
            <span class="stat-box-label">PEAK CONGESTION WINDOW</span>
            <span class="stat-box-val">${segment.peakPeriod || '10:00 — 12:30'}</span>
            <span class="stat-box-sub">Avoid linear rush</span>
          </div>

          <div class="inspector-stat-box">
            <span class="stat-box-label">DEMOGRAPHIC SPLIT</span>
            <span class="stat-box-val font-mono">${segment.touristPct || 84}% Tourists · ${segment.localPct || 16}% Locals</span>
            <span class="stat-box-sub">${segment.flowType?.toUpperCase() || 'BOTH'} LENS</span>
          </div>
        </div>

        <!-- Deep Behavioral Analysis: "WHY IS THIS HAPPENING?" -->
        <div class="inspector-insight-card">
          <div class="insight-card-header">
            <span class="insight-icon">🔍</span>
            <h4>WHY IS THIS HAPPENING?</h4>
          </div>
          <p class="insight-card-body">
            ${segment.whyHappening || 'High concentration along single-file entrance corridors caused by synchronous tour vehicle arrivals.'}
          </p>
        </div>

        <!-- ROAM Opportunity Banner -->
        <div class="inspector-opportunity-card">
          <div class="opportunity-header">
            <span class="opportunity-icon">⚡</span>
            <h4>ROAM REDISTRIBUTION OPPORTUNITY</h4>
          </div>
          <p class="opportunity-body">
            ${segment.roamOpportunity || 'Redirecting 20–25% of this flow into adjoining craft guilds reduces wait times and stimulates local businesses.'}
          </p>
        </div>

        <!-- "ROAM CAN REDIRECT THIS FLOW" — SMART SURROGATE ALTERNATIVES -->
        <div class="surrogate-recommendations-section">
          <div class="surrogate-header-row">
            <div>
              <span class="surrogate-kicker">INTELLIGENT REDIRECTION</span>
              <h3 class="surrogate-title">ROAM CAN REDIRECT THIS FLOW TO THESE LIVING SURROGATES</h3>
            </div>
            <span class="badge badge-optimal">ROOM AVAILABLE NOW</span>
          </div>

          <div class="surrogates-cards-grid">
            ${surrogates.map(alt => {
              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(alt.name + ', ' + city)}`;
              const dirUrl = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(alt.name + ', ' + city)}`;

              return `
                <div class="surrogate-card" data-node-id="${alt.id}">
                  <div class="surrogate-top">
                    <div class="surrogate-meta-badges">
                      <span class="badge badge-optimal">🟢 LOW · 18% CAPACITY</span>
                      <span class="surrogate-cat-pill">${alt.category?.toUpperCase()}</span>
                    </div>
                    <h4 class="surrogate-card-name">${alt.name}</h4>
                    <p class="surrogate-card-desc">${alt.description}</p>
                  </div>

                  <!-- Telemetry Chips -->
                  <div class="surrogate-telemetry-strip">
                    <div class="telemetry-item">
                      <span class="tele-label">DISTANCE</span>
                      <span class="tele-val">~450m (6m walk)</span>
                    </div>
                    <div class="telemetry-item">
                      <span class="tele-label">CULTURAL DNA</span>
                      <span class="tele-val text-accent">${alt.culturalScore || 96}/100</span>
                    </div>
                    <div class="telemetry-item">
                      <span class="tele-label">DWELL TIME</span>
                      <span class="tele-val">${alt.dwellTimeMinutes || 45}m</span>
                    </div>
                    <div class="telemetry-item">
                      <span class="tele-label">LOCAL IMPACT</span>
                      <span class="tele-val text-green">+ ₹${alt.localImpactINR || 450}</span>
                    </div>
                  </div>

                  <!-- Why ROAM Recommends This -->
                  <div class="surrogate-reason-box">
                    <span class="reason-sparkle">✨</span>
                    <span class="reason-text"><strong>Why ROAM recommends:</strong> ${alt.reason || 'Zero queue wait, direct artisan workshop engagement, generational local recipes.'}</span>
                  </div>

                  <!-- 1-Click Action Buttons -->
                  <div class="surrogate-actions-row">
                    <button class="btn btn-sm btn-primary surrogate-add-btn" data-name="${alt.name}" data-cat="${alt.category || 'culture'}" data-dur="${alt.dwellTimeMinutes || 45}">
                      + Add to Plan
                    </button>
                    <button class="btn btn-sm btn-outline surrogate-ai-btn" data-query="Tell me about visiting ${alt.name} in ${city} and why it's a better alternative right now">
                      Ask ROAM AI
                    </button>
                    <a href="${dirUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-secondary surrogate-maps-btn">
                      Directions ↗
                    </a>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

      </div>
    `;
  }

  attachEventListeners() {
    // 1. Master Toggle Buttons (Current vs Optimized)
    const currentBtn = this.container.querySelector('#flow-toggle-current');
    const optBtn = this.container.querySelector('#flow-toggle-optimized');

    if (currentBtn) {
      currentBtn.onclick = () => this.setFlowMode('current');
    }
    if (optBtn) {
      optBtn.onclick = () => this.setFlowMode('optimized');
    }

    // 2. Time Play / Step Toggle
    const playBtn = this.container.querySelector('#flow-timeline-play-toggle');
    if (playBtn) {
      playBtn.onclick = () => this.toggleTimelinePlay();
    }

    // 3. Time Chips
    this.container.querySelectorAll('.flow-time-chip').forEach(chip => {
      chip.onclick = () => {
        const hr = chip.dataset.hour;
        if (hr) this.setSelectedHour(hr);
      };
    });

    // 4. Movement Lens Buttons
    this.container.querySelectorAll('.flow-lens-btn').forEach(btn => {
      btn.onclick = () => {
        const lens = btn.dataset.lens;
        if (lens) this.setMovementLens(lens);
      };
    });

    // 5. Category Chips
    this.container.querySelectorAll('.flow-cat-chip').forEach(chip => {
      chip.onclick = () => {
        const cat = chip.dataset.cat;
        if (cat) this.setCategoryFilter(cat);
      };
    });

    // 6. SVG Flow Segments Click
    this.container.querySelectorAll('.flow-segment-group').forEach(segEl => {
      segEl.onclick = (e) => {
        e.stopPropagation();
        const id = segEl.dataset.segmentId;
        if (id) this.selectSegment(id);
      };
    });

    // 7. SVG Nodes Click
    this.container.querySelectorAll('.flow-node-group').forEach(nodeEl => {
      nodeEl.onclick = (e) => {
        e.stopPropagation();
        const id = nodeEl.dataset.nodeId;
        if (id) this.selectNode(id);
      };
    });

    // 8. Alert Banner 1-Click Redirect
    const bannerRedirectBtn = this.container.querySelector('#flow-banner-redirect-btn');
    if (bannerRedirectBtn) {
      bannerRedirectBtn.onclick = () => {
        this.setFlowMode('optimized');
        // Add top surrogate place to plan
        const topSurrogate = this.flowData?.nodes?.find(n => n.type === 'surrogate' || n.status === 'optimal');
        if (topSurrogate) {
          travelState.addPlaceIntelligently({
            name: topSurrogate.name,
            category: topSurrogate.category || 'culture',
            durationMinutes: topSurrogate.dwellTimeMinutes || 50
          });
          if (window.ROAM?.modalController) {
            window.ROAM.modalController.showToast(`⚡ Switched to ROAM Optimized Flow! Added ${topSurrogate.name} to itinerary.`);
          }
        }
      };
    }

    // 9. Alert Banner Ask ROAM AI
    const bannerAIBtn = this.container.querySelector('#flow-banner-ai-btn');
    if (bannerAIBtn) {
      bannerAIBtn.onclick = () => {
        const city = this.flowData?.city || 'Jaipur';
        if (window.ROAM?.roamAI) {
          window.ROAM.roamAI.toggleDrawer(true);
          window.ROAM.roamAI.sendQuery(`How does ROAM redistribute visitor flow in ${city} at ${this.selectedHour}? Show me optimal surrogates.`);
        }
      };
    }

    // 10. Surrogate "+ Add to Plan" Buttons
    this.container.querySelectorAll('.surrogate-add-btn').forEach(btn => {
      btn.onclick = () => {
        const name = btn.dataset.name;
        const cat = btn.dataset.cat || 'culture';
        const dur = parseInt(btn.dataset.dur, 10) || 60;

        const res = travelState.addPlaceIntelligently({
          name: name,
          category: cat,
          durationMinutes: dur
        });

        btn.textContent = '✓ Added to Plan';
        btn.disabled = true;
        btn.classList.remove('btn-primary');
        btn.classList.add('btn-secondary');

        if (window.ROAM?.modalController) {
          window.ROAM.modalController.showToast(`Added ${name} to your plan (${res.time})`);
        }
      };
    });

    // 11. Surrogate "Ask ROAM AI" Buttons
    this.container.querySelectorAll('.surrogate-ai-btn').forEach(btn => {
      btn.onclick = () => {
        const query = btn.dataset.query;
        if (query && window.ROAM?.roamAI) {
          window.ROAM.roamAI.toggleDrawer(true);
          window.ROAM.roamAI.sendQuery(query);
        }
      };
    });
  }
}
