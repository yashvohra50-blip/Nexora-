/**
 * ROAM AI Companion Component (V4)
 * Action-Oriented Interactive Companion for India's Living Destination Intelligence Layer
 */

import { roamAIEngine } from '../engine/aiAgentEngine.js';
import { travelState } from '../state/travelState.js';

export class RoamAIController {
  constructor(appInstance) {
    this.app = appInstance;
    this.isOpen = false;
    this.messages = [];
    this.mount = null;
    this.init();
  }

  init() {
    this.createDomElements();
    this.render();

    // Subscribe to state changes to update context chips in AI drawer
    travelState.subscribe((event) => {
      if (['location:changed', 'itinerary:updated', 'interests:changed', 'mood:changed'].includes(event)) {
        this.updateContextChip();
      }
    });

    // Initial greeting
    const city = travelState.location?.name || 'Jaipur';
    this.messages.push({
      id: 'msg-welcome',
      sender: 'roam_ai',
      text: `### Namaste! I am ROAM AI, your living destination agent for ${city}.\n\nI understand real-time crowd flows, generational artisan guilds, legendary food gullies, and rural craft hamlets. Tell me what you'd like to experience or ask me to optimize your day.`,
      cards: [],
      suggestedActions: [
        { type: 'LOCAL', label: '🧭 Show me like a local' },
        { type: 'RURAL', label: '🌾 Beyond the City (Rural)' },
        { type: 'FOOD', label: '🍛 Where locals eat' },
        { type: 'OPTIMIZE_DAY', label: '⚡ Optimize today’s flow' }
      ],
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
  }

  createDomElements() {
    // 1. Floating Launcher Button
    let launcher = document.getElementById('roam-ai-launcher');
    if (!launcher) {
      launcher = document.createElement('div');
      launcher.id = 'roam-ai-launcher';
      launcher.className = 'roam-ai-launcher';
      launcher.innerHTML = `
        <button class="ai-launcher-btn" id="ai-launcher-toggle" aria-label="Open ROAM AI Travel Agent">
          <span class="ai-launcher-sparkle">✨</span>
          <span class="ai-launcher-label">ASK ROAM AI</span>
          <span class="ai-launcher-context" id="ai-launcher-context-pill">JAIPUR</span>
        </button>
      `;
      document.body.appendChild(launcher);
    }

    // 2. Slide-out Drawer / Overlay
    let drawer = document.getElementById('roam-ai-drawer');
    if (!drawer) {
      drawer = document.createElement('div');
      drawer.id = 'roam-ai-drawer';
      drawer.className = 'roam-ai-drawer';
      document.body.appendChild(drawer);
    }
    this.mount = drawer;

    const toggleBtn = document.getElementById('ai-launcher-toggle');
    if (toggleBtn) {
      toggleBtn.onclick = () => this.toggleDrawer();
    }
  }

  toggleDrawer(forceState) {
    this.isOpen = typeof forceState === 'boolean' ? forceState : !this.isOpen;
    if (this.mount) {
      if (this.isOpen) {
        this.mount.classList.add('open');
        this.render();
        const input = this.mount.querySelector('#roam-ai-chat-input');
        if (input) setTimeout(() => input.focus(), 150);
      } else {
        this.mount.classList.remove('open');
      }
    }
  }

  updateContextChip() {
    const pill = document.getElementById('ai-launcher-context-pill');
    if (pill) {
      pill.textContent = (travelState.location?.name || 'INDIA').toUpperCase();
    }
    if (this.isOpen) {
      this.render();
    }
  }

  async sendQuery(queryText) {
    if (!queryText || !queryText.trim()) return;
    const clean = queryText.trim();

    // Push User message
    this.messages.push({
      id: 'msg-user-' + Date.now(),
      sender: 'user',
      text: clean,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    });
    this.render();
    this.scrollToBottom();

    // Show typing state
    this.isTyping = true;
    this.render();
    this.scrollToBottom();

    // Process via AI Agent Engine
    const reply = await roamAIEngine.processQuery(clean);
    this.isTyping = false;
    if (reply) {
      this.messages.push(reply);
    }
    this.render();
    this.scrollToBottom();
  }

  scrollToBottom() {
    const scrollContainer = this.mount?.querySelector('#roam-ai-messages-wrap');
    if (scrollContainer) {
      scrollContainer.scrollTop = scrollContainer.scrollHeight;
    }
  }

  render() {
    if (!this.mount) return;

    const loc = travelState.location;
    const city = loc?.name || 'Jaipur';
    const prompts = roamAIEngine.getSuggestedPrompts();
    const dayHealth = travelState.dayHealth?.status || 'BALANCED';
    const mood = travelState.journeyMood;

    this.mount.innerHTML = `
      <div class="roam-ai-drawer-inner">
        
        <!-- Drawer Header -->
        <div class="ai-drawer-header">
          <div class="ai-drawer-header-left">
            <div class="ai-avatar">✨</div>
            <div>
              <div class="ai-title">ROAM DESTINATION AGENT</div>
              <div class="ai-subtitle">
                <span>${city.toUpperCase()}</span> • 
                <span class="ai-status-dot"></span>
                <span>Day Health: ${dayHealth}</span>
              </div>
            </div>
          </div>

          <button class="ai-drawer-close-btn" id="roam-ai-close-btn" aria-label="Close ROAM AI">&times;</button>
        </div>

        <!-- Agent Context Strip -->
        <div class="ai-context-indicator-strip">
          <span class="context-tag">🧭 ${mood?.touristLocal || 85}% Local</span>
          <span class="context-tag">🌿 ${mood?.chaosCalm || 65}% Calm</span>
          <span class="context-tag">📅 ${travelState.itinerary.length} Stops Active</span>
        </div>

        <!-- Suggestion Chips Strip -->
        <div class="ai-prompts-strip">
          <div class="ai-prompts-label">QUICK AGENT PROMPTS:</div>
          <div class="ai-prompts-scroller">
            ${prompts.map(p => `
              <button class="ai-prompt-chip" data-query="${p.text}">
                <span>${p.icon}</span>
                <span>${p.text}</span>
              </button>
            `).join('')}
          </div>
        </div>

        <!-- Chat Messages Container -->
        <div class="ai-messages-wrap" id="roam-ai-messages-wrap">
          ${this.messages.map(msg => {
            const isAI = msg.sender === 'roam_ai';
            return `
              <div class="ai-chat-bubble-row ${isAI ? 'ai-row' : 'user-row'}">
                <div class="ai-chat-bubble ${isAI ? 'bubble-ai' : 'bubble-user'}">
                  <div class="bubble-meta">
                    <span class="bubble-sender">${isAI ? '✨ ROAM AGENT' : 'YOU'}</span>
                    <span class="bubble-time">${msg.timestamp || ''}</span>
                  </div>

                  <div class="bubble-content">
                    ${this.formatMarkdown(msg.text)}
                  </div>

                  <!-- Structured Recommendation Cards -->
                  ${(msg.cards && msg.cards.length > 0) ? `
                    <div class="ai-recommendation-cards">
                      ${msg.cards.map(c => {
                        const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(c.mapsQuery || (c.destination + ', ' + city))}`;

                        return `
                          <div class="ai-card-item">
                            <div class="ai-card-top">
                              <div>
                                <div class="ai-card-title">${c.destination || c.title}</div>
                                <div class="ai-card-subtitle">${c.category} • ${c.distance || 'Nearby'}</div>
                              </div>
                              <a href="${mapsUrl}" target="_blank" rel="noopener noreferrer" class="ai-maps-btn" title="Open Google Maps">
                                MAPS ↗
                              </a>
                            </div>

                            <div class="ai-card-reason"><strong>Why:</strong> ${c.reason}</div>
                            
                            <div class="ai-card-meta-row">
                              <span>⏱️ ${c.estimatedDuration || '75m'}</span> • 
                              <span>💰 ${c.estimatedCost || '₹200'}</span> • 
                              <span>🟢 ${c.crowdStatus || 'Quiet'}</span>
                            </div>

                            <div class="ai-card-desc">${c.culturalSignificance || c.desc || ''}</div>

                            <div class="ai-card-actions">
                              ${c.action?.type === 'ADD_ITINERARY_ITEM' ? `
                                <button class="btn btn-sm btn-primary ai-add-itinerary-btn" data-title="${c.destination}" data-cat="${c.category}">
                                  + Add to Itinerary
                                </button>
                              ` : (c.action?.type === 'SWITCH_LOCATION' ? `
                                <button class="btn btn-sm btn-secondary ai-switch-loc-btn" data-locid="${c.action.locId}">
                                  ${c.action.label || 'Explore ➔'}
                                </button>
                              ` : '')}
                            </div>
                          </div>
                        `;
                      }).join('')}
                    </div>
                  ` : ''}

                  <!-- Suggested Action Triggers -->
                  ${(msg.suggestedActions && msg.suggestedActions.length > 0) ? `
                    <div class="ai-actions-row">
                      ${msg.suggestedActions.map(act => `
                        <button class="ai-action-btn" data-action="${act.type || act.action}">
                          ${act.label}
                        </button>
                      `).join('')}
                    </div>
                  ` : ''}

                </div>
              </div>
            `;
          }).join('')}

          ${this.isTyping ? `
            <div class="ai-chat-bubble-row ai-row">
              <div class="ai-chat-bubble bubble-ai typing-indicator-bubble">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span style="font-size:0.8rem; color:var(--text-muted); margin-left:8px;">ROAM Agent is synthesizing living data...</span>
              </div>
            </div>
          ` : ''}
        </div>

        <!-- Chat Input Bar -->
        <div class="ai-input-bar">
          <form id="roam-ai-form" class="ai-input-form">
            <input 
              type="text" 
              id="roam-ai-chat-input" 
              class="ai-chat-input" 
              placeholder="Ask anything or command ROAM (e.g. 'Show Jaipur like a local', 'Optimize day')..." 
              autocomplete="off"
            />
            <button type="submit" class="ai-send-btn" id="roam-ai-send-btn" title="Send Query">
              <span>Send</span> ➔
            </button>
          </form>
        </div>

      </div>
    `;

    this.attachEventListeners();
  }

  formatMarkdown(text) {
    if (!text) return '';
    let html = text
      .replace(/### (.*?)\n/g, '<h4 class="ai-h4">$1</h4>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/• (.*?)\n/g, '<div class="ai-bullet">• $1</div>')
      .replace(/\n\n/g, '<br/><br/>');
    return html;
  }

  attachEventListeners() {
    if (!this.mount) return;

    // Close Button
    const closeBtn = this.mount.querySelector('#roam-ai-close-btn');
    if (closeBtn) closeBtn.onclick = () => this.toggleDrawer(false);

    // Form Submit
    const form = this.mount.querySelector('#roam-ai-form');
    const input = this.mount.querySelector('#roam-ai-chat-input');
    if (form && input) {
      form.onsubmit = (e) => {
        e.preventDefault();
        const val = input.value;
        if (val) {
          input.value = '';
          this.sendQuery(val);
        }
      };
    }

    // Prompt Chips
    this.mount.querySelectorAll('.ai-prompt-chip').forEach(chip => {
      chip.onclick = () => {
        const query = chip.dataset.query;
        this.sendQuery(query);
      };
    });

    // Add to Itinerary from AI card
    this.mount.querySelectorAll('.ai-add-itinerary-btn').forEach(btn => {
      btn.onclick = () => {
        const title = btn.dataset.title;
        const cat = (btn.dataset.cat || 'culture').toLowerCase();
        const res = travelState.addPlaceIntelligently({
          name: title,
          category: cat,
          durationMinutes: 75
        });
        if (this.app?.modalController) {
          this.app.modalController.showToast(`Added ${title} to your plan (${res.time})`);
        }
        btn.textContent = '✓ Added to Itinerary';
        btn.disabled = true;
      };
    });

    // Switch location from AI card
    this.mount.querySelectorAll('.ai-switch-loc-btn').forEach(btn => {
      btn.onclick = () => {
        const locId = btn.dataset.locid;
        if (locId && this.app) {
          this.app.setLocation(locId);
          this.toggleDrawer(false);
          if (this.app.modalController) {
            this.app.modalController.showToast(`Switched destination to ${locId.toUpperCase()}`);
          }
        }
      };
    });

    // Action button triggers
    this.mount.querySelectorAll('.ai-action-btn').forEach(btn => {
      btn.onclick = () => {
        const action = btn.dataset.action;
        
        if (action === 'APPLY_OPTIMIZED_DAY' || action === 'OPTIMIZE_DAY') {
          const comp = travelState.balanceDay();
          if (comp) {
            travelState.applyBalancedSchedule(comp.balancedPlan);
            if (this.app?.modalController) {
              this.app.modalController.showToast('Applied optimized day schedule! Peak queues eliminated.');
            }
            this.app.switchMode('plan');
            this.toggleDrawer(false);
          }
        } else if (action === 'SWITCH_MODE_PLAN') {
          this.app.switchMode('plan');
          this.toggleDrawer(false);
        } else if (action === 'SWITCH_MODE_MARKET') {
          this.app.switchMode('market');
          this.toggleDrawer(false);
        } else if (action === 'OPEN_MAP') {
          this.app.switchMode('discover');
          this.toggleDrawer(false);
          const mapEl = document.getElementById('map-canvas-container');
          if (mapEl) mapEl.scrollIntoView({ behavior: 'smooth' });
        } else if (action === 'FILTER_DISCOVERY_RURAL') {
          this.app.switchMode('discover');
          if (this.app.discoverView) this.app.discoverView.setTier('RURAL');
          this.toggleDrawer(false);
          const disc = document.getElementById('national-discover-mount');
          if (disc) disc.scrollIntoView({ behavior: 'smooth' });
        } else if (action === 'ADD_BREAK_CHAI') {
          travelState.insertBreak('chai');
          if (this.app?.modalController) {
            this.app.modalController.showToast('Added 30-min Masala Chai break ☕');
          }
          this.app.switchMode('plan');
          this.toggleDrawer(false);
        } else if (action.startsWith('ROUTE_')) {
          const route = action.replace('ROUTE_', '').toLowerCase();
          travelState.setActiveRoute(route);
          if (this.app?.modalController) {
            this.app.modalController.showToast(`Active route lens: ${route.toUpperCase()}`);
          }
          this.app.switchMode('discover');
          this.toggleDrawer(false);
        } else if (action === 'LOCAL') {
          this.sendQuery(`Show me ${travelState.location?.name || 'Jaipur'} like a local`);
        } else if (action === 'RURAL') {
          this.sendQuery('Find village & rural craft experiences near here');
        } else if (action === 'FOOD') {
          this.sendQuery('Where can I eat where locals go?');
        }
      };
    });
  }
}
