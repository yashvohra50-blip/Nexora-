/**
 * ROAM Discover View Component (V4)
 * "India's Living Destination Intelligence Layer"
 *
 * Features:
 * 1. 3-Tier Discovery:
 *    - Tier 1: Iconic Capitals & Heritage
 *    - Tier 2: Emerging Cultural Hubs
 *    - Tier 3: Rural India & Craft Villages (First-Class Citizen)
 * 2. "BEYOND THE CITY" Signature Rural Exploration Layer
 * 3. "ROAM It Differently" Thematic Lens Selector (10 Curated Routes)
 * 4. Live "Right Now" Destination Telemetry Strip (Clearly Labelled Modelled Forecast)
 * 5. Regional Quick Filters (North, South, West, East, Northeast)
 */

import { ALL_INDIAN_LOCATIONS } from '../data/locations/index.js';
import { travelState } from '../state/travelState.js';
import { formatIndianNumber } from '../utils/formatters.js';

export class DiscoverViewController {
  constructor(mountId, options = {}) {
    this.mount = typeof mountId === 'string' ? document.getElementById(mountId) : mountId;
    this.onSelectLocation = options.onSelectLocation || (() => {});
    this.activeTier = 'ALL_TIERS'; // 'ALL_TIERS' | 'TIER_1' | 'TIER_2' | 'RURAL'
    this.activeRegion = 'ALL';     // 'ALL' | 'NORTH' | 'SOUTH' | 'WEST' | 'EAST' | 'NORTHEAST'
    this.init();
  }

  init() {
    if (!this.mount) return;
    this.render();

    // Re-render when route or location changes
    travelState.subscribe((event) => {
      if (['route:changed', 'location:changed', 'mood:changed'].includes(event)) {
        this.render();
      }
    });
  }

  setTier(tier) {
    this.activeTier = tier;
    this.render();
  }

  setRegion(reg) {
    this.activeRegion = reg;
    this.render();
  }

  render() {
    if (!this.mount) return;

    const loc = travelState.location || ALL_INDIAN_LOCATIONS[0];
    const telemetry = travelState.getRightNowTelemetry();
    const activeRoute = travelState.activeRoute || 'all';

    // Filter locations by Tier and Region
    let filtered = ALL_INDIAN_LOCATIONS;

    if (this.activeTier === 'TIER_1') {
      filtered = filtered.filter(l => l.tier === 'FULL' || l.type === 'HERITAGE_CAPITAL' || l.type === 'METRO_HERITAGE');
    } else if (this.activeTier === 'TIER_2') {
      filtered = filtered.filter(l => l.type === 'SPIRITUAL_CAPITAL' || l.type === 'PILGRIMAGE_GATEWAY' || l.type === 'HIMALAYAN_CROSSROADS' || l.tier === 'PARTIAL');
    } else if (this.activeTier === 'RURAL') {
      filtered = filtered.filter(l => l.type.includes('VILLAGE') || l.tier === 'RURAL');
    }

    if (this.activeRegion !== 'ALL') {
      filtered = filtered.filter(l => l.region === this.activeRegion);
    }

    const routes = [
      { id: 'all', label: 'All Lenses', icon: '🌐' },
      { id: 'local', label: 'The Local Route', icon: '🧭' },
      { id: 'food', label: 'The Food Trail', icon: '🍛' },
      { id: 'craft', label: 'The Craft Trail', icon: '🧵' },
      { id: 'hidden', label: 'The Hidden Route', icon: '🌿' },
      { id: 'rural', label: 'Beyond The City', icon: '🌾' },
      { id: 'slow', label: 'The Slow Life', icon: '☕' },
      { id: 'night', label: 'Night Explorer', icon: '🌙' },
      { id: 'photo', label: 'Photography Walk', icon: '📸' },
      { id: 'budget', label: 'The Budget Route', icon: '💰' }
    ];

    this.mount.innerHTML = `
      <!-- Live Right Now Destination Telemetry Ticker -->
      ${telemetry ? `
        <div class="right-now-telemetry-card">
          <div class="telemetry-inner">
            <div class="telemetry-live-badge">
              <span class="pulse-green-dot"></span>
              <span>RIGHT NOW: ${telemetry.cityName.toUpperCase()}, ${telemetry.stateName.toUpperCase()}</span>
              <span class="telemetry-model-pill">MODELLED TELEMETRY</span>
            </div>

            <div class="telemetry-metrics-row">
              <div class="telemetry-metric">
                <span class="metric-lbl">Flow Status</span>
                <span class="metric-val" style="color:${telemetry.crowdLoadColor};">${telemetry.crowdLoadStatus}</span>
              </div>
              <div class="telemetry-metric">
                <span class="metric-lbl">Weather & Vibe</span>
                <span class="metric-val">${telemetry.temperature} • ${telemetry.weatherDesc}</span>
              </div>
              <div class="telemetry-metric">
                <span class="metric-lbl">Best Window Right Now</span>
                <span class="metric-val" style="color:var(--roam-accent);">${telemetry.bestWindowNow}</span>
              </div>
              <div class="telemetry-metric">
                <span class="metric-lbl">ROAM Local Score</span>
                <span class="metric-val" style="color:var(--load-optimal);">${telemetry.liveScore}/100</span>
              </div>
            </div>
          </div>
        </div>
      ` : ''}

      <!-- "ROAM It Differently" Thematic Route Picker -->
      <div class="roam-differently-card">
        <div class="differently-header">
          <div>
            <div class="plan-eyebrow">EXPERIENCE LENSES</div>
            <h3 class="differently-title">ROAM IT DIFFERENTLY</h3>
          </div>
          <p class="differently-desc">
            Switch how ROAM perceives and curates India. Each lens reshapes itinerary stops, timings, and verified artisan guild connections.
          </p>
        </div>

        <div class="route-lenses-bar">
          ${routes.map(r => `
            <button class="route-lens-btn ${activeRoute === r.id ? 'active' : ''}" data-route="${r.id}">
              <span class="lens-icon">${r.icon}</span>
              <span class="lens-name">${r.label}</span>
            </button>
          `).join('')}
        </div>
      </div>

      <!-- "BEYOND THE CITY" Signature Rural Exploration Banner -->
      <div class="beyond-the-city-banner">
        <div class="beyond-content">
          <div class="beyond-badge">🌾 BEYOND THE CITY • FIRST-CLASS RURAL DISCOVERY</div>
          <h2 class="beyond-headline">“Some of India's best stories don't have a pin on the tourist map.”</h2>
          <p class="beyond-sub">
            Experience living artisan guilds, traditional earthen kitchens, generational handloom clusters, and community-led agro-homestays where your spending directly sustains working families.
          </p>
          <div class="beyond-pills">
            <span class="beyond-pill">🧵 Generational Weavers</span>
            <span class="beyond-pill">🏺 Terracotta Potteries</span>
            <span class="beyond-pill">🍲 Village Kitchens</span>
            <span class="beyond-pill">🏡 Heritage Homestays</span>
            <span class="beyond-pill">🌾 Organic Agro-Tourism</span>
          </div>
        </div>
      </div>

      <!-- 3-Tier Discovery & National Explorer Section -->
      <div class="national-explorer-section">
        <div class="explorer-header-row">
          <div>
            <div class="plan-eyebrow">NATIONAL DESTINATION NETWORK</div>
            <h2 class="explorer-title">ALL DESTINATIONS & REGIONAL HUBS</h2>
            <p class="explorer-subtitle">
              Discover iconic heritage capitals, emerging cultural towns, and authentic rural craft villages across 28 States & 8 Union Territories.
            </p>
          </div>

          <!-- 3-Tier Pill Switcher -->
          <div class="tier-switcher-pills">
            <button class="tier-pill ${this.activeTier === 'ALL_TIERS' ? 'active' : ''}" data-tier="ALL_TIERS">
              All Destinations (${ALL_INDIAN_LOCATIONS.length})
            </button>
            <button class="tier-pill ${this.activeTier === 'TIER_1' ? 'active' : ''}" data-tier="TIER_1">
              🌟 Tier 1: Iconic Capitals
            </button>
            <button class="tier-pill ${this.activeTier === 'TIER_2' ? 'active' : ''}" data-tier="TIER_2">
              🌿 Tier 2: Emerging Hubs
            </button>
            <button class="tier-pill tier-rural-pill ${this.activeTier === 'RURAL' ? 'active' : ''}" data-tier="RURAL">
              🌾 Tier 3: Rural & Craft Villages
            </button>
          </div>
        </div>

        <!-- Regional Filter Tabs -->
        <div class="discover-filter-bar">
          ${['ALL', 'NORTH', 'SOUTH', 'WEST', 'EAST', 'NORTHEAST'].map(reg => `
            <button class="discover-filter-btn ${this.activeRegion === reg ? 'active' : ''}" data-region="${reg}">
              ${reg === 'ALL' ? 'All India' : reg + ' India'}
            </button>
          `).join('')}
        </div>

        <!-- Destination Cards Grid -->
        <div class="discover-cards-grid">
          ${filtered.map(locItem => {
            const isFull = locItem.tier === 'FULL';
            const isRural = locItem.type.includes('VILLAGE') || locItem.tier === 'RURAL';
            const typeClass = 'type-' + locItem.type.toLowerCase();

            return `
              <div class="discover-card ${isRural ? 'rural-card-highlight' : ''}">
                <div>
                  <div class="discover-card-top">
                    <div>
                      <div class="discover-city-name">${locItem.name}</div>
                      <div class="discover-state-name">${locItem.state} • ${locItem.region}</div>
                    </div>
                    <span class="res-badge ${typeClass}">
                      ${isRural ? '🌾 RURAL CRAFT' : locItem.type.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div style="margin-top:8px;">
                    ${isFull 
                      ? '<span class="badge badge-optimal">✓ FULL TELEMETRY</span>'
                      : (isRural ? '<span class="badge badge-rural">🌾 VERIFIED GUILD</span>' : '<span class="badge badge-elevated">PARTIAL INTELLIGENCE</span>')
                    }
                  </div>

                  <p class="discover-card-desc">
                    ${locItem.culturalDna || `Historic cultural and artisan hub in ${locItem.state}.`}
                  </p>

                  <div class="discover-tagline">
                    Tags: ${(locItem.tags || []).slice(0, 3).join(' • ')}
                  </div>
                </div>

                <button class="discover-action-btn" data-id="${locItem.id}">
                  <span>EXPLORE DESTINATION FLOWS ➔</span>
                </button>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;

    this.attachEvents();
  }

  attachEvents() {
    // Route Lenses
    this.mount.querySelectorAll('.route-lens-btn').forEach(btn => {
      btn.onclick = () => {
        const route = btn.dataset.route;
        travelState.setActiveRoute(route);
      };
    });

    // Tier Switcher Pills
    this.mount.querySelectorAll('.tier-pill').forEach(btn => {
      btn.onclick = () => {
        this.setTier(btn.dataset.tier);
      };
    });

    // Region Filter Tabs
    this.mount.querySelectorAll('.discover-filter-btn').forEach(btn => {
      btn.onclick = () => {
        this.setRegion(btn.dataset.region);
      };
    });

    // Select Location Button
    this.mount.querySelectorAll('.discover-action-btn').forEach(btn => {
      btn.onclick = () => {
        const id = btn.dataset.id;
        this.onSelectLocation(id);
      };
    });
  }
}
