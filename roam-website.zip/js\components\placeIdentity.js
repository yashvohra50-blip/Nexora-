/**
 * ROAM Place Identity Component (V3)
 * Living Cultural DNA & Untold Facts:
 * Renders prominent cultural pillars & untold facts cards in front of the living background.
 */

import { LOCATION_THEMES } from '../data/themes/locationThemes.js';
import { renderTooltip } from '../utils/formatters.js';

// Deep Cultural Facts Database for Indian Heritage Cities (Creative & High-Engagement Edition)
const CITY_UNTOLD_FACTS = {
  jaipur: [
    {
      icon: '👑',
      statBadge: '👑 100% PINK BY LAW',
      tag: 'Royal Decree',
      title: 'Why Jaipur is Legally Terracotta Pink',
      hook: 'One royal visit in 1876 changed the entire city’s color code forever.',
      story: 'To welcome Britain’s Prince Albert in 1876, Maharaja Ram Singh painted the entire walled city in <strong>terracotta pink</strong>—the traditional Rajput shade of hospitality. He loved the transformation so much that he enacted a royal decree making it <strong>illegal for any building in the historic center to be painted any other shade</strong>. Jaipur’s municipal corporation strictly enforces the pink law even today!',
      secretTip: 'Look at the shop shutters in Johari Bazaar—even modern commercial businesses are legally required to retain the standardized terracotta borders.'
    },
    {
      icon: '🌬️',
      statBadge: '⚡ 0 ELECTRICITY',
      tag: 'Physics of Architecture',
      title: 'The 45°C Air Conditioner Miracle',
      hook: 'How 953 windows cool an entire 5-story palace with pure fluid dynamics.',
      story: 'Hawa Mahal was engineered with <strong>953 micro-latticed honeycomb jharokhas</strong> that harness the <em>Venturi effect</em>. As scorching desert air squeezes through the miniature openings, air pressure drops and chills—creating a continuous cooling breeze throughout the palace during <strong>45°C Thar summer heatwaves</strong> without a single watt of power.',
      secretTip: 'Stand right behind the center lattice on the 4th floor at 2 PM to feel the icy natural breeze draft through the casement.'
    },
    {
      icon: '💎',
      statBadge: '💎 80% WORLD EMERALDS',
      tag: 'Hidden Guilds',
      title: 'Earth’s Secret Gem Vault',
      hook: 'Tucked inside medieval alleyways lies the world’s secret gem-cutting capital.',
      story: 'Deep inside the narrow galis of Johari Bazaar, over <strong>300,000 generational lapidaries</strong> cut and polish more than <strong>80% of the entire world’s emeralds and tanzanites</strong>. Master gem-cutters still use century-old hand-turned wooden wheels (*patra*) to shape millions of carats of raw precious gems each month.',
      secretTip: 'Wander through Gopal Ji Ka Rasta at 11 AM to see gemstone merchants evaluating raw Colombian emeralds under natural morning sunlight on white mattresses.'
    },
    {
      icon: '📐',
      statBadge: '⏱️ 2-SEC PRECISION',
      tag: 'Vedic Astronomy',
      title: 'The Giant Shadow Time Machine',
      hook: 'The world’s largest stone sundial calculates solar time in real-time.',
      story: 'The 27-meter tall <strong>Vrihat Samrat Yantra</strong> at Jantar Mantar is the largest stone sundial ever built. Designed in 1734 by astronomer-king Sawai Jai Singh II, its cast shadow travels at <strong>1 millimeter every single second</strong> (6 cm/min), measuring local solar time to an astonishing accuracy of <strong>within 2 seconds</strong> purely from celestial geometry.',
      secretTip: 'Watch the shadow tip slide across the fine marble graduations—you can visibly watch the Earth rotating in real time!'
    }
  ],
  varanasi: [
    {
      icon: '🔥',
      statBadge: '🔥 3,000 YRS UNBROKEN',
      tag: 'Sacred Antiquity',
      title: 'The Flame That Never Sleeps',
      hook: 'One ceremonial fire that has stayed continuously lit since antiquity.',
      story: 'The sacred eternal flame at Manikarnika Ghat is guarded day and night by the <strong>Dom Raja clan</strong>. Continuous chronicles attest that this ceremonial fire has <strong>burned without extinguishing for over 3,000 years</strong>. Every cremation and sacred temple ritual in the ancient quarter draws fire directly from this ancient hearth.',
      secretTip: 'Observe from a respectful distance by wooden rowboat at dusk—the firelit silhouette against the stone ghats is an unforgettable sight.'
    },
    {
      icon: '🧵',
      statBadge: '✨ PURE SILVER & GOLD',
      tag: 'Silk Alchemy',
      title: 'Sarees Spun from Precious Metals',
      hook: 'Where master weavers spend 6 months mathematically weaving a single drape.',
      story: 'Authentic Banarasi silk is interlaced on subterranean pit looms using <strong>pure silver wire electroplated with 24K gold</strong> (called *Zari*). An intricate bridal masterpiece requires over <strong>5,600 punch cards</strong> and up to <strong>6 months of synchronized hand weaving</strong> by two master artisans.',
      secretTip: 'Authentic heritage Banarasi silk is so dense with real gold and silver threads that a traditional bridal saree can weigh between 1.5 to 2.5 kg!'
    },
    {
      icon: '🌅',
      statBadge: '🎶 5:15 AM DAWN RAGA',
      tag: 'Spiritual Symphony',
      title: 'The Awakening of the Ganges',
      hook: 'Where ancient ragas, fire, and sacred river mist harmonize at sunrise.',
      story: 'Every morning at 5:15 AM at Assi Ghat, the holy city awakens with <strong>Subah-e-Banaras</strong>: synchronized brass lamp aarti, resonant Sanskrit Vedic chants by young scholars, and live classical sitar and shehnai ragas tuned specifically to the rising sun as mist lifts off the holy crescent river curve.',
      secretTip: 'Arrive by 5:00 AM for the sound of conch shells echoing across the water—it is universally celebrated as Varanasi’s most meditative hour.'
    },
    {
      icon: '🥣',
      statBadge: '🌙 DEW-WHIPPED CLOUD',
      tag: 'Culinary Alchemy',
      title: 'The Cloud Dessert of Chaukhamba',
      hook: 'A winter delicacy prepared under open night skies and morning dew.',
      story: 'In the narrow alleys of Chaukhamba, raw milk is boiled in massive iron cauldrons, then left on open rooftops to <strong>absorb the chilly winter night dew</strong>. At 4 AM, it is aerated and hand-whipped under moonlight with saffron, pistachios, and green cardamom until it turns into a <strong>cloud-like foam that dissolves instantly</strong> on the palate.',
      secretTip: 'Malaiyo is only prepared from November to February—if you visit in winter, eat it before 10 AM before the morning sun melts the delicate foam!'
    }
  ],
  mumbai: [
    {
      icon: '🍱',
      statBadge: '📊 99.99999% ACCURACY',
      tag: 'Logistics Marvel',
      title: 'The Zero-Error Human Algorithm',
      hook: '5,000 men deliver 200,000 lunches daily with zero barcode scanners.',
      story: 'Without a single line of software or barcodes, Mumbai’s <strong>5,000 Dabbawalas</strong> transport <strong>200,000 hot home-cooked tiffins</strong> across 70 kilometers of suburban rail every day. Their color-coded alphanumeric sorting system achieved a <strong>Six Sigma rating (1 error in 6 million deliveries)</strong>—studied by Harvard Business School and praised worldwide.',
      secretTip: 'Witness the lightning-fast tiffin sorting synchronization at Churchgate Station platform between 11:30 AM and 12:00 PM.'
    },
    {
      icon: '🌊',
      statBadge: '🏝️ 7 ISLANDS RECLAIMED',
      tag: 'Urban Geology',
      title: 'The Ocean That Became a Megacity',
      hook: 'How seven disconnected fishing isles were stitched into a metropolis.',
      story: 'Until the 19th century, Mumbai was an archipelago of <strong>seven distinct mangrove islands</strong> separated by treacherous tidal creeks. Through the massive Hornby Vellard civil engineering project, millions of tons of basalt rock were dumped over 150 years to merge the islands into the continuous urban peninsula seen today.',
      secretTip: 'Walk through Worli Koliwada village—it sits on one of the original 7 island landmasses and preserves 800-year-old indigenous Koli fishing traditions.'
    },
    {
      icon: '🏛️',
      statBadge: '🏙️ #2 ON PLANET EARTH',
      tag: 'Architecture Heritage',
      title: 'The Tropical Art Deco Riviera',
      hook: 'The second-largest collection of Art Deco buildings anywhere on Earth.',
      story: 'Stretching gracefully along Marine Drive and Oval Maidan, Mumbai boasts over <strong>200 heritage Art Deco buildings</strong>—second only to Miami Beach worldwide. Built during the 1930s jazz era, these UNESCO-listed buildings blend nautical curves, sunburst balconies, and Indian mythological motifs into unique *Indo-Deco*.',
      secretTip: 'Look at the balconies along Marine Drive: many are shaped like ocean liner steamship decks, portholes, and nautical steering wheels.'
    },
    {
      icon: '☕',
      statBadge: '🍞 100+ YEARS OF CHAI',
      tag: 'Culinary Lore',
      title: 'Bun Maska & Vintage Mirrors',
      hook: 'Where time stopped in 1910 behind bentwood chairs and marble tables.',
      story: 'Established by Zoroastrian Persian immigrants in the late 19th century, Mumbai’s historic Irani Cafes are living time capsules. Featuring soaring high ceilings, Belgian cut-glass mirrors, and marble tops, they serve legendary <strong>crusty Brun Maska dipped in sweet Irani Chai</strong>, spicy mutton keema pav, and signature Berry Pulao.',
      secretTip: 'Read the vintage chalkboard rules in Kyani & Co.—famous for classic humorous warnings like "No comb hair, no sleeping, no discussion of politics"!'
    }
  ],
  kochi: [
    {
      icon: '🎣',
      statBadge: '⚖️ 600-YR OLD PHYSICS',
      tag: 'Maritime Marvel',
      title: 'The Spider-Legged Fishing Giants',
      hook: '10-meter teakwood levers balanced by massive granite boulders.',
      story: 'Introduced by traders from the court of Mongol emperor Kublai Khan in the 14th century, Kochi’s <strong>Cheenavala</strong> are monumental cantilevered fishing nets. Suspended 10 meters over the Arabian Sea, each net is counterbalanced by heavy granite rocks tied to coir ropes and operated in rhythm by a crew of <strong>6 synchronized fishermen</strong>.',
      secretTip: 'Walk to Vasco da Gama Square at sunset—fishermen often invite visitors to help pull the boulder ropes to hoist the evening catch.'
    },
    {
      icon: '🌿',
      statBadge: '💰 WORTH MORE THAN GOLD',
      tag: 'Spice Trade',
      title: 'The Wharf That Fueled the Roman Empire',
      hook: 'Where Roman galleys traded chests of gold coins for Malabar black pepper.',
      story: 'Centuries before Vasco da Gama landed in 1498, Kochi and the ancient port of Muziris were the <strong>epicenter of the global spice trade</strong>. Roman historians recorded that a single sack of Malabar black pepper (*Black Gold*) was worth more than a Roman soldier’s annual wage in pure solid silver.',
      secretTip: 'Visit the Spice Bazaar on Bazaar Road—the intoxicating aroma of freshly crushed ginger, nutmeg, and Tellicherry pepper still fills the entire street.'
    },
    {
      icon: '🎭',
      statBadge: '🎨 100% CRUSHED MINERALS',
      tag: 'Sacred Arts',
      title: 'The 4-Hour Transformation into Gods',
      hook: 'Where actors paint with crushed stone and rice-paste ridges for 8-hour epics.',
      story: 'Before stepping onto the temple stage for an all-night Kathakali performance, actors spend <strong>4 silent hours in the green room</strong> having their faces painted with ground stone pigments (red arsenic, green cinnabar, and black lampsoot) and sculpted with <em>chutti</em> (white rice-paste facial ridges) to project vivid facial expressions.',
      secretTip: 'Arrive 1 hour before evening Kathakali shows at Kerala Kathakali Centre to watch the sacred silent makeup ritual firsthand.'
    },
    {
      icon: '✡️',
      statBadge: '🎨 1,000+ UNIQUE TILES',
      tag: 'Living Heritage',
      title: 'The Blue Willow Floor of Jew Town',
      hook: 'A synagogue paved with 1,000+ hand-painted porcelain tiles from Canton.',
      story: 'Constructed in 1568, the Paradesi Synagogue in Mattancherry is paved with over <strong>1,000 hand-painted blue-and-white porcelain tiles</strong> brought from Canton, China in 1762. Because each tile was hand-painted by master artisans, <strong>no two tiles on the entire floor have the exact same brushstrokes</strong>.',
      secretTip: 'Step inside without shoes to feel the cool glazed Chinese porcelain underfoot beneath century-old Belgian crystal chandeliers.'
    }
  ],
  leh: [
    {
      icon: '❄️',
      statBadge: '🧊 40M ICE GLACIERS',
      tag: 'Geo-Engineering',
      title: 'The Towering Ice Pyramids of Ladakh',
      hook: 'How Ladakhi engineers freeze winter streams into giant water towers.',
      story: 'In the high-altitude Himalayan desert where rainfall is scarce, visionary Ladakhi engineer Sonam Wangchuk pioneered <strong>Ice Stupas</strong>. Using gravity-fed underground pipes without any fuel or pumps, winter meltwater is sprayed into sub-zero night air, freezing into <strong>40-meter conical ice towers</strong> that store millions of liters of water to irrigate spring barley fields.',
      secretTip: 'Visit Phyang or Igoo village in February to see the massive blue-ice cones rising dramatically against the barren mountain slopes.'
    },
    {
      icon: '🏔️',
      statBadge: '🏔️ 17,982 FT PASS',
      tag: 'High Altitude',
      title: 'The World’s Highest Caravan Route',
      hook: 'Where Bactrian two-humped camels crossed the roof of the world.',
      story: 'Leh was the crucial mountain hub where the Trans-Himalayan trade routes intersected. Caravans carrying pashmina wool, Tibetan turquoise, and Chinese silk traversed <strong>Khardung La and Karakoram Pass at nearly 18,000 feet</strong>, braving thin air, blizzards, and sheer rock cliffs for months to reach Central Asia.',
      secretTip: 'Visit Hunder in the Nubra Valley to see direct descendants of the original double-humped Bactrian Silk Road camels grazing on sand dunes.'
    },
    {
      icon: '🎺',
      statBadge: '🔊 3-METER BRASS HORNS',
      tag: 'Tantric Mysticism',
      title: 'The Mountain-Shaking Monastic Horns',
      hook: 'Deep sonic vibrations that echo across high-altitude Himalayan valleys.',
      story: 'During sacred monastic festivals like Hemis Tsechu, Buddhist monks play <strong>10-foot-long telescoping copper horns called Dungchen</strong>. Their deep, subsonic vibrational frequencies mimic the thunder of the high mountains, accompanying masked <em>Cham</em> dancers who portray wrathful protector deities.',
      secretTip: 'Sit near the monastery courtyard roof at Hemis Monastery during morning prayers to feel the deep resonance vibrate through the wooden floorboards.'
    },
    {
      icon: '🍵',
      statBadge: '🧈 YAK BUTTER FUEL',
      tag: 'Mountain Survival',
      title: 'The Sub-Zero Survival Elixir',
      hook: 'Churned yak butter and pink salt that powers Himalayan monks.',
      story: 'Surviving -30°C Himalayan winters requires a unique caloric fuel: <strong>Gur-Gur Chai</strong>. Prepared by churning boiled mountain tea leaves with rich <strong>yak butter and Himalayan pink rock salt</strong> inside tall wooden cylinders, it provides the essential lipids and electrolytes needed to prevent altitude sickness and retain body heat.',
      secretTip: 'Knead roasted barley flour (*Tsampa*) directly into the warm butter tea in your wooden bowl to make a traditional Ladakhi travel snack.'
    }
  ],
  delhi: [
    {
      icon: '🏛️',
      statBadge: '👑 7 HISTORIC CAPITALS',
      tag: 'Layered Empires',
      title: 'The City Built on Seven Empires',
      hook: 'Delhi is not one city—it is seven medieval empires stacked in stone.',
      story: 'Modern Delhi is built directly upon the remnants of <strong>seven distinct medieval capitals</strong>—from Prithviraj Chauhan’s Qila Rai Pithora (1180 AD) to Tughlaqabad’s fortress, Siri’s war moats, and Shah Jahan’s walled Shahjahanabad. Everywhere you walk, <strong>1,000 years of dynastic history</strong> lies just beneath the modern pavement.',
      secretTip: 'Visit Mehrauli Archaeological Park at sunset—you can see 700 years of Tomar, Sultanate, Mughal, and British architectural layers all within a 5-minute walk.'
    },
    {
      icon: '🍛',
      statBadge: '🌶️ 400 YEARS TRADING',
      tag: 'Spice Trade',
      title: 'The Aromatic Labyrinth of Khari Baoli',
      hook: 'Operating continuously since 1650 with mountain-high spice sacks.',
      story: 'Established in 1650 during the reign of Mughal Emperor Shah Jahan, <strong>Khari Baoli</strong> is Asia’s largest wholesale spice market. Generations of traders navigate narrow vaulted brick corridors stacked with thousands of tons of Kashmiri saffron, dried red chili mountains, green cardamom, and rare Himalayan medicinal roots.',
      secretTip: 'Climb the narrow steps inside Gadodia Market building up to the open rooftop for a panoramic view of spice merchants drying golden chilies in the sun.'
    },
    {
      icon: '🎵',
      statBadge: '🎶 700-YEAR TRADITION',
      tag: 'Sufi Heritage',
      title: 'The Thursday Night Mystic Echo',
      hook: 'Where descendants of Amir Khusrau sing ecstatic poetry under yellow lights.',
      story: 'Every Thursday after sunset, the marble courtyard of the 14th-century <strong>Hazrat Nizamuddin Dargah</strong> fills with the intoxicating sounds of live Sufi Qawwali. Hereditary Nizami musicians sing poetry composed by 13th-century polymath Amir Khusrau, maintaining a <strong>700-year continuous musical lineage</strong> of devotion and peace.',
      secretTip: 'Sit on the cool marble courtyard floor by 6:00 PM to secure a front spot near the harmonium and dholak musicians.'
    },
    {
      icon: '🌳',
      statBadge: '🌿 23% GREEN CANOPY',
      tag: 'Urban Canopy',
      title: 'The Forested Capital of Avenues',
      hook: 'Over 250 species of heritage trees form a living green tunnel across the city.',
      story: 'Designed in 1912 by Edwin Lutyens with botanist Walter Sykes George, New Delhi was laid out as an imperial garden city. Over <strong>250 species of indigenous trees</strong>—including flowering Amaltas (golden rain), Tamarind, and evergreen Neem—were planted along radial avenues, giving Delhi an astonishing <strong>23% forested green canopy cover</strong>.',
      secretTip: 'Drive down Shanti Path in May when the Amaltas trees bloom in brilliant cascading golden-yellow flowers!'
    }
  ]
};

// Deep Cultural Inquiries Database for 6 Signature Cultural Questions
const CITY_CULTURAL_INQUIRIES = {
  jaipur: [
    {
      icon: '🏛️',
      title: 'WHY THIS EXISTS',
      question: 'Why was Jaipur founded in 1727 on a rigid grid?',
      answer: 'Founded in 1727 by astronomer-king Maharaja Sawai Jai Singh II, Jaipur was designed on ancient Vedic Vastu Shastra gridiron geometry with wide straight avenues. It was built to solve acute water scarcity in the rocky Amber citadel and establish an open commercial and craft capital.'
    },
    {
      icon: '🧭',
      title: 'WHY LOCALS DO THIS',
      question: 'Why do locals gather in Johari Bazaar before 11 AM?',
      answer: 'Generations of gem brokers gather over morning kulhad chai and hot hing kachoris before the 11 AM gaddi (white mattress) gem trading hours begin, closing deals worth millions on oral trust alone.'
    },
    {
      icon: '👁️',
      title: 'WHAT TOURISTS MISS',
      question: 'What subterranean heritage is hidden behind shopfronts?',
      answer: 'The subterranean rainwater harvesting stepwells (*baoris*) and hidden 18th-century temple havelis tucked quietly behind modern commercial shop shutters in the walled city alleys.'
    },
    {
      icon: '🏺',
      title: 'THE STORY BEHIND THIS CRAFT',
      question: 'What is the alchemy behind Jaipur Blue Pottery?',
      answer: 'Unlike clay pottery, Jaipur Blue Pottery is made from Egyptian paste: quartz stone powder, Fuller’s earth, and natural plant gum. Fired only once, its turquoise and cobalt hues come from natural copper oxide and cobalt minerals.'
    },
    {
      icon: '🍲',
      title: 'WHAT THIS FOOD MEANS',
      question: 'How did Dal Baati Churma power desert armies?',
      answer: 'Dal Baati Churma originated as battlefield ration for medieval Rajput warriors. Dough baatis were buried in desert sand under coals, baked slowly, and kept preserved for weeks, dipped in energy-dense ghee.'
    },
    {
      icon: '🔥',
      title: 'WHO KEEPS THIS TRADITION ALIVE',
      question: 'Who preserves the generational craft guilds?',
      answer: 'Generations of Chippa block-printers in Bagru and Sanganer and hereditary Kumhar potters who continue to hand-carve teakwood blocks and formulate 100% natural plant dyes.'
    }
  ],
  varanasi: [
    {
      icon: '🏛️',
      title: 'WHY THIS EXISTS',
      question: 'Why did 3,000 years of civilization center on this river crescent?',
      answer: 'Situated where the sacred Ganges bends northward (*Uttara-vahini*) toward the Himalayas, Varanasi was established in antiquity as the sacred axis of liberation (*Moksha*), where dying transcends the cycle of rebirth.'
    },
    {
      icon: '🧭',
      title: 'WHY LOCALS DO THIS',
      question: 'Why do locals perform the dawn Ganges dip?',
      answer: 'Locals begin every dawn before 5:30 AM with a river dip at Assi or Dashashwamedh Ghat, offering Surya Arghya water from brass lotas to align bodily biorhythms with the rising sun.'
    },
    {
      icon: '👁️',
      title: 'WHAT TOURISTS MISS',
      question: 'What lies beyond the cremation ghats?',
      answer: 'The hidden inner sanctum galis of Chaukhamba where centuries-old Sanskrit gurukuls still teach Vedic chanting orally without printed texts, echoing through thousand-year-old stone doorways.'
    },
    {
      icon: '🏺',
      title: 'THE STORY BEHIND THIS CRAFT',
      question: 'How are Banarasi gold zari sarees woven?',
      answer: 'Banarasi silk sarees are woven on subterranean pit looms using pure silver wire electroplated with 24K gold (*Zari*). An intricate bridal masterpiece requires over 5,600 Jacquard punch cards and 6 months of hand weaving.'
    },
    {
      icon: '🍲',
      title: 'WHAT THIS FOOD MEANS',
      question: 'Why is Malaiyo prepared only under winter night dew?',
      answer: 'Malaiyo is an ethereal cloud foam prepared by boiling raw milk, exposing it on open rooftops to winter night dew, and hand-whipping it at 4 AM under moonlight with saffron and cardamom.'
    },
    {
      icon: '🔥',
      title: 'WHO KEEPS THIS TRADITION ALIVE',
      question: 'Who guards the sacred eternal flames?',
      answer: 'The Dom Raja lineage guarding the 3,000-year unbroken cremation fire at Manikarnika Ghat, and Muslim Ansari master weavers maintaining handloom pit-loom traditions.'
    }
  ],
  mumbai: [
    {
      icon: '🏛️',
      title: 'WHY THIS EXISTS',
      question: 'How did seven swampy islands become India’s financial gateway?',
      answer: 'Mumbai was stitched together from seven disconnected mangrove islands through 150 years of land reclamation and basalt rock filling, built to harness a deepwater natural harbour on the Arabian Sea.'
    },
    {
      icon: '🧭',
      title: 'WHY LOCALS DO THIS',
      question: 'Why do Mumbaikars gather on Marine Drive at sunset?',
      answer: 'The *katta* culture: gathering on the sea wall tetrapods at dusk for cooling sea breezes, roasted bhutta (corn), and egalitarian community conversation after high-pressure corporate workdays.'
    },
    {
      icon: '👁️',
      title: 'WHAT TOURISTS MISS',
      question: 'What 800-year-old indigenous settlements still thrive?',
      answer: 'The indigenous Koliwada fishing villages of Worli and Versova that predate colonial Bombay by hundreds of years, preserving ancestral fishing rights and vibrant sea-goddess rituals.'
    },
    {
      icon: '🏺',
      title: 'THE STORY BEHIND THIS CRAFT',
      question: 'What is the legacy of Maharashtra’s leather guilds?',
      answer: 'Authentic Kolhapuri leather chappals are hand-stitched without nails, tanned using natural vegetable barks (babool and bagaru), and softened with castor oil to last decades.'
    },
    {
      icon: '🍲',
      title: 'WHAT THIS FOOD MEANS',
      question: 'Why was the iconic Vada Pav invented?',
      answer: 'Invented in 1966 outside Dadar railway station by Ashok Vaidya, Vada Pav was engineered as a cheap, ultra-portable, energy-packed carbohydrate meal for 12-hour textile mill workers.'
    },
    {
      icon: '🔥',
      title: 'WHO KEEPS THIS TRADITION ALIVE',
      question: 'Who maintains the human logistics miracle?',
      answer: '5,000 Mumbai Dabbawalas transporting 200,000 hot tiffins daily with Six Sigma mathematical accuracy, and generational Koli fisherwomen commanding the morning wholesale docks.'
    }
  ],
  kochi: [
    {
      icon: '🏛️',
      title: 'WHY THIS EXISTS',
      question: 'Why did the 1341 AD flood birth this spice capital?',
      answer: 'A catastrophic flood in 1341 AD silted the ancient Roman spice port of Muziris and created a natural protected ocean estuary at Kochi, quickly making it the epicenter of the global Malabar spice trade.'
    },
    {
      icon: '🧭',
      title: 'WHY LOCALS DO THIS',
      question: 'Why do locals buy fish directly off the cantilever nets?',
      answer: 'Fishermen at Fort Kochi lower their 10-meter teakwood Chinese nets (*Cheenavala*) into the outgoing tide and sell the shimmering catch directly to beach stalls where cooks fry it in banana leaves.'
    },
    {
      icon: '👁️',
      title: 'WHAT TOURISTS MISS',
      question: 'Where is the 16th-century syncretic heritage hidden?',
      answer: 'The quiet lanes of Mattancherry where centuries-old Paradesi Jewish synagogues, Syrian Christian churches, Gujarati spice houses, and Konkani temples live within 500 meters of each other.'
    },
    {
      icon: '🏺',
      title: 'THE STORY BEHIND THIS CRAFT',
      question: 'What is the secret metallurgical formula of Aranmula mirrors?',
      answer: 'Aranmula Kannadi are front-reflecting metal mirrors made from a secret sacred alloy of copper and tin by a single hereditary guild, eliminating the double-refraction of modern glass mirrors.'
    },
    {
      icon: '🍲',
      title: 'WHAT THIS FOOD MEANS',
      question: 'How does a traditional Kerala Sadhya balance health?',
      answer: 'Served on fresh banana leaves, Kerala Sadhya incorporates all 6 fundamental Ayurvedic tastes (*Shad-rasa*) using cold-pressed coconut oil, fresh curry leaves, and Malabar tamarind (*Kudampuli*).'
    },
    {
      icon: '🔥',
      title: 'WHO KEEPS THIS TRADITION ALIVE',
      question: 'Who preserves the sacred 8-hour green-room rituals?',
      answer: 'Kathakali and Koodiyattam master actors who spend 4 silent hours in mineral face-painting before performing ancient epics by temple oil-lamp light throughout the night.'
    }
  ]
};

export class PlaceIdentityController {
  constructor(mountId) {
    this.mount = document.getElementById(mountId);
  }

  render(locationData) {
    if (!this.mount || !locationData) return;

    const theme = LOCATION_THEMES[locationData.id] || LOCATION_THEMES.default;
    const isPartial = locationData.intelligenceTier === 'PARTIAL';
    const cityId = locationData.id;

    const dna = locationData.culturalDNA || {
      knownFor: ['Regional Cultural Heritage', 'Grassroots Craftsmanship', 'Ancient Community Centers'],
      taste: ['Traditional Regional Delicacies', 'Locally Harvested Spices'],
      landscape: ['Historic Geography', 'Subtropical / Semi-arid terrain'],
      festivals: ['Annual Cultural Fairs', 'Regional Community Celebrations']
    };

    // Get untold facts for city or generate dynamic fallback facts
    const facts = CITY_UNTOLD_FACTS[cityId] || [
      {
        icon: '🏛️',
        statBadge: '📜 CENTURIES OLD',
        tag: 'Heritage Archive',
        title: `Historic Roots of ${locationData.name || 'India'}`,
        hook: `A living cultural crossroads preserved across generations.`,
        story: `${locationData.name || 'This destination'} has served as an essential cultural crossroads in <strong>${locationData.state || 'India'}</strong> for centuries, celebrated for its unique regional architectural legacy and communal harmony.`,
        secretTip: `Explore the morning bazaars to discover traditional artisan quarters preserved since the founding era.`
      },
      {
        icon: '🎨',
        statBadge: '✋ 100% HANDCRAFTED',
        tag: 'Living Craft',
        title: 'Grassroots Artisan Legacy',
        hook: 'Centuries of generational guild knowledge passed father to son.',
        story: `Generations of local craftsmen in <strong>${locationData.name || 'the region'}</strong> have preserved indigenous techniques in textiles, hand-carved stone, and regional folk arts that cannot be replicated by modern machines.`,
        secretTip: `Support local heritage by sourcing directly from master weavers and stone-carving cooperatives.`
      },
      {
        icon: '🍲',
        statBadge: '🌶️ ANCIENT FLAVORS',
        tag: 'Gastronomy',
        title: 'Authentic Regional Flavours',
        hook: 'Culinary alchemy tuned to seasonal rhythms and local harvests.',
        story: `Local culinary traditions are deeply attuned to the micro-seasons of <strong>${locationData.state || 'the region'}</strong>, using cold-pressed oils, native whole grains, and distinctive slow-cooked spice blends.`,
        secretTip: `Ask street food stalls for the seasonal specialty of the current month!`
      },
      {
        icon: '🌿',
        statBadge: '🗺️ SACRED GEOGRAPHY',
        tag: 'Natural Flow',
        title: 'Cultural Geography',
        hook: 'How ancient town planning harmonious with nature survived.',
        story: `The spatial geography of <strong>${locationData.name || 'the area'}</strong> balances historic water harvesting stepwells, vibrant shaded community market squares, and sacred gathering corridors.`,
        secretTip: `Observe the orientation of older buildings—they naturally channel wind for passive summer cooling.`
      }
    ];

    // Get 6 Signature Cultural Inquiries
    const inquiries = CITY_CULTURAL_INQUIRIES[cityId] || [
      {
        icon: '🏛️',
        title: 'WHY THIS EXISTS',
        question: `Why was ${locationData.name || 'this city'} established in this region?`,
        answer: `${locationData.name || 'This destination'} was settled as a strategic cultural, mercantile, and spiritual hub in ${locationData.state || 'India'}, shaped by ancestral trade routes and geography.`
      },
      {
        icon: '🧭',
        title: 'WHY LOCALS DO THIS',
        question: `What daily ritual defines life in ${locationData.name || 'this city'}?`,
        answer: `Locals begin the day with traditional dawn prayers, visits to sacred temple/market corners, and multi-generational tea gathering spots.`
      },
      {
        icon: '👁️',
        title: 'WHAT TOURISTS MISS',
        question: `What authentic layer is often overlooked by quick tour buses?`,
        answer: `The quiet interior gullies, historic stepwells, community courtyards, and direct artisan workshops away from monument ticket gates.`
      },
      {
        icon: '🏺',
        title: 'THE STORY BEHIND THIS CRAFT',
        question: `What generational craft is rooted in ${locationData.state || 'this land'}?`,
        answer: `Hereditary guilds have preserved indigenous handloom, wood-carving, terracotta, or metalworking techniques transmitted across centuries.`
      },
      {
        icon: '🍲',
        title: 'WHAT THIS FOOD MEANS',
        question: `How does the local gastronomy reflect the landscape?`,
        answer: `Traditional regional cuisine balances local soil harvests, native grains, seasonal micro-climates, and slow wood-fire cooking methods.`
      },
      {
        icon: '🔥',
        title: 'WHO KEEPS THIS TRADITION ALIVE',
        question: `Who are the living custodians of this cultural legacy?`,
        answer: `Generational artisan families, hereditary community elders, traditional cooks, and folk musicians who sustain these living arts.`
      }
    ];

    const photoBgStyle = theme.photoUrl 
      ? `style="background: linear-gradient(135deg, ${theme.colors.bg}ee 0%, ${theme.colors.bgSurface}fa 100%), url('${theme.photoUrl}') center 25% / cover no-repeat; border-color: ${theme.colors.accentBorder};"` 
      : '';

    const factsStripBgStyle = theme.photoUrl 
      ? `style="background: linear-gradient(135deg, rgba(14, 20, 34, 0.90) 0%, ${theme.colors.bgElevated}f6 100%), url('${theme.photoUrl}') center 60% / cover no-repeat; border-color: ${theme.colors.accentBorder};"` 
      : '';

    this.mount.innerHTML = `
      <div class="place-identity-panel" ${photoBgStyle}>
        <div class="place-identity-header">
          <div class="place-title-wrap">
            <span class="place-region-badge">
              ${locationData.state || 'India'} • ${locationData.culturalRegion || locationData.region || 'Heritage Corridor'}
            </span>
            <div class="place-name">
              <span>${locationData.name || 'Destination'}</span>
              ${isPartial 
                ? '<span class="badge badge-elevated">PARTIAL LOCATION INTELLIGENCE' + renderTooltip('capacity') + '</span>'
                : '<span class="badge badge-optimal">FULL INTELLIGENCE ACTIVE' + renderTooltip('demand') + '</span>'
              }
            </div>
            <div class="place-atmosphere-tag">${locationData.tagline || theme.atmosphere}</div>
          </div>
        </div>

        <!-- Four Cultural Pillars Grid -->
        <div class="cultural-dna-grid">
          <!-- 1. Known For -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🏛️</span> KNOWN FOR
            </div>
            <ul class="dna-list">
              ${(dna.knownFor || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>

          <!-- 2. Taste -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🍲</span> TASTE
            </div>
            <ul class="dna-list">
              ${(dna.taste || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>

          <!-- 3. Landscape -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🌄</span> LANDSCAPE & SITES
            </div>
            <ul class="dna-list">
              ${(dna.landscape || dna.architecture || []).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>

          <!-- 4. Festivals -->
          <div class="dna-card">
            <div class="dna-label">
              <span>🪔</span> RHYTHM & FESTIVALS
            </div>
            <ul class="dna-list">
              ${(dna.festivals || [dna.localRhythm] || []).filter(Boolean).map(item => `<li>${item}</li>`).join('')}
            </ul>
          </div>
        </div>

        <!-- ============================================================
             6 SIGNATURE CULTURAL INQUIRIES SECTION
             ============================================================ -->
        <div class="cultural-inquiries-section">
          <div class="cultural-inquiries-header">
            <span class="cultural-facts-badge">🧭 SIGNATURE CULTURAL INQUIRIES</span>
            <h3 class="inquiries-section-title">DON'T JUST VISIT ${locationData.name ? locationData.name.toUpperCase() : 'INDIA'}. UNDERSTAND IT.</h3>
            <p class="inquiries-section-sub">
              6 critical cultural lenses unlocking why this destination exists, how locals live, what tourists miss, and who keeps heritage alive.
            </p>
          </div>

          <div class="cultural-inquiries-grid">
            ${inquiries.map(inq => `
              <div class="cultural-inquiry-card">
                <div class="inquiry-badge-row">
                  <span class="inquiry-icon">${inq.icon}</span>
                  <span class="inquiry-title-tag">${inq.title}</span>
                </div>
                <div class="inquiry-question">${inq.question}</div>
                <div class="inquiry-answer">${inq.answer}</div>
              </div>
            `).join('')}
          </div>
        </div>

        <!-- ============================================================
             LIVING CULTURAL DNA & UNTOLD FACTS FOREGROUND SECTION
             ============================================================ -->
        <div class="cultural-dna-container">
          <div class="cultural-facts-strip" ${factsStripBgStyle}>
            <div class="cultural-facts-header">
              <div>
                <div class="cultural-facts-badge">✨ LIVING CULTURAL DNA & UNTOLD FACTS</div>
                <h3 class="cultural-facts-title">${locationData.name || 'City'}: Untold Stories & Architectural Secrets</h3>
                <p class="cultural-facts-subtitle">
                  Beyond monument tickets: how physics, generational guilds, royal decrees, and sacred traditions shaped this historic Indian capital.
                </p>
              </div>
            </div>

            <!-- Dynamic Fact Cards Grid with Creative Stories & Tips -->
            <div class="cultural-facts-grid">
              ${facts.map(f => `
                <div class="cultural-fact-card">
                  <div class="fact-card-main">
                    <div class="fact-card-header">
                      <div class="fact-card-top">
                        <span class="fact-icon">${f.icon}</span>
                        <span class="fact-tag">${f.tag}</span>
                      </div>
                      ${f.statBadge ? `<span class="fact-stat-badge">${f.statBadge}</span>` : ''}
                    </div>
                    <div class="fact-title">${f.title}</div>
                    ${f.hook ? `<div class="fact-hook">${f.hook}</div>` : ''}
                    <div class="fact-desc">${f.story || f.fact}</div>
                  </div>
                  ${f.secretTip ? `
                    <div class="fact-secret-box">
                      <span class="secret-box-icon">💡</span>
                      <div class="secret-box-text"><strong>Insider Secret:</strong> ${f.secretTip}</div>
                    </div>
                  ` : ''}
                </div>
              `).join('')}
            </div>
          </div>
        </div>

      </div>
    `;
  }
}

